/**
 * 懒加载轻扫的调度策略（纯函数，不碰 DOM）。
 *
 * 背景（v1.9.92）：旧实现全页固定滚 5 档（`scrollTop = total * i / 5`）。
 * 页面高 5000px、视口 900px 时，5 档的视口区间是 [1000,1900] [2000,2900] [3000,3900] …
 * —— 档与档之间**存在覆盖空洞**，落在空洞里的元素**从未进入过视口**，
 * IntersectionObserver 一次都不触发，懒加载图永远不加载。
 * 实测症状：1688 变体轮播区空白、商品详情区白屏（超哥截图）。
 *
 * 修法：按「视口高度 × (1-重叠)」算步长，保证相邻两档的视口区间**连续覆盖**整页。
 */

/**
 * 计算轻扫的档数与步长。
 * @param {{scrollHeight?:number, viewportHeight?:number, overlap?:number, maxSteps?:number, minSteps?:number}} input
 * @returns {{steps:number, stride:number, continuous:boolean, note:string}}
 */
export function planSweepSteps({
  scrollHeight = 0,
  viewportHeight = 0,
  overlap = 0.6,
  maxSteps = 30,
  minSteps = 3,
} = {}) {
  const vh = Math.max(1, Math.floor(Number(viewportHeight) || 0));
  const total = Math.max(0, Math.floor(Number(scrollHeight) || 0));
  const ratio = Math.min(0.9, Math.max(0.1, Number(overlap) || 0.6));
  const cap = Math.max(1, Math.floor(Number(maxSteps) || 30));

  // 一屏装得下：不用滚，轻轻扫几下让 IntersectionObserver 初始化即可
  if (total <= vh) {
    return {
      steps: Math.max(1, Math.min(cap, Math.floor(Number(minSteps) || 3))),
      stride: Math.max(1, Math.round(total / 3) || 1),
      continuous: true,
      note: "页面一屏可容纳，轻扫即可",
    };
  }

  // 每步走 (1 - overlap) 屏 → 相邻视口必然重叠，无覆盖空洞
  const stride = Math.max(1, Math.round(vh * (1 - ratio)));
  const needed = Math.ceil(total / stride);
  const steps = Math.max(1, Math.min(cap, needed));
  const continuous = steps >= needed;
  return {
    steps,
    stride,
    continuous,
    note: continuous
      ? `整页连续覆盖：${steps} 档 × 每档 ${stride}px（重叠 ${Math.round(ratio * 100)}%）`
      : `档数被上限截断（需 ${needed} 档 > 上限 ${cap} 档），长页面可能仍有未覆盖区`,
  };
}

/**
 * 时间预算：随页面高度和档数放大，不再用固定 3000ms 把长页面腰斩。
 * 旧版固定 3s：大页面滚到一半就被 break 掉，详情区压根没扫到。
 */
export function sweepBudgetMs({ steps = 5, perStepMs = 110, settleMs = 260 } = {}) {
  const n = Math.max(1, Math.floor(Number(steps) || 5));
  const per = Math.max(0, Number(perStepMs) || 0) + Math.max(0, Number(settleMs) || 0);
  return Math.min(12000, Math.max(1500, Math.round(1200 + n * per * 1.6)));
}

/**
 * 是否需要补扫一轮。
 * 判据：这一趟扫完，可加载图数量没增长（或目标容器仍是空的）→ 页面多半还在渲染，值得再扫一趟。
 * @param {{before:number, after:number, minYield?:number}} input
 */
export function shouldRetrySweep({ before = 0, after = 0, minYield = 1 } = {}) {
  return after - before < Math.max(1, Math.floor(Number(minYield) || 1));
}

/**
 * 通用重试 + 退避（指数退避，封顶）。异常不外抛——返回 { ok, value, error, attempts }，
 * 让上层决定「跳过这一项」还是「整体中止」，实现「异常不中断整体任务」。
 */
export async function withRetry(fn, { retries = 2, baseDelayMs = 120, maxDelayMs = 800, onRetry } = {}) {
  const limit = Math.max(0, Math.floor(Number(retries) || 0));
  let attempt = 0;
  let lastError = null;
  while (attempt <= limit) {
    try {
      // eslint-disable-next-line no-await-in-loop
      const value = await fn(attempt);
      return { ok: true, value, error: null, attempts: attempt + 1 };
    } catch (error) {
      lastError = error;
      attempt += 1;
      if (attempt > limit) break;
      const delay = Math.min(maxDelayMs, baseDelayMs * 2 ** (attempt - 1));
      if (typeof onRetry === "function") {
        try { onRetry({ attempt, error, delay }); } catch { /* 回调自身的错不能影响重试 */ }
      }
      // eslint-disable-next-line no-await-in-loop
      await new Promise((resolve) => setTimeout(resolve, delay));
    }
  }
  return { ok: false, value: null, error: lastError, attempts: attempt };
}

/** 统计「可加载图」数量：有 src/data-src/背景图 之一的 <img>。用于轻扫前后的收益判定。 */
export function countLoadableImages(root = document) {
  const scope = root && root.querySelectorAll ? root : document;
  const nodes = scope.querySelectorAll("img, [style*='background-image']");
  let n = 0;
  for (const node of nodes) {
    const src = node.getAttribute?.("src")
      || node.getAttribute?.("data-src")
      || node.getAttribute?.("data-lazy-src")
      || node.getAttribute?.("data-ks-lazyload")
      || node.getAttribute?.("data-lazyload")
      || "";
    const bg = node.getAttribute?.("style") || "";
    if (src && src.trim() && !/^data:image\/(gif|svg)/i.test(src)) n += 1;
    else if (/background-image\s*:\s*url\(/i.test(bg)) n += 1;
  }
  return n;
}

/**
 * content script 不能 import ESM（manifest 原生加载多个 JS，无构建步骤）。
 * 这里同时挂全局，供 adapter-base.js 转放进 registry.utils；
 * 自测跑在 Node 里走 ESM 导出，两条路互不影响。
 */
if (typeof globalThis !== "undefined" && !globalThis.__OZON_LAZY_SWEEP__) {
  globalThis.__OZON_LAZY_SWEEP__ = {
    planSweepSteps,
    sweepBudgetMs,
    shouldRetrySweep,
    withRetry,
    countLoadableImages,
  };
}