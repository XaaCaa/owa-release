/**
 * 1688 商品详情采集适配器。
 * 只读公开 DOM / meta / JSON-LD / 内联数据；读不到的字段留空并写入诊断，不伪造。
 */
(function (global) {
  "use strict";

  const registry = global.__OZON_ADAPTERS__;
  if (!registry) return;
  const U = registry.utils;
  const { cleanText, parseNumber, normalizeImageUrl, dedupe, all, text, sleep } = U;

  const ORIGIN = "https:";

  /* 店铺/公司名不是商品标题：新版 1688 的店招 / 公司卡片会被 h1 之类选择器命中，
   * 采出「XX有限公司」当标题，草稿名跟着全错（超哥 2026-09-21 截图案例）。先判掉再选。 */
  const COMPANY_NAME_RE = /(有限公司|有限责任公司|股份有限公司|集团有限公司|经营部|商行|专卖店|旗舰店)$/;
  function looksLikeCompanyName(value) {
    const v = String(value || "").trim();
    if (!v || v.length > 40) return false;
    if (COMPANY_NAME_RE.test(v)) return true;
    // 「威海丹泰体育用品有限公司」这类：带主体词（有限/集团）且以 公司/厂/店 收尾
    if (/(有限|集团)/.test(v) && /(公司|厂|店)$/.test(v)) return true;
    // 「义乌市XX电子商务厂」这类：以城市名开头 + 厂/公司/店 收尾的短主体名
    return v.length <= 20 && !/\d/.test(v) && /^(?:[\u4e00-\u9fa5]{1,4}市)?.{1,14}(?:厂|公司|店)$/.test(v);
  }

  const TITLE_SELECTORS = [
    ".d-title",
    "h1.d-title",
    '[data-tag="title"]',
    ".title-text",
    ".offer-title",
    "#mod-detail-title h1",
    "h1",
  ];

  function pickTitle(cache) {
    // v1.9.69 关键修复：**权威标题优先**。
    // og:title / document.title 一定属于「当前页面这件商品」，是唯一可信的锚点。
    // 旧顺序是 [og:title, ...选择器命中, document.title]：当页面没有 og:title 时，
    // 排在 document.title 前面的通用选择器（尤其是那个裸 "h1"）会命中**推荐位里另一件
    // 商品**的标题 —— 于是「采 A 得到 B 的标题」，用户看到的就是「没按我采的产品来」。
    const authoritative = U.authoritativeTitle();
    if (authoritative) return authoritative;

    // 权威标题拿不到时才退回 DOM 选择器，而且命中必须落在**商品主体区**内，
    // 否则宁可留空也不把推荐位里别的商品的名字塞进来。
    const scope = cache && cache.scope ? cache.scope() : null;
    const inScope = (node) => !scope
      || scope === document.body
      || scope === document.documentElement
      || scope === node
      || Boolean(scope.contains && scope.contains(node));
    const selectorHits = [];
    for (const selector of TITLE_SELECTORS) {
      for (const node of all(selector)) {
        if (!inScope(node)) continue;
        const value = cleanText(node.textContent);
        if (value && value.length > 3) { selectorHits.push(value); break; }
      }
    }
    const ordered = selectorHits
      .map((value) => U.sanitizeTitle(value) || value)
      .filter(Boolean);
    const good = ordered.find((value) => value.length > 3 && !looksLikeCompanyName(value));
    if (good) return good;
    // v1.9.63：候选全是「公司名 / 店铺名」时不要再硬塞一个给下游。
    // 旧写法兜底 return ordered[0]，于是店铺名被当成商品标题发给 AI，
    // AI 只会回「原始数据中只标注了官方名称」这种放弃式文案，用户还以为是插件坏了。
    // 宁可留空 + 写一条诊断，让用户去补标题。
    return "";
  }

  // 1688 新版详情页的价格节点（类名经过混淆，写死的老选择器经常取不到，这里多备几套）
  const PRICE_SELECTORS = [
    ".price-original-sku .value",
    "#mod-detail-price .value",
    ".price-now .value",
    ".price .value",
    ".offer-price .value",
    ".price-original",
    '[data-tag="price"]',
    '[class*="priceText"]',
    '[class*="price-text"]',
    '[class*="mainPrice"]',
    '[class*="offerPrice"]',
    '[class*="salePrice"]',
    '[class*="priceNum"]',
    '[class*="price-num"]',
    '[class*="promoPrice"]',
    '[data-testid*="price"]',
    ".main-price",
    ".sale-price",
    "#mod-price",
  ];

  function pickPrice(cache) {
    // 兜底顺序：JSON-LD → meta → 已知选择器 → 类名带 price 的元素 → 全页第一个 ¥ 数字
    const picked = U.pickPagePrice({ cache, selectors: PRICE_SELECTORS });
    if (picked.min > 0) return picked;
    return { min: 0, max: 0, raw: "" };
  }

  /* ------------------------------------------------------------------
   * 图片采集：主图 / 图集缩略图 / 详情长图 三组分头抓，互不污染。
   * 老实现是把十来个 gallery/thumb 选择器一股脑塞给 collectImages，
   * 容器一个没命中就退回全页扫描，把推荐位、店铺卡片、图标全收进来，
   * 于是「主图」经常是张不相关的图。这里按层抓 + 排除推荐位 + 按尺寸挑主图。
   * ------------------------------------------------------------------ */

  // 推荐位 / 猜你喜欢 / 店铺卡片里的图不是本商品图，必须排除。
  // v1.9.62 补评价区：1688 详情页的「买家评价」模块里也是一排 <img>，
  // 缩略图选择器（[class*=thumb] / [class*=thumbList]）会连它们一起命中，
  // 于是买家秀混进图集、甚至被尺寸规则判成产品图抢走主图位。
  const IMAGE_EXCLUDE_ZONES = [
    "[class*=recommend]",
    "[class*=recommendation]",
    "[class*=similar]",
    "[class*=related]",
    "[class*=guess]",
    "[class*=mayLike]",
    "[class*=maylike]",
    "[class*=footLike]",
    "[class*=shopCard]",
    "[class*=shop-card]",
    "[class*=supplierCard]",
    "[class*=companyCard]",
    "[class*=review]",
    "[class*=Review]",
    "[class*=comment]",
    "[class*=Comment]",
    "[class*=评价]",
    "[class*=appraise]",
    "[class*=rate-]",
    ".mod-recommend",
    "#mod-recommend",
  ];

  // 主图：图集里当前展示的大图（1688 新旧版类名不同，多备几套）
  const GALLERY_MAIN_SELECTORS = [
    ".detail-gallery .main-image img",
    ".detail-gallery [class*=mainImg] img",
    ".detail-gallery [class*=main-img] img",
    "#dt-tab .main-img img",
    "#dt-tab [class*=mainImg] img",
    ".mod-detail-gallery .main-img img",
    ".od-gallery [class*=mainImage] img",
    "[class*=gallery] [class*=mainImg] img",
    "[class*=gallery] [class*=main-image] img",
    "[class*=mainImage] img",
    "[class*=main-image] img",
    "[class*=bigImage] img",
    "[class*=big-image] img",
    // v1.9.67 新版详情页（od-pc）主图容器换成了 turn / media / pic 系类名
    ".detail-gallery-turn-item img",
    ".detail-gallery-turn img",
    "[class*=galleryTurn] img",
    "[class*=gallery-turn] img",
    "[class*=turnItem] img",
    "[class*=turn-item] img",
    "[class*=mainPic] img",
    "[class*=main-pic] img",
    "[class*=mainPhoto] img",
    "[class*=bigPic] img",
    "[class*=picView] img",
    "[class*=mediaView] img",
  ];

  // 缩略图列表：主图下面那排小图，代表完整图集
  const GALLERY_THUMB_SELECTORS = [
    ".detail-gallery [class*=thumbList] img",
    ".detail-gallery [class*=thumb-list] img",
    ".detail-gallery .thumb-list img",
    "#dt-tab [class*=thumbList] img",
    "#dt-tab .thumb-list img",
    ".mod-detail-gallery [class*=thumb] img",
    ".od-gallery [class*=thumb] img",
    "[class*=gallery] [class*=thumbList] img",
    "[class*=thumbList] img",
    "[class*=thumb-list] img",
    // v1.9.67 新版详情页左侧竖排缩略图栏
    ".detail-gallery-thumb img",
    ".detail-gallery-turn-thumb img",
    "[class*=galleryThumb] img",
    "[class*=gallery-thumb] img",
    "[class*=turnThumb] img",
    "[class*=turn-thumb] img",
    "[class*=thumbItem] img",
    "[class*=thumb-item] img",
    "[class*=smallPic] img",
    "[class*=picList] img",
    "[class*=pic-list] img",
    "[class*=tabTrigger] img",
    "[class*=tab-trigger] img",
  ];

  // 兜底：主图/缩略图选择器都没命中（1688 改版）时才用的整块图集容器
  const GALLERY_FALLBACK_SELECTORS = [
    ".detail-gallery",
    "#dt-tab",
    ".image-gallery",
    ".mod-detail-gallery",
    ".od-gallery",
    "[class*=gallery]",
    "[class*=thumb]",
    // v1.9.67 类名整批换掉时的兜底容器
    "[class*=galleryTurn]",
    "[class*=gallery-turn]",
    "[class*=turnItem]",
    "[class*=turn-item]",
    "[class*=mainPic]",
    "[class*=main-pic]",
    "[class*=picList]",
    "[class*=pic-list]",
    "[class*=mediaView]",
  ];

  // v1.9.67：1688 商品图（含图集缩略图）全部挂在阿里图床的 /img/ibank/ 路径下。
  // 这是比类名、比尺寸都可靠的「这是商品图」信号，用来做选择器全部落空时的最后兜底。
  const ALI_GALLERY_IMAGE_RE = /^https?:\/\/[^/]*(?:alicdn|alibaba|1688)\.com\/img\/ibank\//i;

  // 商品详情长图所在容器
  const DETAIL_IMAGE_SELECTORS = [
    "#mod-detail-description",
    "#desc-lazyload-container",
    ".desc-lazyload-container",
    ".detail-description",
    ".description-content",
    "#J_DivItemDesc",
    ".detail-content",
    "[class*=descContent]",
    "[class*=desc-content]",
    "[class*=detailDescription]",
    "[class*=detail-description]",
    "[class*=richText]",
    "[class*=rich-text]",
    "[class*=descV8]",
  ];

  const DETAIL_IMAGE_LIMIT = 60;

  /** 图片面积：挑主图时用它排序 */
  function imageAreaScore(meta) {
    const width = Number(meta && meta.width) || 0;
    const height = Number(meta && meta.height) || 0;
    return width * height;
  }

  /**
   * 挑主图：1688 主图通常是图集里尺寸最大且接近正方形的那张（800x800 / 1000x1000），
   * 详情长图那种细长条会被降权。没有任何尺寸信息时退回第一张（保持卖家排序）。
   * v1.9.60：渲染尺寸（natural=false，懒加载没量到真实文件尺寸）打 25% 折，
   * 避免「页面上被拉大的 60px 缩略图」压过真正量到 1000x1000 的主图。
   */
  function pickMainImage(images = [], imageMeta = {}) {
    const list = Array.isArray(images) ? images : [];
    if (!list.length) return "";
    let best = list[0];
    let bestScore = -1;
    let squarePicked = "";
    let squareArea = -1;
    for (const url of list) {
      const meta = imageMeta[url] || {};
      const width = Number(meta.width) || 0;
      const height = Number(meta.height) || 0;
      if (!width || !height) continue;
      const trusted = meta.natural === false ? 0.25 : 1;
      const area = imageAreaScore(meta);
      const squareness = Math.min(width, height) / Math.max(width, height);
      // 正方形优先：1688 主图是 800x800 / 1000x1000，详情长图那种细长条要降权
      if (squareness >= 0.7 && trusted === 1 && area > squareArea) {
        squareArea = area;
        squarePicked = url;
      }
      const score = area * (squareness >= 0.7 ? 1 : squareness) * trusted;
      if (score > bestScore) {
        bestScore = score;
        best = url;
      }
    }
    return squarePicked || best;
  }

  function jsonLdImages(cache) {
    const out = [];
    for (const block of cache.jsonLd()) {
      if (!block.image) continue;
      const list = Array.isArray(block.image) ? block.image : [block.image];
      for (const item of list) out.push(typeof item === "string" ? item : item.url);
    }
    return out;
  }

  const IMAGE_PICK_BASE = { origin: ORIGIN, excludeZones: IMAGE_EXCLUDE_ZONES, noPageFallback: true };

  /** 合并多个来源的尺寸元数据：同一 URL 取各来源里的最大尺寸与 natural 标记 */
  function mergeImageMeta(...metas) {
    const out = {};
    for (const meta of metas) {
      for (const [url, size] of Object.entries(meta || {})) {
        const known = out[url];
        if (!known) {
          out[url] = { width: Number(size.width) || 0, height: Number(size.height) || 0, natural: Boolean(size.natural) };
          continue;
        }
        known.width = Math.max(known.width, Number(size.width) || 0);
        known.height = Math.max(known.height, Number(size.height) || 0);
        known.natural = known.natural || Boolean(size.natural);
      }
    }
    return out;
  }

  // 图集最多收多少张：1688 图集通常 5~15 张，多出来的基本是漏网的推荐位/评价图
  const GALLERY_IMAGE_LIMIT = 30;

  /** 主图 + 图集：先大图容器，再缩略图列表，都空了才用整块图集兜底 */
  function pickImages(cache) {
    const fromJsonLd = jsonLdImages(cache);
    // v1.9.62 extraFirst：JSON-LD 的图最干净（不含图标、不含推荐位），排到 DOM 图前面，
    // 这样「其余图片」的顺序也贴近结构化数据里的卖家排序，而不是页面 DOM 的偶然顺序。
    const main = U.collectImages({
      ...IMAGE_PICK_BASE,
      containers: GALLERY_MAIN_SELECTORS,
      extra: fromJsonLd,
      extraFirst: true,
      limit: GALLERY_IMAGE_LIMIT,
    });
    const thumbs = U.collectImages({ ...IMAGE_PICK_BASE, containers: GALLERY_THUMB_SELECTORS, allowSmall: true });
    let fallback = { images: [], imageMeta: {} };
    if (!main.images.length && !thumbs.images.length) {
      fallback = U.collectImages({
        origin: ORIGIN,
        excludeZones: IMAGE_EXCLUDE_ZONES,
        containers: GALLERY_FALLBACK_SELECTORS,
        // v1.9.69：兜底层会扫到页面别处，必须限定在商品主体区内，
        // 否则「猜你喜欢」里别的商品的主图会被收进来
        scopeRoot: cache.scope(),
        // v1.9.67 关键修复：图集兜底必须允许小图。新版 1688 详情页的图集只有 60×60 的
        // 缩略图 <img>（主图位是一个 <video>），不带 allowSmall 就会命中「最长边 < 120px
        // 当图标丢掉」的规则，整批缩略图被误杀 —— 用户看到的就是「未识别到产品图」。
        // 缩略图 URL 经 normalizeImageUrl 已经升到原图（去掉 _60x60q90.jpg 后缀），
        // 所以按缩略图收进来，拿到的仍然是高清原图。
        allowSmall: true,
      });
    }
    // 最后一道网：按阿里图床路径 + 文档顺序捞。类名整批换掉也不怕，且不做尺寸过滤。
    let hostPicked = { images: [], imageMeta: {} };
    if (!main.images.length && !thumbs.images.length && !fallback.images.length) {
      hostPicked = U.collectImagesByHostPattern({
        pattern: ALI_GALLERY_IMAGE_RE,
        stopSelector: DETAIL_IMAGE_SELECTORS.join(", "),
        excludeZones: IMAGE_EXCLUDE_ZONES,
        origin: ORIGIN,
        limit: GALLERY_IMAGE_LIMIT,
        scopeRoot: cache.scope(),
      });
    }

    // 旧写法是 Object.assign(fallback, thumbs, main)——同名 URL 直接被缩略图/主图的
    // 小尺寸覆盖掉其它来源量到的大尺寸，这里改成逐 URL 取最大值
    const imageMeta = mergeImageMeta(fallback.imageMeta, thumbs.imageMeta, main.imageMeta, hostPicked.imageMeta);
    const ordered = dedupe([].concat(main.images, thumbs.images, fallback.images, hostPicked.images)).slice(0, GALLERY_IMAGE_LIMIT);
    for (const url of ordered) if (!imageMeta[url]) imageMeta[url] = { width: 0, height: 0 };
    // 主图排到第一位，其余保持采集顺序
    const mainImage = pickMainImage(ordered, imageMeta);
    const images = mainImage ? [mainImage].concat(ordered.filter((url) => url !== mainImage)) : ordered;
    return {
      images,
      imageMeta,
      mainImage,
      // 每层各捞到多少张：采集结果的备注里会写出来，页面再改版时一眼能看出是哪一层失灵
      layers: {
        main: main.images.length,
        thumbs: thumbs.images.length,
        fallback: fallback.images.length,
        host: hostPicked.images.length,
      },
    };
  }

  /**
   * 商品详情长图：详情描述区里的图，单独一组，用户确认后才并入图片集。
   * exclude 传图集已有的地址——详情区第一张往往就是主图封面，重复的没必要再勾一遍。
   */
  function pickDetailImages(exclude = []) {
    const skip = new Set((exclude || []).map((url) => normalizeImageUrl(url, ORIGIN)).filter(Boolean));
    const picked = U.collectImages({
      origin: ORIGIN,
      containers: DETAIL_IMAGE_SELECTORS,
      allowSmall: true,        // 详情长图基本都是懒加载，没有 naturalWidth
      includeBackground: true, // 详情区常把长图铺在 background-image 上
      excludeZones: IMAGE_EXCLUDE_ZONES,
      noPageFallback: true,
      limit: DETAIL_IMAGE_LIMIT,
    });
    let images = picked.images;
    // v1.9.67：详情区的类名同样经常整批换掉。一张都没收着时，按阿里图床路径 +
    // 「落在详情描述容器内」再捞一次（图集在外面、详情长图在里面，用位置就能分开）。
    if (!images.length) {
      images = U.collectImagesByHostPattern({
        pattern: ALI_GALLERY_IMAGE_RE,
        insideSelector: DETAIL_IMAGE_SELECTORS.join(", "),
        excludeZones: IMAGE_EXCLUDE_ZONES,
        origin: ORIGIN,
        limit: DETAIL_IMAGE_LIMIT,
      }).images;
    }
    return images.filter((url) => !skip.has(url));
  }

  /**
   * 规格色卡 / SKU 缩略图：优先取 img 的懒加载属性，取不到再看选项节点的背景图
   * （1688 新版颜色色卡常把图放在 background-image 里，老实现只读 data-src + src 基本抓空）。
   */
  function nodeImageUrl(node, img) {
    const fromImg = img ? U.imageSource(img) : "";
    if (fromImg) return fromImg;
    const style = node && node.getAttribute ? node.getAttribute("style") : "";
    if (style && /url\(/i.test(style)) {
      const match = /url\((['"]?)([^'")]+)\1\)/i.exec(style);
      if (match) return normalizeImageUrl(match[2], ORIGIN);
    }
    return "";
  }

  /**
   * 详情长图懒加载「轻扫」：不滚到那个位置，<img> 的地址根本不会写进 DOM。
   * 记住当前滚动位置 → 逐段下滚并派发 scroll → 回到原位。失败也不抛错。
   * （与 adapter-taobao.js 的同名函数保持一致；顺手把 loading="lazy" 的图强制成 eager，
   *   滚过去一次就让浏览器真开始加载，采集完不还原——面板拿到的地址可用性更高。）
   */
  async function sweepForLazyImages(steps = 5, stepDelay = 110) {
    const scroller = document.scrollingElement || document.documentElement;
    if (!scroller) return;
    const startY = scroller.scrollTop;
    const total = Math.max(scroller.scrollHeight - (window.innerHeight || 0), 0);
    const startedAt = Date.now();
    // v1.9.67：大页面上页面自己的 scroll 处理器可能非常贵（实测这一步能跑到 5s+，
    // 占掉整次采集 99% 的时间）。给轻扫一个总预算，超了就停——已经滚过的部分该触发的懒加载也触发了。
    const budget = 3000;
    try {
      for (let index = 1; index <= steps; index += 1) {
        if (Date.now() - startedAt > budget) break;
        scroller.scrollTop = Math.round((total * index) / steps);
        window.dispatchEvent(new Event("scroll"));
        document.dispatchEvent(new Event("scroll"));
        // eslint-disable-next-line no-await-in-loop
        await U.sleep(stepDelay);
      }
      for (const img of all("img[loading='lazy']")) {
        if (img.getAttribute("loading") === "lazy") img.setAttribute("loading", "eager");
      }
    } catch {
      /* 滚动失败就当没扫过，后面的采集照旧 */
    } finally {
      scroller.scrollTop = startY;
      window.dispatchEvent(new Event("scroll"));
    }
  }

  function pickVideos() {
    const urls = [];
    for (const node of all("video[src], source[src]")) {
      const value = node.getAttribute("src");
      if (value && /^https?:/i.test(value)) urls.push(value);
    }
    return dedupe(urls);
  }

  function pickSales(cache) {
    const selectors = [
      ".total-sales",
      ".sale-num",
      '[data-tag="saleCount"]',
      ".offer-sale-count",
      ".sale-count",
      // v1.9.68：新版类名多为 saleCount / soldCount / tradeCount / monthSale 这类驼峰写法
      "[class*=saleCount]", "[class*=sale-count]", "[class*=soldCount]", "[class*=sold-count]",
      "[class*=tradeCount]", "[class*=trade-count]", "[class*=monthSale]", "[class*=month-sale]",
      "[class*=sellCount]", "[class*=totalSold]", "[class*=saleNum]",
    ];
    for (const selector of selectors) {
      const value = text(selector);
      if (value) return { text: value, number: parseNumber(value) };
    }
    // v1.9.69：扫「商品主体区」而不是全页 —— 推荐位里另一件商品的「成交 12 件」
    // 会被当成当前商品的销量（旧实现就是扫全页的第一个命中）。
    const bodyHit = cache.scopeText().match(/(?:成交|销量|30天成交)[^\d]{0,10}([\d.,]+\s*[件笔单]?)/);
    if (bodyHit) return { text: bodyHit[0], number: parseNumber(bodyHit[1]) };
    return { text: "", number: 0 };
  }

  function pickStock(cache) {
    // v1.9.69：同上，库存也必须来自商品主体区
    const hit = cache.scopeText().match(/(?:库存|可售)[^\d]{0,10}([\d.,]+)/);
    return hit ? parseNumber(hit[1]) : 0;
  }

  function pickShop() {
    const nameSelectors = [
      ".shop-name",
      ".company-name",
      ".shop-card .name",
      "#mod-detail-shop .name",
      ".supplier-name",
      ".slogo-shopname strong",
      // v1.9.68：新版 1688 类名带 shopName / companyName / supplierName 等驼峰写法，
      // 老实现只备了连字符版本，于是「店铺」整项落空（截图里就是「未识别：店铺」）
      "[class*=shopName]", "[class*=shop-name]", "[class*=shopTitle]", "[class*=shop-title]",
      "[class*=companyName]", "[class*=company-name]",
      "[class*=supplierName]", "[class*=supplier-name]",
      "[class*=sellerName]", "[class*=seller-name]", "[class*=factoryName]",
    ];
    for (const selector of nameSelectors) {
      const value = text(selector);
      if (value && value.length <= 40) return value;
    }
    // 结构兜底 1：详情页一定有「进店 / 店铺」链接，链接文字就是店铺名
    const link = document.querySelector(
      'a[href*="winport"], a[href*=".1688.com/page/index"], a[href*="shop.1688.com"], a[href*="/shop/"]',
    );
    const linkText = link ? cleanText(link.textContent) : "";
    if (linkText && linkText.length <= 30 && !/^(进店|进入店铺|进入|查看|店铺|首页|联系|收藏|关注|全部商品)$/.test(linkText)) {
      return linkText;
    }
    // 结构兜底 2：在「店铺 / 公司」语义的容器里找像公司名或店铺名的短文本
    for (const node of all("[class*=shop], [class*=company], [class*=supplier], [class*=seller], [class*=factory]").slice(0, 40)) {
      const value = cleanText(node.textContent);
      if (!value || value.length > 40) continue;
      const head = value.split(/\s+/)[0];
      if (!head || head.length > 20) continue;
      if (looksLikeCompanyName(head) || U.looksLikeShopName(head)) return head;
    }
    return "";
  }

  function pickShopUrl() {
    const node = document.querySelector('.shop-name a, .company-name a, a.shop-url, a[href*="shop"]');
    return node ? node.href : "";
  }

  // 1688 的 SKU 规格：老版在 .obj-sku 下，新版（react/od- 前缀）类名带 skuProp / sku-prop
  const SPEC_GROUP_SELECTORS = [
    ".obj-sku",
    "#mod-detail-sku .obj",
    ".sku-item",
    "[data-sku-name]",
    "[class*=skuProp]",
    "[class*=sku-prop]",
    "[class*=skuWrapper]",
    "[class*=sku-wrapper]",
    "[class*=skuItem]",
    "[class*=sku-item]",
    ".od-sku .prop",
    ".prop-item",
    ".offer-prop",
  ];

  const SPEC_NAME_SELECTORS = ".obj-name, .name, .sku-title, .label, [class*=propName], [class*=prop-name], [class*=propTitle], [class*=prop-title]";

  // v1.9.75：单维度规格值上限。原来写死 40，多尺码/多颜色的商品会被截断
  //（用户看到「页面上还有很多规格，插件只采到这些」）。
  const MAX_VALUES_PER_OPTION = 120;

  function mergeOptions(groups) {
    const byName = new Map();
    for (const group of groups) {
      const name = cleanText(group.name);
      if (!name) continue;
      const existing = byName.get(name);
      if (existing) existing.values = dedupe(existing.values.concat(group.values)).slice(0, MAX_VALUES_PER_OPTION);
      else byName.set(name, { name, values: dedupe(group.values).slice(0, MAX_VALUES_PER_OPTION) });
    }
    return Array.from(byName.values()).filter((option) => option.values.length);
  }

  // 规格值里混进来的价格/库存/运费片段不是规格（如「¥78」「库存42123箱」「运费¥11起」）
  const SPEC_VALUE_NOISE_PATTERN = /[¥￥]|库存|可售|起批|快递|运费|包邮|月销|已售|^(?:\d+(?:\.\d+)?)(?:件|个|箱|套|只|条|双|包|米|克|千克|kg|g)$/i;

  function isSpecNoise(value) {
    const flat = String(value || "").trim();
    if (!flat) return true;
    return SPEC_VALUE_NOISE_PATTERN.test(flat);
  }

  // 规格值/选项节点上的「不可选」信号：灰色禁用、售罄、缺货、无货、请选其他
  // 1688 新版把不能选的色卡/尺码标成 disabled 类或划掉，选中它会让上传后立刻售罄，
  // 采集时就标出来，面板默认不勾选这些组合（多规格切换时避开不可选组合）。
  const SPEC_DISABLED_PATTERN = /disabled|sold.?out|cannot|unselect|noStock|out.?of|无货|缺货|售罄|已售完|暂时无/i;

  /** 判断某个规格值选项是否「不可选」（类名、aria、划掉线、文字提示综合判断） */
  function isDisabledSpecOption(item, label) {
    if (!item) return false;
    const classes = typeof item.className === "string" ? item.className : "";
    if (SPEC_DISABLED_PATTERN.test(classes)) return true;
    if (item.getAttribute) {
      if (item.getAttribute("aria-disabled") === "true" || item.hasAttribute("disabled")) return true;
      const dataState = String(item.getAttribute("data-disabled") || item.getAttribute("data-state") || "");
      if (/true|disable|sold|无/i.test(dataState)) return true;
    }
    // 划线（text-decoration: line-through）的色卡文字 = 已下架
    try {
      const deco = typeof window !== "undefined" && window.getComputedStyle
        ? String(window.getComputedStyle(item).textDecorationLine || "") : "";
      if (/line-through/.test(deco)) return true;
    } catch { /* 拿不到样式就按可选 */ }
    if (label && SPEC_DISABLED_PATTERN.test(String(label))) return true;
    return false;
  }

  /**
   * 收集规格维度（颜色/尺码/规格…），同时收集每个规格值对应的缩略图 URL。
   * 返回 { name, values, images, disabled }，images 是 value→imageUrl 的映射，
   * disabled 是「不可选」的 维度名:值 集合。
   */
  function pickSpecOptions() {
    const groups = [];
    for (const selector of SPEC_GROUP_SELECTORS) {
      for (const node of all(selector)) if (!groups.includes(node)) groups.push(node);
    }

    const out = [];
    const images = {};
    const disabled = {};
    for (const group of groups) {
      const nameNode = group.querySelector(SPEC_NAME_SELECTORS);
      const name = cleanText(nameNode ? nameNode.textContent : "");
      const values = [];
      for (const item of all("li, .item, .sku-value, [class*=propValue], [class*=prop-value], [class*=valueItem], button", group)) {
        const classes = item.className || "";
        if (typeof classes === "string" && /obj-name|sku-title|propName|prop-name|propTitle|prop-title/i.test(classes) && !item.querySelector("img")) continue;
        const img = item.querySelector("img");
        let label = cleanText(item.getAttribute("title") || item.getAttribute("data-sku-value") || item.textContent);
        if (!label && img) label = cleanText(img.getAttribute("alt") || img.getAttribute("title"));
        if (!label || label.length > 80 || label === name || isSpecNoise(label)) continue;
        values.push(label);
        if (isDisabledSpecOption(item, label)) disabled[`${name}:${label}`] = true;
        // 收集规格值对应的小图：颜色图、款式图等
        const src = nodeImageUrl(item, img);
        if (src) images[`${name}:${label}`] = src;
      }
      if (name && values.length) out.push({ name, values, images });
    }
    if (out.length) return { options: mergeOptions(out), images, disabled };
    return pickSpecOptionsByHeuristic();
  }

  /**
   * 结构兜底：新版详情页类名混淆（无 sku 字样），改为找「以规格词开头的小标签 + 若干短选项」的结构。
   * 只在候选块足够小的时候才认，避免把整块详情内容误判成规格。
   */
  function pickSpecOptionsByHeuristic() {
    const LABEL_PATTERN = /^(颜色|颜色分类|规格|尺码|尺寸|型号|款式|容量|材质|套餐|口味|版本|套餐类型|净含量|口味分类|适用尺码|规格属性)$/;
    // v1.9.75：候选选项上限从 40 放宽到 150。原上限会把「颜色 60 × 尺码 6」这类
    // 多规格商品整块跳掉（options.length > 40 直接 continue），规格维度整个采不到。
    // 上限仍然保留，但只用于「挡住把整块详情误判成规格」的情况。
    const MAX_HEURISTIC_OPTIONS = 150;
    const out = [];
    const images = {};
    for (const node of all("div, dl, section, ul")) {
      const nameNode = node.querySelector(":scope > dt, :scope > .name, :scope > [class*=title], :scope > [class*=label], :scope > h3, :scope > h4");
      const name = cleanText(nameNode ? nameNode.textContent : "");
      if (!LABEL_PATTERN.test(name)) continue;
      const options = all("li, a, button, [class*=value], [class*=item]", node);
      if (options.length < 2 || options.length > MAX_HEURISTIC_OPTIONS) continue;
      const values = [];
      for (const item of options) {
        const label = cleanText(item.getAttribute("title") || item.getAttribute("data-value") || item.textContent);
        // v1.9.75：上限与合并口径保持一致（原来写死 40，长规格名会被误丢）
        if (!label || label.length > 80 || label === name || isSpecNoise(label)) continue;
        values.push(label);
        const img = item.querySelector("img");
        const src = nodeImageUrl(item, img);
        if (src) images[`${name}:${label}`] = src;
      }
      if (values.length >= 2) out.push({ name, values, images });
    }
    return { options: mergeOptions(out), images };
  }

  /* ------------------------------------------------------------------
   * SKU 表格行解析（优先于内联 JSON）
   * 1688 详情页的「规格 / 价格 / 库存」是一张可见的表格（或等价的 div 行），
   * 用户真正要的就是每行三列：规格名（如「小号 米白 可自由组合」）、价格（¥78）、库存（42123箱）。
   * 旧实现只解析内联 JSON，拿不到就退化成笛卡尔积，价格/库存全是 0。
   * 这里逐行扫 DOM，把每行的「价格列 / 库存列 / 其余当作规格」拆开。
   * ------------------------------------------------------------------ */

  const SKU_ROW_SELECTORS = [
    ".obj-sku table tr",
    "#mod-detail-sku table tr",
    ".table-sku tr",
    "[class*=skuTable] tr",
    "[class*=sku-table] tr",
    "[class*=skuList] > [class*=skuItem]",
    "[class*=sku-list] > [class*=sku-item]",
    "[class*=skuList] > li",
    "[class*=sku-list] > li",
    ".detail-sku-list li",
    "#mod-detail-price table tr",
    "[class*=priceTable] tr",
    "[class*=price-table] tr",
  ];

  // 库存单位：1688 常见「件/个/箱/套/…」，也允许纯数字（无单位）
  const SKU_UNIT = "(?:件|个|箱|套|只|条|双|包|米|千克|公斤|克|台|支|片|张|块|罐|瓶|袋|对|把|卷|副|根|粒|枚|桶|批|打|g|kg|ml|l|pcs|set|box|pair)";
  const SKU_STOCK_PATTERN = new RegExp(`^\\s*([\\d,.]+)\\s*${SKU_UNIT}\\s*$`, "i");
  const SKU_NUMBER_PATTERN = /^\s*[\d,]+(?:\.\d+)?\s*$/;
  const SKU_PRICE_PATTERN = /[¥￥]\s*([\d,]+(?:\.\d+)?)/;

  // 表头/说明性单元格，单独出现时不算规格
  const SKU_HEADER_WORDS = new Set([
    "规格", "颜色", "颜色分类", "尺码", "尺寸", "型号", "款式", "价格", "单价", "批发价",
    "库存", "数量", "可售", "可售数量", "起批量", "重量", "备注", "货号", "操作", "已选",
    "图片", "图", "合计", "小计", "货源", "单价(元)", "价格(元)", "库存(件)",
  ]);

  function isHeaderCell(value) {
    if (!value) return true;
    const flat = value.replace(/\s+/g, "");
    return SKU_HEADER_WORDS.has(flat) || SKU_HEADER_WORDS.has(value);
  }

  // 提取库存时「库存/可售」关键词是必须的：像「1.2米灰色」这种规格里带「米」，
  // 关键词可选会把它当成「库存 2 米」，既吃掉规格又给出错误的库存。
  const SKU_STOCK_EXTRACT_PATTERN = new RegExp(
    `(?:库存|可售|现货|数量)\\s*[:：]?\\s*([\\d,]+)\\s*${SKU_UNIT}`,
    "i",
  );

  /**
   * 从一段文本里抽出「价格 / 库存」，并把这两段从规格名里剔掉。
   * 1688 的 DOM 经常把整行塞进一个节点（如「小号 米白 可自由组合¥78库存42123箱」），
   * 只按列拆会拆出「¥78」「库存42123箱」这种碎片行，这里必须正则抽干净。
   */
  function extractPriceStock(rawText) {
    let label = String(rawText || "");
    let price = 0;
    let stock = 0;
    let stockText = "";

    const priceMatch = label.match(SKU_PRICE_PATTERN);
    if (priceMatch) {
      price = parseNumber(priceMatch[1]);
      label = label.slice(0, priceMatch.index) + " " + label.slice(priceMatch.index + priceMatch[0].length);
    }

    // 库存两种形态：带「库存/可售」关键词的混排文本，或整格就是「数字+单位」的库存列
    const stockMatch = label.match(SKU_STOCK_EXTRACT_PATTERN) || label.match(SKU_STOCK_PATTERN);
    if (stockMatch) {
      stock = parseNumber(stockMatch[1]);
      stockText = stockMatch[0].trim();
      label = label.slice(0, stockMatch.index) + " " + label.slice(stockMatch.index + stockMatch[0].length);
    }

    // 整个单元格就是个裸数字（老版表格价格列没有 ¥）：不当规格，交由调用方决定当价格还是库存
    let bareNumber = 0;
    if (!price && !stock) {
      const trimmed = label.trim();
      if (SKU_NUMBER_PATTERN.test(trimmed)) bareNumber = parseNumber(trimmed);
    }

    label = label
      .replace(/[¥￥]/g, " ")
      .replace(/\s+/g, " ")
      .trim();
    return { price, stock, stockText, bareNumber, label };
  }

  /**
   * 规格名里混进来的「页面文案」片段。v1.9.74 新增。
   *
   * 现象（超哥截图）：面板「规格」列显示成一整段「售100% 200+人已加购 领券 满100减10 …」，
   * 30 多个变体挤在一格里分不出来。
   * 根因：1688 新版把营销文案和 SKU 列表塞进同一个容器，整块 innerText 被当成一行 SKU，
   * 剥掉价格/库存后剩下的**整段页面文案**就全变成了规格名。
   *
   * 这里只删「确定不属于规格名」的片段，不猜、不改写真实规格。
   */
  const SPEC_LABEL_NOISE_RE = [
    // 销量 / 人气：「已售 100 件」「成交 12 笔」「750+人已加购」「售100%」
    // 注意「售100%」这种把「已」省掉、百分号结尾的写法：要单独一条，否则逃过清洗
    /(?:已售|售出|成交|销量|月销|已拼|售)\s*[\d.,]+\s*(?:万|\+)?\s*%/g,
    /(?:已售|售出|成交|销量|月销|已拼)\s*[\d.,]+\s*(?:万|\+)?\s*(?:件|笔|单|人|台|个|箱|套)?/g,
    /[\d.,]+\s*(?:万)?\s*\+?\s*人\s*(?:已|正在)?\s*(?:加购|购买|收藏|关注|回头|浏览)/g,
    // 优惠 / 营销：「领券」「满100减10」「限时特价」「包邮」「7天无理由」
    /(?:领取|立即领|去领|领券|优惠券|优惠卷|代金券|满\s*\d+\s*减\s*\d+|满\s*\d+\s*包邮|满减|立减|券后价?)/g,
    /(?:包邮|运费险|退货包运费|7\s*天无理由|七天无理由|极速退款|售后无忧|假一赔十)/g,
    /(?:限时|秒杀|特价|清仓|亏本|促销|活动价|到手价|直降|补贴价)/g,
    /(?:支持一件代发|一件代发|厂家直销|源头工厂|实力商家|诚信通|超级工厂|现货供应|批发)/g,
    // 库存 / 起批 / 交互提示
    /(?:起批量?|起订量|可售|现货|库存)\s*[:：]?\s*[\d,]*\s*(?:件|个|箱|套|只|条|双|包|米|千克|公斤|克|台|支|片|张|块|罐|瓶|袋|对|把|卷|副|根|粒|枚|桶|批|打|pcs|set|box|pair)?/gi,
    /(?:请选择|已选|点击选择|选择规格|共\s*\d+\s*种|以下规格可选)/g,
  ];

  /**
   * 规格名长度上限。真实 1688 SKU 行（哪怕三个维度全拼上）也很少超过这个数；
   * 但**它只是兜底**——判断「这是不是一行」主要看库存锚点数（见 parseSkuRow），
   * 因为多维度长规格（如「豪华款双向推-卡其色(EVA/八轮)+收纳袋」）本来就可能很长。
   * v1.9.75：从 80 放宽到 200，避免把合规的长规格行误杀成容器。
   */
  const SPEC_LABEL_MAX = 200;

  /** 去掉规格名里的页面文案片段；清完只剩标点或空串的返回 "" */
  function cleanSpecLabel(label) {
    let out = cleanText(label);
    if (!out) return "";
    for (const pattern of SPEC_LABEL_NOISE_RE) out = out.replace(pattern, " ");
    out = cleanText(out)
      .replace(/^[\s，,、。;；:：|｜/\-·]+/, "")
      .replace(/[\s，,、。;；:：|｜/\-·]+$/, "");
    // 清完没有任何实义字符（中文/字母/数字）的，不算规格名
    if (!out || !/[\u4e00-\u9fa5a-zA-Z0-9]/.test(out)) return "";
    return out;
  }

  /**
   * 把一行文本拆成 { label, price, stock }。
   * 规则：先从每个格子里抽价格/库存并剔除；剩下的裸数字列，第一个当价格、之后的当库存；
   * 没有规格名的碎片行（只有「¥78」或「库存42123箱」）直接丢弃——那不是一行 SKU。
   */
  function parseSkuRow(texts) {
    const cells = dedupe(texts.map((value) => cleanText(value)).filter(Boolean));
    if (!cells.length) return null;

    let price = 0;
    let stock = 0;
    let stockText = "";
    const specParts = [];
    const bareCells = [];

    for (const cell of cells) {
      const extracted = extractPriceStock(cell);
      if (extracted.price && !price) price = extracted.price;
      if (extracted.stock && !stock) { stock = extracted.stock; stockText = extracted.stockText; }
      if (!extracted.label || isHeaderCell(extracted.label)) continue;
      // 整格是裸数字（老版表格的价格/库存列没有 ¥ 也没有「库存」关键词）时先扣住：
      // 旧代码把它同时当规格又当数字，label 会拼进「大号 黑色 98 500」。
      // 但纯数字也可能是真规格（鞋码「42」），所以只有**真被消费成价格/库存**才从规格里剔掉。
      if (extracted.bareNumber) bareCells.push(extracted);
      else specParts.push(extracted.label);
    }

    for (const bare of bareCells) {
      if (!price) price = bare.bareNumber;
      else if (!stock) stock = bare.bareNumber;
      else specParts.push(bare.label);   // 价格和库存都齐了，这格是规格不是数字列
    }

    // v1.9.74：拼接后再统一清洗一遍规格名（页面文案片段必须在这里清掉，
    // 否则「规格」列显示的是整段营销文案，用户看不出哪个是规格）
    const label = cleanSpecLabel(specParts.join(" "));
    // 必须既有规格名、又有价格或库存，才算一条真实 SKU 行
    if (!label || (!price && !stock)) return null;
    // v1.9.75 判断「这是不是一行 SKU」改用**本质特征**，不再只看长度：
    // 一个装了很多行的容器，即使把价格/库存剥掉，剩下的规格文本里一定还留着
    // 多个「库存/可售」锚点（因为容器的行内文本本来就有好几份）。
    // 而正常一行只有一个库存锚点（已被 extractPriceStock 剥掉）。
    // 只看长度会把「多维长规格的正常一行」误杀，也会漏掉「文本不长的容器」。
    const rawText = cells.join(" ");
    if (countStockAnchors(rawText) > 1) return null;
    // 长度作为第二道兜底（防止极端情况：容器文本被清洗后锚点也没了）
    if (label.length > SPEC_LABEL_MAX) return null;
    // stockText 之前没有透传：调用方（表格行/文本行/DOM 行）拿到的永远是 undefined，
    // 「库存 42123 箱」这种带单位的原文丢失，面板只能显示裸数字
    return { label, price, stock, stockText };
  }

  /** 一段文本里出现几次「库存/可售 + 数字」（复用 SKU_STOCK_EXTRACT_PATTERN 的口径） */
  function countStockAnchors(text) {
    const flat = cleanText(text);
    if (!flat) return 0;
    const pattern = new RegExp(
      `(?:库存|可售|现货)\\s*[:：]?\\s*[\\d,]+(?:\\.\\d+)?\\s*${SKU_UNIT}?`,
      "gi",
    );
    return (flat.match(pattern) || []).length;
  }

  /**
   * 把「一整段没有换行的文本」切成一行行 SKU。v1.9.74 新增。
   *
   * 真实现象：1688 新版 SKU 列表用 flex 布局，innerText 拿回来是
   *   「标准款-卡其色 ¥129 库存4333件 标准款-亚麻灰 ¥129 库存4523件 豪华款-卡其色 ¥139 库存2662件 …」
   * 30 多个变体全在一行、没有任何 \n。旧实现只按 \n 切行 → 拿到 1 条超长「SKU」，
   * 规格列显示成一整段页面文案，最终去重后只剩 1 条 —— 这就是「只采到 1 个 SKU」。
   *
   * 切分策略：以「库存/可售 N 单位」为**行尾锚点**。1688 每个 SKU 行的 innerText 都以
   * 库存数结尾，所以在每个锚点后面切一刀，天然还原成一行行。
   * 带价格的行才算切点（避免「库存充足」这种说明文字被当成锚点）。
   */
  function splitSkuBlob(text) {
    const flat = cleanText(text);
    if (!flat) return [];
    // 锚点：库存/可售 + 数字 + 可选单位，且**该行内**存在价格符号
    const anchor = new RegExp(
      `(?:库存|可售|现货)\\s*[:：]?\\s*[\\d,]+(?:\\.\\d+)?\\s*${SKU_UNIT}?`,
      "gi",
    );
    const cuts = [];
    let match;
    while ((match = anchor.exec(flat))) {
      cuts.push(match.index + match[0].length);
      if (cuts.length >= 200) break;
    }
    if (cuts.length < 2) return [];   // 只有 0~1 个锚点，不值得切（正常单行由调用方处理）
    const pieces = [];
    let start = 0;
    for (const cut of cuts) {
      pieces.push(flat.slice(start, cut));
      start = cut;
    }
    if (start < flat.length) pieces.push(flat.slice(start));
    return pieces
      .map((piece) => cleanText(piece))
      // 每片必须自带价格符号，否则是残留说明文字，丢掉
      .filter((piece) => piece.length > 3 && piece.length <= SPEC_LABEL_MAX * 2 && /[¥￥]/.test(piece));
  }

  /**
   * v1.9.82 矩阵式 SKU 行展开。
   *
   * 1688 颜色×大小矩阵布局（超哥截图实证：猫窝 2色×2码=4 SKU 只采到 1 条）：
   * 颜色名挂在列头，价库行长这样——「中号 ¥41.6 库存9930个 ¥41.6 库存9930个」，
   * 一行里按颜色顺序排了 N 组（价格,库存），但行文本只有「中号」一个维度值。
   * 旧 parseSkuRow 开头的 dedupe 会把两组相同的「¥41.6」「库存9930个」单元格折叠成一组，
   * 于是每行只出 1 条、颜色维度整个丢失。
   *
   * 触发条件（全部满足才展开，任何一条不满足返回 null 走原逻辑，宁可不展也不错配）：
   * ① 行内 ≥2 组「¥价格 + 库存数字」配对；
   * ② 恰好一个规格维度的值出现在行文本里（present），且每个维度最多 1 个值
   *    （同维度出现两个值 = 窗口跨行，配对顺序不可信）；
   * ③ 恰好一个维度缺失（missing），且它的候选值数量 === 配对数量（一一对应）。
   * 配对顺序 = 页面渲染顺序 = missing 维度候选值顺序（1688 矩阵行按色卡顺序排）。
   */
  function expandSkuMatrixRow(flat, specOptions) {
    if (!flat || !Array.isArray(specOptions) || specOptions.length < 2) return null;
    const pairRe = new RegExp(
      `[¥￥]\\s*([\\d,]+(?:\\.\\d+)?)[^¥￥\\d]{0,24}?(?:库存|可售|现货)\\s*[:：]?\\s*([\\d,]+(?:\\.\\d+)?)\\s*${SKU_UNIT}?`,
      "gi",
    );
    const pairs = [];
    let match;
    while ((match = pairRe.exec(flat)) && pairs.length < 60) {
      pairs.push({ price: parseNumber(match[1]), stock: parseNumber(match[2]) });
    }
    if (pairs.length < 2) return null;
    const present = [];
    const missing = [];
    for (const opt of specOptions) {
      const hits = (opt.values || []).filter((v) => v && flat.includes(v));
      if (hits.length > 1) return null;
      if (hits.length === 1) present.push({ name: opt.name, value: hits[0] });
      else missing.push(opt);
    }
    if (!present.length || missing.length !== 1) return null;
    if (missing[0].values.length !== pairs.length) return null;
    return pairs.map((p, i) => {
      const specs = {};
      for (const item of present) specs[item.name] = item.value;
      specs[missing[0].name] = missing[0].values[i];
      return {
        specs,
        price: p.price,
        stock: p.stock,
        label: [...present.map((item) => item.value), missing[0].values[i]].join(" "),
      };
    });
  }

  /**
   * v1.9.82 把「一行文本」（或一个容器块）解析成 SKU 列表，矩阵感知优先。
   * 顺序：① 整行直接矩阵展开；② 按库存锚点切片后**分组**再展开——
   * 矩阵行被切碎的「后半截」（「¥41.6 库存9930个」没有规格值）并入当前组，
   * 组内再走矩阵展开；展不动的组退回 parseSkuRow 单行解析。
   * 返回 null 表示这条路走不通，调用方继续原逻辑（单元格分列解析 / 多行回溯）。
   */
  function expandSkuLineToSkus(flat, specOptions) {
    const direct = expandSkuMatrixRow(flat, specOptions);
    if (direct) return direct;
    if (!/[¥￥]/.test(flat) || countStockAnchors(flat) < 2) return null;
    const pieces = splitSkuBlob(flat);
    if (pieces.length < 2) return null;
    const hasSpecValue = (piece) => (specOptions || []).some((opt) => (opt.values || []).some((v) => v && piece.includes(v)));
    const groups = [];
    for (const piece of pieces) {
      if (hasSpecValue(piece) || !groups.length) groups.push(piece);
      else groups[groups.length - 1] = cleanText(`${groups[groups.length - 1]} ${piece}`);
    }
    const out = [];
    for (const group of groups) {
      const matrix = expandSkuMatrixRow(group, specOptions);
      if (matrix) { out.push(...matrix); continue; }
      const parsed = parseSkuRow([group]);
      if (parsed) out.push(parsed);
    }
    return out.length ? out : null;
  }

  /**
   * 用规格维度把「小号 米白 可自由组合」拆回 {尺码:小号, 颜色:米白, 规格:可自由组合}。
   * v1.9.60 两遍匹配：先全维度**精确**匹配，再按「值更长者优先」做子串匹配。
   * 老实现按维度顺序一遍过，且精确/子串混在一起：
   *   - 靠前维度可能用短值（如「米」）抢先吞掉本该属于别的维度的 token（「米白」）；
   *   - 一个维度也可能拿到后半截，导致后面的维度全错、剩余文本再兜进「规格」。
   * 先精确后模糊 + 长值优先，能把这类误配挡掉；同一 token 仍只允许被一个维度消费。
   */
  function splitSpecLabel(label, specOptions) {
    const specs = {};
    if (!label) return specs;
    const tokens = label.split(/[\s/|｜、]+/).filter(Boolean);
    const used = new Set();
    // ① 精确匹配：所有维度先各扫一遍，保证「完全相等」永远赢过「包含关系」
    for (const option of specOptions || []) {
      for (const value of option.values || []) {
        const target = cleanText(value);
        if (!target) continue;
        const index = tokens.findIndex((token, i) => !used.has(i) && token === target);
        if (index >= 0 && specs[option.name] === undefined) {
          specs[option.name] = target;
          used.add(index);
          break;
        }
      }
    }
    // ② 子串匹配：候选按值长度降序，长的先挑（「米白」不会被「米」截胡）
    const fuzzy = [];
    for (const option of specOptions || []) {
      if (specs[option.name] !== undefined) continue;
      for (const value of option.values || []) {
        const target = cleanText(value);
        if (target) fuzzy.push({ name: option.name, target });
      }
    }
    fuzzy.sort((a, b) => b.target.length - a.target.length);
    // v1.9.74：token 比命中的候选值长时，**剩下的部分是真规格信息，不能丢**。
    // 案例：「标准款-卡其色」命中「卡其色」→ 旧实现把整个 token 标记为已消费，
    // 「标准款」被丢掉了。于是「标准款-卡其色」和「豪华款-卡其色」拆出完全相同的 specs
    // （只有 {颜色:卡其色}），去重时后者被当成重复条目删掉 —— 页面上有、插件里没有。
    const leftover = [];
    for (const candidate of fuzzy) {
      if (specs[candidate.name] !== undefined) continue;
      const index = tokens.findIndex((token, i) => !used.has(i) && (token.includes(candidate.target) || candidate.target.includes(token)));
      if (index >= 0) {
        specs[candidate.name] = candidate.target;
        used.add(index);
        const token = tokens[index];
        if (token !== candidate.target && token.includes(candidate.target)) {
          const remainder = cleanText(
            token.split(candidate.target).join(" ").replace(/[-_/|｜、+＋]+/g, " "),
          );
          if (remainder) leftover.push(remainder);
        }
      }
    }
    const rest = tokens.filter((token, i) => !used.has(i)).concat(leftover);
    if (rest.length) specs["规格"] = rest.join(" ");
    if (!Object.keys(specs).length) specs["规格"] = label;
    return specs;
  }

  function collectSkuRowNodes() {
    const seen = new Set();
    const rows = [];
    const push = (node) => {
      if (!node || seen.has(node)) return;
      seen.add(node);
      rows.push(node);
    };
    for (const selector of SKU_ROW_SELECTORS) {
      for (const node of all(selector)) push(node);
    }
    return rows;
  }

  function rowCellTexts(row) {
    const tag = (row.tagName || "").toLowerCase();
    const nodes = tag === "tr"
      ? all("td, th", row)
      : all(":scope > td, :scope > th, :scope > div, :scope > span, :scope > li, :scope > p", row);
    // tr 里没有 td（用 div 布局的伪表格）时退回直接子节点
    const list = nodes.length ? nodes : Array.from(row.children || []);
    return list.map((node) => cleanText(node.textContent || "")).filter(Boolean);
  }

  function pickSkuTableRows(specOptions) {
    const rows = collectSkuRowNodes();
    if (!rows.length) return [];
    const out = [];
    const pushRow = (parsed, row, index, suffix = "") => {
      if (!parsed || !parsed.label) return;
      if (isHeaderCell(parsed.label)) return;             // 整行都是表头
      const rowImg = row && row.querySelector ? row.querySelector("img") : null;
      const rowImage = rowImg ? U.imageSource(rowImg) : "";
      out.push({
        id: `sku_${index}${suffix}`,
        // 矩阵展开自带精确 specs（label 拼出来的顺序可能让 splitSpecLabel 误配），优先用
        specs: parsed.specs || splitSpecLabel(parsed.label, specOptions),
        price: parsed.price,
        stock: parsed.stock,
        stockText: parsed.stockText,
        image: rowImage,
        label: parsed.label,
      });
    };
    rows.forEach((row, index) => {
      const texts = rowCellTexts(row);
      if (texts.length < 2) return;
      // v1.9.82 矩阵感知优先：颜色×大小矩阵的价库行（「中号 ¥41.6 库存9930个 ¥41.6 库存9930个」）
      // 走 parseSkuRow 会因单元格去重只剩一组价库、颜色维度整个丢失。
      // expandSkuLineToSkus 先矩阵展开、再切片分组、最后才退回单行解析；展不动返回 null 走原逻辑。
      const expanded = expandSkuLineToSkus(cleanText(texts.join(" ")), specOptions);
      if (expanded) {
        expanded.forEach((sku, i) => pushRow(sku, row, index, `_x${i}`));
        return;
      }
      const parsed = parseSkuRow(texts);
      if (parsed) { pushRow(parsed, row, index); return; }
      // v1.9.74：选择器命中的其实是**外层容器**（里面装着多个变体）时，
      // parseSkuRow 会因为规格名超长而拒绝整行 —— 这时按「库存」锚点把整行切回多条。
      // 旧实现就此静默丢掉这一整块，于是页面上几十个变体一条都采不到。
      const flat = cleanText(texts.join(" "));
      if (!flat || !/[¥￥]/.test(flat) || countStockAnchors(flat) < 2) return;
      const pieces = splitSkuBlob(flat);
      if (pieces.length < 2) return;
      pieces.forEach((piece, i) => pushRow(parseSkuRow([piece]), row, index, `_${i}`));
    });
    return U.dedupeSkus(out);
  }

  /** 两个来源谁更可信：有价有库的条目越多越可信 */
  function scoreSkuList(list) {
    let score = 0;
    for (const sku of list || []) {
      if (Number(sku.price) > 0) score += 2;
      if (Number(sku.stock) > 0) score += 1;
      if (sku.label) score += 1;
    }
    return score;
  }

  // 尝试从页面内联数据里提取完整 SKU 矩阵（含价格与库存）
  function pickSkusFromData(cache) {
    const data = U.findInlineJson([
      /window\.__INIT_DATA__\s*=\s*(\{[\s\S]{0,400000}?\});?\s*(?:window\.|<\/script>)/,
      /"skuInfos"\s*:\s*(\{[\s\S]{0,200000}?\})\s*[,}]/,
      /"skuList"\s*:\s*(\[[\s\S]{0,200000}?\])\s*[,}]/,
      /"skuMap"\s*:\s*(\{[\s\S]{0,200000}?\})\s*[,}]/,
    ], null, cache);
    if (!data) return [];
    const rawList =
      data.skuInfos || data.skuList || data.skuMap || (data.data && (data.data.skuInfos || data.data.skuList));
    if (!rawList) return [];

    const entries = Array.isArray(rawList) ? rawList : Object.values(rawList);
    const out = [];
    entries.forEach((entry, index) => {
      if (!entry || typeof entry !== "object") return;
      const specs = {};
      const specSource = entry.specAttrs || entry.attributes || entry.props || entry.specs || {};
      if (typeof specSource === "string") {
        for (const chunk of specSource.split(/[;；]/)) {
          const pair = chunk.split(/[:：]/);
          if (pair.length >= 2) specs[cleanText(pair[0])] = cleanText(pair[1]);
        }
      } else if (Array.isArray(specSource)) {
        for (const item of specSource) {
          const name = cleanText(item.name || item.attrName || item.propName);
          const value = cleanText(item.value || item.attrValue || item.propValue);
          if (name && value) specs[name] = value;
        }
      } else {
        for (const [key, value] of Object.entries(specSource)) {
          const name = cleanText(value && value.name ? value.name : key);
          const val = cleanText(value && value.value ? value.value : value);
          if (name && val) specs[name] = val;
        }
      }
      // 价格优先级必须写清楚：原来用 ?? 连着三元表达式，会被解析成「先判断 priceCent 是否存在」，
      // 导致 entry.price 有值时反而取 priceCent/100（取到 0），这里改成显式取值。
      const priceRaw = entry.price != null ? entry.price
        : entry.salePrice != null ? entry.salePrice
          : entry.priceCent != null ? entry.priceCent / 100
            : "";
      const price = parseNumber(priceRaw);
      const stock = parseNumber(entry.stock ?? entry.quantity ?? entry.canBookCount);
      out.push({
        id: cleanText(entry.skuId || entry.id || `sku_${index}`),
        specs,
        price,
        stock,
        image: normalizeImageUrl(entry.image || entry.imgUrl || (entry.imageUrlList || [])[0], ORIGIN),
        label: Object.values(specs).join(" / "),
      });
    });
    return U.dedupeSkus(out);
  }

  /**
   * 文本行兜底：新版详情页的 SKU 列表类名混淆，表格行选择器抓不到时，
   * 直接按可见文本解析——1688 每行 SKU 的 innerText 形如
   * 「1.2-1.2米灰色（海洋球+手拉环+收纳袋）¥100 库存6698袋」，
   * 或拆成三行（规格 / ¥价格 / 库存N件）。两种排布都能还原成规格+价格+库存。
   */
  function pickSkuRowsFromText(cache, specOptions = []) {
    // v1.9.69：SKU 文本行只在商品主体区里找，避免把推荐位的「规格/价格」当成本商品的
    const lines = cache.scopeText().split(/\n+/).map((line) => cleanText(line)).filter(Boolean);
    const out = [];
    const seen = new Set();
    const push = (parsed) => {
      if (!parsed || !parsed.label || seen.has(parsed.label)) return;
      seen.add(parsed.label);
      out.push({
        id: `sku_text_${out.length}`,
        // v1.9.74：原来这里传的是 []，于是所有规格值全堆在「规格」这一个键下，
        // 面板里看不出「尺码/颜色」的维度结构。把真实规格维度传进去。
        // v1.9.82：矩阵展开自带精确 specs，优先用
        specs: parsed.specs || splitSpecLabel(parsed.label, specOptions),
        price: parsed.price,
        stock: parsed.stock,
        stockText: parsed.stockText,
        image: "",
        label: parsed.label,
      });
    };
    for (let i = 0; i < lines.length; i += 1) {
      const line = lines[i];
      if (!/库存|可售/.test(line)) continue;
      // v1.9.82 矩阵感知优先：「中号 ¥41.6 库存9930个 ¥41.6 库存9930个」按库存锚点切
      // 只会剩一条「中号」（颜色名不在行上、第二片没规格被丢）；矩阵展开还原全部颜色。
      const expanded = expandSkuLineToSkus(line, specOptions);
      if (expanded) {
        for (const sku of expanded) push(sku);
        continue;
      }
      // v1.9.74：整段没有换行、里面含多个变体时，先按库存锚点切成多条再逐条解析。
      // 旧实现把整段当成一条 SKU —— 规格列是一整段页面文案，去重后只剩 1 条。
      if (countStockAnchors(line) >= 2 && /[¥￥]/.test(line)) {
        const pieces = splitSkuBlob(line);
        if (pieces.length >= 2) {
          for (const piece of pieces) push(parseSkuRow([piece]));
          continue;
        }
      }
      // 价格和库存在同一行：整行就是一条 SKU
      if (/[¥￥]/.test(line)) {
        push(parseSkuRow([line]));
        continue;
      }
      // 库存单独成行：往前找「价格行」以及它上面的「规格行」
      let priceIdx = -1;
      for (let back = 1; back <= 3 && i - back >= 0; back += 1) {
        const prev = lines[i - back];
        if (isHeaderCell(cleanText(prev))) break;
        if (/[¥￥]/.test(prev)) { priceIdx = i - back; break; }
      }
      if (priceIdx < 0) continue;
      const parts = [];
      const labelLine = priceIdx - 1 >= 0 ? lines[priceIdx - 1] : "";
      if (labelLine && !/[¥￥]/.test(labelLine) && !isHeaderCell(cleanText(labelLine))) parts.push(labelLine);
      parts.push(lines[priceIdx], line);
      push(parseSkuRow(parts));
    }
    return U.dedupeSkus(out);
  }

  /* 变体缩略图：行级抓图的几个上限，防止在大页面里把整棵 DOM 走一遍 */
  const MAX_SKU_ROW_ANCHORS = 400;
  // v1.9.75：单行文本上限从 200 放宽到 400。原上限会把「多维长规格 + 价格 + 库存」
  // 的正常一行判成多行容器直接 break，那一行的变体图就丢了。
  // 真正判断「这是不是一行」靠库存锚点数（见 pickSkuRowsFromDom），不靠长度。
  const MAX_SKU_ROW_DEPTH = 8;
  const MAX_SKU_ROW_TEXT = 400;
  const MIN_SKU_THUMB_PX = 24;
  const SKU_STOCK_WORD = /库存|可售/g;

  /** 规格标签归一化：文本行与 DOM 行对同一行的措辞可能差个空格，比较前先压平 */
  function skuLabelKey(label) {
    return cleanText(label).toLowerCase().replace(/\s+/g, " ");
  }

  /**
   * 从「一行」容器里挑变体缩略图：img 优先（懒加载属性由 imageSource 处理），
   * 取不到再退回 background-image（1688 色卡常把图铺在背景里）。
   * 一行里常有箭头/客服小图标，按面积取最大的那张，并跳过明显是图标的。
   */
  function pickRowThumbnail(row) {
    if (!row || !row.querySelectorAll) return "";
    const imgs = Array.from(row.querySelectorAll("img")).slice(0, 8);
    let best = "";
    let bestArea = 0;
    for (const img of imgs) {
      const src = U.imageSource(img);
      if (!src) continue;
      const size = U.imageSize(img);
      // 懒加载图常常还没量出尺寸，拿不到尺寸时不当图标处理
      if (size.width && size.width < MIN_SKU_THUMB_PX) continue;
      const area = (size.width || 0) * (size.height || 0);
      if (area >= bestArea) {
        bestArea = area;
        best = src;
      }
    }
    if (best) return best;
    const backgrounds = U.backgroundImageUrls(row);
    return backgrounds.length ? normalizeImageUrl(backgrounds[0], ORIGIN) : "";
  }

  /**
   * 按「DOM 行」抓每个变体自己的缩略图。
   *
   * 新版详情页的 SKU 列表类名混淆，SKU_ROW_SELECTORS 经常全空，于是选了文本行兜底——
   * 但文本行只有规格/价格/库存，**没有图**，面板里「图」列就整列显示「无图」，
   * 上传时每个变体也就拿不到自己的主图。
   *
   * 这里反着来：以「库存 / 可售」为锚点（每行必有，且文本节点很便宜），向上爬到
   * 「仍然只装得下一行」的容器，再从这个容器里取缩略图。
   *
   * 判定「这一层就是一行」的两个条件缺一不可：文本里有价格、且**只出现一次**
   * 「库存/可售」——外层容器会把多行的库存词都带上，出现两次就说明还站在多行上，
   * 继续往上只会更糟，直接放弃这个锚点。
   */
  function pickSkuRowsFromDom() {
    const rows = [];
    const seen = new Set();
    if (!document.body || typeof document.createTreeWalker !== "function") return rows;

    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
    const anchors = [];
    let node = walker.nextNode();
    while (node && anchors.length < MAX_SKU_ROW_ANCHORS) {
      if (/库存|可售/.test(node.nodeValue || "")) anchors.push(node.parentElement);
      node = walker.nextNode();
    }

    for (const anchor of anchors) {
      let row = anchor;
      let depth = 0;
      while (row && depth <= MAX_SKU_ROW_DEPTH) {
        const text = cleanText(row.textContent || "");
        if (text.length > MAX_SKU_ROW_TEXT) break;
        const stockHits = (text.match(SKU_STOCK_WORD) || []).length;
        if (stockHits === 1 && /[¥￥]/.test(text)) {
          const parsed = parseSkuRow([text]);
          if (parsed && parsed.label && !isHeaderCell(parsed.label) && !seen.has(parsed.label)) {
            const image = pickRowThumbnail(row);
            if (image) {
              seen.add(parsed.label);
              rows.push({
                id: `sku_dom_${rows.length}`,
                specs: {},
                price: parsed.price,
                stock: parsed.stock,
                stockText: parsed.stockText,
                image,
                label: parsed.label,
              });
            }
          }
          break;
        }
        // 已经爬到多行容器（库存词出现多次），本行不再往上找
        if (stockHits > 1) break;
        row = row.parentElement;
        depth += 1;
      }
    }
    return U.dedupeSkus(rows);
  }

  /**
   * 给最终选中的 SKU 列表补变体图，三个来源按可信度依次尝试：
   * 行级 DOM 图 → 标签宽松匹配（括号/空格/措辞略有出入）→ 规格色卡图。
   * 返回补到图的条数。
   */
  function attachSkuImages(skus, rowSkus = [], specImages = {}) {
    const byLabel = new Map();
    for (const row of rowSkus || []) {
      if (!row.label || !row.image) continue;
      byLabel.set(skuLabelKey(row.label), row.image);
    }
    const specEntries = Object.keys(specImages || {}).map((key) => {
      const split = key.indexOf(":");
      return {
        name: split > -1 ? key.slice(0, split) : "",
        value: skuLabelKey(split > -1 ? key.slice(split + 1) : key),
        image: specImages[key],
      };
    });

    let filled = 0;
    for (const sku of skus || []) {
      if (sku.image) continue;
      const direct = byLabel.get(skuLabelKey(sku.label));
      if (direct) {
        sku.image = direct;
        filled += 1;
        continue;
      }
      // 措辞略有出入时用「去掉括号与空格后互相包含」兜一层
      const loose = skuLabelKey(sku.label).replace(/[()（）\s]/g, "");
      if (loose) {
        for (const [key, image] of byLabel) {
          const other = key.replace(/[()（）\s]/g, "");
          if (other && (other.includes(loose) || loose.includes(other))) {
            sku.image = image;
            filled += 1;
            break;
          }
        }
        if (sku.image) continue;
      }
      // 最后退回规格色卡图：先严格按「维度名:值」匹配，再拿规格值去模糊命中
      const specs = sku.specs || {};
      for (const [name, value] of Object.entries(specs)) {
        const exact = specImages[`${name}:${value}`];
        if (exact) {
          sku.image = exact;
          filled += 1;
          break;
        }
      }
      if (sku.image) continue;
      const values = Object.values(specs).map((value) => skuLabelKey(value)).filter(Boolean);
      const hit = specEntries.find((entry) => entry.value && values.some((value) => entry.value === value || entry.value.includes(value) || value.includes(entry.value)));
      if (hit) {
        sku.image = hit.image;
        filled += 1;
      }
    }
    return filled;
  }

  function pickAttributes(cache) {
    const pairs = U.extractAttributePairs([
      ".offer-attr",
      "#mod-detail-attributes",
      ".detail-attribute",
      ".obj-attribute",
      ".attributes-list",
      "#J_AttrUL",
      // v1.9.68：新版类名多为 attribute / param / property / props / specification 的驼峰写法，
      // 老实现只有连字符版，于是「属性/参数」整项落空（截图里就是「未识别：属性/参数」）
      "[class*=attribute]", "[class*=Attribute]",
      "[class*=param]", "[class*=Param]",
      "[class*=property]", "[class*=Property]",
      "[class*=offerAttr]", "[class*=offer-attr]",
      "[class*=detailAttr]", "[class*=detail-attr]",
      "[class*=productAttr]", "[class*=product-attr]",
      "[class*=specification]", "[class*=specList]", "[class*=spec-list]",
      "[class*=props]", "[class*=Props]",
    ]);
    if (pairs.length) return U.dedupeAttributes(pairs);

    // 兜底：抓 "xxx: yyy" 形式的整段参数区。
    // v1.9.68：区块标题不只有「产品参数 / 商品参数 / 详细信息」，新版还叫
    // 「规格参数 / 技术参数 / 产品属性 / 商品属性 / 基本参数 / 参数信息」，
    // 关键词少一个就整块参数都取不到。
    const out = [];
    // v1.9.69：参数区文本只在商品主体区里找
    const bodyText = cache.scopeText();
    const block = bodyText.match(
      /(?:产品参数|商品参数|规格参数|技术参数|基本参数|详细参数|参数信息|产品属性|商品属性|属性参数|详细信息|商品详情)[\s\S]{0,3000}/,
    );
    if (block) {
      for (const line of block[0].split(/\n+/)) {
        // 「品牌：XX」也常见写成「品牌 XX」（空格分隔），两种都收
        const match = line.match(/^([^\n:：]{2,12})\s*[:：]\s*([^\n]{1,60})$/)
          || line.match(/^([\u4e00-\u9fa5]{2,8})\s+([^\n:：]{1,60})$/);
        if (match) out.push({ name: cleanText(match[1]), value: cleanText(match[2]) });
      }
    }
    return U.dedupeAttributes(out);
  }

  /**
   * 「运费 ¥11 起」「快递 ¥8」→ 11 / 8；解析不出返回 0。
   * 「费」字可有可无：1688 页面上写的是「运费/快递费/物流费 ¥11 起」；
   * ¥ 也可有可无（部分页面「快递 8 元」），金额单位「元」同样放过。
   */
  function parseFreightCny(freightText) {
    const match = String(freightText || "").match(/(?:运费|快递费|快递|物流费|物流)[^\d¥￥]{0,8}[¥￥]?\s*([\d,]+(?:\.\d+)?)/);
    return match ? parseNumber(match[1]) : 0;
  }

  /** 包裹毛重与包装尺寸：定价要用的重量/体积直接从采集信息里带出来，免得手填 */
  function pickParcel(cache) {
    // v1.9.69：毛重/尺寸只在商品主体区里找
    const bodyText = cache.scopeText();
    const weight = bodyText.match(/(?:毛重|净重|重量|产品重量|包装重量)\s*[:：]?\s*([\d.]+)\s*(kg|千克|公斤|g|克)/i);
    const dims = bodyText.match(
      /(?:包装尺寸|外包装尺寸|包裹尺寸|外箱尺寸|产品尺寸|商品尺寸|尺寸)\s*[:：]?\s*([\d.]+)\s*[x×*]\s*([\d.]+)\s*[x×*]\s*([\d.]+)\s*(mm|毫米|cm|厘米|米)?/i,
    );
    let weightKg = 0;
    if (weight) {
      const value = parseFloat(weight[1]) || 0;
      weightKg = /kg|千克|公斤/i.test(weight[2]) ? value : value / 1000;
    }
    let lengthCm = 0;
    let widthCm = 0;
    let heightCm = 0;
    if (dims) {
      const unit = String(dims[4] || "cm").toLowerCase();
      const factor = unit === "mm" || unit === "毫米" ? 0.1 : unit === "米" ? 100 : 1;
      lengthCm = (parseFloat(dims[1]) || 0) * factor;
      widthCm = (parseFloat(dims[2]) || 0) * factor;
      heightCm = (parseFloat(dims[3]) || 0) * factor;
    }
    return {
      weightKg,
      lengthCm,
      widthCm,
      heightCm,
      raw: cleanText(weight ? weight[0] : ""),
      dimsRaw: cleanText(dims ? dims[0] : ""),
    };
  }

  /**
   * 商品编码。v1.9.74 新增 —— 用户点名要采「商品编码」，之前整条链路都没有这个字段。
   *
   * 三个来源，按可信度排序：
   *  ① 属性区里的「货号 / 商品编码 / 型号 / 物料编码」—— 商家真正在用的编码，最准；
   *  ② 商品 URL 里的 offerId（detail.1688.com/offer/<数字>.html）—— 1688 商品唯一 ID，
   *     永远存在且稳定，作为兜底；
   *  ③ 内联数据里的 productId / offerId。
   * 拿不到就返回空串，不编造。
   */
  function pickProductCode(cache, attributes = []) {
    const CODE_NAMES = /^(货号|商品编码|产品编码|物料编码|编码|型号|产品型号|商品货号|sku编码|SKU编码|款号|编号)$/i;
    for (const item of attributes || []) {
      const name = cleanText(item && item.name);
      if (!name || !CODE_NAMES.test(name)) continue;
      const value = cleanText(item.value);
      if (value && value.length <= 60) return value;
    }
    // 属性区没命中时，退一步在属性区文本里找「货号 xxx」这种一行
    const hit = cache.scopeText().match(/(?:货号|商品编码|产品编码|物料编码|款号)\s*[:：]?\s*([A-Za-z0-9][A-Za-z0-9\-_.]{2,40})/);
    if (hit) return cleanText(hit[1]);
    // URL 兜底：1688 商品详情页一定是 /offer/<数字>.html
    const urlHit = String(location.href || "").match(/\/offer\/(\d{6,})\.html/i);
    if (urlHit) return urlHit[1];
    const dataHit = String(cache.scripts() || "").match(/"(?:productId|offerId|productID)"\s*:\s*"?(\d{6,})"?/);
    return dataHit ? dataHit[1] : "";
  }

  function pickLogistics(cache) {
    // v1.9.69：发货地/运费只在商品主体区里找
    const bodyText = cache.scopeText();
    const from = (bodyText.match(/发货地[^\n]{0,20}/) || [""])[0];
    const freight = (bodyText.match(/(?:快递|物流|运费)[^\n]{0,30}/) || [""])[0];
    return {
      from: cleanText(from),
      freightText: cleanText(freight),
      freightCny: parseFreightCny(freight),
      express: cleanText(text(".express-fee, .logistics-fee") || ""),
    };
  }

  function pickDescription(cache) {
    const value = U.meta("og:description");
    if (value) return value;
    const rich = document.querySelector("#mod-detail-description, .detail-description, .description-content");
    // innerText 对整块详情可能很贵，限定在一小块里取
    if (rich) return cleanText((rich.innerText || rich.textContent || "")).slice(0, 3000);
    // v1.9.69：最后的兜底也只在商品主体区里取，避免把整页（含推荐位）当成商品描述
    return cleanText(cache.scopeText()).slice(0, 3000);
  }

  const adapter = registry.createAdapter({
    platform: "1688",
    label: "1688",
    matchHosts: ["1688.com"],
    async capture() {
      const cache = U.createPageCache();
      const notes = [];
      const startedAt = Date.now();

      // 懒加载图集：先看现在有没有，没有才等（最多 900ms），不再无脑等满 2.5s
      await cache.time("等待页面就绪", () => U.waitForImages(
        [
          ".detail-gallery img", "[class*=gallery] img", "[class*=thumb] img",
          "[class*=turn] img", "[class*=pic] img", "[class*=swiper] img", "#dt-tab img",
        ],
        { timeout: 900 },
      ));

      // v1.9.67 顺序调整：轻扫必须在抓图**之前**。
      // 旧写法是「先抓图集、再轻扫详情区」——新版 1688 的图集缩略图也是懒加载的，
      // 先抓就只拿到空壳；而且详情长图本来就在同一次扫描里被逼出来，两次扫描合成一次。
      await cache.time("懒加载轻扫", () => sweepForLazyImages());

      const picked = await cache.time("图片", () => pickImages(cache));
      const images = picked.images;
      // 详情长图单独一组：默认不进主图集，避免 1688 的营销长图把 Ozon 图片位占满
      const detailImages = await cache.time("详情长图", () => pickDetailImages(images));
      const { options: specOptions, images: specImages, disabled: specDisabled = {} } = await cache.time("规格维度", () => pickSpecOptions());
      // SKU 优先取页面上真实可见的表格行（规格 / 价格 / 库存），拿不到再用内联 JSON，
      // 都不行最后按可见文本行解析（新版 DOM 类名混淆，选择器经常全空）
      const tableSkus = await cache.time("SKU 表格行", () => pickSkuTableRows(specOptions));
      const dataSkus = await cache.time("SKU 内联数据", () => pickSkusFromData(cache));
      const textSkus = await cache.time("SKU 文本行", () => pickSkuRowsFromText(cache, specOptions));
      // 变体缩略图只从 DOM 行里拿（文本行没有图），先抓出来备用
      const domRowSkus = await cache.time("SKU 变体图", () => pickSkuRowsFromDom());
      // 给内联 JSON 的 SKU 也补上规格图（按 specs 里的值匹配）
      for (const sku of dataSkus) {
        if (sku.image) continue;
        for (const [name, value] of Object.entries(sku.specs || {})) {
          const candidate = specImages[`${name}:${value}`];
          if (candidate) { sku.image = candidate; break; }
        }
      }
      // 三个来源择优：分数高者胜。但**条数**也是一票 ——
      // v1.9.74：真实案例是表格行只命中 1 条（容器污染），文本行有 30 条，
      // 而那 1 条因为「有价有库有规格」分数反而更高，于是 30 个变体被 1 条顶掉。
      // 规则：若最优源只有 1 条、而别的源 >= 3 条，说明最优源是「命中了容器」，
      // 改用条数更多的源（多出来的是真变体，比少而「完整」的一条可信）。
      let skus = [tableSkus, dataSkus, textSkus].reduce(
        (best, list) => (scoreSkuList(list) > scoreSkuList(best) ? list : best),
        [],
      );
      const richer = [tableSkus, dataSkus, textSkus]
        .filter((list) => list.length >= 3)
        .sort((a, b) => b.length - a.length)[0];
      if (skus.length <= 1 && richer && richer.length >= 3) {
        notes.push(`SKU 表格行只解析出 ${skus.length} 条（疑似命中了外层容器），已改用识别到 ${richer.length} 条的来源`);
        skus = richer;
      }
      // 三个来源都空、但 DOM 行抓到了（规格/价格/库存齐全）时，DOM 行直接当 SKU 源
      if (!skus.length && domRowSkus.length) {
        skus = domRowSkus.map((sku) => ({ ...sku, specs: splitSpecLabel(sku.label, specOptions) }));
      }
      if (!skus.length && specOptions.length) {
        notes.push("未取到 SKU 价格矩阵，仅识别到规格维度，需要人工补价");
        skus = buildSkusFromOptions(specOptions, specImages, specDisabled);
      }
      // 变体图：行级 DOM 图最准，其次规格色卡图。挂上后上传时它就是该变体的主图。
      const imageFilled = attachSkuImages(skus, domRowSkus, specImages);
      if (imageFilled) {
        notes.push(`${imageFilled} 个 SKU 已配上变体图，上传时会作为该变体的主图`);
      } else if (skus.length) {
        notes.push("没抓到变体图（列表可能未展开或图片懒加载未触发），变体将共用整单主图");
      }
      // 规格维度里被判「不可选/售罄」的值：命中它的 SKU 标成 unavailable，
      // 面板默认不勾选，避免上架一个「传上去就是缺货」的变体
      if (Object.keys(specDisabled).length) {
        let marked = 0;
        for (const sku of skus) {
          if (sku.unavailable) continue;
          for (const [name, value] of Object.entries(sku.specs || {})) {
            if (specDisabled[`${name}:${value}`]) {
              sku.unavailable = true;
              sku.unavailableReason = `规格「${name}:${value}」在 1688 页面上是置灰/售罄状态`;
              marked += 1;
              break;
            }
          }
        }
        if (marked) notes.push(`${marked} 个 SKU 命中不可选规格（置灰/售罄），默认未勾选，上架前请核对`);
      }
      const logistics = await cache.time("物流", () => pickLogistics(cache));
      const parcel = await cache.time("毛重与尺寸", () => pickParcel(cache));
      if (!skus.length && !specOptions.length) {
        notes.push("未识别到 SKU 规格（页面可能是新版 DOM 或需先展开规格选择区），可在「SKU 与成本」里手动补规格");
      }
      if (!images.length) {
        const l = picked.layers || {};
        notes.push(`未识别到产品图（主图位 ${l.main || 0} / 缩略图位 ${l.thumbs || 0} / 图集兜底 ${l.fallback || 0} / 图床兜底 ${l.host || 0}），页面结构可能又改版了，请把这条备注发给开发者`);
      } else if (picked.layers?.host) {
        notes.push(`图集选择器全部落空，已按阿里图床路径兜底捞到 ${picked.layers.host} 张商品图，请核对`);
      }
      let price = await cache.time("价格", () => pickPrice(cache));
      const sales = await cache.time("销量", () => pickSales(cache));
      // SKU 表里有真实采购价时，SKU 价格就是成本的权威来源：
      // 整页价格区容易混进脏数据（「¥100.00」和「1起批」拼成 100.001、销量「750+」被当价格）
      const skuPrices = skus
        .map((sku) => Number(sku.basePrice) || Number(sku.price) || 0)
        .filter((value) => value > 0);
      if (skuPrices.length) {
        const sMin = Math.min(...skuPrices);
        const sMax = Math.max(...skuPrices);
        const rawClean = String(price.raw || "").replace(/[,\s]/g, "");
        const dirty = Boolean(price.raw) && !/^\d+(?:\.\d{1,2})?$/.test(rawClean);
        const outside = price.min > 0 && (price.min < sMin * 0.5 || price.min > sMax * 3);
        if (!(price.min > 0)) {
          price = { min: sMin, max: sMax, raw: String(sMin) };
          notes.push("页面价格区没抓到，已用 SKU 表里的采购价，请核对");
        } else if (dirty || outside) {
          notes.push(`页面价格区抓到 ¥${price.min}~${price.max}，疑似脏数据或与 SKU 表对不上，已改用 SKU 采购价 ¥${sMin}~${sMax}`);
          price = { min: sMin, max: sMax, raw: String(sMin) };
        }
      }
      // 整单有价但 SKU 没价时（规格维度展开出来的空行），用整单价填进去 —— 成本不能空着
      if (Number(price.min) > 0 && skus.length) {
        let filled = 0;
        for (const sku of skus) {
          if (!(Number(sku.price) > 0)) {
            sku.price = price.min;
            // basePrice 只在还没有采集原价时补；否则内联数据里「price 含运费、basePrice 是原价」
            // 这种条目会被整单价顶掉原价，成本列核价就丢了一段运费依据
            if (!(Number(sku.basePrice) > 0)) sku.basePrice = price.min;
            filled += 1;
          }
        }
        if (filled) notes.push(`${filled} 个 SKU 没取到单独报价，已按整单采集价 ¥${price.min} 填成本`);
      }
      // 成本 = 1688 采集价 + 运费（页面上「运费 ¥11 起」）；原始采集价保留在 basePrice
      const freightCny = Number(logistics.freightCny) || 0;
      if (freightCny > 0 && skus.length) {
        let touched = 0;
        for (const sku of skus) {
          if (Number(sku.price) > 0) {
            sku.basePrice = Number(sku.basePrice) || sku.price;
            sku.price = Math.round((sku.price + freightCny) * 100) / 100;
            touched += 1;
          }
        }
        if (touched) notes.push(`SKU 成本已含 1688 运费 ¥${freightCny}（采集原价保留在 basePrice）`);
      }
      if (price.max > price.min) {
        notes.push(`识别到区间价 ¥${price.min}~${price.max}，定价时请确认用哪一档作为成本`);
      }
      if (images.length === 1) notes.push("只识别到 1 张产品图，建议人工确认是否漏图");
      if (detailImages.length) {
        notes.push(`另采集到 ${detailImages.length} 张商品详情长图，可在「图片 → 商品详情长图」里勾选并入`);
      }

      const title = pickTitle(cache);
      const attributes = await cache.time("属性", () => pickAttributes(cache));
      // v1.9.74 商品编码：属性区「货号」优先，URL 里的 offerId 兜底
      const productCode = pickProductCode(cache, attributes);
      if (!productCode) {
        notes.push("没采到商品编码（属性区没有「货号」，URL 里也没拿到 offer ID），导出上架表时货号会用自动编号");
      }
      if (!title) {
        notes.push("没能从页面取到商品标题（页面上的候选标题都是店铺名 / 公司名）。请在「商品词 / 品类」手动填写品类后再生成文案");
      } else {
        // v1.9.69 一致性校验：标题必须能在商品主体区里找到。
        // 找不到说明它来自页面别处（推荐位 / 猜你喜欢里的别的商品），必须让用户知道。
        const scope = cache.scope();
        const scoped = scope && scope !== document.body && scope !== document.documentElement
          ? cleanText(scope.innerText || scope.textContent || "")
          : "";
        if (scoped && scoped.indexOf(title) < 0) {
          notes.push(`采集到的标题不在商品主体区内（" ${title.slice(0, 24)}…"），可能命中了推荐位里别的商品，请核对标题`);
        }
      }

      return {
        platform: "1688",
        sourceUrl: location.href,
        title,
        productCode,
        shopName: pickShop(),
        shopUrl: pickShopUrl(),
        price: { min: price.min, max: price.max, currency: "CNY", raw: price.raw },
        salesText: sales.text,
        sales: sales.number,
        stock: await cache.time("库存", () => pickStock(cache)),
        mainImage: picked.mainImage || images[0] || "",
        images,
        imageMeta: picked.imageMeta,
        detailImages,
        videos: pickVideos(),
        specOptions,
        specImages,
        skus,
        attributes,
        logistics,
        parcel,
        description: await cache.time("详情", () => pickDescription(cache)),
        timings: { ...cache.timing, total: Date.now() - startedAt },
        diagnostics: { notes: notes.concat(this.takeNotes()) },
      };
    },
  });

  function buildSkusFromOptions(options, specImages = {}, specDisabled = {}) {
    // 规格值→图片的健壮匹配：先严格匹配，再按「去空格+小写」归一化匹配，
    // 解决「红色」与「红」之类同义挂不上图的问题。
    function findSpecImage(name, value) {
      if (!specImages || !name) return "";
      const exact = specImages[`${name}:${value}`] || specImages[`${name}:${String(value).trim()}`];
      if (exact) return exact;
      const specBase = (v) => String(v).trim().toLowerCase().replace(/\s+/g, "").replace(/色系$/, "").replace(/色$/, "");
      const nn = specBase(name);
      const nv = specBase(value);
      if (!nv) return "";
      for (const key of Object.keys(specImages)) {
        const i = key.indexOf(":");
        if (i < 0) continue;
        const kn = specBase(key.slice(0, i));
        const kv = specBase(key.slice(i + 1));
        if (kn === nn && kv === nv) return specImages[key];
      }
      return "";
    }
    // 笛卡尔积展开规格组合，价格留 0 由用户补；如果规格值有图，优先挂到对应 SKU。
    // v1.9.75：原来写死「前 2 个维度 × 各前 12 个值、上限 60 条」——多规格商品
    //（颜色 8 × 尺码 6 × 款式 3 = 144 个真变体）会被砍到只剩一小撮，用户看到的就是
    //「页面上还有很多规格，插件只采到这些」。改为：所有维度参与、单维度值上限放宽到 40、
    // 组合上限放宽到 300（与 Ozon 单次上传上限 100 对齐后还留足余量）。
    //
    // ⚠️ 截断必须在**所有维度都展开完**之后做，不能在循环里 break ——
    // 中途 break 会让后面的维度整个不参与（实测：「款式」维度会全丢，
    // 因为前两个维度已经超过上限就跳出了循环）。
    const MAX_SPEC_DIMENSIONS = 4;
    const MAX_VALUES_PER_DIMENSION = 40;
    const MAX_SKU_COMBOS = 300;
    let combos = [[]];
    let truncated = false;
    for (const option of options.slice(0, MAX_SPEC_DIMENSIONS)) {
      const next = [];
      for (const combo of combos) {
        for (const value of option.values.slice(0, MAX_VALUES_PER_DIMENSION)) {
          next.push(combo.concat([{ name: option.name, value }]));
        }
      }
      combos = next;
      if (combos.length > MAX_SKU_COMBOS) truncated = true;
    }
    if (truncated) combos = combos.slice(0, MAX_SKU_COMBOS);
    return combos.map((combo, index) => {
      const specs = {};
      for (const item of combo) specs[item.name] = item.value;
      // 找第一个有规格图的维度作为该 SKU 的展示图
      let image = "";
      for (const item of combo) {
        const candidate = findSpecImage(item.name, item.value);
        if (candidate) { image = candidate; break; }
      }
      // 组合里任一维度值不可选 → 该组合整体不可选（颜色×尺码的联动在 1688 上通常整行置灰）
      const blocked = combo.find((item) => specDisabled[`${item.name}:${item.value}`]);
      return {
        id: `gen_${index}`,
        specs,
        price: 0,
        stock: 0,
        image,
        label: Object.values(specs).join(" / "),
        ...(blocked
          ? { unavailable: true, unavailableReason: `规格「${blocked.name}:${blocked.value}」在 1688 页面上是置灰/售罄状态` }
          : {}),
      };
    });
  }

  registry.adapters.push(adapter);
  /**
   * SKU 采集诊断（v1.9.75 新增）。
   *
   * 目的：采集不准时把**页面真实结构**吐出来，而不是靠猜。
   * 输出三个东西：
   *  ① 每个 SKU 行选择器各命中几个节点；
   *  ② 命中的节点长什么样（tagName / class / 文本前 200 字）；
   *  ③ 商品主体区里所有含「库存」的文本行（去重后前 60 条）+ 每个变体区块的 DOM 路径。
   * 这一份发回来，就能确定选择器该怎么改。
   */
  function diagnoseSkuStructure() {
    const out = { url: location.href, selectors: [], sampleRows: [], stockLines: [], anchors: [] };

    for (const selector of SKU_ROW_SELECTORS) {
      const nodes = all(selector);
      out.selectors.push({ selector, count: nodes.length });
      // 每个选择器取前 3 个节点做样本（结构可能一个选择器命中多种容器）
      for (const node of nodes.slice(0, 3)) {
        const text = cleanText(node.textContent || "");
        out.sampleRows.push({
          selector,
          tag: (node.tagName || "").toLowerCase(),
          class: String(node.className || "").slice(0, 120),
          childCount: (node.children || []).length,
          textLength: text.length,
          text: text.slice(0, 220),
          stockAnchors: countStockAnchors(text),
          hasPriceSymbol: /[¥￥]/.test(text),
        });
      }
    }

    // 商品主体区里的「库存」文本行 —— 这才是最终要解析的东西
    const seenLine = new Set();
    for (const line of cacheTextLines()) {
      if (!/库存|可售/.test(line)) continue;
      const key = line.slice(0, 60);
      if (seenLine.has(key)) continue;
      seenLine.add(key);
      out.stockLines.push({ len: line.length, anchors: countStockAnchors(line), text: line.slice(0, 300) });
      if (out.stockLines.length >= 60) break;
    }

    // 以「库存」文本节点为锚点，记录它的祖先链（前 12 个），看真正的一行长在哪层
    if (document.body && typeof document.createTreeWalker === "function") {
      const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
      let node = walker.nextNode();
      let guard = 0;
      while (node && out.anchors.length < 12 && guard < 20000) {
        guard += 1;
        if (/库存|可售/.test(node.nodeValue || "")) {
          const chain = [];
          let cur = node.parentElement;
          for (let d = 0; d < 8 && cur; d += 1) {
            const text = cleanText(cur.textContent || "");
            chain.push({
              tag: (cur.tagName || "").toLowerCase(),
              class: String(cur.className || "").slice(0, 100),
              textLength: text.length,
              anchors: countStockAnchors(text),
              hasPrice: /[¥￥]/.test(text),
              text: text.slice(0, 140),
            });
            // 已经装不下更多行了就别再往上记
            if (countStockAnchors(text) > 1) break;
            cur = cur.parentElement;
          }
          out.anchors.push(chain);
        }
        node = walker.nextNode();
      }
    }

    // 规格维度识别结果
    try {
      const spec = pickSpecOptions();
      out.specOptions = (spec.options || []).map((option) => ({
        name: option.name,
        count: (option.values || []).length,
        values: (option.values || []).slice(0, 20),
      }));
    } catch (error) {
      out.specOptions = [{ error: String(error?.message || error) }];
    }
    return out;
  }

  /** 商品主体区文本按行返回（诊断用，走和采集同一套取数逻辑） */
  function cacheTextLines() {
    const scope = U.resolveProductScope ? U.resolveProductScope() : document.body;
    const text = scope && scope !== document.body
      ? cleanText(scope.innerText || scope.textContent || "")
      : cleanText(document.body ? document.body.innerText || "" : "");
    return text.split(/\n+/).map((line) => cleanText(line)).filter(Boolean);
  }

  // 暴露纯函数给 tools/self-test.mjs 在 vm 里直接回归（不参与运行时逻辑）
  registry.sku1688 = {
    parseSkuRow,
    splitSpecLabel,
    // v1.9.74 新增：规格名清洗 + 整段切分 + 库存锚点计数（自测直接回归）
    cleanSpecLabel,
    splitSkuBlob,
    countStockAnchors,
    // v1.9.82 矩阵式 SKU 行展开（自测直接回归）
    expandSkuMatrixRow,
    expandSkuLineToSkus,
    pickProductCode,
    diagnoseSkuStructure,
    buildSkusFromOptions,
    scoreSkuList,
    extractPriceStock,
    parseFreightCny,
    isSpecNoise,
    imageAreaScore,
    pickMainImage,
    pickSkuRowsFromText,
    pickSkuRowsFromDom,
    attachSkuImages,
    pickRowThumbnail,
    skuLabelKey,
    pickTitle,
    looksLikeCompanyName,
  };
})(window);
