// 面板主控制器：绑定各视图交互，所有外部请求都通过后台 service worker 发起。
import {
  AI_PRESETS, IMAGE_PRESETS, XIANGJI_VENDORS, MESSAGE_ACTIONS, STORAGE_KEYS,
  validateImageSize, effectiveSupportedSizes, pickListingSetSize,
  IMAGE_SIZE_TIERS, IMAGE_SIZE_RATIOS, DEFAULT_SIZE_RATIO, DEFAULT_SIZE_TIER,
  sizeForRatio, findSizeRatio, resolveProviderSize, BUILT_IN_UPDATE_URL, BUILT_IN_UPDATE_MIRROR,
} from "../shared/constants.js";
import {
  IMAGE_KINDS, DEFAULT_SET_KINDS, DEFAULT_KIND_LIMITS, DEFAULT_SET_COUNT, MAX_SET_SHOTS,
  TEXT_MODES, MAX_REFERENCE_IMAGES, pickStyleFor, findKind, expandSetShots, planSetShots, assignSetDirections,
  SKU_MAIN_SHOT, assignShotVariants, nextShotVariant,
} from "../shared/image-prompts.js";
import { loadSettings, saveSettings, xiangjiConfiguredVendors } from "../shared/settings.js";
// v1.9.73 策划师模式：卖点排序 + 8 图固定结构方案 + 逐张出图指令 + 方案导出
import { parsePlanResult, buildPlannedPrompt, renderPlanMarkdown } from "../shared/image-plan.js";
import {
  DEFAULT_LISTING_TEMPLATE, OZON_CHANNELS, normalizeListingTemplate, computeListing, splitCostCny,
} from "../shared/pricing.js";
import { cleanText, createId, imagesEndpoint, extractApiConfig, normalizeApiBase, highResImageUrl } from "../shared/utils.js";
import { draftFromProduct, listDrafts, saveDraft, getDraft, deleteDraft, clearDrafts } from "./drafts.js";
import {
  $, $$, el, toast, setBadge, renderTable, kv, switchTab, downloadBlob, openModal, confirmDialog, loadImage,
} from "./dom.js";
import { exportCsv, exportXlsx, exportListingXlsx } from "./exporter.js";
import { isLikelyProductImage, productImageReason } from "../shared/image-filter.js";
import { validateAttributeValues, buildStableModel, matchSpecImage, sanitizeOfferId, snapAttributeValues, reconcileAttributes, classifyOzonImportErrors, productIdentity } from "../shared/product-model.js";
import { detectProductDomains, domainsOfPath } from "../shared/category-keywords.js";
import { collectBrandRisks, isBrandAttribute, isNoBrandValue, pickNoBrandFromDictionary } from "../shared/brand-risk.js";
import { isPlaceholderProductType } from "../shared/prompts.js";
import {
  RICH_CONTENT_ATTR_ID, RICH_CONTENT_MAX_BLOCKS,
  pickRichContentImages, buildRichContentJson, buildRichContentFallback,
  validateRichContentJson, summarizeRichContent,
} from "../shared/rich-content.js";
import { attrTypeZh, isChineseText } from "../shared/offline-kb.js";
import { getLicenseStatus, activateLicense, getMachineId, formatMachineId, trialHoursLeft } from "../shared/license.js";

const state = {
  settings: null,
  product: null,      // 最近一次采集结果
  productTabs: [],    // 检测到的标签页（含 productPage 标记）
  productTabsKnown: false, // 列表是否真的查过一次（决定采集结果卡要不要校验来源页）
  draft: null,        // 当前编辑的草稿
  templates: null,
  categoryTree: [],
  categoryTreeSource: "",     // v1.9.65 类目树来源：local（本地完整树）/ cache（历史缓存）/ api（实时拉取）
  categoryTreeStats: null,    // v1.9.65 类目树规模统计：{ domains, categories, types, pending, usable }
  categoryNode: null,
  categoryAttributes: [],   // 当前类目「类型」要求的属性定义（v1.9.55 起来自官方元数据缓存）
  attrMetaInfo: null,       // v1.9.55 属性元数据来源：{ source: "cache"|"network", at, fingerprint }
  attrCheck: null,          // v1.9.55 最近一次属性对账结果（reconcileAttributes 的 report）
  categoryZh: {},           // Ozon 原名 → 中文名（Ozon 只给 RU/EN，界面中文靠这一层）
  zhKeyword: {},            // 中文搜索词 → 俄语关键词（用于按中文搜类目）
  attributeZh: {},         // Ozon 属性名/枚举值 → 中文名（类目属性表显示用）
  categoryExpanded: new Set(), // 展开的类目层级节点（树默认折叠，避免一次渲染上万条俄文节点）
  watermarked: [],    // { name, dataUrl }
  translated: [],     // { name, url } 象寄翻译结果
  redrawn: [],        // { name, dataUrl, url }
  setGen: [],         // 上架套图生成结果 { shot, label, title, dataUrl, url, error, variant }
  setGenArt: null,    // v1.9.49 出图前视觉分析：{ comparison, shots: { shotId: { layout, artDirection, why } } }
  setGenKindIds: [...DEFAULT_SET_KINDS],   // 勾选的图片类型
  setGenRatio: DEFAULT_SIZE_RATIO,         // 尺寸比例（3:4）
  setGenTier: DEFAULT_SIZE_TIER,           // 分辨率档（1K/2K/4K）
  setGenCount: DEFAULT_SET_COUNT,          // 生成张数上限
  setGenPoints: [],                        // 卖点 [{ text, on }]
  setGenTitles: {},                        // shotId → { title, subtitle }（AI 拟的俄文标题）
  setGenLabels: [],                        // 规格标签（俄文，给规格标注图/参数表用）
  aiImageOnly: false,                      // v1.9.51 图片列表「筛选 AI 图片」开关：只显示 AI 生成的图
  setKindLimits: { ...DEFAULT_KIND_LIMITS }, // v1.9.52 每种图片类型出几张（用户手填；key 不存在 = 该类全部拍法都出）
  categoryCandidates: [], // AI 匹配的类目候选（卡片展示用）
  pendingCategoryNode: null, // 用户在类目树里点选的待确认节点
  draftCategoryStale: null, // null=未校验；{reason}=草稿类目与本地中文树不一致；已修正后会置 null
  xiangjiKeyRows: null, // 设置页正在编辑的象寄密钥行（null = 尚未从设置里生成）
  selectedImages: new Set(), // 勾选的产品图 URL
  selectedDetailImages: new Set(), // 勾选的 1688 详情长图 URL（并入图片集用）
  selectedSkus: new Set(),    // 勾选参与定价/库存的 SKU id
  attrDictLoading: false,     // 正在拉枚举属性候选值（防止重复打请求）
  // v1.9.73 策划师模式
  plan: null,                 // { sellingPoints:[], bestIndex, shots:[] }
  planGen: [],                // 每张方案图的出图结果 [{ slot, key, label, dataUrl, url, error, prompt }]
  planDraftId: "",            // 方案归属的草稿 id；换草稿即作废，防止 A 商品方案串到 B
};

function send(message) {
  return chrome.runtime.sendMessage(message);
}


/** 当前在 Ozon 页选中的店铺 id；未选（默认店铺）时为空串 */
function currentStoreId() {
  return $("#store-select")?.value || "";
}

async function call(message) {
  // 单店操作统一跟随 Ozon 页的店铺下拉；多店批量上传走 storeIds，不注入
  if (message.action?.startsWith("ozon") && message.storeId === undefined && message.action !== MESSAGE_ACTIONS.ozonBulkImport) {
    message.storeId = currentStoreId();
  }
  const response = await send(message);
  if (!response?.ok) throw new Error(response?.error || "操作失败");
  return response.data;
}

/* ---------------- 视图切换 ---------------- */

function bindTabs() {
  for (const tab of $$(".tab")) {
    tab.addEventListener("click", () => switchTab(tab.dataset.tab));
  }
}

/* ---------------- 采集 ---------------- */

function bindCapture() {
  $("#btn-capture").addEventListener("click", () => detectAndCapture());
  $("#btn-reload-tabs").addEventListener("click", async () => {
    await refreshProductTabs();
    const count = (state.productTabs || []).length;
    toast(count ? `检测到 ${count} 个商品页` : "未检测到商品页", count ? "ok" : "error");
  });

  $("#btn-diagnose").addEventListener("click", async () => {
    const output = $("#diagnose-output");
    output.hidden = false;
    output.textContent = "诊断中…";
    try {
      const report = await call({ action: MESSAGE_ACTIONS.diagnose });
      output.textContent = JSON.stringify(report, null, 2);
      const hint = report?.hints?.[0];
      toast(hint || "诊断完成，看下方输出", report?.matchedTabs?.length ? "ok" : "error");
    } catch (error) {
      output.textContent = `诊断失败：${error.message}`;
      toast(error.message, "error");
    }
  });

  $("#btn-copy-diagnose").addEventListener("click", async () => {
    const text = $("#diagnose-output").textContent || "";
    if (!text) return toast("请先运行诊断", "error");
    try {
      await navigator.clipboard.writeText(text);
      toast("已复制", "ok");
    } catch {
      toast("复制失败，请手动选中复制", "error");
    }
  });

  // v1.9.75 SKU 采集诊断：把 1688 页面的真实结构吐出来（选择器命中数 / 节点样本 / 库存行）
  $("#btn-diagnose-sku")?.addEventListener("click", async () => {
    const output = $("#diagnose-sku-output");
    if (!output) return;
    output.hidden = false;
    output.textContent = "正在读取 1688 页面的 SKU 结构…";
    try {
      const reply = await call({ action: MESSAGE_ACTIONS.diagnoseSku });
      if (!reply?.ok) {
        output.textContent = `SKU 诊断失败：${reply?.error || "未知错误"}`;
        return toast(reply?.error || "SKU 诊断失败", "error");
      }
      const data = reply.data || {};
      output.textContent = JSON.stringify(data, null, 2);
      const hit = (data.selectors || []).filter((item) => item.count > 0).length;
      toast(`诊断完成：${hit} 个选择器命中，库存行 ${data.stockLines?.length || 0} 条。点「复制 SKU 诊断」发给我`, "ok");
    } catch (error) {
      output.textContent = `SKU 诊断失败：${error.message}`;
      toast(error.message, "error");
    }
  });

  $("#btn-copy-diagnose-sku")?.addEventListener("click", async () => {
    const text = $("#diagnose-sku-output")?.textContent || "";
    if (!text || text.startsWith("正在读取") || text.startsWith("SKU 诊断失败")) {
      return toast("请先点「诊断 SKU 采集」", "error");
    }
    try {
      await navigator.clipboard.writeText(text);
      toast("已复制，粘贴给我就行", "ok");
    } catch {
      toast("复制失败，请手动选中复制", "error");
    }
  });

  $("#btn-reload-last").addEventListener("click", async () => {
    const result = await chrome.storage.local.get(STORAGE_KEYS.lastCapture);
    const product = result?.[STORAGE_KEYS.lastCapture];
    if (!product) return toast("没有上次的采集记录", "error");
    state.product = product;
    renderCapture(product);
    setBadge("#capture-platform", product.platform, "ok");
  });

  $("#btn-save-draft").addEventListener("click", async () => {
    if (!state.product) return toast("请先采集商品", "error");
    // 复用采集时已建立的草稿，避免重复创建
    const base = draftFromProduct(state.product);
    const draft = state.draft
      ? await saveDraft({ ...base, id: state.draft.id })
      : await saveDraft(base);
    state.draft = draft;
    state.selectedImages = new Set(draft.images || []);
    state.selectedDetailImages.clear();
    await refreshDraftOptions(draft.id);
    toast("已保存为草稿", "ok");
    renderEditor();
    await renderBulkLists();
    $("#workspace")?.scrollIntoView({ behavior: "smooth", block: "start" });
    // 采集即接管：AI 自动匹配中文类目 → 生成俄语文案 → 算好价格，全部写回草稿
    setBadge("#ai-pipe-status", "AI 填写中…", "warn");
    await aiAutoFillDraft();
    renderEditor();
    setBadge("#ai-pipe-status", "AI 已填好，可核对后上传", "ok");
  });
}

async function refreshProductTabs() {
  try {
    state.productTabs = await call({ action: MESSAGE_ACTIONS.listProductTabs });
  } catch {
    state.productTabs = [];
  }
  // 标记「这次列表是真的查过」，采集结果卡据此判断来源页是否还在——
  // 没查过就不报警告，避免误报「来源页已关闭」
  state.productTabsKnown = true;
  renderProductTabs();
  return state.productTabs || [];
}

/** 标签页地址的短显示形式：host + path，丢掉 spm / from 这类跟踪参数 */
function shortUrl(url) {
  try {
    const u = new URL(url);
    return `${u.hostname}${u.pathname}`;
  } catch {
    return String(url || "");
  }
}

function renderProductTabs() {
  const wrap = $("#product-tabs");
  wrap.innerHTML = "";
  const tabs = state.productTabs || [];
  $("#product-tabs-empty").hidden = tabs.length > 0;
  for (const tab of tabs) {
    let host = "";
    try { host = new URL(tab.url).hostname; } catch { host = tab.url; }
    // 旧后台没有 productPage 字段时按「是商品页」处理，避免升级瞬间把列表清空
    const isProduct = tab.productPage !== false;
    const row = el("div", { class: "row" }, [
      el("span", { class: `badge${tab.active ? " ok" : ""}`, text: host }),
      el("span", { class: "muted", text: (tab.title || "").slice(0, 60) }),
      el("span", { class: "muted", text: shortUrl(tab.url) }),
    ]);
    if (!isProduct) {
      // 首页 / 搜索页 / 店铺页：采出来只会是推荐位的数据，跟用户要的商品无关
      row.appendChild(el("span", { class: "badge err", text: "非商品详情页" }));
    }
    row.appendChild(el("button", { text: isProduct ? "采集这一页" : "仍要采集", onclick: () => doCapture(tab.id) }));
    wrap.appendChild(row);
  }
  const nonProduct = tabs.filter((tab) => tab.productPage === false);
  const note = $("#product-tabs-note");
  if (note) {
    note.hidden = !nonProduct.length;
    note.textContent = nonProduct.length
      ? `有 ${nonProduct.length} 个标签页不是商品详情页（1688 首页 / 搜索页 / 店铺页等）。在这类页面上采集只能抓到推荐位的数据，和你要采的商品无关，请打开具体商品的详情页再采集。`
      : "";
  }
}

/**
 * 采集提示区：专门用来回答「这次到底采没采」。
 * 它和「上一次的采集结果」是两个位置 —— 旧实现没有这条通道，
 * 用户在「检测到多个商品页」时点了大按钮、什么都没发生，就会把卡片里
 * 上一次的结果当成这次的采集结果，看起来就是「采集的数据严重不准确」。
 */
function setCaptureNotice(message) {
  const node = $("#capture-notice");
  if (!node) return;
  node.hidden = !message;
  node.textContent = message || "";
}

/** 采集一开始就把结果卡切成「采集中」，清掉上一件商品的标题 / 主图 / 价格 */
function beginCaptureCard(targetLabel) {
  const card = $("#capture-result");
  if (!card) return;
  card.hidden = false;
  const thumb = $("#capture-thumb");
  if (thumb) {
    thumb.removeAttribute("src");
    thumb.alt = "采集中…";
    thumb.onclick = null;
    thumb.onkeydown = null;
    thumb.tabIndex = -1;
  }
  const source = $("#capture-source");
  if (source) source.textContent = `正在采集：${targetLabel}…`;
  $("#capture-title").textContent = "采集中…";
  $("#capture-meta").textContent = "";
  kv("#capture-diagnostics", []);
  const raw = $("#last-capture-raw");
  if (raw) raw.hidden = true;
}

async function detectAndCapture() {
  const tabs = await refreshProductTabs();
  if (!tabs.length) {
    setBadge("#capture-platform", "未检测到", "err");
    const message = "未检测到 1688 / 淘宝 / 拼多多页面。请先打开商品详情页，再点「刷新检测」。";
    setCaptureNotice(message);
    return toast(message, "error");
  }
  // 只有真正的商品详情页才值得自动采：首页 / 搜索页自动采出来一定是错的数据
  const productTabs = tabs.filter((tab) => tab.productPage !== false);
  if (!productTabs.length) {
    setBadge("#capture-platform", "无商品详情页", "err");
    const message = `检测到 ${tabs.length} 个平台页面，但没有一个是商品详情页（都是首页 / 搜索页 / 店铺页）。请打开具体商品的详情页再采集。`;
    setCaptureNotice(message);
    return toast(message, "error");
  }
  if (productTabs.length === 1) return doCapture(productTabs[0].id);
  // 多个商品页时不猜：明确告诉用户「本次没有采集」，并把要点的位置说清楚
  const message = `检测到 ${productTabs.length} 个商品页，本次没有采集任何页面。请点下面某一行的「采集这一页」选择要采的商品。`;
  setCaptureNotice(message);
  toast(message, "warn");
}

async function doCapture(tabId) {
  const tab = (state.productTabs || []).find((item) => item.id === tabId) || null;
  const targetLabel = tab ? shortUrl(tab.url) : `标签页 ${tabId}`;
  setBadge("#capture-platform", "采集中…", "warn");
  setCaptureNotice("");
  // 先把卡片清成「采集中」：这样无论采集成功还是失败，卡片上都不可能再留着上一件商品的数据
  beginCaptureCard(targetLabel);
  const startedAt = Date.now();
  try {
    const data = await call({ action: MESSAGE_ACTIONS.captureProduct, tabId });
    const elapsed = Date.now() - startedAt;
    state.product = data;
    renderCapture(data);
    await syncDraftWithCapture(data);
    state.selectedImages = new Set(state.draft?.images || []);
    state.selectedDetailImages.clear();
    renderEditor();
    // 达瓦式顺序第一步：先把 1688 抓到的 SKU 摆出来让用户确认，再走类目/属性
    await maybeConfirmSkus();
    setBadge("#capture-platform", data.platform, "ok");
    const imageCount = data.images?.length || 0;
    toast(
      imageCount
        ? formatCaptureTiming(data.timings, elapsed)
        : `${formatCaptureTiming(data.timings, elapsed)}，但未识别到商品图片，请刷新商品页后重试`,
      imageCount ? "ok" : "error",
    );
  } catch (error) {
    // 采集失败必须显式落在卡片上，绝不保留上一件商品的标题 / 图 / 价格
    setBadge("#capture-platform", "采集失败", "err");
    renderCaptureFailure(targetLabel, error);
    toast(error.message, "error");
  }
}

/**
 * 让草稿跟着「这一件商品」走。
 *
 * 关键修复：旧实现只在「当前没有草稿」时才新建草稿 —— 载入 A 的草稿后去采 B，
 * B 的图片会被并进 A 的草稿、标题还是 A 的，两件商品的数据混在一起。
 * 现在按商品身份键判断：换了商品必然新建草稿，只有同一件商品重复采集才合并图片。
 */
async function syncDraftWithCapture(data) {
  const identity = productIdentity(data.captureSource?.identity || data.sourceUrl || "");
  const draftIdentity = productIdentity(state.draft?.sourceIdentity || state.draft?.sourceUrl || "");
  const sameProduct = Boolean(state.draft) && Boolean(identity) && identity === draftIdentity;
  if (!sameProduct) {
    const carriedOver = Boolean(state.draft);
    state.draft = await saveDraft(draftFromProduct(data));
    await refreshDraftOptions(state.draft.id);
    // 新草稿：默认全部 SKU 都选用，避免沿用上一批的勾选；
    // 但采集端标记为「不可选/售罄」的组合默认不勾选（用户可以手动勾回来）
    state.selectedSkus = new Set((state.draft.skus || []).filter((sku) => !sku.unavailable).map((sku) => sku.id));
    if (carriedOver) {
      setCaptureNotice("这是另一件商品，已新建草稿；上一份草稿原样保留，可在「选择草稿」里切回去。");
    }
    return;
  }
  const prev = state.draft.images || [];
  const merged = [...new Set([...prev, ...(data.images || [])])];
  if (merged.length > prev.length) {
    state.draft = await saveDraft({ id: state.draft.id, images: merged });
  }
}

// 采集耗时提示：总耗时 + 最慢的三步，方便判断慢在哪（页面脚本、内联数据还是图片）
function formatCaptureTiming(timings, fallbackMs) {
  const total = Number(timings?.total) || fallbackMs || 0;
  const steps = Object.entries(timings || {})
    .filter(([key]) => key !== "total")
    .sort((a, b) => b[1] - a[1])
    .slice(0, 3)
    .filter(([, ms]) => ms >= 30)
    .map(([label, ms]) => `${label} ${ms}ms`);
  return `采集成功（${total}ms${steps.length ? ` · ${steps.join("，")}` : ""}）`;
}

/** 采集失败时卡片显示明确的失败态，不保留任何上一件商品的数据 */
function renderCaptureFailure(targetLabel, error) {
  const card = $("#capture-result");
  if (!card) return;
  card.hidden = false;
  const thumb = $("#capture-thumb");
  if (thumb) {
    thumb.removeAttribute("src");
    thumb.alt = "采集失败";
    thumb.onclick = null;
    thumb.onkeydown = null;
    thumb.tabIndex = -1;
  }
  const source = $("#capture-source");
  if (source) source.textContent = `采集目标：${targetLabel} · 本次采集失败`;
  $("#capture-title").textContent = "本次采集失败，没有拿到任何商品数据";
  $("#capture-meta").textContent = String(error?.message || error || "未知错误");
  kv("#capture-diagnostics", [["处理建议", "请确认商品详情页已完全加载（先刷新一次），再点「采集这一页」重试。"]]);
  const raw = $("#last-capture-raw");
  if (raw) raw.hidden = true;
}

function renderCapture(product) {
  const card = $("#capture-result");
  card.hidden = false;
  const captureThumb = $("#capture-thumb");
  captureThumb.src = product.mainImage || "";
  captureThumb.tabIndex = product.mainImage ? 0 : -1;
  captureThumb.alt = product.mainImage ? "主图预览" : "无主图";
  captureThumb.onclick = product.mainImage ? () => openImagePreview(product.mainImage, "商品主图") : null;
  captureThumb.onkeydown = product.mainImage ? (event) => {
    if (event.key === "Enter" || event.key === " ") openImagePreview(product.mainImage, "商品主图");
  } : null;
  captureThumb.onerror = () => { captureThumb.alt = "主图加载失败"; };

  // 来源行：写清「这份数据是从哪一页采的、什么时候采的」，来源页已经不在打开的
  // 标签页里时直接警告 —— 用户据此能立刻发现「卡片里不是这次采集的结果」。
  const sourceNode = $("#capture-source");
  if (sourceNode) {
    const src = product.captureSource || {};
    const at = src.at ? new Date(src.at) : null;
    const timeText = at && !Number.isNaN(at.getTime())
      ? `${String(at.getHours()).padStart(2, "0")}:${String(at.getMinutes()).padStart(2, "0")}:${String(at.getSeconds()).padStart(2, "0")}`
      : "";
    const stillOpen = !state.productTabsKnown || !src.tabId
      ? true
      : (state.productTabs || []).some((tab) => tab.id === src.tabId && shortUrl(tab.url) === shortUrl(src.url));
    const parts = [
      src.url ? `来源页：${shortUrl(src.url)}` : "",
      timeText ? `采集于 ${timeText}` : "",
      !stillOpen && src.url ? "⚠️ 该来源页已关闭或已跳转，这份结果可能不是当前页面的数据" : "",
    ].filter(Boolean);
    sourceNode.textContent = parts.join(" · ");
  }

  $("#capture-title").textContent = product.title || "(无标题)";
  const priceText = product.price?.min
    ? `${product.price.currency} ${product.price.min}${product.price.max && product.price.max !== product.price.min ? `~${product.price.max}` : ""}`
    : "";
  $("#capture-meta").textContent = [
    product.shopName,
    // v1.9.74 商品编码（1688 货号 / offerId）：采集到就在摘要里显示，采集不准时用户一眼能看出来
    product.productCode ? `编码 ${product.productCode}` : "",
    priceText,
    product.salesText,
    `图片 ${product.images?.length || 0}`,
    `SKU ${product.skus?.length || 0}`,
    product.specOptions?.length ? `规格维度 ${product.specOptions.length}` : "",
    product.timings?.total ? `耗时 ${product.timings.total}ms` : "",
  ].filter(Boolean).join(" · ");

  const d = product.diagnostics || {};
  kv("#capture-diagnostics", [
    ["已识别", (d.recognized || []).join("、") || "无"],
    ["未识别", (d.missing || []).join("、") || "无"],
    ["备注", (d.notes || []).join("；") || "无"],
  ]);

  const raw = $("#last-capture-raw");
  raw.hidden = false;
  raw.textContent = JSON.stringify(product, null, 2).slice(0, 6000);
  $("#last-capture-empty").hidden = true;
}

/* ---------------- 草稿与编辑 ---------------- */

async function refreshDraftOptions(selectedId = "") {
  const drafts = await listDrafts();
  const select = $("#draft-select");
  select.innerHTML = '<option value="">— 选择草稿 —</option>';
  for (const draft of drafts) {
    select.appendChild(el("option", { value: draft.id, text: `${draft.title || "(无标题)"} · ${draft.id.slice(-6)}` }));
  }
  if (selectedId) select.value = selectedId;
}

/** 上架工作台步骤条：点击滚动到对应区块，滚动时自动高亮当前区块 */
function bindWorkspace() {
  const steps = $$(".wstep");
  const targets = new Map(
    steps.map((step) => [step.dataset.step, $(`#step-${step.dataset.step}`)]).filter(([, node]) => node),
  );

  const setCurrent = (name) => {
    for (const step of steps) step.classList.toggle("is-current", step.dataset.step === name);
  };

  for (const step of steps) {
    step.addEventListener("click", () => {
      const target = targets.get(step.dataset.step);
      if (target) target.scrollIntoView({ behavior: "smooth", block: "start" });
      setCurrent(step.dataset.step);
      // 进「⑤ 上传」时重算变体属性提示：选用的 SKU / 类目属性可能在别处改过
      if (step.dataset.step === "publish") renderVariantAttrHint();
    });
  }

  if ("IntersectionObserver" in window) {
    const observer = new IntersectionObserver((entries) => {
      const visible = entries.filter((entry) => entry.isIntersecting)
        .sort((a, b) => a.boundingClientRect.top - b.boundingClientRect.top)[0];
      if (visible) setCurrent(visible.target.id.replace("step-", ""));
    }, { rootMargin: "-20% 0px -70% 0px" });
    for (const node of targets.values()) observer.observe(node);
  }
}

function bindEditor() {
  $("#btn-draft-load").addEventListener("click", async () => {
    const id = $("#draft-select").value;
    if (!id) return toast("请选择草稿", "error");
    state.draft = await getDraft(id);
    // 恢复保存过的选择；没有则默认全选（采集端标记不可选的除外）
    state.selectedImages = new Set(state.draft.selectedImages || state.draft.images || []);
    state.selectedDetailImages.clear();
    state.selectedSkus = new Set(state.draft.selectedSkus
      || (state.draft.skus || []).filter((sku) => !sku.unavailable).map((sku) => sku.id));
    renderEditor();
    toast("已载入草稿");
  });

  $("#btn-export-listing").addEventListener("click", () => {
    if (!state.draft) return toast("请先载入草稿", "error");
    exportPreparedListing([state.draft], `ozon-上架表-${(state.draft.title || state.draft.id || "").slice(0, 20)}.xlsx`);
  });

  $("#btn-draft-delete").addEventListener("click", async () => {
    const id = $("#draft-select").value;
    if (!id) return toast("请选择草稿", "error");
    const draft = await getDraft(id);
    if (!draft) return toast("草稿不存在", "error");
    await deleteDraftEverywhere(draft);
  });

  $("#btn-ai-generate").addEventListener("click", () => generateRu(false));
  $("#btn-ai-stream").addEventListener("click", () => generateRu(true));

  // v1.9.64 富内容：AI 生成 / 不调 AI 快速排版 / 清空；文本框实时刷状态，失焦写回草稿
  $("#btn-rich-ai")?.addEventListener("click", () => generateRichContent({ useAi: true }));
  $("#btn-rich-fallback")?.addEventListener("click", () => generateRichContent({ useAi: false }));
  $("#btn-rich-clear")?.addEventListener("click", async () => {
    if (!state.draft) return toast("请先载入草稿", "error");
    if (!richContentText() && !cleanText($("#rich-content")?.value || "")) return toast("富内容本来就是空的", "info");
    const box = $("#rich-content");
    if (box) box.value = "";
    await saveRichContent("");
    updateRichContentStatus();
    toast("富内容已清空", "ok");
  });
  $("#rich-content")?.addEventListener("input", () => updateRichContentStatus());
  $("#rich-content")?.addEventListener("change", async () => {
    if (!state.draft) return;
    const text = cleanText($("#rich-content")?.value || "");
    if (text) {
      const check = validateRichContentJson(text);
      if (!check.ok) {
        toast(`富内容 JSON 有问题：${check.error}`, "error");
        updateRichContentStatus();
        return;
      }
    }
    await saveRichContent(text);
    updateRichContentStatus();
  });

  $("#ru-title").addEventListener("input", () => {
    $("#title-len").textContent = `${$("#ru-title").value.length} 字符`;
  });

  // 「商品词/品类」一旦被用户手动改过就锁定（dirty），后续生成不再覆盖它；
  // 没改过则每次生成都由 AI 重新识别，避免旧值把 AI 的判断也一起带偏。
  $("#ru-product-type")?.addEventListener("input", (event) => {
    const node = event.currentTarget;
    const value = String(node.value || "").trim();
    // v1.9.63：占位值（未知商品 / 未指定…）不算「用户填的品类」，不锁定，
    // 免得把模型自己吐出来的废话当成用户意图又回传给它，形成死循环。
    node.dataset.dirty = value && !isPlaceholderProductType(value) ? "1" : "";
  });

  $("#btn-save-ru").addEventListener("click", async () => {
    if (!state.draft) return toast("请先载入草稿", "error");
    const ru = {
      title: $("#ru-title").value,
      shortDescription: $("#ru-short").value,
      description: $("#ru-desc").value,
      keywords: $("#ru-keywords").value.split(/[,，]/).map(cleanText).filter(Boolean),
      bulletPoints: state.draft.ru?.bulletPoints || [],
      categoryHint: $("#ru-category-hint").value,
      productType: $("#ru-product-type")?.value || "",
      usage: state.draft.ru?.usage || "",
    };
    // v1.9.64 富内容的输入框在详细描述下方，保存时一并落进 attributeValues["11254"]
    // （上传链路会原样提交，和过去手工在属性表里填的行为完全一致）。
    const richText = cleanText($("#rich-content")?.value || "");
    if (richText) {
      const check = validateRichContentJson(richText);
      if (!check.ok) return toast(`富内容 JSON 有问题：${check.error}`, "error");
    }
    state.draft = await saveDraft({ id: state.draft.id, ru });
    await saveRichContent(richText);
    renderRichContentBox();
    toast("文案已保存", "ok");
  });

  $("#btn-export").addEventListener("click", () => {
    if (!state.draft) return toast("请先载入草稿", "error");
    exportXlsx([state.draft], `ozon-${state.draft.id.slice(-6)}.xlsx`);
    toast("已导出 XLSX", "ok");
  });
}

async function generateRu(useStream) {
  if (!state.draft) return toast("请先载入草稿", "error");
  // 把「商品词/品类」作为硬约束传下去：AI 先识别，用户改过就以用户的为准，
  // 这样「足球鞋被写成跑步鞋」这类跑偏可以直接就地纠正。
  const options = {
    extraKeywords: $("#kw-extra").value,
    tone: $("#tone-select").value,
    productType: $("#ru-product-type")?.value || "",
  };
  const preview = $("#ai-preview");

  try {
    if (useStream) {
      preview.hidden = false;
      preview.textContent = "";
      await streamRu(state.draft, options, (chunk) => { preview.textContent += chunk; });
      return;
    }
    setBadge("#ai-status", "生成中…", "warn");
    const data = await call({ action: MESSAGE_ACTIONS.aiGenerateText, product: state.draft, options });
    applyRu(data);
    setBadge("#ai-status", "完成", "ok");
    toast("俄语文案已生成", "ok");
  } catch (error) {
    toast(error.message, "error");
    setBadge("#ai-status", "失败", "err");
  }
}

function applyRu(data) {
  if (!data) return;
  $("#ru-title").value = data.title || "";
  $("#ru-short").value = data.shortDescription || "";
  $("#ru-desc").value = data.description || "";
  $("#ru-keywords").value = (data.keywords || []).join(", ");
  $("#ru-category-hint").value = data.categoryHint || "";
  // 品类与用途单独显示：文案跑偏时第一眼就能看出是「识别错了」还是「写错了」
  const typeNode = $("#ru-product-type");
  // v1.9.63：AI 没识别出来时（未知商品 / 未指定…）绝不写进输入框——
  // 写进去下次载入草稿就会被当成「用户已确认的品类」锁死，之后再生成也救不回来。
  const usableType = data.productType && !isPlaceholderProductType(data.productType) ? data.productType : "";
  if (typeNode && typeNode.dataset.dirty !== "1" && usableType) typeNode.value = usableType;
  else if (typeNode && usableType) typeNode.placeholder = `AI 识别为：${usableType}`;
  else if (typeNode && typeNode.dataset.dirty !== "1") typeNode.value = "";
  const usageNode = $("#ru-usage");
  if (usageNode) {
    const locked = typeNode && typeNode.dataset.dirty === "1";
    usageNode.textContent = data.usage
      ? `${locked ? "已按你填的品类生成" : "AI 识别用途"}：${data.usage}`
      : "";
  }
  $("#title-len").textContent = `${(data.title || "").length} 字符`;
  // v1.9.63：落草稿时也要清掉占位品类，避免它被持久化后反过来锁死下一次生成
  if (state.draft) {
    state.draft.ru = {
      ...(state.draft.ru || {}),
      ...data,
      productType: usableType || state.draft.ru?.productType || "",
    };
  }
}

function streamRu(draft, options, onDelta) {
  return new Promise((resolve, reject) => {
    const port = chrome.runtime.connect({ name: "ai_stream" });
    port.onMessage.addListener((message) => {
      if (message.type === "delta") onDelta(message.delta);
      else if (message.type === "done") {
        if (message.ok) {
          applyRu(message.data);
          toast("流式生成完成", "ok");
        } else {
          // v1.9.63：质量闸门拦下来时带上具体原因，而不是笼统说「无法解析」
          toast(message.error || "生成结束，但结果无法解析为 JSON", "error");
        }
        port.disconnect();
        resolve();
      } else if (message.type === "error") {
        toast(message.error, "error");
        port.disconnect();
        reject(new Error(message.error));
      }
    });
    port.postMessage({ product: draft, options });
  });
}

/** 有草稿才显示上架工作台，否则显示引导文案 */
function updateWorkspaceVisibility() {
  const has = Boolean(state.draft);
  const workspace = $("#workspace");
  const empty = $("#workspace-empty");
  if (workspace) workspace.hidden = !has;
  if (empty) empty.hidden = has;
}

async function renderEditor() {
  let draft = state.draft;
  updateWorkspaceVisibility();
  // v1.9.73 换了草稿：策划方案与已出的方案图立刻作废（防止 A 商品的卖点/图带到 B 商品）
  if (state.plan && state.planDraftId && state.planDraftId !== (draft?.id || "")) {
    state.plan = null;
    state.planGen = [];
    state.planDraftId = "";
    renderPlanReport();
    renderPlanGrid();
    setBadge("#plan-status", "已换草稿，方案已清空", "");
  }
  if (!draft) {
    $("#sku-card").hidden = true;
    $("#attr-card").hidden = true;
    state.draftCategoryStale = null;
    renderCategoryPick();
    state.categoryAttributes = [];
    renderRichContentBox();
    // 没有草稿时也把策划方案清掉（载入上次采集/删草稿会走到这里）
    if (state.plan) {
      state.plan = null;
      state.planGen = [];
      state.planDraftId = "";
      renderPlanReport();
      renderPlanGrid();
    }
    return;
  }

  // 载入草稿时先把旧的 ozonCategory 与本地中文树对齐；若 type_id 对不上则标记为需重选
  state.draftCategoryStale = null;
  const sync = await syncDraftCategoryToTree(draft);
  if (!sync.ok) {
    state.draftCategoryStale = { reason: sync.reason };
  } else if (sync.updated) {
    state.draft = await saveDraft({ id: draft.id, ozonCategory: sync.leaf ? {
      ...draft.ozonCategory,
      descriptionCategoryId: Number(sync.leaf.description_category_id) || 0,
      typeId: Number(sync.leaf.type_id) || 0,
      pathText: getCategoryPathText(state.categoryTree, sync.leaf.type_id) || sync.leaf.title,
    } : draft.ozonCategory });
    state.categoryNode = sync.leaf ? { ...sync.leaf, category_id: sync.leaf.description_category_id, type_id: sync.leaf.type_id } : null;
    if (sync.reason) toast(sync.reason, "warn");
  }
  // 后续渲染用更新后的 draft
  draft = state.draft;

  renderCategoryPick();

  $("#ru-title").value = draft.ru?.title || "";
  $("#ru-short").value = draft.ru?.shortDescription || "";
  $("#ru-desc").value = draft.ru?.description || "";
  // v1.9.64 富内容（属性 11254）从属性表搬到了详细描述下方，载入草稿时一起回填
  renderRichContentBox();
  $("#ru-keywords").value = (draft.ru?.keywords || []).join(", ");
  $("#ru-category-hint").value = draft.ru?.categoryHint || "";
  const typeInput = $("#ru-product-type");
  if (typeInput) {
    // v1.9.63：上次 AI「没识别出来」时写下的占位值（未知商品 / 未指定…）不能当成用户已确认的品类，
    // 否则每次生成都把它回传给模型，模型就永远答「未知」——踩进去就出不来。这里直接丢掉。
    const savedType = String(draft.ru?.productType || "").trim();
    const usableType = savedType && !isPlaceholderProductType(savedType) ? savedType : "";
    typeInput.value = usableType;
    // 只有真正可用的品类才算「用户已确认」；清空输入框即可交回给 AI 重新识别
    typeInput.dataset.dirty = usableType ? "1" : "";
    if (!usableType && savedType) typeInput.placeholder = `上次 AI 没识别出来（${savedType}），可手动填写后重新生成`;
  }
  const usageNode = $("#ru-usage");
  if (usageNode) usageNode.textContent = draft.ru?.usage ? `AI 识别用途：${draft.ru.usage}` : "";
  $("#title-len").textContent = `${(draft.ru?.title || "").length} 字符`;

  renderSkuSection(draft.skus || [], draft.specOptions || []);
  renderAttributeDefs();
  // 草稿缓存里的属性定义可能是俄文原名，先渲染再异步补中文并重绘
  ensureAttributesChinese();
  // 类目已确认但属性定义还没拉：自动补拉，保证「选了类目就一定能看到属性」
  autoLoadCategoryAttributes();

  renderTable("#attr-table", [
    { key: "name", label: "属性" },
    { key: "value", label: "值" },
  ], draft.attributes || []);
  $("#attr-card").hidden = !(draft.attributes && draft.attributes.length);
  // 草稿进入工作台后立即显示采集到的图片；手动按钮仍保留作为兼容入口。
  renderImageGallery();
  // 载入草稿后：毛重/尺寸按采集信息回填一次，核价表跟着草稿刷新
  autoFillMeasurements({ force: false });
  renderListingResult();
  // v1.9.47 上架 SKU 的自动货号：首次渲染时算好写回草稿（导出上架表 / 上传 / 库存价格更新要拿同一个值）
  void ensureSkuOfferIds();
}

/* ---------------- 定价 ----------------
 * 只有一套定价：OZON 核价（对齐用户自用的「上架表」）。
 * 之前并存两套（老的成本加成 + 上架表口径），两边汇率/利润率各算各的，结果互相打架，
 * 现在统一到下面「OZON 核价」那一段。
 */

function getSelectedSkus() {
  return (state.draft?.skus || []).filter((sku) => state.selectedSkus.has(sku.id));
}

function averageSelectedCost() {
  const selected = getSelectedSkus();
  if (!selected.length) return state.draft?.costCny || 0;
  const total = selected.reduce((sum, sku) => sum + (Number(sku.price) || 0), 0);
  return total / selected.length;
}

/**
 * 用采集到的包裹毛重/包装尺寸回填核价表单（重量 kg / 长宽高 cm），并同步上传参数（g / mm）。
 * force=false 时只补空的（值 >0 的视为用户已改，不覆盖）。
 */
function autoFillMeasurements({ force = false } = {}) {
  const parcel = state.draft?.parcel || {};
  const pairs = [
    ["#listing-weightKg", parcel.weightKg],
    ["#listing-lengthCm", parcel.lengthCm],
    ["#listing-widthCm", parcel.widthCm],
    ["#listing-heightCm", parcel.heightCm],
  ];
  let filled = 0;
  for (const [selector, value] of pairs) {
    const input = $(selector);
    const num = Number(value) || 0;
    if (!input || !num) continue;
    if (!force && Number(input.value) > 0) continue;
    input.value = num;
    filled += 1;
  }
  if (parcel.weightKg) {
    const weight = $("#ozon-weight");
    if (weight && (force || Number(weight.value) === 500)) weight.value = Math.round(parcel.weightKg * 1000);
  }
  const dimMap = [["#ozon-depth", parcel.lengthCm], ["#ozon-width", parcel.widthCm], ["#ozon-height", parcel.heightCm]];
  for (const [selector, cm] of dimMap) {
    const input = $(selector);
    if (!input || !cm) continue;
    if (force || Number(input.value) === 100) input.value = Math.round(cm * 10);
  }
  return filled;
}

/* ---------------- OZON 核价（对齐用户自用的「上架表」） ---------------- */

const LISTING_FIELDS = [
  // 包裹信息：载入草稿时按采集的毛重/包装尺寸自动回填
  { key: "weightKg", label: "毛重（kg）", step: "0.01" },
  { key: "lengthCm", label: "长（cm）", step: "1" },
  { key: "widthCm", label: "宽（cm）", step: "1" },
  { key: "heightCm", label: "高（cm）", step: "1" },
  // 核价参数
  { key: "purchaseCost", label: "采购成本 ¥（0 = 按 SKU 采集价）", step: "0.01" },
  { key: "domesticFreight", label: "国内运费 ¥（1688 运费）", step: "0.01" },
  { key: "exchangeRate", label: "汇率（1 ¥ = ? ₽）", step: "0.1" },
  { key: "withdrawalRate", label: "提现率（结算→到账）", step: "0.001" },
  { key: "volumetricDivisor", label: "体积重除数", step: "100" },
  { key: "discountRate", label: "活动折扣（0.4 = 6 折）", step: "0.05" },
  { key: "adRate", label: "广告出价（%）", step: "1" },
  { key: "commissionRate", label: "平台佣金（%）", step: "1" },
  { key: "targetProfitRate", label: "目标采购利润率（%）", step: "1" },
  { key: "roundingStep", label: "售价取整步长（¥）", step: "1" },
  { key: "priceCny", label: "平台售价 ¥（0 = 反推）", step: "1" },
  { key: "logisticsA", label: "物流系数 a（0 = 跟渠道）", step: "0.0001" },
  { key: "logisticsB", label: "物流常数 b（0 = 跟渠道）", step: "0.01" },
];

function renderListingForm() {
  const wrap = $("#listing-form");
  if (!wrap) return;
  wrap.innerHTML = "";
  const template = normalizeListingTemplate(state.settings?.listing);
  for (const field of LISTING_FIELDS) {
    wrap.appendChild(el("label", {}, [
      field.label,
      el("input", {
        type: "number",
        id: `listing-${field.key}`,
        step: field.step,
        value: template[field.key],
        oninput: () => renderListingResult(),
      }),
    ]));
  }
  const select = el("select", { id: "listing-channelId", onchange: () => {
    // 选了具体渠道就把该渠道的广告/佣金默认值带出来（跟表里「计价方式」那套一致，仍可手改）
    const picked = OZON_CHANNELS.find((item) => item.id === select.value);
    if (picked) {
      const ad = $("#listing-adRate");
      const commission = $("#listing-commissionRate");
      if (ad) ad.value = picked.adRate;
      if (commission) commission.value = picked.commissionRate;
    }
    renderListingResult();
  } }, [
    el("option", { value: "", text: "自动（按重量 / 售价判定）" }),
    ...OZON_CHANNELS.map((channel) => el("option", {
      value: channel.id,
      text: `${channel.label}｜${channel.bounds}`,
      selected: channel.id === template.channelId,
    })),
  ]);
  select.value = template.channelId || "";
  wrap.appendChild(el("label", {}, ["OZON 渠道", select]));
  // 渠道系数说明：让用户知道 a/b 是哪来的
  wrap.appendChild(el("label", {}, [
    "当前渠道系数",
    el("input", { type: "text", id: "listing-ab-hint", value: "", readonly: true, title: "国际物流 U = a × 重量(g) + b" }),
  ]));
}

function readListingForm() {
  const patch = { channelId: $("#listing-channelId")?.value || "" };
  for (const field of LISTING_FIELDS) {
    const input = $(`#listing-${field.key}`);
    if (input) patch[field.key] = Number(input.value) || 0;
  }
  return normalizeListingTemplate({ ...(state.settings?.listing || {}), ...patch });
}

/** 重量与尺寸：优先用核价表单里手填的（#listing-*），其次用采集到的包裹信息 */
function listingMeasurements() {
  const read = (id) => Number($(id)?.value) || 0;
  const parcel = state.draft?.parcel || {};
  return {
    weightG: Math.round((read("#listing-weightKg") || Number(parcel.weightKg) || 0) * 1000),
    lengthCm: read("#listing-lengthCm") || Number(parcel.lengthCm) || 0,
    widthCm: read("#listing-widthCm") || Number(parcel.widthCm) || 0,
    heightCm: read("#listing-heightCm") || Number(parcel.heightCm) || 0,
  };
}

/** 按上架表口径把当前草稿每个 SKU 整套算一遍 */
function computeDraftListing() {
  const template = readListingForm();
  const { weightG, lengthCm, widthCm, heightCm } = listingMeasurements();
  const draft = state.draft;
  const skus = (draft?.skus || []).length
    ? draft.skus
    : [{ id: "", label: "", price: draft?.costCny || 0 }];
  return skus.map((sku) => {
    // 拿货成本 = 采购成本（采集价） + 国内运费（1688 运费），两段分开可看、可手改
    const costParts = splitCostCny({ sku, draft, template });
    return {
      sku,
      costParts,
      calc: computeListing({
        costCny: costParts.cost,
        priceCny: template.priceCny,
        weightG, lengthCm, widthCm, heightCm,
        template,
      }),
    };
  });
}

const pct = (value) => `${(Number(value) || 0) * 100 >= 0 ? "" : ""}${((Number(value) || 0) * 100).toFixed(1)}%`;

// 只在「草稿变了」时同步一次采集运费，避免用户正在手填时被输入事件触发的重渲染覆盖
let lastFreightSyncKey = "";

/** 国内运费：默认带出当前草稿采集到的 1688 运费（可手改，手改后不再被覆盖） */
function syncListingCostInputs() {
  const draft = state.draft;
  const freight = Number(draft?.logistics?.freightCny) || 0;
  const key = draft ? `${draft.id}:${freight}` : "";
  if (!key || key === lastFreightSyncKey) return;
  lastFreightSyncKey = key;
  const input = $("#listing-domesticFreight");
  if (input && freight > 0) input.value = freight;
}

const money = (value) => `¥${(Number(value) || 0).toFixed(2)}`;

/**
 * 单个 SKU 的售价计算明细（v1.9.45：放在该 SKU 行正下方，不再挤在一张十几列的宽表里）。
 * 口径与「上架表」一一对应，只是换成了卡片式排版，方便一个 SKU 一个 SKU 地看。
 */
function skuCalcHtml(row) {
  const { calc, costParts } = row;
  const profitTone = calc.profitCny >= 0 ? "ok" : "err";
  // v1.9.46：列名与顺序跟「全局核价一览」那张表**完全对齐**（规格/渠道/采购成本¥/国内运费¥/拿货成本¥/
  // 售价¥/售价₽/活动价¥/活动价₽/国际物流¥/佣金¥/广告¥/店铺利润¥/采购·销售·物流利润率/体积重kg），
  // 这样每个 SKU 下面这一条横排就是那张表的一行，不用在两处之间来回换算。
  const cells = [
    ["渠道", calc.channelLabel || "自动"],
    ["采购成本 ¥", money(costParts.purchase)],
    ["国内运费 ¥", money(costParts.freight)],
    ["拿货成本 ¥", money(costParts.cost)],
    ["售价 ¥", money(calc.priceCny)],
    ["售价 ₽", `${Math.round(calc.priceRub)} ₽`],
    ["活动价 ¥", money(calc.promoCny)],
    ["活动价 ₽", `${Math.round(calc.promoRub)} ₽`],
    ["国际物流 ¥", money(calc.logisticsCny)],
    ["佣金 ¥", money(calc.commissionCny)],
    ["广告 ¥", money(calc.adCny)],
    ["店铺利润 ¥", money(calc.profitCny), profitTone],
    ["采购利润率", pct(calc.purchaseMarginRate)],
    ["销售利润率", pct(calc.salesMarginRate)],
    ["物流利润率", pct(calc.logisticsMarginRate)],
    ["体积重 kg", String(calc.volumetricKg || 0)],
  ];
  const body = cells.map(([key, value, tone]) =>
    `<div class="sku-calc-cell"><span class="k">${escapeHtml(key)}</span><b class="${tone || ""}">${escapeHtml(String(value))}</b></div>`,
  ).join("");
  return `<div class="sku-calc"><div class="sku-calc-head">该 SKU 的售价计算（上架表口径，与「全局核价一览」同列）　a=${calc.logisticsA} b=${calc.logisticsB}</div><div class="sku-calc-grid">${body}</div></div>`;
}

/** 把算好的核价结果填回每个 SKU 行下面的面板里（面板本身由 renderSkuSection 渲染） */
function renderSkuCalcDetails(rows) {
  const byId = new Map();
  let singleRow = null;
  for (const row of rows) {
    const id = row.sku?.id || "";
    if (id) byId.set(id, row);
    else singleRow = row;
  }
  for (const box of $$("#sku-table .sku-calc-box")) {
    const row = byId.get(box.dataset.id);
    box.innerHTML = row ? skuCalcHtml(row) : `<p class="hint">这个 SKU 没有成本数据，先在「成本 ¥」里填个数。</p>`;
  }
  // 没采集到 SKU（单规格商品）时，给一块独立的核价面板，别让核价整个消失
  const standalone = $("#sku-single-calc");
  if (standalone) {
    standalone.hidden = !singleRow;
    standalone.innerHTML = singleRow ? `<p class="sub">没有采集到 SKU 规格，按单规格核算：</p>${skuCalcHtml(singleRow)}` : "";
  }
}

function renderListingResult() {
  syncListingCostInputs();
  const rows = state.draft ? computeDraftListing() : [];
  renderSkuCalcDetails(rows);
  renderTable("#listing-table", [
    { key: "label", label: "规格" },
    { key: "channel", label: "渠道" },
    { key: "purchase", label: "采购成本 ¥" },
    { key: "freight", label: "国内运费 ¥" },
    { key: "cost", label: "拿货成本 ¥" },
    { key: "priceCny", label: "售价 ¥" },
    { key: "priceRub", label: "售价 ₽" },
    { key: "promoRub", label: "活动价 ₽" },
    { key: "logistics", label: "国际物流 ¥" },
    { key: "commission", label: "佣金 ¥" },
    { key: "ad", label: "广告 ¥" },
    { key: "profit", label: "店铺利润 ¥" },
    { key: "purchaseRate", label: "采购利润率" },
    { key: "sales", label: "销售利润率" },
    { key: "logisticsRate", label: "物流利润率" },
    { key: "density", label: "体积重 kg" },
  ], rows.map(({ sku, calc, costParts }) => ({
    label: sku.label || "(单规格)",
    channel: calc.channelLabel,
    purchase: costParts.purchase,
    freight: costParts.freight,
    cost: calc.costCny,
    priceCny: calc.priceCny,
    priceRub: Math.round(calc.priceRub),
    promoRub: Math.round(calc.promoRub),
    logistics: calc.logisticsCny,
    commission: calc.commissionCny,
    ad: calc.adCny,
    profit: calc.profitCny,
    purchaseRate: pct(calc.purchaseMarginRate),
    sales: pct(calc.salesMarginRate),
    logisticsRate: pct(calc.logisticsMarginRate),
    density: calc.volumetricKg,
  })));
  const hint = $("#listing-ab-hint");
  if (hint) {
    hint.value = rows.length
      ? `a=${rows[0].calc.logisticsA} b=${rows[0].calc.logisticsB} → U=${rows[0].calc.logisticsCny} ¥`
      : "";
  }
  const status = $("#listing-status");
  if (status) {
    if (!rows.length) setBadge("#listing-status", "待核算", "");
    else {
      const worst = Math.min(...rows.map(({ calc }) => calc.purchaseMarginRate));
      setBadge("#listing-status", `最低采购利润率 ${pct(worst)}`, worst >= 0.2 ? "ok" : "warn");
    }
  }
  return rows;
}

/** 反推售价并写回草稿：perSku 的 RUB 价直接就是上传时用的价 */
async function applyListingToDraft() {
  if (!state.draft) return toast("请先载入草稿", "error");
  const rows = computeDraftListing();
  const template = readListingForm();
  const perSku = { ...(state.draft.pricing?.perSku || {}) };
  const calcBySku = { ...(state.draft.listing?.calcBySku || {}) };
  for (const { sku, calc } of rows) {
    if (!sku.id) continue;
    // Ozon 后台要求人民币结算；写回草稿的售价用 CNY，卢布价仅做内部参考。
    // ⚠️ v1.9.50 修正语义：Ozon 的 price 是「买家实付价」，old_price 是「划线价」且必须 > price。
    // 本模块里 priceCny 是标价(K)、promoCny 是打折后的活动价(N)＝真正成交价。
    // 之前把两者写反了：old_price 拿到更低的活动价 → 必然小于 price → 划线价被整条丢掉，
    // 折扣永远不生效，而且买家看到的是没打折的标价（实收偏高）。
    perSku[sku.id] = {
      priceCny: calc.promoCny,        // Ozon price ← 实际成交价
      oldPriceCny: calc.priceCny,     // Ozon old_price ← 划线价（原价）
      // 内部参考：卢布价仍保留，方便核价表与上架表沿用
      priceRub: Math.round(calc.promoRub),
      oldPriceRub: Math.round(calc.priceRub),
    };
    calcBySku[sku.id] = calc;
  }
  const first = rows[0]?.calc || null;
  state.draft = await saveDraft({
    id: state.draft.id,
    pricing: {
      ...(state.draft.pricing || {}),
      ...(first ? {
        // 与 perSku 同口径：price = 成交价，old_price = 划线价
        priceCny: first.promoCny,
        oldPriceCny: first.priceCny,
        // 内部参考：卢布价仍保留，方便核价表与上架表沿用
        priceRub: Math.round(first.promoRub),
        oldPriceRub: Math.round(first.priceRub),
      } : {}),
      perSku,
    },
    listing: { template, calcBySku, summary: first },
  });
  renderListingResult();
  toast(first ? `已按上架表口径定价：成交价 ${first.promoCny} CNY（划线价 ${first.priceCny} / ≈ ${Math.round(first.promoRub)} RUB）` : "已核算", "ok");
  // 流水线备注要的是文字，返回 rows（对象数组）会显示成一串 [object Object]
  return rows.length ? `已定价 ${rows.length} 个 SKU` : "已核算";
}

/**
 * 导出上架表。没点过「反推售价」的草稿也会现算一遍，
 * 保证导出的表里 a/b、售价、各档利润率都是完整的。
 */
function exportPreparedListing(drafts, filename) {
  const template = readListingForm();
  const list = [].concat(drafts).filter(Boolean);
  if (!list.length) return toast("没有可导出的草稿", "error");
  const prepared = list.map((draft) => {
    const calcBySku = draft.listing?.calcBySku || {};
    const skus = (draft.skus || []).length ? draft.skus : [{ id: "", label: "", price: draft.costCny || 0 }];
    const parcel = draft.parcel || {};
    // 当前草稿用界面上（手填/回填）的重量与尺寸，历史草稿用它自己采集到的
    const m = (state.draft && draft.id === state.draft.id)
      ? listingMeasurements()
      : {
        weightG: Math.round((Number(parcel.weightKg) || 0) * 1000),
        lengthCm: Number(parcel.lengthCm) || 0,
        widthCm: Number(parcel.widthCm) || 0,
        heightCm: Number(parcel.heightCm) || 0,
      };
    return {
      ...draft,
      // 覆盖 parcel，导出的表里「重量/长宽高」就是实际参与核价的值
      parcel: { ...parcel, weightKg: m.weightG / 1000, lengthCm: m.lengthCm, widthCm: m.widthCm, heightCm: m.heightCm },
      skus: skus.map((sku) => ({
        ...sku,
        calc: calcBySku[sku.id] || computeListing({
          costCny: splitCostCny({ sku, draft, template }).cost,
          priceCny: template.priceCny,
          weightG: m.weightG, lengthCm: m.lengthCm, widthCm: m.widthCm, heightCm: m.heightCm,
          template,
        }),
      })),
    };
  });
  exportListingXlsx(prepared, template, filename);
  toast(`已导出上架表（${prepared.length} 个草稿）`, "ok");
}

function bindListing() {
  renderListingForm();
  renderListingResult();
  $("#btn-listing-save").addEventListener("click", async () => {
    state.settings = await saveSettings({ listing: readListingForm() });
    toast("核价参数已保存", "ok");
    renderListingResult();
  });
  $("#btn-listing-reset").addEventListener("click", async () => {
    state.settings = await saveSettings({ listing: DEFAULT_LISTING_TEMPLATE });
    renderListingForm();
    renderListingResult();
    toast("已恢复默认核价参数");
  });
  $("#btn-listing-apply").addEventListener("click", async () => {
    try {
      await applyListingToDraft();
    } catch (error) {
      toast(error.message, "error");
    }
  });
  $("#btn-listing-export").addEventListener("click", () => {
    if (!state.draft) return toast("请先载入草稿", "error");
    exportPreparedListing([state.draft], `ozon-上架表-${(state.draft.title || state.draft.id || "").slice(0, 20)}.xlsx`);
  });
}

/* ---------------- 图片与水印 ---------------- */

/* ---------------- v1.9.66 AI 类目匹配用的产品外观图片 ---------------- */

// 一次最多喂给 AI 几张外观图。多模态图片很吃 token，3 张足够判断「实物是什么」。
const CATEGORY_MATCH_IMAGE_LIMIT = 3;

/**
 * 为 AI 类目匹配准备「产品外观图片」。
 * 优先主图，其次商品图集，最多 3 张；逐张经后台取回（绕防盗链 / CORS）后压成 800px 的 JPEG。
 * 任何一张失败都静默跳过——一张都取不到时匹配自动降级为「仅按标题文字」，不阻断流程。
 */
async function collectCategoryMatchImages(draft) {
  const urls = dedupeUrls([
    draft?.mainImage,
    ...(Array.isArray(draft?.images) ? draft.images : []),
  ]).filter((url) => /^https?:\/\//i.test(String(url || "").trim()));
  const out = [];
  for (const url of urls.slice(0, CATEGORY_MATCH_IMAGE_LIMIT)) {
    try {
      const raw = await fetchDataUrl(url);
      if (raw) out.push(await shrinkImageDataUrl(raw, 800, 0.8));
    } catch { /* 单张失败不影响其它图，也不影响文字匹配 */ }
  }
  return out;
}

/** 把 data URL 压到最长边 maxSide 的 JPEG，控制多模态请求的体积与 token */
function shrinkImageDataUrl(dataUrl, maxSide = 800, quality = 0.8) {
  return new Promise((resolve) => {
    const done = (value) => resolve(value || dataUrl);
    try {
      const image = new Image();
      image.onload = () => {
        try {
          const w0 = image.naturalWidth || image.width || 0;
          const h0 = image.naturalHeight || image.height || 0;
          if (!w0 || !h0) return done(dataUrl);
          const scale = Math.min(1, maxSide / Math.max(w0, h0));
          // 本来就小且是 JPEG，不必重新编码（重编码反而可能更大）
          if (scale >= 1 && dataUrl.length < 300000) return done(dataUrl);
          const canvas = document.createElement("canvas");
          canvas.width = Math.max(1, Math.round(w0 * scale));
          canvas.height = Math.max(1, Math.round(h0 * scale));
          canvas.getContext("2d").drawImage(image, 0, 0, canvas.width, canvas.height);
          return done(canvas.toDataURL("image/jpeg", quality));
        } catch { return done(dataUrl); }
      };
      image.onerror = () => done(dataUrl);
      image.src = dataUrl;
    } catch { done(dataUrl); }
  });
}

// 通过后台取回图片（绕过防盗链与 CORS），返回 data URL
async function fetchDataUrl(url) {
  const response = await chrome.runtime.sendMessage({ action: MESSAGE_ACTIONS.fetchImageAsDataUrl, url });
  if (!response?.ok) throw new Error(response?.error || "取图失败");
  return response.dataUrl;
}

/**
 * 探测图片能不能被 Ozon 抓到（v1.9.50）。
 *
 * Ozon 是拿图片 URL 自己回源下载的，抓不到就把商品判成「商品卡片中没有照片」直接封锁。
 * 常见的坏地址有三类：本地 base64（data:，Ozon 根本解析不了）、会过期的图床临时签名链、
 * 防盗链/需登录导致回源拿到 HTML 错误页。上传前先把这些挑出来，比上传后被封锁划算。
 */
async function probeImageUrls(urls = []) {
  const list = [...new Set((urls || []).map((url) => cleanText(url)).filter(Boolean))];
  if (!list.length) return { results: [], bad: 0 };
  const response = await chrome.runtime.sendMessage({ action: MESSAGE_ACTIONS.imageProbe, urls: list });
  if (!response?.ok) throw new Error(response?.error || "图片可达性探测失败");
  return response.data || { results: [], bad: 0 };
}

// 组装待翻译图片清单：优先用「已勾选」的图片；未勾选任何图时退回草稿全部图。
// 选用 SKU 的专属图（sku.image）也会一并纳入，实现「选 SKU → 连带翻译该 SKU 的图」。
function buildTranslatePlan(onlyMain = false) {
  const draft = state.draft;
  if (!draft) return [];
  // draft.images 理论上不会是 undefined，但旧草稿 / 手改过的存储可能缺字段，
  // 直接 .filter 会抛 "Cannot read properties of undefined"，整个翻译流程崩掉
  const allImages = Array.isArray(draft.images) ? draft.images : [];
  const picked = allImages.filter((url) => state.selectedImages.has(url));
  const base = picked.length ? picked : (state.selectedImages.size ? [] : allImages);
  const selectedSkus = getSelectedSkus();
  const skuImages = selectedSkus.map((sku) => sku.image).filter(Boolean);
  const seen = new Set();
  const plan = [];
  for (const url of [...base, ...skuImages]) {
    if (!url || seen.has(url)) continue;
    seen.add(url);
    plan.push({ url });
  }
  if (onlyMain) return plan.slice(0, 1);
  return plan.slice(0, 20);
}

/* 图片预览大图与缩略图：模块级函数。
 * 注意必须放在外层——图库 / 重绘图 / 水印图 / 采集结果都在别处调用，
 * 之前误嵌进「翻译图片文字」的点击处理器里，导致 imageThumb is not defined、整个图片区渲染崩溃。
 *
 * v1.9.44 重写（修「点开放大全是糊的」）：
 * ① 地址先升到最高清的那一版（1688 图床的 _400x400 / x-oss-process 这类缩放后缀全部去掉）——
 *    拿缩略图地址去看大图，怎么放大都是糊的，这是根因；
 * ② 显示时「只缩不放」：不再用 width:100% 把小图硬拉到面板宽度；
 * ③ 支持 适应窗口 / 原始尺寸 / ± 缩放 / 滚轮缩放 / 新窗口打开。 */

/** 预览弹窗外壳：标题 + 工具按钮区 + 内容容器 */
function openPreviewShell(title, subtitle = "") {
  const overlay = el("div", { class: "modal-overlay image-preview-overlay", role: "dialog", "aria-modal": "true" });
  const modal = el("div", { class: "image-preview-modal" });
  const tools = el("span", { class: "image-preview-tools" });
  const close = () => {
    document.removeEventListener("keydown", onKey);
    overlay.remove();
  };
  const onKey = (event) => {
    if (event.key === "Escape") {
      event.stopPropagation();
      close();
    }
  };
  const head = el("div", { class: "image-preview-head" }, [
    el("strong", { text: title }),
    subtitle ? el("span", { class: "sub", text: subtitle }) : null,
    el("span", { class: "spacer" }),
    tools,
    el("button", { type: "button", class: "mini", text: "关闭", onclick: close }),
  ]);
  const body = el("div", { class: "image-preview-body" });
  modal.append(head, body);
  overlay.appendChild(modal);
  overlay.addEventListener("click", (event) => { if (event.target === overlay) close(); });
  document.body.appendChild(overlay);
  document.addEventListener("keydown", onKey);
  return { overlay, modal, head, tools, body, close };
}

/**
 * 一个可缩放的图框。默认「适应窗口」= 只缩不放（小图按原始像素显示，不拉伸就不会糊），
 * 切「原始尺寸」或用滚轮放大才会超过 100%，此时容器可滚动查看。
 */
function buildPreviewPane({ src, label = "", note = "" } = {}) {
  const pane = el("div", { class: "preview-pane" });
  const info = el("span", { class: "sub", text: "加载中…" });
  const viewport = el("div", { class: "image-preview-viewport" });
  const fallback = el("p", { class: "image-preview-error", text: "图片加载失败，请检查 URL 或网络" });
  fallback.hidden = true;
  const image = el("img", {
    class: "image-preview-img",
    src: src || "",
    alt: label || "预览图",
    referrerpolicy: "no-referrer",
    decoding: "async",
  });
  let scale = 0;   // 0 = 适应窗口；>0 = 相对原始尺寸的倍率
  const refresh = () => {
    if (!image.naturalWidth) return;
    const natural = `${image.naturalWidth}×${image.naturalHeight}`;
    if (!scale) {
      image.classList.remove("is-zoomed");
      image.style.width = "";
      info.textContent = [natural, "适应窗口", note].filter(Boolean).join(" · ");
      return;
    }
    image.classList.add("is-zoomed");
    image.style.width = `${Math.max(1, Math.round(image.naturalWidth * scale))}px`;
    info.textContent = [natural, `${Math.round(scale * 100)}%`, note].filter(Boolean).join(" · ");
  };
  const setScale = (value) => {
    const next = Math.min(5, Math.max(0, Number(value) || 0));
    scale = next < 0.05 ? 0 : next;
    refresh();
  };
  image.addEventListener("load", refresh);
  image.addEventListener("error", () => {
    image.hidden = true;
    fallback.hidden = false;
    info.textContent = "加载失败";
  });
  viewport.append(image, fallback);
  // 滚轮缩放：不 preventDefault 的话页面会跟着一起滚
  viewport.addEventListener("wheel", (event) => {
    if (!image.naturalWidth) return;
    event.preventDefault();
    setScale((scale || 1) * (event.deltaY < 0 ? 1.2 : 1 / 1.2));
  }, { passive: false });
  const head = el("div", { class: "preview-pane-head" }, [
    label ? el("strong", { text: label }) : null,
    info,
    el("span", { class: "spacer" }),
    el("button", { type: "button", class: "mini", text: "适应窗口", onclick: () => setScale(0) }),
    el("button", { type: "button", class: "mini", text: "原始尺寸", onclick: () => setScale(1) }),
    el("button", { type: "button", class: "mini", text: "－", title: "缩小", onclick: () => setScale((scale || 1) / 1.25) }),
    el("button", { type: "button", class: "mini", text: "＋", title: "放大", onclick: () => setScale((scale || 1) * 1.25) }),
    /^https?:/i.test(src || "")
      ? el("button", { type: "button", class: "mini", text: "新窗口", onclick: () => window.open(src, "_blank", "noopener") })
      : null,
  ]);
  pane.append(head, viewport);
  return pane;
}

/** 单图放大：先升到高清地址，再交给「只缩不放」的看图器 */
function openImagePreview(url, title = "图片预览") {
  const raw = cleanText(url);
  if (!raw) return toast("这张图片没有可用 URL", "warn");
  const source = highResImageUrl(raw) || raw;
  const shell = openPreviewShell(title);
  shell.modal.classList.add("is-single");
  shell.body.appendChild(buildPreviewPane({
    src: source,
    note: source === raw ? "" : "已自动取高清原图",
  }));
}

/**
 * 原图 / AI 主图 对比预览：并排对比 + 滑块对比两种模式。
 * 还没生成 AI 主图时也照常打开，右侧显示占位说明——用来对比「已生成 / 未生成」的差别。
 */
function openImageComparePreview({ original = "", generated = "", title = "原图 / AI 主图 对比" } = {}) {
  const leftRaw = cleanText(original);
  const rightRaw = cleanText(generated);
  if (!leftRaw && !rightRaw) return toast("没有可对比的图片", "warn");
  const left = leftRaw ? (highResImageUrl(leftRaw) || leftRaw) : "";
  const right = rightRaw ? (highResImageUrl(rightRaw) || rightRaw) : "";

  const shell = openPreviewShell(title, right ? "" : "该 SKU 还没生成 AI 主图");
  shell.modal.classList.add("is-compare");
  const modes = [];
  let mode = "side";

  const renderSide = () => {
    shell.body.innerHTML = "";
    const pair = el("div", { class: "compare-pair" });
    pair.appendChild(left
      ? buildPreviewPane({ src: left, label: "原图（生成前）" })
      : el("div", { class: "compare-placeholder", text: "这个 SKU 没有原图" }));
    pair.appendChild(right
      ? buildPreviewPane({ src: right, label: "AI 主图（生成后）" })
      : el("div", {
          class: "compare-placeholder",
          text: "还没生成 AI 主图。\n点 SKU 表「AI 主图」列里的生成按钮，出图后这里会并排显示生成前 / 生成后的效果。",
        }));
    shell.body.appendChild(pair);
  };

  const renderSlider = () => {
    shell.body.innerHTML = "";
    if (!left || !right) {
      shell.body.appendChild(el("div", {
        class: "compare-placeholder",
        text: left ? "还没有 AI 主图，无法做滑块对比。" : "这个 SKU 没有原图，无法做滑块对比。",
      }));
      return;
    }
    const box = el("div", { class: "compare-slider" });
    const base = el("img", { class: "cmp-base", src: left, alt: "原图", referrerpolicy: "no-referrer" });
    const top = el("img", { class: "cmp-top", src: right, alt: "AI 主图", referrerpolicy: "no-referrer" });
    const divider = el("span", { class: "compare-divider" });
    const tagLeft = el("span", { class: "compare-tag left", text: "原图" });
    const tagRight = el("span", { class: "compare-tag right", text: "AI 主图" });
    const range = el("input", { type: "range", min: "0", max: "100", step: "1", value: "50", class: "compare-range" });
    const apply = (value) => {
      const pos = Math.min(100, Math.max(0, Number(value) || 0));
      top.style.clipPath = `inset(0 0 0 ${pos}%)`;
      divider.style.left = `${pos}%`;
      tagLeft.style.opacity = pos < 12 ? "0.35" : "1";
      tagRight.style.opacity = pos > 88 ? "0.35" : "1";
    };
    range.addEventListener("input", () => apply(range.value));
    apply(50);
    box.append(base, top, divider, tagLeft, tagRight);
    shell.body.appendChild(el("div", { class: "compare-slider-wrap" }, [
      box,
      el("div", { class: "compare-slider-bar" }, [
        el("span", { class: "sub", text: "拖动滑块：左 = 原图，右 = AI 主图" }),
        range,
      ]),
    ]));
  };

  const addMode = (label, value, render) => {
    const button = el("button", { type: "button", class: `mini${mode === value ? " is-active" : ""}`, text: label });
    button.addEventListener("click", () => {
      mode = value;
      for (const item of modes) item.button.classList.toggle("is-active", item.value === mode);
      render();
    });
    modes.push({ button, value });
    shell.tools.appendChild(button);
  };
  addMode("并排对比", "side", renderSide);
  addMode("滑块对比", "slider", renderSlider);
  if (right) {
    shell.tools.appendChild(el("button", {
      type: "button",
      class: "mini",
      text: "放大 AI 图",
      onclick: () => { shell.close(); openImagePreview(right, "AI 主图"); },
    }));
  }
  renderSide();
}

/* v1.9.60 缩略图直连加载失败时的兜底：改走后台 fetch 转 data URL（面板是扩展自己的
 * 页面，直连 1688/淘宝图床受防盗链影响时 <img> 会挂；后台带扩展权限抓取成功率高得多）。
 * 每个地址只重试一次，避免加载失败来回打请求。 */
const thumbProbedUrls = new Set();
function retryThumbViaBackground(img, url) {
  const target = String(url || "");
  if (!target || /^data:/i.test(target) || thumbProbedUrls.has(target)) return;
  thumbProbedUrls.add(target);
  fetchDataUrl(target)
    .then((dataUrl) => {
      if (!dataUrl) return;
      img.src = dataUrl;
      img.classList.remove("is-broken");
    })
    .catch(() => { /* 后台也取不到，保持破图标记 */ });
}

function imageThumb(url, alt, extra = {}) {
  if (!url) return el("span", { class: "image-missing", text: "无图片 URL" });
  return el("img", {
    ...extra,
    src: url,
    alt,
    referrerpolicy: "no-referrer",
    tabindex: "0",
    role: "button",
    title: "点击查看大图",
    onclick: () => openImagePreview(url, alt),
    onkeydown: (event) => {
      if (event.key === "Enter" || event.key === " ") {
        event.preventDefault();
        openImagePreview(url, alt);
      }
    },
    onerror: (event) => {
      event.currentTarget.classList.add("is-broken");
      event.currentTarget.alt = "图片加载失败";
      retryThumbViaBackground(event.currentTarget, url);
    },
  });
}

function bindImageTranslate() {
  $("#btn-it-analyze").addEventListener("click", async () => {
    if (!await ensureLicensed("图片翻译")) return;
    if (!state.draft?.images?.length) return toast("请先载入带图片的草稿", "error");
    const vendor = $("#it-vendor")?.value || state.settings?.xiangjiVendor || "";
    const parallel = (state.settings?.xiangjiKeys || []).filter((item) => item.vendor === vendor).length;
    if (!parallel) {
      return toast("请先在「插件设置 → 图片翻译与 AI 生图」为要用的翻译引擎添加象寄 ImgTransKey（每个引擎一把）", "error");
    }

    // v1.9.44 处理范围下拉已删除：一律翻全部已勾选图片 + 已选用 SKU 的专属图，不再只挑一张
    const plan = buildTranslatePlan();
    if (!plan.length) return toast("没有可翻译的图片，请先勾选图片或 SKU", "error");
    const targets = plan.map((entry) => entry.url);
    const grid = $("#it-grid");
    grid.innerHTML = "";
    state.translated = [];
    setBadge("#it-status", `翻译中（${targets.length} 张${parallel > 1 ? ` × ${parallel} 密钥并行` : ""}）…`, "warn");

    try {
      const response = await send({
        action: MESSAGE_ACTIONS.imageTranslate,
        images: targets,
        vendor,
      });
      if (!response?.ok) throw new Error(response?.error || "翻译失败");
      const results = response.data || [];

      let done = 0;
      results.forEach((item, index) => {
        const ok = Boolean(item.translated);
        if (ok) done++;
        grid.appendChild(el("figure", {}, [
          imageThumb(item.translated || item.original, `翻译图 ${index + 1}`),
          el("figcaption", { text: ok ? `第 ${index + 1} 张：已翻译` : `第 ${index + 1} 张失败：${item.error || "未知原因"}` }),
        ]));
        if (ok) state.translated.push({ name: `ru-${index + 1}.jpg`, url: item.translated });
      });

      // 翻译成功的图按来源写回：主图集换新图，SKU 图同步替换（去重后的位置对应）
      if (done) {
        const replaced = new Map();
        results.forEach((item, index) => {
          if (item?.translated && plan[index]) replaced.set(plan[index].url, item.translated);
        });
        const images = state.draft.images.map((url) => replaced.get(url) || url);
        const skus = (state.draft.skus || []).map((sku) => {
          const images = (sku.images || [sku.image]).map((url) => replaced.get(url) || url).filter(Boolean);
          const image = replaced.get(sku.image) || sku.image || images[0] || "";
          return images.length || image ? { ...sku, image, images: [...new Set([image, ...images])].slice(0, 9) } : sku;
        });
        state.draft = await saveDraft({ id: state.draft.id, images, skus });
        if (images[0]) state.translated.unshift({ name: "ru-main.jpg", url: images[0] });
        renderImageGallery();
        await renderBulkLists();
      }

      setBadge("#it-status", `完成 ${done}/${targets.length}`, done ? "ok" : "err");
      toast(
        done ? `翻译完成 ${done} 张，已写回草稿图片${parallel > 1 ? `（${parallel} 把密钥并行）` : ""}` : "没有图片翻译成功，请看下方每张的失败原因",
        done ? "ok" : "error",
      );
    } catch (error) {
      setBadge("#it-status", "翻译失败", "err");
      grid.appendChild(el("figure", {}, [el("figcaption", { text: `失败：${error.message}` })]));
      toast(error.message, "error");
    }
  });

  $("#btn-it-download").addEventListener("click", async () => {
    if (!state.translated.length) return toast("还没有翻译结果", "error");
    for (const item of state.translated) {
      try {
        const dataUrl = await fetchDataUrl(item.url);
        downloadBlob(item.name, dataUrlToBlob(dataUrl));
      } catch {
        window.open(item.url, "_blank", "noopener");
      }
    }
    toast("已开始下载", "ok");
  });

  // v1.9.44 「AI 单张重绘」从界面移除（图片区只留「图片翻译」「AI 图片」两项）；
  // 入口没了就用可选链兜住，不然整页脚本会在这里断掉。
  $("#btn-it-redraw")?.addEventListener("click", async () => {
    if (!state.draft) return toast("请先载入草稿", "error");
    setBadge("#it-status", "生成中…", "warn");
    try {
      // 带上本产品参考图（图生图）：不带的话模型会自由发挥，画出一个跟本商品无关的东西
      let referenceImage = "";
      const sourceUrl = $("#set-gen-source")?.value || state.draft.mainImage || (state.draft.images || [])[0] || "";
      if (sourceUrl) {
        try { referenceImage = await fetchDataUrl(sourceUrl); } catch { /* 取不到就退回纯文生图 */ }
      }
      const data = await call({
        action: MESSAGE_ACTIONS.imageRedraw,
        // 品类 + 标题一起给：只给标题时，模型容易把「足球鞋」画成「跑鞋」
        context: cleanText([state.draft.ru?.productType, state.draft.ru?.title || state.draft.title].filter(Boolean).join(", ")),
        styleHint: cleanText($("#it-style").value),
        referenceImage,
        // 不传 size：后台用「设置 → AI 生图」里的出图尺寸（各服务支持范围不同）
      });
      const grid = $("#it-redraw-grid");
      const remoteUrl = data?.url || "";
      let src = data?.dataUrl || remoteUrl;
      if (!src) throw new Error("生图接口未返回可用图片");
      if (remoteUrl) {
        try { src = await fetchDataUrl(remoteUrl); } catch { /* 取不回就直接用远端 URL 展示 */ }
      }

      const index = state.redrawn.length + 1;
      state.redrawn.push({ name: `redraw-${index}.png`, dataUrl: src, url: remoteUrl });
      const figure = el("figure", {}, [imageThumb(src, `重绘图 ${index}`), el("figcaption", { text: `重绘图 ${index}` })]);
      // Ozon 只接受图片 URL，base64 的图无法直接上传；有远端地址时才允许写入草稿
      if (remoteUrl) {
        figure.appendChild(el("button", {
          text: "用作草稿图片",
          onclick: async () => {
            state.draft = await saveDraft({ id: state.draft.id, images: [remoteUrl, ...(state.draft.images || [])] });
            renderEditor();
            toast("已插入草稿图片首位", "ok");
          },
        }));
      } else {
        figure.appendChild(el("div", { class: "sub", text: "本地 base64 图，Ozon 无法直接使用，请下载后自行上传图床" }));
      }
      grid.appendChild(figure);
      setBadge("#it-status", "生成完成", "ok");
      toast("重绘图已生成，请人工确认后使用", "ok");
    } catch (error) {
      setBadge("#it-status", "生成失败", "err");
      const grid = $("#it-redraw-grid");
      // 把完整错误写进重绘网格（toast 几秒就消失，这里一直可见）
      grid.appendChild(el("div", { class: "error-box", text: `失败：${error.message || String(error)}` }));
      toast(error.message || "生图失败", "error");
    }
  });

  // 可用性检测：只测地址/密钥，不消耗额度
  $("#btn-it-test-vendor").addEventListener("click", () => {
    const vendor = $("#it-vendor")?.value || state.settings?.xiangjiVendor || "";
    if (!vendor) return toast("请先在上方选择翻译引擎（需先在设置里添加对应引擎的密钥）", "error");
    runXiangjiTest({ vendor, badge: "#it-status", tableSelector: "", wrapSelector: "" });
  });

  $("#btn-it-test-redraw")?.addEventListener("click", () => {
    // 在工作台里不直接改设置页的输入框，只在提示里给出规范化后的地址
    runImageTest({ badge: "#it-status", resultSelector: "", writeBack: false });
  });

  bindSetGen();
}

/* ---------------- OZON 上架套图（基于本产品图的图生图） ---------------- */

/** 当前生图预设：优先按模型名匹配，其次按 Base URL 前缀匹配 */
function activeImagePreset() {
  const model = String(state.settings?.imageModel || "").trim().toLowerCase();
  const base = normalizeApiBase(state.settings?.imageBaseUrl || "");
  const byModel = IMAGE_PRESETS.find((preset) => (preset.models || []).some((item) => item.toLowerCase() === model));
  if (byModel) return byModel;
  const byBase = IMAGE_PRESETS.find((preset) => preset.baseUrl && base && base.startsWith(normalizeApiBase(preset.baseUrl)));
  return byBase || IMAGE_PRESETS[0];
}

/** 用户选的尺寸 → 当前生图服务真正能出的尺寸（不支持时自动换最接近的，并说明） */
function currentSetSize() {
  const wanted = sizeForRatio(state.setGenRatio, state.setGenTier);
  const preset = activeImagePreset();
  const model = state.settings?.imageModel || "";
  return { wanted, ...resolveProviderSize(preset, model, wanted, state.setGenRatio) };
}

/* ---------- ① 图片类型 ---------- */

function renderSetGenKinds() {
  const wrap = $("#set-gen-kinds");
  if (!wrap) return;
  wrap.innerHTML = "";
  for (const kind of IMAGE_KINDS) {
    const on = state.setGenKindIds.includes(kind.id);
    // v1.9.52 每类张数可手填：上限 = 该类定义的拍法数（超出只会重复同一套拍法，没有意义）；
    // 没填过的类型保持默认构成（DEFAULT_KIND_LIMITS，未配置的类出全部拍法）
    const max = kind.shots.length;
    const current = Number(state.setKindLimits[kind.id]) || max;
    wrap.appendChild(el("label", { class: `setgen-card${on ? " is-on" : ""}` }, [
      el("input", { type: "checkbox", class: "setgen-kind", value: kind.id, checked: on }),
      el("span", { class: "txt" }, [
        el("span", { class: "name" }, [
          el("span", { text: `${kind.label} · ` }),
          el("input", {
            type: "number",
            class: "setgen-kind-count",
            dataset: { kind: kind.id },
            value: String(current),
            min: "1",
            max: String(max),
            step: "1",
            title: `${kind.label}出几张（1~${max}，最多 ${max} 种拍法）`,
          }),
          el("span", { text: " 张" }),
        ]),
        el("span", { class: "desc", text: kind.note }),
      ]),
    ]));
  }
  for (const box of $$("#set-gen-kinds input.setgen-kind")) {
    box.addEventListener("change", () => {
      state.setGenKindIds = $$("#set-gen-kinds input.setgen-kind:checked").map((node) => node.value);
      box.closest(".setgen-card")?.classList.toggle("is-on", box.checked);
      refreshSetGenSummary();
    });
  }
  // v1.9.52 张数输入校验：只收整数；越界自动纠正并提示；空/非法回退默认构成
  for (const input of $$("#set-gen-kinds input.setgen-kind-count")) {
    input.addEventListener("input", () => {
      // 输入过程中只拦非法字符，不打断打字
      input.value = input.value.replace(/[^\d]/g, "").slice(0, 2);
    });
    input.addEventListener("change", () => {
      const kind = IMAGE_KINDS.find((item) => item.id === input.dataset.kind);
      const max = kind ? kind.shots.length : MAX_SET_SHOTS;
      const fallback = Number(DEFAULT_KIND_LIMITS[input.dataset.kind]) || max;
      const raw = input.value.trim();
      let value = Number(raw);
      let note = "";
      if (!raw || !Number.isFinite(value)) {
        value = fallback;
        note = `${kind?.label || "该类型"}张数没填或不是整数，已回退默认 ${fallback} 张`;
      } else if (value < 1) {
        value = 1;
        note = `${kind?.label || "该类型"}至少出 1 张，已按 1 张处理`;
      } else if (value > max) {
        value = max;
        note = `${kind?.label || "该类型"}最多只有 ${max} 种拍法，已按 ${max} 张处理`;
      }
      value = Math.floor(value);
      state.setKindLimits[input.dataset.kind] = value;
      if (note) {
        input.value = String(value);
        toast(note, "warn");
      }
      refreshSetGenSummary();
    });
  }
}

/* ---------- ② 尺寸比例 ---------- */

function renderSetGenTiers() {
  const select = $("#set-gen-tier");
  if (!select) return;
  select.innerHTML = "";
  for (const tier of IMAGE_SIZE_TIERS) select.appendChild(el("option", { value: tier, text: tier }));
  select.value = state.setGenTier;
  select.addEventListener("change", () => {
    state.setGenTier = select.value;
    renderSetGenRatios();
    refreshSetGenSummary();
  });
}

function renderSetGenRatios() {
  const wrap = $("#set-gen-ratios");
  if (!wrap) return;
  wrap.innerHTML = "";
  for (const ratio of IMAGE_SIZE_RATIOS) {
    const size = sizeForRatio(ratio.id, state.setGenTier);
    const on = ratio.id === state.setGenRatio;
    wrap.appendChild(el("label", { class: `setgen-card${on ? " is-on" : ""}` }, [
      el("input", { type: "radio", name: "setgen-ratio", class: "setgen-ratio", value: ratio.id, checked: on }),
      el("span", { class: "txt" }, [
        el("span", { class: "name", text: `${ratio.label} · ${size}` }),
        el("span", { class: "desc", text: ratio.note }),
      ]),
    ]));
  }
  for (const box of $$("#set-gen-ratios input.setgen-ratio")) {
    box.addEventListener("change", () => {
      state.setGenRatio = box.value;
      for (const card of $$("#set-gen-ratios .setgen-card")) card.classList.remove("is-on");
      box.closest(".setgen-card")?.classList.add("is-on");
      refreshSetGenSummary();
    });
  }
}

/* ---------- ③ 张数（v1.9.51：预设按钮组改成手填输入框，1~15 张，非法值自动纠正） ---------- */

function renderSetGenCounts() {
  const input = $("#set-gen-count");
  if (!input) return;
  input.value = String(state.setGenCount);
  input.addEventListener("input", () => {
    // 输入过程中只拦非法字符，不打断打字
    input.value = input.value.replace(/[^\d]/g, "").slice(0, 2);
  });
  input.addEventListener("change", () => {
    const raw = input.value.trim();
    let value = Number(raw);
    if (!raw || !Number.isFinite(value)) {
      value = DEFAULT_SET_COUNT;
      toast(`张数没填或不是数字，已重置为 ${DEFAULT_SET_COUNT}`, "warn");
    } else if (value < 1) {
      value = 1;
      toast("张数至少 1 张，已按 1 张处理", "warn");
    } else if (value > MAX_SET_SHOTS) {
      value = MAX_SET_SHOTS;
      toast(`一次最多生成 ${MAX_SET_SHOTS} 张（再多容易被生图服务限流），已按 ${MAX_SET_SHOTS} 处理`, "warn");
    }
    value = Math.floor(value);
    state.setGenCount = value;
    input.value = String(value);
    refreshSetGenSummary();
  });
}

/* ---------- 参考图（本产品图） ---------- */

/** 可作参考图的本产品图：主图集 + 各 SKU 的专属图 */
function imageSourceCandidates() {
  const draft = state.draft;
  if (!draft) return [];
  const out = [];
  (draft.images || []).forEach((url, index) => {
    out.push({ url, label: index === 0 ? "主图（第 1 张）" : `图片 ${index + 1}` });
  });
  for (const sku of draft.skus || []) {
    const url = sku.image || (sku.images || [])[0];
    if (url && !out.some((item) => item.url === url)) out.push({ url, label: `SKU 图：${sku.label || sku.id}` });
  }
  return out;
}

/** 参考图 data URL 转换结果缓存（v1.9.50）：转换要下载整张原图，同一张图重复转一次很亏 */
const refDataUrlCache = new Map();

async function cachedRefDataUrl(url) {
  const key = String(url || "");
  if (!key) return "";
  if (refDataUrlCache.has(key)) return refDataUrlCache.get(key);
  const value = await fetchDataUrl(key);
  refDataUrlCache.set(key, value);
  if (refDataUrlCache.size > 24) refDataUrlCache.delete(refDataUrlCache.keys().next().value);
  return value;
}

/** 参考图：主参考图 + 其余产品图一并转 data URL（v1.9.38 参考全部产品图，上限 MAX_REFERENCE_IMAGES=3）
 *  v1.9.50：改成**并行**取多张 + 命中缓存直接复用——原来是 for 里串行 await，3 张图白白多等两个来回。 */
async function fetchReferenceImages() {
  const sourceUrl = $("#set-gen-source")?.value || "";
  if (!sourceUrl) throw new Error("请先在「② 尺寸 · 参考图」选择参考图（本产品图）");
  let referenceImage = "";
  try {
    // 转成 data URL：1688 的图有防盗链，直接把 URL 交给生图服务大概率取不到
    referenceImage = await cachedRefDataUrl(sourceUrl);
  } catch (error) {
    throw new Error(`取参考图失败（${error?.message || error}）—— 请先确认图片能正常显示，或换一张参考图`);
  }
  const extraUrls = [];
  const usedRefUrls = new Set([sourceUrl]);
  for (const item of imageSourceCandidates()) {
    if (1 + extraUrls.length >= MAX_REFERENCE_IMAGES) break;
    if (!item.url || usedRefUrls.has(item.url)) continue;
    usedRefUrls.add(item.url);
    extraUrls.push(item.url);
  }
  const rest = await Promise.all(extraUrls.map((url) => cachedRefDataUrl(url).catch(() => "")));
  return { referenceImage, referenceImages: [referenceImage, ...rest.filter(Boolean)] };
}

/** 拼风格提示：风格方向的俄文描述 + 品类自动风格（都为空时返回空串） */
function joinStyle(...parts) {
  return parts.map((item) => cleanText(item)).filter(Boolean).join("; ");
}

function syncSetGenSources() {
  const select = $("#set-gen-source");
  if (!select) return;
  const previous = select.value;
  const list = imageSourceCandidates();
  select.innerHTML = "";
  if (!list.length) {
    select.appendChild(el("option", { value: "", text: "（草稿还没有图片，请先采集或载入草稿）" }));
    return;
  }
  for (const item of list) select.appendChild(el("option", { value: item.url, text: item.label }));
  select.value = list.some((item) => item.url === previous) ? previous : list[0].url;
}

/* ---------- ⑤ 卖点 ---------- */

function renderSetGenPoints() {
  const wrap = $("#set-gen-points-list");
  if (!wrap) return;
  wrap.innerHTML = "";
  if (!state.setGenPoints.length) {
    wrap.appendChild(el("p", {
      class: "sub",
      text: "还没有卖点。点「AI 生成卖点」自动生成俄文卖点，或在下面手动追加。卖点会作为图上出现的俄文小字。",
    }));
    return;
  }
  state.setGenPoints.forEach((item, index) => {
    const card = el("label", { class: `setgen-card${item.on ? " is-on" : ""}` }, [
      el("input", { type: "checkbox", class: "setgen-point", checked: item.on }),
      el("span", { class: "txt text", text: item.text }),
    ]);
    const box = card.querySelector("input");
    box.addEventListener("change", () => {
      state.setGenPoints[index].on = box.checked;
      card.classList.toggle("is-on", box.checked);
      refreshSetGenSummary();
    });
    wrap.appendChild(card);
  });
}

/** 勾选的 AI 卖点 + 手动追加的卖点，最多 6 条（图面塞不下更多） */
function selectedSetPoints() {
  const manual = String($("#set-gen-points-extra")?.value || "")
    .split(/[\n,，、;；]/)
    .map((item) => cleanText(item))
    .filter(Boolean);
  return [
    ...state.setGenPoints.filter((item) => item.on).map((item) => item.text),
    ...manual,
  ].slice(0, 6);
}

async function generateSetGenPoints() {
  if (!state.draft) return toast("请先载入草稿", "error");
  if (!await ensureLicensed("AI 生成卖点")) return;
  const btn = $("#btn-set-gen-points");
  if (btn) btn.disabled = true;
  setBadge("#set-gen-points-status", "生成中…", "warn");
  try {
    const data = await call({
      action: MESSAGE_ACTIONS.aiSellingPoints,
      product: state.draft,
      options: { extraInfo: cleanText($("#set-gen-extra")?.value || ""), count: 6 },
    });
    const points = Array.isArray(data?.points) ? data.points : [];
    if (!points.length) throw new Error("AI 没返回可用卖点");
    state.setGenPoints = points.map((text) => ({ text, on: true }));
    renderSetGenPoints();
    setBadge("#set-gen-points-status", `已生成 ${points.length} 条`, "ok");
    refreshSetGenSummary();
  } catch (error) {
    setBadge("#set-gen-points-status", "生成失败", "err");
    toast(`生成卖点失败：${error?.message || error}`, "error");
  } finally {
    if (btn) btn.disabled = false;
  }
}

/* ---------- 出图计划 ---------- */

function plannedShots() {
  return planSetShots({
    kinds: state.setGenKindIds,
    count: state.setGenCount,
    titles: state.setGenTitles,
    labels: state.setGenLabels,
    custom: cleanText($("#set-gen-kind-custom")?.value || ""),
    // v1.9.52 每类张数用用户手填的值（没填过的类仍按默认构成）
    limits: state.setKindLimits,
  });
}

/** 草稿属性里挑出不含中文的规格标签（含中文的一概不用，免得图上出现中文） */
function fallbackSetGenLabels() {
  return (state.draft?.attributes || [])
    .map((attr) => `${cleanText(attr?.name)} ${cleanText(attr?.value)}`.trim())
    .filter((line) => line && !/[\u4e00-\u9fa5]/.test(line))
    .slice(0, 6);
}

/**
 * 让 AI 给每张「带文字的图」拟俄文标题（对应出图工具里的「视觉方案规划」）。
 * 失败不阻断出图——直接用方案表里的兜底标题。
 */
async function fetchSetGenPlan(shots) {
  const withText = shots.filter((shot) => shot.text && shot.text !== TEXT_MODES.NONE);
  if (!withText.length) return {};
  if (!$("#set-gen-points-ai")?.checked) return {};
  try {
    const data = await call({
      action: MESSAGE_ACTIONS.aiImagePlan,
      product: state.draft,
      shots: withText.map((shot) => ({ id: shot.id, label: shot.label })),
      options: {
        points: selectedSetPoints(),
        extraInfo: cleanText($("#set-gen-extra")?.value || ""),
      },
    });
    const plan = data?.plan || {};
    // 把 AI 给的俄文参数收集起来，下次生成规格图就有现成的标签
    const labels = Object.values(plan).flatMap((item) => (Array.isArray(item?.labels) ? item.labels : []));
    if (labels.length) {
      state.setGenLabels = [...new Set([...state.setGenLabels, ...labels])].slice(0, 8);
    }
    return plan;
  } catch (error) {
    setBadge("#set-gen-status", `AI 拟标题失败（${error?.message || error}），改用默认俄文标题`, "warn");
    return {};
  }
}

/* ---------- 图位板：双列格子，数字在图片底下，生成后图片填进对应格子 ---------- */

/** 当前出图方案的签名：类型/张数没变就不整板重绘（v1.9.51 渲染提速） */
let lastSetPlanKey = "";

function setPlanKey(shots) {
  return (shots || []).map((shot) => shot.id).join("|");
}

/** 构建单个图位卡片（renderSetGenGrid 与 patchSetGenSlot 共用） */
function buildSetGenSlotCard(shot, index, item) {
  const hasImg = item && !item.error && (item.dataUrl || item.url);
  const card = el("figure", {
    class: `setgen-slot${hasImg ? " has-img" : ""}${item?.error ? " is-error" : ""}`,
    dataset: { shot: shot.id },
  });
  if (hasImg) {
    card.appendChild(imageThumb(item.dataUrl || item.url, shot.label));
  } else {
    card.appendChild(el("div", { class: "setgen-slot-empty" }, [
      el("span", { text: item?.error ? "生成失败" : "待生成" }),
    ]));
    if (item?.error) card.appendChild(el("span", { class: "danger-text slot-err", text: item.error }));
  }
  // 数字在图片底下：图位编号 + 名称（+ AI 拟的俄文标题，便于核对图上文字）
  const variantNote = hasImg
    ? (item.artDirection
      ? "独立方案"
      : `版式 ${((Number(item.variant?.layoutSeed) || 0) % 5) + 1}/机位 ${Number(item.variant?.framingSeed) || 1}`)
    : "";
  card.appendChild(el("figcaption", { class: "slot-cap" }, [
    el("span", { class: "slot-no", text: String(index + 1) }),
    el("span", {
      class: "slot-label",
      text: [item?.title ? `${shot.label}｜${item.title}` : shot.label, item?.direction?.label ? `· ${item.direction.label}` : "", variantNote ? `· ${variantNote}` : ""]
        .filter(Boolean).join(" "),
    }),
  ]));
  // v1.9.42 单张重出：这张图不合约束（面孔/产品/文字/风格）就只重做这一张
  card.appendChild(el("button", {
    class: "slot-redo",
    text: "重出此图",
    onclick: () => regenerateSetShot(shot.id),
  }));
  if (item?.url) {
    // v1.9.51 改名「设为主图」：点它把这张 AI 图挪到草稿图片首位（Ozon 主图 = 第一张）
    card.appendChild(el("button", {
      text: "设为主图",
      onclick: () => setDraftMainImage(item.url),
    }));
  }
  return card;
}

function renderSetGenGrid() {
  const grid = $("#set-gen-grid");
  if (!grid) return;
  grid.innerHTML = "";
  const shots = plannedShots();
  lastSetPlanKey = setPlanKey(shots);
  if (!shots.length) {
    grid.appendChild(el("p", {
      class: "sub",
      text: "勾选上面的图片类型后，这里会按出图位排好格子；生成的图片直接填进对应格子。",
    }));
    return;
  }
  const results = new Map();
  for (const item of state.setGen) if (item.shot) results.set(item.shot, item);
  shots.forEach((shot, index) => {
    grid.appendChild(buildSetGenSlotCard(shot, index, results.get(shot.id)));
  });
}

/** v1.9.51 增量渲染：只重画完成的那一格。
 *  原来每完成一张就整板重建——8 张大 data URL 全部重新解码，越到后面越卡，
 *  也让「边出边看」的等待感更明显。方案变了（找不到格子）时才退回整板重建。 */
function patchSetGenSlot(shotId) {
  const grid = $("#set-gen-grid");
  if (!grid) return;
  const shots = plannedShots();
  const index = shots.findIndex((shot) => shot.id === shotId);
  const item = state.setGen.find((entry) => entry.shot === shotId);
  const card = index >= 0 ? grid.querySelector(`figure[data-shot="${shotId}"]`) : null;
  if (index < 0 || !item || !card) {
    renderSetGenGrid();
    return;
  }
  grid.replaceChild(buildSetGenSlotCard(shots[index], index, item), card);
}

/** 汇总提示：实际出几张、尺寸会被怎么适配、参数图有没有俄文参数 */
function refreshSetGenSummary() {
  const resolved = currentSetSize();
  const sizeNote = $("#set-gen-size-note");
  if (sizeNote) {
    sizeNote.textContent = resolved.exact
      ? `将按 ${resolved.size || "—"} 出图`
      : `当前生图服务不支持 ${resolved.requested}，会自动改用最接近的 ${resolved.size} 出图`;
  }

  const shots = plannedShots();
  const countNote = $("#set-gen-count-note");
  if (countNote) {
    const custom = cleanText($("#set-gen-kind-custom")?.value || "") ? 1 : 0;
    // v1.9.52 汇总同样按用户手填的每类张数算，不按默认构成
    const total = expandSetShots(state.setGenKindIds, state.setKindLimits).length + custom;
    const needsLabel = shots.some((shot) => shot.text === TEXT_MODES.SPEC || shot.text === TEXT_MODES.TABLE);
    countNote.textContent = [
      `已选类型共 ${total} 张，张数上限 ${state.setGenCount} → 实际生成 ${shots.length} 张`,
      needsLabel && !state.setGenLabels.length
        ? "参数图需要俄文参数：建议先点「AI 生成卖点」，并保持「生成前用 AI 拟俄文标题」勾选"
        : "",
    ].filter(Boolean).join("；");
  }

  const planNode = $("#set-gen-plan");
  if (planNode) {
    planNode.textContent = shots.length
      ? `出图顺序：${shots.map((shot, index) => `${index + 1}.${shot.label}`).join(" · ")}`
      : "请至少选择一种图片类型";
  }

  // v1.9.38 风格留空时按品类自动选：把自动风格亮在输入框 placeholder 里，手填则优先
  const styleInput = $("#set-gen-style");
  if (styleInput && !styleInput.value.trim()) {
    const autoStyle = pickStyleFor(
      state.draft?.ru?.productType || "",
      [state.draft?.ozonCategory?.path, state.draft?.categoryPath, state.draft?.category].filter(Boolean).flat().join(" > "),
    );
    styleInput.placeholder = `留空则按品类自动风格：${autoStyle.slice(0, 60)}…`;
  }

  // 图位板跟着类型/张数联动；方案没变就不重绘（v1.9.51：补充信息框每敲一个字都会走到这里，
  // 原来每次都整板重建、所有大图重新解码，生成完成后打字会明显卡顿）
  const planKey = setPlanKey(shots);
  if (planKey !== lastSetPlanKey) renderSetGenGrid();
}

/* ---------- 生成套图 ---------- */

/** 逐张串行生成（避免并发限流），每张都带本产品参考图 */
async function generateListingSet() {
  if (!state.draft) return toast("请先载入草稿", "error");
  if (!await ensureLicensed("AI 生成图片")) return;
  const sourceUrl = $("#set-gen-source")?.value || "";
  if (!sourceUrl) return toast("请先选择参考图（本产品图）", "error");
  if (!state.setGenKindIds.length && !cleanText($("#set-gen-kind-custom")?.value || "")) {
    return toast("请至少选择一种图片类型", "error");
  }

  const btn = $("#btn-set-gen");
  if (btn) btn.disabled = true;
  state.setGen = [];
  state.setGenTitles = {};
  state.setGenArt = null;
  renderSetGenGrid();

  const shots = plannedShots();
  if (!shots.length) {
    if (btn) btn.disabled = false;
    return toast("没有可生成的图", "error");
  }

  // v1.9.50 「取参考图」和「拟俄文标题」互不依赖 → 并行跑，省掉一个来回的等待
  // （原来是先取完参考图再拟标题，8 张套图光前置就要多等十几秒）
  setBadge("#set-gen-status", "准备参考图 + 拟俄文标题…", "warn");
  const [refsResult, planResult] = await Promise.allSettled([fetchReferenceImages(), fetchSetGenPlan(shots)]);
  if (refsResult.status === "rejected") {
    if (btn) btn.disabled = false;
    setBadge("#set-gen-status", "参考图获取失败", "err");
    return toast(refsResult.reason?.message || String(refsResult.reason), "error");
  }
  const refs = refsResult.value;
  if (!state.setGenLabels.length) state.setGenLabels = fallbackSetGenLabels();
  // 拟标题失败不阻断出图：fetchSetGenPlan 内部已兜底，这里再兜一层
  const plan = planResult.status === "fulfilled" ? planResult.value : null;
  for (const shot of shots) {
    const given = plan?.[shot.id];
    if (!given) continue;
    if (given.title) shot.title = given.title;
    if (given.subtitle) shot.subtitle = given.subtitle;
    if (Array.isArray(given.labels) && given.labels.length) shot.labels = given.labels;
    state.setGenTitles[shot.id] = { title: shot.title, subtitle: shot.subtitle, labels: shot.labels };
  }

  // v1.9.49 出图前视觉分析：先看参考图对比差异，再给每张图一份独立的「导演方案」。
  // 勾选了「逐图定制」且模型可用才做；失败不阻断——下面还有版式逐张轮换兜底。
  if ($("#set-gen-art-ai")?.checked) {
    setBadge("#set-gen-status", "分析参考图（构图/光影/材质）…", "warn");
    try {
      state.setGenArt = await call({
        action: MESSAGE_ACTIONS.aiArtDirection,
        product: state.draft,
        shots: shots.map((shot) => ({ id: shot.id, label: shot.label, text: shot.text })),
        referenceImages: refs.referenceImages,
        options: {
          extraInfo: cleanText($("#set-gen-extra")?.value || ""),
          points: selectedSetPoints(),
        },
      });
      setBadge("#set-gen-status", `参考图分析完成，${Object.keys(state.setGenArt?.shots || {}).length}/${shots.length} 张有独立方案`, "ok");
    } catch (error) {
      state.setGenArt = null;
      setBadge("#set-gen-status", `视觉分析失败（${error?.message || error}），改用逐张轮换版式出图`, "warn");
    }
  } else {
    state.setGenArt = null;
  }
  // 每张图分配互不相同的版式/取景种子；有视觉分析结果时版式以 AI 为该图挑的为准
  const variants = assignShotVariants(shots);
  shots.forEach((shot, index) => {
    const art = state.setGenArt?.shots?.[shot.id];
    if (art) {
      shot.artDirection = art.artDirection || "";
      if (shot.text === TEXT_MODES.INFO && Number.isFinite(Number(art.layout))) {
        variants[index].layoutSeed = Number(art.layout);
      }
    }
    shot.variant = variants[index];
  });

  // 品类 + 标题一起给：只给标题时，模型容易把「足球鞋」画成「跑鞋」
  const context = cleanText([state.draft.ru?.productType, state.draft.ru?.title || state.draft.title].filter(Boolean).join(", "));
  // v1.9.38 按品类自动挑风格（参考 OZON 热销卡片的视觉语言）；手填风格优先
  const manualStyle = cleanText($("#set-gen-style")?.value || "");
  const autoStyle = pickStyleFor(
    state.draft.ru?.productType || "",
    [state.draft.ozonCategory?.path, state.draft.categoryPath, state.draft.category].filter(Boolean).flat().join(" > "),
  );
  const extraInfo = cleanText($("#set-gen-extra")?.value || "");
  const points = selectedSetPoints();
  const resolved = currentSetSize();
  // v1.9.42 每张按「风格方向」出图（纯色棚拍/极简高级/居家/街景/暖调/节日），成套图风格多样、同方向一致
  const directions = assignSetDirections(shots);
  const allowWhiteBg = Boolean($("#set-gen-bg-white")?.checked);
  let done = 0;

  // v1.9.50 并发出图：默认 2 张同时跑（「并发数」可调 1~3）。
  // 原来是一张一张串行 await，8 张套图要 3~5 分钟；并发 2 基本能砍掉一半等待。
  // 上限锁在 3 是为了别把生图服务打出限流（限流反而更慢，还会整批失败）。
  const concurrency = Math.min(3, Math.max(1, Number($("#set-gen-concurrency")?.value) || 2));
  let cursor = 0;
  const generateOne = async () => {
    while (cursor < shots.length) {
      const index = cursor;
      cursor += 1;
      const shot = shots[index];
      const direction = directions[index];
      const variant = shot.variant || { layoutSeed: 0, framingSeed: index + 1 };
      setBadge("#set-gen-status", `生成中 ${done + 1}/${shots.length}：${shot.label}（${direction.label}${shot.artDirection ? " · 独立方案" : ` · 版式 ${(variant.layoutSeed % 5) + 1}/机位 ${variant.framingSeed}`}）`, "warn");
      try {
        const data = await call({
          action: MESSAGE_ACTIONS.imageRedraw,
          context,
          styleHint: manualStyle || joinStyle(cleanText(direction?.style), autoStyle),
          styleDirection: direction?.label || "",
          size: resolved.size,
          // 传整个方案对象：自定义图片类型的拍法也在这条链路上
          shot,
          // v1.9.38 卖点每张都传：带字的图上字、无字的图按卖点决定取景重点
          points,
          title: shot.title || "",
          subtitle: shot.subtitle || "",
          labels: shot.labels || [],
          extraInfo,
          direction,
          allowWhiteBg,
          // v1.9.49 逐图定制：版式种子 / 取景种子 / 该图专属导演方案（视觉分析产出）
          layoutSeed: variant.layoutSeed,
          framingSeed: variant.framingSeed,
          artDirection: shot.artDirection || "",
          referenceImages: refs.referenceImages,
          referenceImage: refs.referenceImage,
        });
        const remoteUrl = data?.url || "";
        // v1.9.51 拿到结果立刻上屏：不再先 await fetchDataUrl(remoteUrl) 把整张图下载回本地
        //（8 张套图就是 8 次全量下载，每张好几 MB，用户盯着「生成中」多等一两分钟纯属浪费）。
        // 展示直接用远端 URL；本地 dataUrl 只在「下载全部」时按需取（那里已有 fallback）。
        const src = data?.dataUrl || remoteUrl;
        if (!src) throw new Error("生图接口未返回可用图片");
        state.setGen.push({ shot: shot.id, label: shot.label, title: shot.title || "", dataUrl: src, url: remoteUrl, error: "", direction, variant, artDirection: shot.artDirection || "", attempts: 1 });
        done += 1;
      } catch (error) {
        state.setGen.push({ shot: shot.id, label: shot.label, title: shot.title || "", dataUrl: "", url: "", error: error?.message || String(error), direction, variant, artDirection: shot.artDirection || "", attempts: 1 });
      }
      // 只重画这一格，不整板重建（整板重建会把所有已出的大图重新解码）
      patchSetGenSlot(shot.id);
    }
  };
  await Promise.all(Array.from({ length: Math.min(concurrency, shots.length) }, generateOne));

  if (btn) btn.disabled = false;
  const failed = state.setGen.filter((item) => item.error).length;
  setBadge(
    "#set-gen-status",
    failed ? `完成 ${done}/${shots.length}（${failed} 张失败）` : `完成 ${done}/${shots.length}`,
    failed ? "warn" : "ok",
  );
  toast(
    failed
      ? `套图生成完成：成功 ${done} 张、失败 ${failed} 张（失败原因见上方图位板）`
      : `套图生成完成，共 ${done} 张，请人工确认后使用`,
    failed ? "warn" : "ok",
  );
}

/**
 * 单张重出（v1.9.42，v1.9.49 强化）：某张图效果不理想时点「重出此图」。
 * v1.9.49 起会先问「上一版哪里不满意、想往哪个方向改」，重出时：
 *   - 把反馈原文压进提示词（reworkNote），明确要求模型离开上一版的构图/光线/排版；
 *   - 版式/取景种子强制 +1/+3 轮换——就算反馈留空，也不会重复上一次的固定做法。
 */
async function regenerateSetShot(shotId) {
  if (!state.draft) return toast("请先载入草稿", "error");
  const shot = plannedShots().find((item) => item.id === shotId);
  if (!shot) return toast("这张图位已不在当前出图方案里", "error");
  const prev = state.setGen.find((item) => item.shot === shotId);
  const given = state.setGenTitles?.[shot.id] || {};
  if (given.title) shot.title = given.title;
  if (given.subtitle) shot.subtitle = given.subtitle;
  if (Array.isArray(given.labels) && given.labels.length) shot.labels = given.labels;

  // 问一次「这张哪里不行」——反馈会进提示词；留空也照样换版式换机位重出
  const feedback = await openModal({
    title: `重出「${shot.label}」`,
    submitText: "换方向重出",
    fields: [{
      key: "note",
      label: "上一版哪里不满意？想让这张往什么方向改？（选填，但写了效果更准）",
      type: "textarea",
      rows: 3,
      placeholder: "如：文字块压住了商品把手；背景太暗，换成明亮居家场景；排版换一个样式",
      hint: "留空也会自动换一套版式和机位重出——不会重复上一次的画法。",
    }],
  });
  if (feedback === null) return; // 取消
  const reworkNote = cleanText(feedback.note || "");

  const context = cleanText([state.draft.ru?.productType, state.draft.ru?.title || state.draft.title].filter(Boolean).join(", "));
  const manualStyle = cleanText($("#set-gen-style")?.value || "");
  const autoStyle = pickStyleFor(
    state.draft.ru?.productType || "",
    [state.draft.ozonCategory?.path, state.draft.categoryPath, state.draft.category].filter(Boolean).flat().join(" > "),
  );
  const direction = prev?.direction || assignSetDirections([shot])[0];
  const allowWhiteBg = Boolean($("#set-gen-bg-white")?.checked);
  // 强制离开上一次的版式/机位（prev.variant 可能没有——老草稿没存过，就从当前轮换值往后跳）
  const variant = nextShotVariant(prev?.variant || shot.variant || { layoutSeed: 0, framingSeed: 1 });
  const art = state.setGenArt?.shots?.[shot.id];
  shot.artDirection = art?.artDirection || prev?.artDirection || "";
  setBadge("#set-gen-status", `重出中：${shot.label}（已换版式/机位${reworkNote ? " + 按反馈调整" : ""}）`, "warn");
  try {
    const refs = await fetchReferenceImages();
    const data = await call({
      action: MESSAGE_ACTIONS.imageRedraw,
      context,
      styleHint: manualStyle || joinStyle(cleanText(direction?.style), autoStyle),
      styleDirection: direction?.label || "",
      size: currentSetSize().size,
      shot,
      points: selectedSetPoints(),
      title: shot.title || "",
      subtitle: shot.subtitle || "",
      labels: shot.labels || [],
      extraInfo: cleanText($("#set-gen-extra")?.value || ""),
      direction,
      allowWhiteBg,
      layoutSeed: variant.layoutSeed,
      framingSeed: variant.framingSeed,
      artDirection: shot.artDirection,
      reworkNote,
      referenceImages: refs.referenceImages,
      referenceImage: refs.referenceImage,
    });
    const remoteUrl = data?.url || "";
    // v1.9.51 同主流程：拿到结果立刻上屏，不再阻塞在整图下载上
    const src = data?.dataUrl || remoteUrl;
    if (!src) throw new Error("生图接口未返回可用图片");
    const entry = {
      shot: shot.id, label: shot.label, title: shot.title || "", dataUrl: src, url: remoteUrl, error: "",
      direction, variant, artDirection: shot.artDirection,
      attempts: (Number(prev?.attempts) || 1) + 1,
    };
    const index = state.setGen.findIndex((item) => item.shot === shotId);
    if (index >= 0) state.setGen[index] = entry;
    else state.setGen.push(entry);
    patchSetGenSlot(shotId);
    setBadge("#set-gen-status", `已重出：${shot.label}（第 ${entry.attempts} 版，换了版式/机位）`, "ok");
    toast(`已按新方向重出「${shot.label}」`, "ok");
  } catch (error) {
    setBadge("#set-gen-status", `重出失败：${shot.label}`, "err");
    toast(`重出失败：${error?.message || error}`, "error");
  }
}

function bindSetGen() {
  if (!$("#set-gen-block")) return;
  renderSetGenKinds();
  renderSetGenTiers();
  renderSetGenRatios();
  renderSetGenCounts();
  renderSetGenPoints();
  syncSetGenSources();

  $("#btn-set-gen").addEventListener("click", generateListingSet);
  $("#btn-set-gen-points").addEventListener("click", generateSetGenPoints);
  $("#btn-set-gen-points-clear").addEventListener("click", () => {
    state.setGenPoints = [];
    renderSetGenPoints();
    refreshSetGenSummary();
    toast("已清空卖点", "ok");
  });
  for (const id of ["#set-gen-kind-custom", "#set-gen-extra", "#set-gen-points-extra"]) {
    $(id)?.addEventListener("input", refreshSetGenSummary);
  }

  $("#btn-set-gen-download").addEventListener("click", async () => {
    const list = state.setGen.filter((item) => !item.error && (item.dataUrl || item.url));
    if (!list.length) return toast("还没有可下载的套图", "error");
    for (const [index, item] of list.entries()) {
      const name = `ozon-set-${String(index + 1).padStart(2, "0")}-${item.shot}.png`;
      try {
        // v1.9.51 起展示用直链，dataUrl 字段可能是远端 URL；只有真正的 data: 才能直接转 Blob
        const local = String(item.dataUrl || "").startsWith("data:") ? item.dataUrl : "";
        const dataUrl = local || await fetchDataUrl(item.url);
        downloadBlob(name, dataUrlToBlob(dataUrl));
      } catch {
        window.open(item.url, "_blank", "noopener");
      }
    }
    toast(`已开始下载 ${list.length} 张`, "ok");
  });

  $("#btn-set-gen-apply").addEventListener("click", async () => {
    if (!state.draft) return toast("请先载入草稿", "error");
    const btnApply = $("#btn-set-gen-apply");
    const ready = state.setGen.filter((item) => !item.error && item.url);
    const localOnly = state.setGen.filter((item) => !item.error && !item.url);
    if (!ready.length) {
      return toast(
        localOnly.length
          ? `这 ${localOnly.length} 张只拿到本地 base64（生图接口没返回图片直链）。Ozon 抓不到 base64，等于「商品卡片中没有照片」——请先下载这些图、上传到图床拿到直链，或换一个会返回图片 URL 的生图接口`
          : "还没有可加入草稿的套图",
        "error",
      );
    }
    // v1.9.50 加进来之前先确认 Ozon 抓得到：临时链/防盗链的地址混进草稿，
    // 上传后就是「商品卡片中没有照片」+ 商品被封锁。
    let bad = [];
    if (btnApply) btnApply.disabled = true;
    setBadge("#set-gen-status", "校验图片可访问性…", "warn");
    try {
      const probe = await probeImageUrls(ready.map((item) => item.url));
      bad = (probe.results || []).filter((item) => !item.ok);
    } catch { /* 探测本身失败就不拦，按原样加入 */ } finally {
      if (btnApply) btnApply.disabled = false;
    }
    const badUrls = new Set(bad.map((item) => item.url));
    const urls = ready.map((item) => item.url).filter((url) => !badUrls.has(url));
    if (!urls.length) {
      const detail = bad.slice(0, 3).map((item) => `${item.reason || "地址不可访问"}`).join("；");
      setBadge("#set-gen-status", `已拦下 ${bad.length} 张：Ozon 抓不到`, "err");
      return toast(`这些套图 Ozon 服务器打不开（${detail}），加进草稿上传后会被判「没有照片」并封锁，所以全拦下了。解法：点「下载图片」存本地 → 传到能公开访问的图床/OSS 拿新直链再导入，或换一个返回稳定图片 URL 的生图接口。`, "error");
    }
    const images = dedupeUrls([...(state.draft.images || []), ...urls]);
    // 记下哪些是 AI 生成的：上传前要用它判断「主图是不是采集原图（多半带中文）」
    const aiImageUrls = dedupeUrls([...(state.draft.aiImageUrls || []), ...urls]);
    state.draft = await saveDraft({ id: state.draft.id, images, aiImageUrls });
    state.selectedImages = new Set(images);
    renderEditor();
    const notes = [];
    if (bad.length) notes.push(`${bad.length} 张 Ozon 抓不到已拦下`);
    if (localOnly.length) notes.push(`${localOnly.length} 张只有 base64 没加进来`);
    if (images.length > 9) notes.push(`共 ${images.length} 张，Ozon 单次最多 9 张，超出会被截断`);
    toast(
      notes.length ? `已加入 ${urls.length} 张套图（${notes.join("；")}）` : `已加入 ${urls.length} 张套图`,
      notes.length ? "warn" : "ok",
    );
  });

  $("#btn-it-test-redraw2").addEventListener("click", () => {
    runImageTest({ badge: "#set-gen-status", resultSelector: "", writeBack: false });
  });

  refreshSetGenSummary();
}

function dataUrlToBlob(dataUrl) {
  const [meta, body] = String(dataUrl).split(",");
  const mime = (meta.match(/:(.*?);/) || [, "image/png"])[1];
  const binary = atob(body || "");
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return new Blob([bytes], { type: mime });
}

// 产品图判定统一走 shared/image-filter.js（纯函数，带单测）；这里只负责渲染与交互

/** 草稿里 AI 生成图的 URL 集合（v1.9.50 加入草稿时记录在 aiImageUrls） */
function draftAiUrlSet() {
  return new Set((Array.isArray(state.draft?.aiImageUrls) ? state.draft.aiImageUrls : []).filter(Boolean));
}

/** v1.9.51 把某张图设为草稿主图（Ozon 主图 = 图片列表第一张）。
 *  「生成 → 筛选 AI 图 → 选一张载入主图」流程的最后一步：AI 图挪到首位，其余顺序不变。 */
async function setDraftMainImage(url) {
  if (!state.draft) return toast("请先载入草稿", "error");
  const images = state.draft.images || [];
  if (!url || !images.includes(url)) return toast("这张图不在草稿图片列表里，先把 AI 图加入草稿（「全部加入草稿图片」）", "warn");
  const kept = [url, ...images.filter((item) => item !== url)];
  state.draft = await saveDraft({ id: state.draft.id, images: kept });
  state.selectedImages.add(url);
  renderImageGallery();
  await renderBulkLists();
  const isAi = draftAiUrlSet().has(url);
  toast(isAi ? "已设为草稿主图（AI 图，无中文文案风险）" : "已设为草稿主图。注意：采集原图多半带中文文案，Ozon 禁止主图出现汉字/英文，建议优先用 AI 主图", isAi ? "ok" : "warn");
}

function renderImageGallery() {
  const grid = $("#image-grid");
  if (!grid) return;
  grid.innerHTML = "";
  // v1.9.51 「筛选 AI 图片」：开关打开时列表只显示 AI 生成的图，其余来源隐藏；再点一次恢复全部
  const all = state.draft?.images || [];
  const aiSet = draftAiUrlSet();
  const images = state.aiImageOnly ? all.filter((url) => aiSet.has(url)) : all;
  const meta = state.draft?.imageMeta || {};
  updateImageCount();
  if (!images.length) {
    grid.appendChild(el("p", {
      class: "hint",
      text: state.aiImageOnly
        ? "草稿里还没有 AI 生成的图片。先在下方「AI 图片」生成，点「全部加入草稿图片」，再回来筛选。"
        : "当前草稿没有可用商品图片。请重新采集并确认商品页已完成加载；也可以保留手动载入入口重试。",
    }));
    return;
  }
  images.forEach((url, index) => {
    const checked = state.selectedImages.has(url);
    const product = isLikelyProductImage(url, meta);
    const figure = el("figure", { class: checked ? "" : "is-excluded" }, [
      el("button", {
        class: "img-remove",
        type: "button",
        text: "×",
        title: "从草稿里删除这张图",
        onclick: () => removeDraftImage(url),
      }),
      el("label", { class: "image-select" }, [
        el("input", { type: "checkbox", class: "img-select", value: url, checked, dataset: { url } }),
        el("span", { text: `${index + 1}` }),
      ]),
      imageThumb(url, `图 ${index + 1}`),
      el("figcaption", {}, [
        el("span", { text: productImageReason(url, meta), class: product ? "" : "danger-text" }),
        // v1.9.51 「设为主图」：不用再手动把图挪到第一位；AI 图载入主图就从这里点
        el("button", {
          class: "mini img-set-main",
          type: "button",
          text: aiSet.has(url) ? "设为主图 (AI)" : "设为主图",
          title: "把这张图挪到草稿图片首位（Ozon 主图 = 第一张）",
          onclick: () => setDraftMainImage(url),
        }),
      ]),
    ]);
    grid.appendChild(figure);
  });

  for (const checkbox of $$("#image-grid input.img-select")) {
    checkbox.addEventListener("change", () => {
      const url = checkbox.dataset.url;
      if (checkbox.checked) state.selectedImages.add(url);
      else state.selectedImages.delete(url);
      checkbox.closest("figure")?.classList.toggle("is-excluded", !checkbox.checked);
      updateImageCount();
    });
  }

  renderDetailImageGallery();
  syncSetGenSources();
}

function updateDetailImageCount() {
  const node = $("#detail-img-count");
  if (node) node.textContent = String(state.draft?.detailImages?.length || 0);
}

/** 1688 详情长图：默认不进主图集，勾选后点「并入图片集」才合并 */
function renderDetailImageGallery() {
  const grid = $("#detail-image-grid");
  if (!grid) return;
  grid.innerHTML = "";
  const images = state.draft?.detailImages || [];
  updateDetailImageCount();
  const block = $("#detail-img-block");
  if (block) block.hidden = !images.length;
  if (!images.length) return;
  // 「商品详情长图」入口挂在采集结果卡上（图片处理区只留「图片翻译」「AI 图片」两项）。
  // 重新载入旧草稿时那张卡可能还是收起的，有长图就把它露出来，否则用户找不到「并入图片集」。
  const captureCard = $("#capture-result");
  if (captureCard?.hidden) {
    captureCard.hidden = false;
    const thumb = $("#capture-thumb");
    if (thumb) thumb.removeAttribute("src");
    const title = $("#capture-title");
    if (title && !cleanText(title.textContent)) title.textContent = "（载入的草稿）本次未重新采集";
  }
  for (const [index, url] of images.entries()) {
    const checked = state.selectedDetailImages.has(url);
    grid.appendChild(el("figure", { class: checked ? "" : "is-excluded" }, [
      el("label", { class: "image-select" }, [
        el("input", { type: "checkbox", class: "detail-img-select", checked, dataset: { url } }),
        el("span", { text: `${index + 1}` }),
      ]),
      imageThumb(url, `详情图 ${index + 1}`),
    ]));
  }
  for (const checkbox of $$("#detail-image-grid input.detail-img-select")) {
    checkbox.addEventListener("change", () => {
      const url = checkbox.dataset.url;
      if (checkbox.checked) state.selectedDetailImages.add(url);
      else state.selectedDetailImages.delete(url);
      checkbox.closest("figure")?.classList.toggle("is-excluded", !checkbox.checked);
    });
  }
}

async function mergeDetailImages() {
  if (!state.draft) return toast("请先载入草稿", "error");
  const picked = (state.draft.detailImages || []).filter((url) => state.selectedDetailImages.has(url));
  if (!picked.length) return toast("请先勾选要并入的详情长图", "error");
  const images = dedupeUrls((state.draft.images || []).concat(picked));
  const remaining = (state.draft.detailImages || []).filter((url) => !state.selectedDetailImages.has(url));
  state.draft = await saveDraft({ id: state.draft.id, images, detailImages: remaining });
  for (const url of picked) state.selectedImages.add(url);
  state.selectedDetailImages.clear();
  renderImageGallery();
  await renderBulkLists();
  setBadge("#detail-img-status", `已并入 ${picked.length} 张`, "ok");
  // Ozon 单次上传最多 9 张，超了要提醒，否则上传时会被静默截断
  if (images.length > 9) toast(`图片集现在 ${images.length} 张，Ozon 单次最多上传 9 张，超出部分会被截断`, "warn");
  else toast(`已并入 ${picked.length} 张详情长图`, "ok");
}

function dedupeUrls(list) {
  const seen = new Set();
  const out = [];
  for (const url of list || []) {
    if (!url || seen.has(url)) continue;
    seen.add(url);
    out.push(url);
  }
  return out;
}

function bindDetailImages() {
  $("#btn-detail-img-select-all")?.addEventListener("click", () => {
    for (const url of state.draft?.detailImages || []) state.selectedDetailImages.add(url);
    renderDetailImageGallery();
  });
  $("#btn-detail-img-unselect-all")?.addEventListener("click", () => {
    state.selectedDetailImages.clear();
    renderDetailImageGallery();
  });
  $("#btn-detail-img-merge")?.addEventListener("click", mergeDetailImages);
}

function updateImageCount() {
  const node = $("#img-count");
  if (!node) return;
  const total = state.draft?.images?.length || 0;
  const aiCount = (state.draft?.images || []).filter((url) => draftAiUrlSet().has(url)).length;
  const scope = state.aiImageOnly ? ` · AI 图 ${aiCount} 张（只看 AI 图）` : "";
  node.textContent = `${total} 张 · 已选 ${state.selectedImages.size} 张${scope}`;
}

// 单张删除：立即从草稿里移除（不弹确认，误删可重新采集；批量删除才有确认）
async function removeDraftImage(url) {
  if (!state.draft) return;
  const kept = (state.draft.images || []).filter((item) => item !== url);
  state.draft = await saveDraft({ id: state.draft.id, images: kept });
  state.selectedImages.delete(url);
  renderImageGallery();
  await renderBulkLists();
  toast(`已删除 1 张，剩余 ${kept.length} 张`, "ok");
}

/* ================= v1.9.73 策划师模式（先卖点→8图方案→按方案出图） ================= */

/** 商品"是什么"的一句上下文（和旧套图口径一致：品类 + 标题，防止把足球鞋画成跑鞋） */
function planContext() {
  return cleanText([state.draft?.ru?.productType, state.draft?.ru?.title || state.draft?.title].filter(Boolean).join(", "));
}

/** 品类风格提示（策划模式统一风格，和旧套图一致走 pickStyleFor） */
function planStyleHint() {
  const manual = cleanText($("#set-gen-style")?.value || "");
  if (manual) return manual;
  return pickStyleFor(
    state.draft?.ru?.productType || "",
    [state.draft?.ozonCategory?.path, state.draft?.categoryPath, state.draft?.category].filter(Boolean).flat().join(" > "),
  );
}

/** 渲染方案顶部提示条：卖点表 + 最强卖点 + 校验问题 */
function renderPlanReport() {
  const box = $("#plan-report");
  if (!box) return;
  const plan = state.plan;
  if (!plan) { box.innerHTML = ""; return; }
  const spRows = plan.sellingPoints.map((p, i) => {
    const star = i === plan.bestIndex ? "plan-best" : "";
    return `<li class="${star}"><b>${i + 1}${i === plan.bestIndex ? " ⭐最强" : ""}</b> ${escapeHtml(p.zh || "")}${p.ru ? ` — <span class="plan-ru">${escapeHtml(p.ru)}</span>` : ""}${p.evidence ? `<span class="plan-ev">视觉证据：${escapeHtml(p.evidence)}</span>` : ""}</li>`;
  }).join("");
  const problems = (plan.__problems || []).filter(Boolean);
  const probHtml = problems.length
    ? `<div class="plan-problems">⚠ 方案有 ${problems.length} 处需留意：${problems.map((x) => escapeHtml(x)).join("；")}${plan.__coreBad ? "；最强卖点没落进第2张图，出图时会补进去" : ""}</div>`
    : "";
  box.innerHTML = `<h3>第一步 · 卖点清单（按下单影响力排序）</h3><ol class="plan-points">${spRows}</ol>${probHtml}`;
}

/** 渲染 8 图方案卡（含画面/俄文/prompt/出图预览/编辑重出） */
function renderPlanGrid() {
  const grid = $("#plan-grid");
  if (!grid) return;
  const plan = state.plan;
  grid.innerHTML = "";
  if (!plan) return;
  const bySlot = new Map((state.planGen || []).map((item) => [item.slot, item]));
  plan.shots.forEach((shot) => {
    const res = bySlot.get(shot.slot);
    const card = el("div", { class: `plan-cell${res && !res.error && (res.dataUrl || res.url) ? " has-img" : ""}${res?.error ? " is-error" : ""}` });
    const head = el("div", { class: "plan-cell-head" }, [
      el("span", { class: "plan-slot", text: `${shot.slot}` }),
      el("b", { text: shot.label }),
      el("span", { class: "plan-task", text: `｜${shot.task}` }),
    ]);
    card.appendChild(head);
    if (shot.hard) card.appendChild(el("p", { class: "plan-hard", text: shot.hard }));
    if (shot.sceneZh) card.appendChild(el("p", { class: "plan-scene", text: `画面：${shot.sceneZh}` }));
    if (shot.ruText) card.appendChild(el("p", { class: "plan-rutext" }, [el("span", { text: "图内俄文：" }), el("code", { text: shot.ruText })]));
    // 出图区
    if (res && !res.error && (res.dataUrl || res.url)) {
      card.appendChild(imageThumb(res.dataUrl || res.url, `${shot.label} 生成结果`));
    } else {
      card.appendChild(el("div", { class: "plan-empty" }, [el("span", { text: res?.error ? "生成失败" : "待生成" })]));
      if (res?.error) card.appendChild(el("p", { class: "plan-err", text: res.error }));
    }
    const editBtn = el("button", { class: "mini", type: "button", text: "编辑此图并重出" });
    editBtn.onclick = () => editAndRegeneratePlanShot(shot.slot);
    card.appendChild(editBtn);
    grid.appendChild(card);
  });
}

/** 拉方案：卖点表 + 8 图结构化方案一次产出 */
async function generatePlanStrategy() {
  if (!state.draft) return toast("请先载入草稿", "error");
  if (!await ensureLicensed("策划师模式")) return;
  const btn = $("#btn-plan-strategy");
  if (btn) btn.disabled = true;
  setBadge("#plan-status", "AI 策划中…", "warn");
  try {
    const data = await call({
      action: MESSAGE_ACTIONS.aiImageStrategy,
      product: state.draft,
      options: {
        extraInfo: cleanText($("#plan-extra")?.value || ""),
        audience: cleanText($("#plan-audience")?.value || ""),
        pricePosition: cleanText($("#plan-price")?.value || ""),
        points: selectedSetPoints(),
      },
    });
    const plan = data?.plan;
    if (!plan || !Array.isArray(plan.shots)) throw new Error("方案解析失败");
    plan.__problems = data?.problems || [];
    plan.__coreBad = plan.coreCarriesBest === false;
    state.plan = plan;
    state.planDraftId = state.draft?.id || "";
    state.planGen = [];
    renderPlanReport();
    renderPlanGrid();
    setBadge("#plan-status", `方案就绪：${plan.sellingPoints.length} 个卖点 + 8 张图，可出图`, "ok");
    if (plan.__problems.length) toast(`方案已生成，但有 ${plan.__problems.length} 处建议核对（见报告）`, "warn");
  } catch (error) {
    setBadge("#plan-status", "策划失败", "err");
    toast(`生成策划方案失败：${error?.message || error}`, "error");
  } finally {
    if (btn) btn.disabled = false;
  }
}

/** 按方案逐张出图（并发，结果进独立 planGen，不碰旧 setGen） */
async function generatePlanImages() {
  if (!state.draft) return toast("请先载入草稿", "error");
  if (!state.plan) return toast("请先生成策划方案", "error");
  if (!await ensureLicensed("策划师模式出图")) return;
  const sourceUrl = $("#set-gen-source")?.value || "";
  if (!sourceUrl) return toast("请先在上方「④ 图片 → AI 图片」选择参考图（本产品图）", "error");
  const btn = $("#btn-plan-images");
  if (btn) btn.disabled = true;

  const context = planContext();
  const styleHint = planStyleHint();
  const bestPoint = state.plan.sellingPoints[state.plan.bestIndex] || null;
  const shots = state.plan.shots;
  let refs;
  try {
    refs = await fetchReferenceImages();
  } catch (error) {
    if (btn) btn.disabled = false;
    return toast(error?.message || String(error), "error");
  }
  const size = currentSetSize().size;

  // 已有的结果保留（重出单张时用），本轮未选中的不动
  const results = new Map((state.planGen || []).map((item) => [item.slot, item]));
  let done = 0;
  const concurrency = Math.min(3, Math.max(1, Number($("#set-gen-concurrency")?.value) || 2));
  let cursor = 0;
  const runOne = async () => {
    while (cursor < shots.length) {
      const index = cursor;
      cursor += 1;
      const shot = shots[index];
      // 最强卖点必须落在第2张（核心卖点图）：AI 没让第2张承载它时，出图前强制用最强卖点俄文短句
      if (state.plan.__coreBad && shot.key === "core-benefit" && bestPoint?.ru) shot.ruText = bestPoint.ru;
      const prompt = buildPlannedPrompt(shot, { bestPoint, context, styleHint });
      setBadge("#plan-status", `出图 ${done + 1}/${shots.length}：${shot.label}`, "warn");
      try {
        const data = await call({
          action: MESSAGE_ACTIONS.imageRedraw,
          plannedPrompt: prompt,
          context,
          styleHint,
          size,
          referenceImage: refs.referenceImage,
          referenceImages: refs.referenceImages,
        });
        const remoteUrl = data?.url || "";
        const src = data?.dataUrl || remoteUrl;
        if (!src) throw new Error("生图接口未返回可用图片");
        results.set(shot.slot, { slot: shot.slot, key: shot.key, label: shot.label, dataUrl: src, url: remoteUrl, error: "", prompt });
      } catch (error) {
        results.set(shot.slot, { slot: shot.slot, key: shot.key, label: shot.label, dataUrl: "", url: "", error: error?.message || String(error), prompt });
      }
      done += 1;
      state.planGen = shots.filter((s) => results.has(s.slot)).map((s) => results.get(s.slot));
      renderPlanGrid();
    }
  };
  await Promise.all(Array.from({ length: Math.min(concurrency, shots.length) }, runOne));
  state.planGen = shots.filter((s) => results.has(s.slot)).map((s) => results.get(s.slot));
  const bad = state.planGen.filter((x) => x.error).length;
  setBadge("#plan-status", bad ? `出图完成：${shots.length - bad} 成功 / ${bad} 失败` : `8 张全部出好`, bad ? "warn" : "ok");
  if (btn) btn.disabled = false;
  renderPlanGrid();
}

/** 编辑单张（俄文文案 + 英文画面）后重出 */
async function editAndRegeneratePlanShot(slot) {
  if (!state.draft) return toast("请先载入草稿", "error");
  const shot = state.plan?.shots?.find((s) => s.slot === slot);
  if (!shot) return toast("这张图位已不在方案里", "error");
  if (!await ensureLicensed("策划师模式出图")) return;
  const form = await openModal({
    title: `编辑并重出：${shot.slot}·${shot.label}`,
    submitText: "按新内容重出",
    fields: [
      { key: "sceneZh", label: "画面描述（中文，给人看）", type: "textarea", rows: 2, value: shot.sceneZh || "" },
      { key: "ruText", label: "图内俄文文案（留空=该图不写字）", type: "textarea", rows: 2, value: shot.ruText || "" },
      { key: "promptEn", label: "英文出图指令（写给生图模型的画面部分）", type: "textarea", rows: 4, value: shot.promptEn || "" },
    ],
  });
  if (!form) return;
  shot.sceneZh = cleanText(form.sceneZh);
  shot.ruText = cleanText(form.ruText);
  shot.promptEn = cleanText(form.promptEn);
  state.plan.__coreBad = shot.key === "core-benefit"
    ? !(shot.ruText && (shot.ruText.toLowerCase().includes((state.plan.sellingPoints[state.plan.bestIndex]?.ru || "").toLowerCase().slice(0, 8))))
    : state.plan.__coreBad;
  renderPlanReport();

  const sourceUrl = $("#set-gen-source")?.value || "";
  if (!sourceUrl) return toast("请先在「AI 图片」区选参考图", "error");
  let refs;
  try { refs = await fetchReferenceImages(); } catch (error) { return toast(error?.message || String(error), "error"); }
  const prompt = buildPlannedPrompt(shot, { bestPoint: state.plan.sellingPoints[state.plan.bestIndex] || null, context: planContext(), styleHint: planStyleHint() });
  const idx = state.planGen.findIndex((x) => x.slot === slot);
  if (idx >= 0) state.planGen[idx] = { ...state.planGen[idx], error: "", dataUrl: "", url: "" };
  renderPlanGrid();
  setBadge("#plan-status", `重出第 ${slot} 张…`, "warn");
  try {
    const data = await call({
      action: MESSAGE_ACTIONS.imageRedraw,
      plannedPrompt: prompt, context: planContext(), styleHint: planStyleHint(), size: currentSetSize().size,
      referenceImage: refs.referenceImage, referenceImages: refs.referenceImages,
    });
    const remoteUrl = data?.url || "";
    const src = data?.dataUrl || remoteUrl;
    if (!src) throw new Error("生图接口未返回可用图片");
    const rec = { slot, key: shot.key, label: shot.label, dataUrl: src, url: remoteUrl, error: "", prompt };
    if (idx >= 0) state.planGen[idx] = rec; else state.planGen.push(rec);
    state.planGen.sort((a, b) => a.slot - b.slot);
    toast(`第 ${slot} 张已重出`, "ok");
  } catch (error) {
    const rec = { slot, key: shot.key, label: shot.label, dataUrl: "", url: "", error: error?.message || String(error), prompt };
    if (idx >= 0) state.planGen[idx] = rec; else state.planGen.push(rec);
    toast(error?.message || String(error), "error");
  }
  renderPlanGrid();
}

/** 导出方案为 Markdown 文件 */
function exportPlan() {
  if (!state.plan) return toast("请先生成策划方案", "error");
  const cat = state.draft?.ozonCategoryPathText || (state.draft?.ozonCategory?.path || []).join(" > ") || "";
  const md = renderPlanMarkdown(state.plan, {
    title: cleanText(state.draft?.ru?.title || state.draft?.title || "") || "OZON 商品",
    category: cat,
    at: new Date().toLocaleString("zh-CN"),
  });
  const slug = (state.draft?.ru?.title || state.draft?.title || "ozon-plan").slice(0, 40).replace(/[\\/:*?"<>|]+/g, "_");
  downloadBlob(`OZON图方案-${slug}.md`, new Blob(["\uFEFF" + md], { type: "text/markdown;charset=utf-8" }));
  toast("方案已导出为 Markdown（含卖点表 + 8 图方案）", "ok");
}

/** 把方案俄文卖点并入上方「AI 图片」卖点区，供旧套图带字图复用 */
function applyPlanPointsToSet() {
  if (!state.plan) return toast("请先生成策划方案", "error");
  const ru = state.plan.sellingPoints.map((p) => cleanText(p.ru)).filter((x) => x && !/[\u4e00-\u9fa5]/.test(x));
  if (!ru.length) return toast("方案里没有可用的俄文卖点", "error");
  const merged = [...new Set([...state.setGenPoints.map((x) => x.text), ...ru])];
  state.setGenPoints = merged.map((text) => {
    const existed = state.setGenPoints.find((x) => x.text === text);
    return { text, on: existed ? existed.on : true };
  });
  renderSetGenPoints();
  toast(`已并入 ${ru.length} 条俄文卖点（去重后共 ${merged.length} 条）`, "ok");
}

function bindPlan() {
  $("#btn-plan-strategy")?.addEventListener("click", generatePlanStrategy);
  $("#btn-plan-images")?.addEventListener("click", generatePlanImages);
  $("#btn-plan-export")?.addEventListener("click", exportPlan);
  $("#btn-plan-apply-points")?.addEventListener("click", applyPlanPointsToSet);
}

function bindImages() {
  $("#btn-img-load").addEventListener("click", () => {
    if (!state.draft) return toast("请先载入草稿", "error");
    renderImageGallery();
  });

  $("#btn-img-filter").addEventListener("click", () => {
    if (!state.draft?.images?.length) return toast("请先载入图片", "error");
    const meta = state.draft.imageMeta || {};
    let kept = 0;
    let removed = 0;
    for (const url of state.draft.images) {
      if (isLikelyProductImage(url, meta)) {
        state.selectedImages.add(url);
        kept++;
      } else {
        state.selectedImages.delete(url);
        removed++;
      }
    }
    renderImageGallery();
    toast(
      removed
        ? `智能筛选完成：保留 ${kept} 张，标记 ${removed} 张为图标/水印（未勾选）。可再点「删除未选中的图」一次清掉。`
        : `智能筛选完成：${kept} 张都像产品图，没有发现图标/水印。`,
      "ok",
    );
  });

  // v1.9.51 「筛选 AI 图片」开关：列表只显示 AI 生成的图，再点一次恢复全部
  $("#btn-img-ai-only")?.addEventListener("click", () => {
    if (!state.draft) return toast("请先载入草稿", "error");
    state.aiImageOnly = !state.aiImageOnly;
    const btn = $("#btn-img-ai-only");
    if (btn) {
      btn.textContent = state.aiImageOnly ? "显示全部图片" : "筛选 AI 图片";
      btn.classList.toggle("primary", state.aiImageOnly);
    }
    renderImageGallery();
    if (state.aiImageOnly) {
      const count = (state.draft.images || []).filter((url) => draftAiUrlSet().has(url)).length;
      toast(count
        ? `只显示 AI 生成的图片：${count} 张。挑好后点图下的「设为主图 (AI)」载入主图`
        : "草稿里还没有 AI 生成的图片，先在下方「AI 图片」生成并「全部加入草稿图片」",
        count ? "ok" : "warn");
    }
  });

  $("#btn-img-select-all").addEventListener("click", () => {
    if (!state.draft?.images?.length) return;
    state.draft.images.forEach((url) => state.selectedImages.add(url));
    renderImageGallery();
  });

  $("#btn-img-unselect-all").addEventListener("click", () => {
    state.selectedImages.clear();
    renderImageGallery();
  });

  // 删除勾选中的图片
  $("#btn-img-delete-selected").addEventListener("click", async () => {
    if (!state.draft) return toast("请先载入草稿", "error");
    const targets = (state.draft.images || []).filter((url) => state.selectedImages.has(url));
    if (!targets.length) return toast("请先勾选要删除的图片", "error");
    if (targets.length === (state.draft.images || []).length) {
      return toast("不能把图片删光，至少保留一张；可先取消勾选要保留的图", "error");
    }
    const yes = await confirmDialog(`删除勾选的 ${targets.length} 张图片？`, { confirmText: "删除", danger: true });
    if (!yes) return;
    const kept = state.draft.images.filter((url) => !state.selectedImages.has(url));
    state.draft = await saveDraft({ id: state.draft.id, images: kept });
    state.selectedImages = new Set(kept);
    renderImageGallery();
    await renderBulkLists();
    toast(`已删除 ${targets.length} 张，剩余 ${kept.length} 张`, "ok");
  });

  // 删除未勾选的图片（等于把「智能筛选」的结果落地）
  $("#btn-img-save-filter").addEventListener("click", async () => {
    if (!state.draft) return toast("请先载入草稿", "error");
    const kept = state.draft.images.filter((url) => state.selectedImages.has(url));
    if (!kept.length) return toast("至少要保留一张产品图", "error");
    const removedCount = state.draft.images.length - kept.length;
    if (removedCount) {
      const yes = await confirmDialog(`删除未勾选的 ${removedCount} 张图片，只保留 ${kept.length} 张？`, { confirmText: "删除", danger: true });
      if (!yes) return;
    }
    state.draft = await saveDraft({ id: state.draft.id, images: kept });
    state.selectedImages = new Set(kept);
    renderImageGallery();
    await renderBulkLists();
    toast(`已保存：保留 ${kept.length} 张，移除 ${removedCount} 张`, "ok");
  });

  // v1.9.44 「本地水印」从界面移除；用可选链兜住，避免整页脚本断在找不到的按钮上
  $("#btn-wm-apply")?.addEventListener("click", async () => {
    if (!state.draft?.images?.length) return toast("请先载入带图片的草稿", "error");
    const text = cleanText($("#wm-text").value);
    if (!text) return toast("请填写水印文字", "error");
    state.watermarked = [];
    const grid = $("#wm-grid");
    grid.innerHTML = "";

    for (const [index, url] of state.draft.images.slice(0, 12).entries()) {
      try {
        const dataUrl = await watermarkImage(url, text);
        state.watermarked.push({ name: `wm-${index + 1}.png`, dataUrl });
        grid.appendChild(el("figure", {}, [
          imageThumb(dataUrl, `水印图 ${index + 1}`),
          el("figcaption", { text: `wm-${index + 1}.png` }),
        ]));
      } catch (error) {
        grid.appendChild(el("figure", {}, [el("figcaption", { text: `第 ${index + 1} 张失败：${error.message}` })]));
      }
    }
    toast(`水印生成完成：${state.watermarked.length} 张`, "ok");
  });

  $("#btn-wm-download")?.addEventListener("click", () => {
    if (!state.watermarked.length) return toast("还没有生成水印图", "error");
    for (const item of state.watermarked) downloadBlob(item.name, dataUrlToBlob(item.dataUrl));
    toast("已开始下载", "ok");
  });

  bindDetailImages();
}

// 通过后台取回图片（绕过防盗链与 CORS），再用 Canvas 叠加文字
async function watermarkImage(url, text) {
  const source = await fetchDataUrl(url);
  const image = await loadImage(source);

  const canvas = document.createElement("canvas");
  canvas.width = image.naturalWidth;
  canvas.height = image.naturalHeight;
  const ctx = canvas.getContext("2d");
  ctx.drawImage(image, 0, 0);

  const fontSize = Math.max(12, Math.min(120, Number($("#wm-size").value) || 24));
  ctx.font = `${fontSize}px sans-serif`;
  ctx.fillStyle = `rgba(255,255,255,${Math.min(1, Math.max(0, Number($("#wm-opacity").value) || 0.35))})`;
  ctx.strokeStyle = "rgba(0,0,0,0.35)";
  ctx.lineWidth = Math.max(1, fontSize / 12);
  ctx.textBaseline = "middle";

  const position = $("#wm-position").value;
  const padding = fontSize;
  if (position === "tile") {
    ctx.save();
    ctx.translate(canvas.width / 2, canvas.height / 2);
    ctx.rotate(-Math.PI / 6);
    const stepX = ctx.measureText(text).width + fontSize * 2;
    const stepY = fontSize * 3;
    for (let y = -canvas.height; y < canvas.height; y += stepY) {
      for (let x = -canvas.width; x < canvas.width; x += stepX) {
        ctx.strokeText(text, x, y);
        ctx.fillText(text, x, y);
      }
    }
    ctx.restore();
  } else {
    ctx.textAlign = position === "center" ? "center" : position.endsWith("right") ? "right" : "left";
    const x = position === "center" ? canvas.width / 2 : position.endsWith("right") ? canvas.width - padding : padding;
    const y = position.startsWith("top") ? padding + fontSize : position === "center" ? canvas.height / 2 : canvas.height - padding - fontSize;
    ctx.strokeText(text, x, y);
    ctx.fillText(text, x, y);
  }

  return canvas.toDataURL("image/png");
}

/* ---------------- SKU 与规格维度 ---------------- */

/* ---- v1.9.47 上架 SKU（Ozon offer_id）----
 * 每行可以手工填一个货号；留空就用自动货号：店铺名 + 年月日 + 时间（多个 SKU 再补 -1/-2…）。
 * 自动货号在第一次渲染 SKU 表时算好并写回草稿——不能每次现算，否则导出上架表、上传、
 * 库存/价格更新会各拿一个值，重传就变成重复铺货。
 */

/** 自动货号里的店铺名：优先当前选中的 Ozon 店铺，其次采集到的 1688 店铺名 */
function offerIdStoreLabel() {
  const stores = state.settings?.stores || [];
  const id = currentStoreId();
  const store = id ? stores.find((item) => item.id === id) : null;
  const name = cleanText(store?.name);
  if (name && name !== "默认店铺") return name;
  return cleanText(state.draft?.shopName) || "ozon";
}

/** 年月日 + 时分秒，例如 20260921170509 */
function offerIdStamp(now = new Date()) {
  const pad = (value) => String(value).padStart(2, "0");
  return `${now.getFullYear()}${pad(now.getMonth() + 1)}${pad(now.getDate())}`
    + `${pad(now.getHours())}${pad(now.getMinutes())}${pad(now.getSeconds())}`;
}

/** 这一刻的自动货号前缀（同一张表里所有 SKU 共用同一个时间戳，好认） */
function offerIdAutoBase() {
  const stamp = offerIdStamp();
  return sanitizeOfferId(`${offerIdStoreLabel()}${stamp}`, `ozon${stamp}`);
}

/** 单个变体的自动货号；多个 SKU 时补序号，避免 Ozon 收到重复 offer_id */
function offerIdAutoValue(base, index, total) {
  return total > 1 ? `${base}-${index + 1}` : base;
}

/** 给还没定上架 SKU 的变体补上自动货号并写回草稿（已填/已算过的不动） */
async function ensureSkuOfferIds() {
  const draft = state.draft;
  const skus = draft?.skus || [];
  if (!skus.length) return;
  if (!skus.some((sku) => !cleanText(sku.offerId) && !cleanText(sku.offerIdAuto))) return;
  const base = offerIdAutoBase();
  skus.forEach((sku, index) => {
    if (cleanText(sku.offerId) || cleanText(sku.offerIdAuto)) return;
    sku.offerIdAuto = offerIdAutoValue(base, index, skus.length);
  });
  state.draft = await saveDraft({ id: draft.id, skus: state.draft.skus });
  refreshSkuSection();
}

/**
 * v1.9.45/v1.9.46：每个 SKU 行下方的核价面板，展开状态记在这里。
 * v1.9.46 起**默认全部展开**（超哥要看「每个 SKU 底下都有价格核算」），
 * 用户手动点「核价」收起过的按他的选择记着；表体重渲染后不会跳回去。
 */
const skuCalcToggle = new Map();

function isSkuCalcOpen(id) {
  return skuCalcToggle.has(id) ? skuCalcToggle.get(id) : true;
}

/**
 * SKU 表 + 核价一起刷新。
 * 生成 AI 主图（单个或批量）改了 sku.aiMainUrl，只调 renderListingResult() 的话
 * 表格里那格还是「未生成」——必须连表体重渲染，这就是 v1.9.46 修的那个 bug。
 */
function refreshSkuSection() {
  if (state.draft) renderSkuSection(state.draft.skus || [], state.draft.specOptions || []);
  renderListingResult();
}

/**
 * v1.9.48 规格名只有**一个维度**时，把改动同步到那个维度的值上。
 * 两个及以上维度时不动手——没法知道用户想改的是哪一维，猜错反而把变体属性写坏。
 */
function syncSingleSpecValue(sku, label) {
  const keys = Object.keys(sku.specs || {});
  if (keys.length !== 1) return;
  sku.specs[keys[0]] = cleanText(label);
}

/**
 * SKU 区始终可见（有草稿就渲染）。
 * 采集不到 SKU 时不再整块隐藏，而是把采集到的「规格维度」摆出来并给出补全按钮，
 * 否则用户会以为「插件没有采集 SKU 分类」。
 */
function renderSkuSection(skus = [], specOptions = []) {
  const card = $("#sku-card");
  if (!card) return;
  card.hidden = false;

  // v1.9.83 未选用的 SKU 默认不显示（超哥：开始采集时没选中的不需要显示——
  // 营销文案混进来的假规格行占着整块核价区）。勾选「显示未选用」可全部展开。
  // 防死锁兜底：一个都没选用时强制显示全部——否则表空了用户没法再勾回来。
  const showUnselected = $("#sku-show-unselected")?.checked === true;
  const selectedList = skus.filter((sku) => state.selectedSkus.has(sku.id));
  const visibleSkus = showUnselected || !selectedList.length ? skus : selectedList;
  const hiddenCount = showUnselected ? 0 : skus.length - selectedList.length;
  const hiddenNode = $("#sku-hidden-count");
  if (hiddenNode) {
    hiddenNode.textContent = hiddenCount > 0 ? `已隐藏 ${hiddenCount} 个未选用 SKU` : "";
  }

  const hasSkus = skus.length > 0;
  const hasSpecs = specOptions.length > 0;

  const notice = $("#sku-notice");
  if (notice) {
    // 区间价商品：把采集到的价格区间摆出来，提醒定价时确认用哪一档成本
    const min = Number(state.draft?.priceMinCny) || 0;
    const max = Number(state.draft?.priceMaxCny) || 0;
    const rangePrefix = min && max > min ? `采集价为区间价 ¥${min}~¥${max}（默认成本取最低档 ¥${min}）；` : "";
    if (hasSkus) {
      notice.className = "hint";
      // 成本 = 采购价（各 SKU 采集原价）+ 国内运费（1688 运费），核价表里两段分开显示
      const freight = Number(state.draft?.logistics?.freightCny) || 0;
      const freightNote = freight ? `成本 = 采购价 + 国内运费 ¥${freight}（核价表里两段分开可看）；` : "";
      const missingIds = skus.filter((sku) => sku.idSource && sku.idSource !== "采集").length;
      const soldOut = skus.filter((sku) => sku.unavailable).length;
      const soldOutNote = soldOut ? `其中 ${soldOut} 个规格页面上是置灰/售罄（默认未勾选，勾选前请核对库存）。` : "";
      notice.textContent = `${rangePrefix}${freightNote}已采集 ${skus.length} 个 SKU（规格组合）。${missingIds ? `其中 ${missingIds} 个缺少源 SKU ID，已用稳定本地序号，仅用于本草稿，请核对后再上传。` : ""}${soldOutNote}选用的 SKU 才参与定价与库存更新。`;
    } else if (hasSpecs) {
      notice.className = "hint danger-text";
      notice.textContent = `${rangePrefix}只采集到 ${specOptions.length} 个规格维度，没有取到 SKU 价格矩阵（新版详情页 SKU 常按需加载）。可点「按规格维度生成 SKU」生成组合后补成本，或「手动添加一行」。`;
    } else {
      notice.className = "hint danger-text";
      notice.textContent = `${rangePrefix}没有采集到 SKU 规格（该商品可能是单规格，或页面规格区未展开/未渲染）。可手动添加 SKU，或先保存为草稿后在商品页展开规格再重新采集。`;
    }
  }

  const specWrap = $("#sku-specs");
  if (specWrap) {
    specWrap.innerHTML = "";
    specWrap.hidden = !hasSpecs;
    if (hasSpecs) {
      specWrap.appendChild(el("p", {
        class: "sub",
        text: `采集到的规格维度（可用于生成 SKU 组合）：${specOptions.map((option) => `${option.name}（${option.values.length} 项）`).join("、")}`,
      }));
      const table = el("table", {});
      table.appendChild(el("thead", {}, [el("tr", {}, [el("th", { text: "规格名" }), el("th", { text: "可选值" })])]));
      table.appendChild(el("tbody", {}, specOptions.map((option) => el("tr", {}, [
        el("td", { text: option.name }),
        el("td", { text: option.values.join(" / ") }),
      ]))));
      specWrap.appendChild(table);
    }
  }

  // v1.9.45 每个 SKU 行下面挂它自己的核价面板；v1.9.46 起默认展开（不点也能看到核算）。
  // v1.9.47 「规格」后面加一列可编辑的「上架 SKU」；占位灰字就是留空时会用的自动货号。
  const offerIdPreviewBase = offerIdAutoBase();
  renderTable("#sku-table", [
    {
      key: "selected",
      label: "选用",
      html: true,
      // data-id 一律转义：SKU id 可能来自采集源（内联数据里的字符串），带引号会截断属性，
      // 既导致 dataset.id 取错、也给注入留了口子
      render: (row) => `<input class="sku-select" data-id="${escapeHtml(row.id)}" type="checkbox"${state.selectedSkus.has(row.id) ? " checked" : ""}${row.unavailable ? " title=\"采集端判定该规格置灰/售罄，默认未勾选\"" : ""}>`,
    },
    {
      key: "label",
      label: "规格",
      html: true,
      // v1.9.48 规格名可直接改：采集不准时不用删掉重加，改完写回草稿；
      // 只有一个规格维度时，改动会同步到那个维度的值上（否则「变体属性值」还是旧的）。
      render: (row) => {
        const auto = Object.values(row.specs || {}).join(" / ");
        return `<input class="sku-label-input" data-id="${escapeHtml(row.id)}" type="text"`
          + ` value="${escapeHtml(row.label || auto)}" placeholder="${escapeHtml(auto || "(未命名)")}"`
          + ` title="可以直接改规格名（写回草稿）。只有一个规格维度时，这里改了该维度的值也跟着改。"`
          + ` style="width:170px">`;
      },
    },
    {
      key: "offerId",
      label: "上架 SKU",
      html: true,
      render: (row) => {
        const manual = cleanText(row.offerId);
        const auto = cleanText(row.offerIdAuto)
          || offerIdAutoValue(offerIdPreviewBase, skus.indexOf(row), skus.length);
        return `<input class="sku-offer-id" data-id="${escapeHtml(row.id)}" type="text"`
          + ` value="${escapeHtml(manual)}" placeholder="${escapeHtml(auto)}"`
          + ` title="Ozon 货号（offer_id）。填了就用你填的；留空则用灰字显示的自动货号（店铺名 + 年月日 + 时间）"`
          + ` style="width:180px">`;
      },
    },
    {
      key: "price",
      label: "成本 ¥",
      html: true,
      render: (row) => `<input class="sku-cost" data-id="${escapeHtml(row.id)}" type="number" value="${row.price || 0}" style="width:100px">`,
    },
    { key: "stock", label: "库存" },
    {
      key: "image",
      label: "图片",
      html: true,
      render: (row) => {
        const base = row.image
          ? `<img class="sku-thumb" src="${escapeHtml(row.image)}" data-id="${escapeHtml(row.id)}" alt="" title="原图（点击查看大图）" loading="lazy">`
          : `<span class="sku-thumb-placeholder">无</span>`;
        return `<span class="sku-image-cell">${base}<button class="mini sku-replace" data-id="${escapeHtml(row.id)}" type="button">换图</button></span>`;
      },
    },
    {
      // v1.9.44 新增「AI 主图」列：缩略图点开放大看 AI 出图，另带「对比」按钮
      // 打开并排 / 滑块对比，一眼看出生成前（原图）和生成后的差别
      key: "aiMain",
      label: "AI 主图",
      html: true,
      render: (row) => {
        const thumb = row.aiMainUrl
          ? `<img class="sku-thumb sku-ai-thumb" src="${escapeHtml(row.aiMainUrl)}" data-id="${escapeHtml(row.id)}" alt="" title="AI 主图（点击查看大图）" loading="lazy">`
          : `<span class="sku-ai-empty">未生成</span>`;
        // v1.9.54 已生成 AI 主图时给「还原主图」：撤销 AI 图，换回该 SKU 原有的商品主图
        const restore = row.aiMainUrl
          ? `<button class="mini sku-ai-restore" data-id="${escapeHtml(row.id)}" type="button" title="撤销 AI 主图：把它从该 SKU 图集移除，换回原有商品主图">还原主图</button>`
          : "";
        return `<span class="sku-image-cell">${thumb}<button class="mini sku-ai-compare" data-id="${escapeHtml(row.id)}" type="button" title="放大并排 / 滑块对比：原图 vs AI 主图">对比</button><button class="mini sku-ai" data-id="${escapeHtml(row.id)}" type="button" title="用该变体自己的原图生成信息图主图">AI 主图</button>${restore}</span>`;
      },
    },
    {
      key: "ops",
      label: "",
      html: true,
      render: (row) => {
        const open = isSkuCalcOpen(row.id);
        return `<span class="sku-ops">`
          + `<button class="mini sku-calc-toggle" data-id="${escapeHtml(row.id)}" type="button" title="展开 / 收起这个 SKU 的售价计算">核价 ${open ? "▴" : "▾"}</button>`
          + `<button class="danger mini sku-remove" data-id="${escapeHtml(row.id)}" type="button">删除</button>`
          + `</span>`;
      },
    },
  ], visibleSkus, {
    // 详情行 = 该 SKU 自己的核价面板，内容由 renderListingResult() 算好后填进来
    detail: (row) => `<div class="sku-calc-box" data-id="${escapeHtml(row.id)}"></div>`,
  });

  // 按记忆的展开状态把详情行显示出来（renderTable 默认是收起的）
  for (const tr of $$("#sku-table tr.row-detail")) {
    const id = tr.querySelector(".sku-calc-box")?.dataset.id || "";
    tr.hidden = !isSkuCalcOpen(id);
  }

  for (const button of $$("#sku-table button.sku-calc-toggle")) {
    button.addEventListener("click", () => {
      const tr = button.closest("tr")?.nextElementSibling;
      if (!tr || !tr.classList.contains("row-detail")) return;
      const open = tr.hidden;
      tr.hidden = !open;
      skuCalcToggle.set(button.dataset.id, open);
      button.textContent = `核价 ${open ? "▴" : "▾"}`;
    });
  }

  for (const input of $$("#sku-table input.sku-select")) {
    input.addEventListener("change", () => {
      const id = input.dataset.id;
      if (input.checked) state.selectedSkus.add(id);
      else {
        state.selectedSkus.delete(id);
        // v1.9.83 取消勾选 → 该行立即从表里消失（默认只显示选用的，留着不勾的行自相矛盾）。
        // 勾回来：开「显示未选用」开关。勾选方向不用重渲染，行本来就显示着。
        renderSkuSection(state.draft?.skus || [], state.draft?.specOptions || []);
      }
      renderListingResult();
      // v1.9.50 选用的 SKU 变了 → 变体属性要重算（选几个就该上架几个）
      renderVariantAttrHint();
    });
  }

  for (const input of $$("#sku-table input.sku-cost")) {
    input.addEventListener("change", async () => {
      const sku = state.draft.skus.find((item) => item.id === input.dataset.id);
      if (!sku) return;
      sku.price = Number(input.value) || 0;
      state.draft = await saveDraft({ id: state.draft.id, skus: state.draft.skus });
      renderListingResult();
      toast("成本已更新");
    });
  }

  // v1.9.47 上架 SKU：填了就存进草稿（并回显合法化后的值），清空则回到灰字里的自动货号
  for (const input of $$("#sku-table input.sku-offer-id")) {
    input.addEventListener("change", async () => {
      const sku = state.draft?.skus?.find((item) => item.id === input.dataset.id);
      if (!sku) return;
      const raw = cleanText(input.value);
      const safe = sanitizeOfferId(raw);
      sku.offerId = safe;
      input.value = safe;
      state.draft = await saveDraft({ id: state.draft.id, skus: state.draft.skus });
      if (!raw) toast("上架 SKU 已留空，将使用灰字里的自动货号（店铺名+年月日+时间）");
      else if (safe !== raw) toast(`上架 SKU 只能填字母、数字、- _ . ，已存为「${safe}」`, "warn");
      else toast("上架 SKU 已保存", "ok");
    });
  }

  // v1.9.48 规格名内联可编辑：写回 sku.label；单维度时同步该维度值
  for (const input of $$("#sku-table input.sku-label-input")) {
    input.addEventListener("change", async () => {
      const sku = state.draft?.skus?.find((item) => item.id === input.dataset.id);
      if (!sku) return;
      const next = cleanText(input.value)
        || Object.values(sku.specs || {}).join(" / ")
        || "(未命名)";
      sku.label = next;
      syncSingleSpecValue(sku, next);
      input.value = next;
      state.draft = await saveDraft({ id: state.draft.id, skus: state.draft.skus });
      renderListingResult();
      toast("规格已更新", "ok");
    });
  }

  for (const button of $$("#sku-table button.sku-remove")) {
    button.addEventListener("click", () => removeSku(button.dataset.id));
  }

  // SKU 图片：点击放大；替换由独立按钮触发，避免破坏查看大图交互
  for (const img of $$("#sku-table .sku-thumb:not(.sku-ai-thumb)")) {
    img.addEventListener("click", () => openImagePreview(img.src, `SKU ${img.dataset.id} 原图`));
    img.addEventListener("error", () => {
      img.classList.add("is-broken");
      retryThumbViaBackground(img, img.getAttribute("src"));
    });
  }
  // v1.9.44 AI 主图列：缩略图点开放大看单图
  for (const img of $$("#sku-table .sku-ai-thumb")) {
    img.addEventListener("click", () => openImagePreview(img.src, `SKU ${img.dataset.id} AI 主图`));
    img.addEventListener("error", () => img.classList.add("is-broken"));
  }
  // 「对比」：并排 / 滑块对比原图与 AI 主图；还没生成时也能打开，右侧给占位说明
  for (const button of $$("#sku-table button.sku-ai-compare")) {
    button.addEventListener("click", () => {
      const sku = state.draft?.skus?.find((item) => item.id === button.dataset.id);
      if (!sku) return;
      openImageComparePreview({
        title: `对比：${sku.label || sku.id}`,
        // v1.9.81 AI 图已替换 sku.image，对比的"原图"必须取替换前存的 originalImage
        original: sku.originalImage || sku.image || (sku.images || [])[0] || "",
        generated: sku.aiMainUrl || "",
      });
    });
  }
  for (const button of $$("#sku-table button.sku-replace")) {
    button.addEventListener("click", () => openSkuImagePicker(button.dataset.id));
  }
  // v1.9.81 「还原主图」：撤销 AI 主图替换——把 sku.image 换回 originalImage（AI 图之前的原图），
  // 并从图集里移除 AI 图。旧版没有 originalImage 的（v1.9.54 那批 AI 图排在首位）也照样还原。
  for (const button of $$("#sku-table button.sku-ai-restore")) {
    button.addEventListener("click", async () => {
      const sku = state.draft?.skus?.find((item) => item.id === button.dataset.id);
      if (!sku) return;
      if (!sku.aiMainUrl) return toast("这个 SKU 还没有 AI 主图，不用还原", "warn");
      const ai = sku.aiMainUrl;
      const original = cleanText(sku.originalImage) || "";
      const rest = (sku.images || []).filter((url) => url && url !== ai);
      // 有存原图 → 主图换回原图；没存（历史数据）→ 退回图集里第一张非 AI 图
      const backTo = original || rest[0] || "";
      sku.image = backTo;
      sku.images = [...new Set([backTo, ...rest].filter(Boolean))].slice(0, 9);
      delete sku.aiMainUrl;
      delete sku.originalImage;
      state.draft = await saveDraft({ id: state.draft.id, skus: state.draft.skus });
      refreshSkuSection();
      toast(backTo ? "已还原：该 SKU 主图换回原来的商品图" : "已移除 AI 主图（该 SKU 没有可还原的原图）", backTo ? "ok" : "warn");
    });
  }
  // v1.9.43 单行「AI 主图」：基于该变体自己的原图出一张信息图主图
  for (const button of $$("#sku-table button.sku-ai")) {
    button.addEventListener("click", async () => {
      button.disabled = true;
      button.textContent = "生成中…";
      const ok = await generateSkuMainImage(button.dataset.id);
      button.disabled = false;
      button.textContent = "AI 主图";
      if (ok) {
        // v1.9.46 修 bug：只刷核价不会重画 SKU 表，那格 AI 主图会一直显示「未生成」
        refreshSkuSection();
        toast("该 SKU 的 AI 主图已排到它图集的首位", "ok");
      }
    });
  }
}

/** 给指定 SKU 换图：从草稿图片池里选一张（v1.9.51：AI 图排前面并带角标，方便直接选 AI 主图） */
async function openSkuImagePicker(skuId) {
  if (!state.draft) return;
  const sku = state.draft.skus.find((item) => item.id === skuId);
  if (!sku) return;
  const images = (state.draft.images || []).filter(Boolean);
  if (!images.length) return toast("草稿还没有图片，先去「图片」区采集", "warn");
  const aiSet = draftAiUrlSet();
  const choices = images
    .map((url) => ({ label: url, value: url, ai: aiSet.has(url) }))
    .sort((a, b) => Number(b.ai) - Number(a.ai));
  const current = sku.image;
  const picked = await showImagePicker(`给「${sku.label || "SKU"}」选一张图`, choices, current);
  if (picked === undefined) return; // 取消
  sku.image = picked || "";
  sku.images = picked ? [picked, ...(sku.images || []).filter((url) => url && url !== picked)].slice(0, 9) : [];
  state.draft = await saveDraft({ id: state.draft.id, skus: state.draft.skus });
  renderEditor();
}

/* ------------------------------------------------------------------
 * v1.9.43 每个 SKU 基于「自己的原图」生成 AI 主图（信息图排版，一一对应）
 * ------------------------------------------------------------------ */

/** SKU 主图的参考图：只用这个变体自己的**原图**（保证 AI 主图与该变体一一对应）。
 *  v1.9.81：AI 主图会替换 sku.image，所以参考图必须优先取 originalImage（替换前存的原图），
 *  否则会拿上一张 AI 图当参考再生成（AI 生 AI，越生成越走样）。 */
async function fetchSkuReference(sku) {
  const sourceUrl = sku.originalImage || sku.image || (sku.images || [])[0] || "";
  if (!sourceUrl) throw new Error("这个变体还没有自己的原图，先点「换图」给它选一张");
  try {
    return await fetchDataUrl(sourceUrl);
  } catch (error) {
    throw new Error(`取该变体原图失败（${error?.message || error}）`);
  }
}

/** SKU 主图上的俄文参数：该变体规格值 + 草稿里不含中文的属性（尺寸/承重/孔距等） */
function skuMainLabels(sku) {
  const specValues = Object.values(sku?.specs || {}).map((value) => cleanText(value)).filter(Boolean);
  const attrs = (state.draft?.attributes || [])
    .map((attr) => `${cleanText(attr?.name)} ${cleanText(Array.isArray(attr?.values) ? attr.values[0] : attr?.value)}`.trim())
    .filter((line) => line && !/[\u4e00-\u9fa5]/.test(line));
  return [...new Set([...specValues, ...attrs, ...(state.setGenLabels || [])])].slice(0, 8);
}

/**
 * 给一个 SKU 生成 AI 主图：shot = SKU_MAIN_SHOT（信息图排版），参考图 = 该变体原图。
 * v1.9.49 variantSeed：批量给多个 SKU 出主图时传入递增序号，让每张走不同版式/机位，
 * 不再「一排 SKU 全是同一个模板换个颜色」。单张点按钮时按该 SKU 在列表里的位置取种子。
 */
async function generateSkuMainImage(skuId, variantSeed = null) {
  if (!state.draft) { toast("请先载入草稿", "error"); return false; }
  const sku = state.draft.skus.find((item) => item.id === skuId);
  if (!sku) { toast("找不到该 SKU", "error"); return false; }
  let referenceImage = "";
  try {
    referenceImage = await fetchSkuReference(sku);
  } catch (error) {
    toast(error?.message || String(error), "error");
    return false;
  }
  const context = cleanText([state.draft.ru?.productType, state.draft.ru?.title || state.draft.title].filter(Boolean).join(", "));
  const manualStyle = cleanText($("#set-gen-style")?.value || "");
  const autoStyle = pickStyleFor(
    state.draft.ru?.productType || "",
    [state.draft.ozonCategory?.path, state.draft.categoryPath, state.draft.category].filter(Boolean).flat().join(" > "),
  );
  const direction = STYLE_DIRECTION_FOR_SKU;
  // 种子缺省时用该 SKU 在带图 SKU 列表里的位置，保证不同 SKU 至少版式不同
  const seed = Number.isFinite(Number(variantSeed))
    ? Number(variantSeed)
    : Math.max(0, (state.draft.skus || []).findIndex((item) => item.id === skuId));
  const art = state.setGenArt?.shots?.["sku-main"];
  try {
    const data = await call({
      action: MESSAGE_ACTIONS.imageRedraw,
      context,
      styleHint: manualStyle || joinStyle(direction.style, autoStyle),
      styleDirection: direction.label,
      size: currentSetSize().size,
      shot: SKU_MAIN_SHOT,
      points: selectedSetPoints(),
      title: cleanText(state.draft.ru?.productType || state.draft.ru?.title || ""),
      subtitle: sku.label || "",
      labels: skuMainLabels(sku),
      extraInfo: cleanText($("#set-gen-extra")?.value || ""),
      direction,
      allowWhiteBg: Boolean($("#set-gen-bg-white")?.checked),
      // v1.9.49 逐 SKU 换版式（5 套轮转）+ 换机位（跳过种子 0）
      layoutSeed: seed,
      framingSeed: (seed % 7) + 1,
      artDirection: art?.artDirection || "",
      referenceImages: [referenceImage],
      referenceImage,
    });
    const remoteUrl = data?.url || "";
    let src = data?.dataUrl || remoteUrl;
    if (!src) throw new Error("生图接口未返回可用图片");
    if (remoteUrl) {
      try { src = await fetchDataUrl(remoteUrl); } catch { /* 展示用 dataUrl 拿不到就直接用远端 URL */ }
    }
    // AI 主图自动替换该变体主图（v1.9.81 超哥：生成后自动替换原来主图）：
    // 有可上传直链时，AI 图成为该 SKU 的新主图（sku.image 指向它），原图存进 originalImage 供「还原主图」；
    // 图集首位也是 AI 图 → 上传时 primary_image 就是它。纯 base64（无直链）时不替换，只进预览位。
    const uploadable = /^https?:\/\//i.test(remoteUrl) ? remoteUrl : "";
    const original = sku.image || "";
    const keep = (sku.images || []).filter((url) => url && url !== uploadable && url !== src && url !== original);
    sku.aiMainUrl = uploadable || src;
    if (uploadable) {
      if (!sku.originalImage) sku.originalImage = original;
      sku.image = uploadable;
      sku.images = [uploadable, ...keep].filter(Boolean).slice(0, 9);
    } else {
      sku.images = [original, ...keep].filter(Boolean).slice(0, 9);
      toast("生图接口只返回了本地预览图（没有可上传的 URL），已放到「AI 主图」预览位；这张不会作为上传图", "warn");
    }
    state.draft = await saveDraft({ id: state.draft.id, skus: state.draft.skus });
    return true;
  } catch (error) {
    toast(`「${sku.label || sku.id}」AI 主图生成失败：${error?.message || error}`, "error");
    return false;
  }
}

/** SKU 主图固定走棚拍方向（信息图排版要干净背景，色彩对比靠色块） */
const STYLE_DIRECTION_FOR_SKU = { id: "studio", label: "纯色棚拍", style: "студийная съёмка на однотонном фоне, мягкий рассеянный свет, максимальная проработка фактуры товара" };

/**
 * 批量生成 AI 主图（串行执行，避免触发限流）。
 * 默认 onlySelected=false：界面按钮就是「为全部 SKU 生成 AI 主图」，
 * 没有自己原图的变体会被跳过，并在结束时的提示里如实报数。
 */
async function generateSkuMainImages({ onlySelected = false } = {}) {
  if (!state.draft) { toast("请先载入草稿", "error"); return; }
  const all = state.draft.skus || [];
  const withImage = all.filter((sku) => sku.image || (sku.images || [])[0]);
  const list = onlySelected ? withImage.filter((sku) => state.selectedSkus.has(sku.id)) : withImage;
  if (!list.length) {
    toast(
      all.length
        ? "这些 SKU 都还没有自己的原图，先在「图片」列点「换图」给变体配一张"
        : (onlySelected ? "没有「已选用且带原图」的 SKU，先勾选或点「换图」配图" : "没有带原图的 SKU"),
      "warn",
    );
    return;
  }
  const btn = $("#btn-sku-ai-main");
  if (btn) btn.disabled = true;
  let done = 0;
  for (const [index, sku] of list.entries()) {
    // 进度先亮出来；生成完 refreshSkuSection 会把说明文字写回 #sku-notice，所以之后再补设一次
    const progress = `AI 主图 ${index + 1}/${list.length}：${sku.label || sku.id}`;
    setBadge("#sku-notice", progress, "warn");
    // v1.9.49 传 index 作版式种子：批量出的主图一张一个版式，不再整套模板脸
    // eslint-disable-next-line no-await-in-loop
    if (await generateSkuMainImage(sku.id, index)) done += 1;
    refreshSkuSection();
    setBadge("#sku-notice", progress, "warn");
  }
  if (btn) btn.disabled = false;
  setBadge("#sku-notice", done === list.length ? `AI 主图完成 ${done} 张` : `AI 主图完成 ${done}/${list.length}（失败见提示）`, done === list.length ? "ok" : "warn");
  toast(done === list.length ? `已为 ${done} 个 SKU 生成 AI 主图（已排到各自图集首位）` : `AI 主图：成功 ${done} 个、失败 ${list.length - done} 个`, done === list.length ? "ok" : "warn");
}

/**
 * 简易图片选择弹窗。
 * v1.9.51 修「点图没反应」：事件改成委托 + settled 防重复关闭——原来给每个 item 单独绑 click，
 * 任何一处 DOM 异常（或双击）都会导致弹窗状态错乱；另外支持 Esc 关闭、点遮罩取消、AI 图带角标。
 * @param {string} title
 * @param {{label:string,value:string,ai?:boolean}[]} choices
 * @param {string} current
 * @returns {Promise<string|undefined>} 选中的 URL；取消返回 undefined
 */
function showImagePicker(title, choices, current) {
  return new Promise((resolve) => {
    const wrap = document.createElement("div");
    wrap.className = "modal-overlay";
    wrap.innerHTML = `
      <div class="modal">
        <h4>${escapeHtml(title)}</h4>
        <div class="image-picker-grid">
          ${choices.map((c) => `<div class="image-picker-item${c.value === current ? " selected" : ""}" data-url="${escapeHtml(c.value)}">
            <img src="${escapeHtml(c.value)}" loading="lazy">
            ${c.ai ? '<span class="picker-ai-badge">AI</span>' : ""}
          </div>`).join("")}
        </div>
        <div class="modal-actions">
          <button id="img-pick-cancel" type="button">取消</button>
          <button id="img-pick-clear" type="button" class="danger">不配图</button>
        </div>
      </div>
    `;
    document.body.appendChild(wrap);
    let settled = false;
    const close = (value) => {
      if (settled) return;   // 双击/连点只认第一次，避免 resolve 两次把后面的交互打乱
      settled = true;
      document.removeEventListener("keydown", onKey);
      wrap.remove();
      resolve(value);
    };
    const onKey = (event) => { if (event.key === "Escape") close(undefined); };
    document.addEventListener("keydown", onKey);
    wrap.querySelector("#img-pick-cancel").addEventListener("click", () => close(undefined));
    wrap.querySelector("#img-pick-clear").addEventListener("click", () => close(""));
    // 事件委托：点在缩略图（或它的 img/角标）上都算选中，不再依赖每个 item 自己的监听器
    wrap.addEventListener("click", (event) => {
      if (event.target === wrap) return close(undefined);   // 点遮罩 = 取消
      const item = event.target.closest?.(".image-picker-item");
      if (item) close(item.dataset.url || "");
    });
  });
}

function escapeHtml(text) {
  return String(text || "").replace(/[&<>"']/g, (ch) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", "\"": "&quot;", "'": "&#39;" }[ch]));
}

/* ---------------- 采集后的 SKU 确认 ----------------
 * 达瓦式顺序：点采集/开始执行 → 先确认 1688 上抓到哪些 SKU 要上架 → 再选类目 → 才拉类目属性。
 * 这样不会在 SKU 还没定的时候就把属性填死。
 */

let skuPromptedFor = "";   // 本次会话已弹过确认框的草稿 id，同一草稿不重复弹

/**
 * 采集后弹一次 SKU 确认框（开关关掉则不弹）。
 * @param {object} [options]
 * @param {boolean} [options.force=false] 无视开关/已确认标记，强制弹（手动点按钮时用）
 */
async function maybeConfirmSkus({ force = false } = {}) {
  const draft = state.draft;
  if (!draft) return null;
  const skus = draft.skus || [];
  if (!skus.length) return null;
  if (!force) {
    if ($("#ai-pipe-sku-confirm")?.checked === false) return null;
    if (draft.skuConfirmed || skuPromptedFor === draft.id) return null;
  }
  skuPromptedFor = draft.id;
  const result = await openSkuConfirmModal(skus);
  if (!result) return null;                 // 取消：保持当前勾选，不打断流程
  state.selectedSkus = new Set(result.ids);
  state.draft = await saveDraft({ id: draft.id, skuConfirmed: true, selectedSkus: result.ids });
  renderEditor();
  renderListingResult();
  // 确认完规格就把「这几个规格会怎么上架」算出来给用户看（选几个就该上架几个）
  await renderVariantAttrHint();
  toast(`已确认 ${result.ids.length} / ${skus.length} 个 SKU，接着选类目`, "ok");
  return { confirmed: true, count: result.ids.length };
}

/** 列出 1688 抓到的全部规格，勾选要上架的；返回 { ids } 或 null（取消） */
function openSkuConfirmModal(skus) {
  return new Promise((resolve) => {
    const wrap = document.createElement("div");
    wrap.className = "modal-overlay";
    const rows = skus.map((sku) => {
      const id = escapeHtml(sku.id);
      const label = escapeHtml(sku.label || Object.values(sku.specs || {}).join(" / ") || "(未命名)");
      const checked = state.selectedSkus.has(sku.id) ? " checked" : "";
      const img = sku.image
        ? `<img class="sku-confirm-thumb" src="${escapeHtml(sku.image)}" loading="lazy">`
        : `<span class="sku-confirm-thumb is-empty">无图</span>`;
      // 采集端标记的「置灰/售罄」组合：默认就没勾上，这里把原因写出来，让用户知道为什么
      const blocked = sku.unavailable
        ? `<div class="sub danger-text">不可选：${escapeHtml(sku.unavailableReason || "页面上置灰/售罄")}</div>`
        : "";
      return `<tr>
        <td><input type="checkbox" class="sku-confirm-check" data-id="${id}"${checked}></td>
        <td>${img}</td>
        <td>${label}${blocked}</td>
        <td>¥${Number(sku.price) || 0}</td>
        <td>${escapeHtml(String(sku.stock ?? ""))}</td>
      </tr>`;
    }).join("");
    wrap.innerHTML = `
      <div class="modal sku-confirm-modal">
        <h4>确认采集到的 1688 SKU（共 ${skus.length} 个）</h4>
        <p class="sub">勾选要上架的规格——只有勾选的 SKU 会参与定价、库存与上传。确认后进入「选类目」。</p>
        <div class="table-wrap sku-confirm-wrap"><table>
          <thead><tr><th>选用</th><th>图</th><th>规格</th><th>成本 ¥</th><th>库存</th></tr></thead>
          <tbody>${rows}</tbody>
        </table></div>
        <p class="sub" id="sku-confirm-count"></p>
        <div class="modal-actions">
          <button id="sku-confirm-all" type="button">全选</button>
          <button id="sku-confirm-none" type="button">取消全选</button>
          <span class="spacer"></span>
          <button id="sku-confirm-cancel" type="button">取消</button>
          <button id="sku-confirm-ok" type="button" class="primary">确认并选类目</button>
        </div>
      </div>`;
    document.body.appendChild(wrap);
    const checks = () => [...wrap.querySelectorAll(".sku-confirm-check")];
    const syncCount = () => {
      const node = wrap.querySelector("#sku-confirm-count");
      if (node) node.textContent = `已选 ${checks().filter((c) => c.checked).length} / ${skus.length}`;
    };
    const close = (value) => { wrap.remove(); resolve(value); };
    for (const box of checks()) box.addEventListener("change", syncCount);
    wrap.querySelector("#sku-confirm-all").addEventListener("click", () => {
      for (const box of checks()) box.checked = true;
      syncCount();
    });
    wrap.querySelector("#sku-confirm-none").addEventListener("click", () => {
      for (const box of checks()) box.checked = false;
      syncCount();
    });
    wrap.querySelector("#sku-confirm-cancel").addEventListener("click", () => close(null));
    wrap.querySelector("#sku-confirm-ok").addEventListener("click", () => {
      const ids = checks().filter((box) => box.checked).map((box) => box.dataset.id);
      if (!ids.length) return toast("至少选一个 SKU", "error");
      return close({ ids });
    });
    syncCount();
  });
}

async function removeSku(id) {
  if (!state.draft) return;
  const sku = (state.draft.skus || []).find((item) => item.id === id);
  if (!sku) return;
  const label = sku.label || Object.values(sku.specs || {}).join(" / ") || id;
  const yes = await confirmDialog(`删除 SKU「${label}」？`, { confirmText: "删除", danger: true });
  if (!yes) return;
  const kept = state.draft.skus.filter((item) => item.id !== id);
  state.selectedSkus.delete(id);
  state.draft = await saveDraft({ id: state.draft.id, skus: kept, selectedSkus: [...state.selectedSkus] });
  renderEditor();
  renderListingResult();
  toast(`已删除，剩余 ${kept.length} 个 SKU`, "ok");
}

// 按规格维度做笛卡尔积生成 SKU 组合（与采集端 buildSkusFromOptions 同逻辑，供手动补全用）
function buildSkuCombos(specOptions) {
  let combos = [[]];
  for (const option of specOptions.slice(0, 2)) {
    const next = [];
    for (const combo of combos) {
      for (const value of option.values.slice(0, 12)) next.push(combo.concat([{ name: option.name, value }]));
    }
    combos = next;
    if (combos.length > 60) break;
  }
  const specImages = state.draft?.specImages || {};
  // 采集端已经标过「置灰/售罄」的同规格组合（specs 完全一致），继承它的标记
  const blockedByKey = new Map();
  for (const sku of state.draft?.skus || []) {
    if (!sku.unavailable) continue;
    const key = Object.entries(sku.specs || {}).map(([k, v]) => `${k}:${v}`).sort().join("|");
    if (key) blockedByKey.set(key, sku.unavailableReason || "页面上置灰/售罄");
  }
  return combos.slice(0, 60).map((combo, index) => {
    const specs = {};
    for (const item of combo) specs[item.name] = item.value;
    // 按规格值匹配对应的小图（颜色图/款式图），方便用户区分；规范化匹配提升命中率
    let image = "";
    for (const item of combo) {
      const candidate = matchSpecImage(specImages, item.name, item.value);
      if (candidate) { image = candidate; break; }
    }
    const comboKey = combo.map((item) => `${item.name}:${item.value}`).sort().join("|");
    const blocked = blockedByKey.get(comboKey);
    return {
      id: `manual_${Date.now().toString(36)}_${index}`,
      specs,
      price: 0,
      stock: 0,
      image,
      label: Object.values(specs).join(" / "),
      ...(blocked ? { unavailable: true, unavailableReason: blocked } : {}),
    };
  });
}

async function addSkuRow() {
  if (!state.draft) return toast("请先载入草稿", "error");
  const skus = state.draft.skus || [];
  const index = skus.length + 1;
  const created = {
    id: `manual_${Date.now().toString(36)}`,
    specs: {},
    price: 0,
    stock: 0,
    image: "",
    label: `规格 ${index}`,
  };
  // v1.9.83 手动加的行自动选用——默认只显示选用的 SKU，不选它一加完就「消失」，用户会以为没加上
  state.selectedSkus.add(created.id);
  state.draft = await saveDraft({ id: state.draft.id, skus: [...skus, created], selectedSkus: [...state.selectedSkus] });
  renderEditor();
  toast("已添加一行 SKU，请补规格名与成本价", "ok");
}

async function generateSkusFromSpecs() {
  if (!state.draft) return toast("请先载入草稿", "error");
  let specOptions = state.draft.specOptions || [];
  const btn = $("#btn-sku-generate");
  // 没采集到规格维度时，先让 AI 根据商品信息自动识别；识别失败再 fallback 手动输入
  if (!specOptions.length) {
    if (btn) { btn.disabled = true; btn.textContent = "AI 识别规格中…"; }
    try {
      const detected = await call({ action: MESSAGE_ACTIONS.aiDetectSpecOptions, product: state.draft });
      if (Array.isArray(detected) && detected.length) {
        specOptions = detected;
        toast(`AI 识别到 ${detected.length} 个规格维度：${detected.map((o) => o.name).join(" / ")}`, "ok");
      }
    } catch (error) {
      toast(`AI 自动识别规格失败：${error.message}，将使用手动输入兜底`, "warn");
    } finally {
      if (btn) { btn.disabled = false; btn.textContent = "按规格维度生成 SKU"; }
    }
  }
  if (!specOptions.length) {
    const manual = await promptForSpecOptions();
    if (!manual?.length) return;
    specOptions = manual;
  }
  const combos = buildSkuCombos(specOptions);
  if (!combos.length) return toast("规格维度为空，无法生成", "error");
  // 生成的组合没有真实价格矩阵：用采集到的整单最低价先垫上，别留 0 成本（0 会把定价/利润全带歪）
  const fallbackPrice = Number(state.draft.priceMinCny) || Number(state.draft.costCny) || 0;
  if (fallbackPrice > 0) {
    for (const sku of combos) if (!(Number(sku.price) > 0)) sku.price = fallbackPrice;
  }
  const priceNote = fallbackPrice > 0
    ? `成本先按采集最低价 ¥${fallbackPrice} 填充`
    : "成本价留 0，需要你补";
  const yes = await confirmDialog(
    `按「${specOptions.map((o) => o.name).slice(0, 2).join(" × ")}」生成 ${combos.length} 个 SKU（${priceNote}）？${(state.draft.skus || []).length ? "现有 SKU 会被替换。" : ""}`,
    { confirmText: "生成" },
  );
  if (!yes) return;
  state.selectedSkus = new Set(combos.filter((sku) => !sku.unavailable).map((sku) => sku.id));
  state.draft = await saveDraft({
    id: state.draft.id,
    skus: combos,
    selectedSkus: [...state.selectedSkus],
    specOptions,
  });
  renderEditor();
  renderListingResult();
  toast(fallbackPrice > 0
    ? `已生成 ${combos.length} 个 SKU，成本暂按采集最低价 ¥${fallbackPrice}，请按实际档位核对`
    : `已生成 ${combos.length} 个 SKU，请补成本价`, "ok");
}

/**
 * 没采集到规格维度时的兜底：让用户手动输入规格名和可选值（用换行或顿号分隔）。
 * 例如：颜色  红色、蓝色、黑色
 */
function promptForSpecOptions() {
  return new Promise((resolve) => {
    const wrap = document.createElement("div");
    wrap.className = "modal-overlay";
    wrap.innerHTML = `
      <div class="modal" style="min-width:320px">
        <h4>手动输入规格维度</h4>
        <p class="hint">页面没自动抓到规格（可能是未展开/未渲染）。请按格式输入，可填 1~2 个维度：</p>
        <label>维度 1 名称（如：颜色）<input id="spec-name-1" type="text" value="颜色"></label>
        <label>维度 1 可选值（用「、」或英文逗号分隔）<input id="spec-values-1" type="text" placeholder="红色、蓝色、黑色"></label>
        <label>维度 2 名称（如：尺码，可留空）<input id="spec-name-2" type="text" value=""></label>
        <label>维度 2 可选值（可留空）<input id="spec-values-2" type="text" placeholder="S、M、L"></label>
        <div class="modal-actions">
          <button id="spec-cancel" type="button">取消</button>
          <button id="spec-ok" class="primary" type="button">生成</button>
        </div>
      </div>
    `;
    document.body.appendChild(wrap);
    const close = (value) => { wrap.remove(); resolve(value); };
    wrap.querySelector("#spec-cancel").addEventListener("click", () => close(null));
    wrap.querySelector("#spec-ok").addEventListener("click", () => {
      const out = [];
      for (let i = 1; i <= 2; i += 1) {
        const name = cleanText(wrap.querySelector(`#spec-name-${i}`).value);
        const raw = cleanText(wrap.querySelector(`#spec-values-${i}`).value);
        const values = raw.split(/[,，、]/).map((v) => cleanText(v)).filter(Boolean);
        if (name && values.length) out.push({ name, values });
      }
      close(out.length ? out : null);
    });
  });
}

/* ---------------- Ozon ---------------- */

function bindSkuSelection() {
  $("#btn-sku-generate").addEventListener("click", () => generateSkusFromSpecs());

  $("#btn-sku-add").addEventListener("click", () => addSkuRow());

  // v1.9.85 「添加库存」：给已选用的 SKU 补/改库存数量。
  // 1688 采集的库存经常是占位值（9999 之类），上架前按实际备货改这里。
  // 弹窗复用 openModal（提交时自带按钮禁用+「处理中…」，失败会 toast 并保持弹窗可重试），
  // 只列选用的 SKU——未选用的不参与上传，改它们的库存没有意义。
  $("#btn-sku-add-stock")?.addEventListener("click", async () => {
    if (!state.draft) return toast("请先采集或载入草稿", "error");
    const candidates = getSelectedSkus();
    if (!candidates.length) return toast("没有已选用的 SKU——先在 SKU 表勾上「选用」或到采集确认里勾选", "warn");
    await openModal({
      title: "添加库存",
      submitText: "保存库存",
      fields: [
        {
          key: "skuId", label: "SKU", type: "select",
          options: candidates.map((sku, i) => ({
            value: sku.id,
            label: `${sku.label || Object.values(sku.specs || {}).join(" / ") || `SKU ${i + 1}`}（当前库存 ${sku.stock ?? 0}）`,
          })),
        },
        {
          key: "stock", label: "库存数量", type: "number", value: String(candidates[0].stock ?? 0),
          hint: "填 0 以上的整数；上传 Ozon 时该 SKU 的可售库存就是这个数",
        },
      ],
      onSubmit: async (values) => {
        const sku = (state.draft.skus || []).find((item) => item.id === values.skuId);
        if (!sku) throw new Error("找不到该 SKU（可能已被删除），请重新打开弹窗");
        const next = Math.floor(Number(values.stock));
        if (!Number.isFinite(next) || next < 0) throw new Error("库存必须是 0 以上的整数");
        sku.stock = next;
        state.draft = await saveDraft({ id: state.draft.id, skus: state.draft.skus });
        refreshSkuSection();
        toast(`「${sku.label || sku.id}」库存已更新为 ${next}`, "ok");
      },
    });
  });

  // v1.9.83 「显示未选用」开关：勾上展开全部行（含未选用的），取消则只留选用的
  $("#sku-show-unselected")?.addEventListener("change", () => {
    if (state.draft) renderSkuSection(state.draft.skus || [], state.draft.specOptions || []);
  });

  $("#btn-sku-select-all").addEventListener("click", () => {
    if (!state.draft?.skus?.length) return;
    state.draft.skus.forEach((sku) => state.selectedSkus.add(sku.id));
    renderEditor();
    toast("已全选 SKU");
  });

  $("#btn-sku-unselect-all").addEventListener("click", () => {
    state.selectedSkus.clear();
    renderEditor();
    toast("已取消全部 SKU 选择");
  });

  $("#btn-sku-confirm")?.addEventListener("click", async () => {
    if (!state.draft) return toast("请先采集或载入草稿", "error");
    if (!(state.draft.skus || []).length) return toast("草稿里还没有 SKU", "error");
    await maybeConfirmSkus({ force: true });
  });

  $("#btn-sku-save-active").addEventListener("click", async () => {
    if (!state.draft) return toast("请先载入草稿", "error");
    if (!state.selectedSkus.size) return toast("至少要选用一个 SKU", "error");
    state.draft = await saveDraft({ id: state.draft.id, selectedSkus: [...state.selectedSkus] });
    toast(`已保存：选用 ${state.selectedSkus.size} 个 SKU 参与定价/库存`, "ok");
  });

  // v1.9.43 批量：每个选用 SKU 用它自己的原图生成 AI 主图（一一对应）
  // v1.9.44 按钮改成「为全部 SKU 生成 AI 主图」：一次把每个变体都用它自己的原图出一张信息图主图
  $("#btn-sku-ai-main")?.addEventListener("click", () => generateSkuMainImages({ onlySelected: false }));
}

function bindOzon() {
  $("#store-select").addEventListener("change", () => {
    setBadge("#ozon-status", "未测试", "");
    toast("已切换店铺，请重新测试连接");
  });

  $("#btn-ozon-test").addEventListener("click", async () => {
    setBadge("#ozon-status", "测试中…", "warn");
    try {
      const data = await call({ action: MESSAGE_ACTIONS.ozonTestConnection });
      setBadge("#ozon-status", `已连接（商品 ${data.total ?? "?"}）`, "ok");
    } catch (error) {
      setBadge("#ozon-status", "连接失败", "err");
      toast(error.message, "error");
    }
  });

  $("#btn-ozon-tree").addEventListener("click", async () => {
    try {
      const tree = await loadCategoryTreeWithStatus({ force: true, label: "类目树" });
      renderCategoryTree();
      const stats = state.categoryTreeStats || countCategoryTree(tree);
      toast(`类目树已加载：${categoryTreeSummary(stats)}`, "ok");
    } catch (error) {
      toast(error.message, "error");
    }
  });

  // 中文搜索：Ozon 树里没有中文，先把中文关键词翻成俄语再过滤
  let searchTimer = 0;
  $("#cat-search").addEventListener("input", () => {
    renderCategoryTree();
    const value = cleanText($("#cat-search").value);
    if (!CJK_PATTERN.test(value) || state.zhKeyword[value]) return;
    clearTimeout(searchTimer);
    searchTimer = setTimeout(async () => {
      try {
        await translateCategoryTexts([value], "ru");
        renderCategoryTree();
      } catch { /* 翻不出来就当普通关键词处理 */ }
    }, 600);
  });

  $("#btn-ozon-upload").addEventListener("click", async () => {
    if (!state.draft) return toast("请先载入草稿", "error");
    if (!await ensureLicensed("上传到 Ozon")) return;
    const review = $("#ozon-review").checked;
    if (review && !await confirmDialog("已开启人工审核，确认现在就上传到 Ozon？")) {
      kv("#upload-result", [["状态", "已取消，未提交"]]);
      return;
    }
    try {
      const items = await buildUploadItems();
      if (!items.length) return toast("没有可上传的商品条目", "error");
      const data = await call({ action: MESSAGE_ACTIONS.ozonImportProducts, items });
      const taskId = data?.task_id || 0;
      kv("#upload-result", [
        ["状态", "已提交，正在查 Ozon 的处理结果…"],
        ["提交条目", String(items.length)],
        ["任务 ID", String(taskId || "(未返回)")],
      ]);
      toast(`上传已提交（${items.length} 条）`, "ok");
      // 提交成功 ≠ 上传成功：Ozon 是异步导入，必须查任务结果才知道哪条被拒
      await pollImportResult(taskId);
    } catch (error) {
      kv("#upload-result", [["状态", "失败"], ["原因", error.message]]);
      toast(error.message, "error");
    }
  });

  $("#btn-cat-auto").addEventListener("click", async () => {
    if (!state.draft) return toast("请先载入草稿", "error");
    try {
      const path = await autoMatchCategory(state.draft);
      if (!path) {
        const hint = cleanText(state.draft.ru?.categoryHint || state.draft.ru?.title);
        toast(hint ? `没匹配上（AI 给的线索是「${hint}」），请手动展开类目树选到最后一层「类型」` : "没匹配上：先生成俄语文案，或手动展开类目树选到最后一层「类型」", "warn");
      } else {
        toast(`已匹配到：${path}`, "ok");
      }
    } catch (error) {
      toast(error.message, "error");
    }
  });

  // 按需补齐枚举属性的候选值（默认只会自动拉必填/变体属性，其余用这个按钮补）
  $("#btn-attr-dict")?.addEventListener("click", async () => {
    if (!state.draft) return toast("请先载入草稿", "error");
    if (!(state.categoryAttributes || []).length) return toast("先点「加载类目属性」", "error");
    await loadAttributeDictionaries(state.categoryAttributes, { onlyImportant: false });
  });

  // v1.9.55 手动跑一次属性对账（载入类目属性后会自动跑，这里是改完值之后复查）
  $("#btn-attr-check")?.addEventListener("click", async () => {
    if (!state.draft) return toast("请先载入草稿", "error");
    if (!(state.categoryAttributes || []).length) return toast("先点「加载类目属性」", "error");
    try {
      await runAttributeCheck();
      const r = state.attrCheck;
      if (r?.ok && !r.removed.length && !r.fixed.length && !r.added.length) toast("属性校验通过：没有发现问题", "ok");
    } catch (error) {
      toast(error.message, "error");
    }
  });

  // v1.9.55 强制刷新元数据：忽略 24h 缓存回源（怀疑平台改了类目属性时用）
  $("#btn-attr-meta-refresh")?.addEventListener("click", async () => {
    if (!state.draft) return toast("请先载入草稿", "error");
    const cat = state.draft.ozonCategory || {};
    const typeId = Number(cat.typeId || cat.type_id) || 0;
    if (!typeId) return toast("还没选到类目「类型」，先选好类目", "error");
    toast("正在强制刷新属性元数据…", "warn");
    await loadCategoryAttributes(state.categoryNode || {
      category_id: Number(cat.descriptionCategoryId || cat.description_category_id || cat.category_id) || 0,
      type_id: typeId,
    }, { force: true });
  });

  // v1.9.55 报告复制 / 导出
  $("#btn-attr-check-copy")?.addEventListener("click", async () => {
    const text = buildAttributeCheckText();
    if (!text) return toast("还没有校验结果", "warn");
    try {
      await navigator.clipboard.writeText(text);
      toast("报告已复制到剪贴板", "ok");
    } catch {
      toast("剪贴板被浏览器拦截，请用「导出 txt」", "error");
    }
  });
  $("#btn-attr-check-export")?.addEventListener("click", () => {
    const text = buildAttributeCheckText();
    if (!text) return toast("还没有校验结果", "warn");
    downloadBlob(new Blob([text], { type: "text/plain;charset=utf-8" }), `属性校验报告-${Date.now()}.txt`);
  });

  $("#btn-attr-reload")?.addEventListener("click", async () => {
    if (!state.draft) return toast("请先载入草稿", "error");
    const cat = state.draft.ozonCategory || {};
    const typeId = Number(cat.typeId || cat.type_id) || 0;
    if (!typeId) return toast("还没选到类目「类型」，先选好类目再加载属性", "error");
    try {
      await loadCategoryAttributes(state.categoryNode || {
        category_id: Number(cat.descriptionCategoryId || cat.description_category_id || cat.category_id) || 0,
        type_id: typeId,
      });
      await afterCategoryConfirmed();
    } catch (error) {
      toast(error.message, "error");
    }
  });

  $("#btn-attr-ai-fill").addEventListener("click", async () => {
    try {
      await aiFillCategoryAttributes();
    } catch (error) {
      toast(error.message, "error");
    }
  });

  $("#btn-cat-confirm").addEventListener("click", async () => {
    try {
      await confirmCategorySelection();
    } catch (error) {
      toast(error.message, "error");
    }
  });

  $("#btn-cat-cancel").addEventListener("click", () => {
    state.pendingCategoryNode = null;
    renderCategoryConfirmBar();
    renderCategoryTree();
    renderCategoryPick();
  });

  $("#btn-upload-check").addEventListener("click", async () => {
    try {
      await runUploadCheck();
    } catch (error) {
      toast(error.message, "error");
    }
  });

  $("#btn-brand-check").addEventListener("click", () => {
    const risk = renderBrandGuard();
    if (!risk) return toast("品牌合规暂无法检查（草稿未载入或类目属性未加载）", "warn");
    if (risk.level === "high") {
      toast(`品牌合规有 ${risk.items.filter((i) => i.level === "problem").length} 项必须处理，见下方提示`, "error");
    } else if (risk.level === "medium") {
      toast("品牌合规有需要确认的地方，见下方提示", "warn");
    } else {
      toast("品牌合规检查通过", "ok");
    }
  });

  $("#btn-brand-nobrand").addEventListener("click", async () => {
    try {
      await fillNoBrandAttributes();
    } catch (error) {
      toast(error.message, "error");
    }
  });

  $("#btn-ozon-list").addEventListener("click", async () => {
    try {
      const data = await call({ action: MESSAGE_ACTIONS.ozonProductList, payload: { limit: 100 } });
      renderTable("#upload-list-table", [
        { key: "product_id", label: "Product ID" },
        { key: "offer_id", label: "Offer ID" },
      ], data?.items || []);
      toast(`已加载 ${data?.items?.length || 0} 条`, "ok");
    } catch (error) {
      toast(error.message, "error");
    }
  });
}

/** 按需加载 Ozon API 模块（面板里多处要用它做本地推算，避免顶层循环依赖） */
let ozonApiModule = null;
async function loadOzonApi() {
  if (!ozonApiModule) ozonApiModule = await import("../background/ozon-api.js");
  return ozonApiModule;
}

/**
 * 自动识别「变体属性」并把对应关系显示出来（v1.9.50）。
 *
 * 旧流程要求用户在上传区手填 Ozon 属性 ID（如 10096＝颜色），留空就只上架 1 条——
 * 这正是「上传了 4 个规格，系统只上架 1 个」的根因。
 * 现在改为从类目属性里按 Ozon 官方的 is_aspect 标记 + 各 SKU 的规格维度名自动匹配：
 * 识别结果写进输入框（用户手填过就不覆盖），下方提示行显示「维度 → 属性(ID)」，
 * 匹配不上时明确说明「多规格将无法上传」，而不是静默降级成单规格。
 */
async function renderVariantAttrHint() {
  const hint = $("#variant-attr-hint");
  const input = $("#ozon-variant-attr");
  if (!hint) return;
  let resolved = [];
  try {
    const { resolveVariantAttributes } = await loadOzonApi();
    resolved = resolveVariantAttributes(getSelectedSkus(), state.categoryAttributes || []);
  } catch { /* 拿不到模块就只提示，不打断界面 */ }
  const skus = getSelectedSkus();
  if (!resolved.length) {
    const blocked = skus.length >= 2;
    hint.textContent = blocked
      ? `识别不到变体属性：选用了 ${skus.length} 个 SKU，但当前类目属性里没有能和规格维度对应的变体属性（is_aspect）。请确认「② 类目与属性」已加载属性，或在这里手填 Ozon 属性 ID；否则多规格无法上传（不会再静默只上 1 个）。`
      : `变体属性会在加载类目属性后自动识别。当前选用 ${skus.length} 个 SKU，按单规格上传。`;
    hint.className = blocked ? "hint warn" : "hint";
    return;
  }
  const text = resolved
    .map((item) => `${item.dim} → ${item.name}（${item.id}${item.isAspect ? "" : " · 非变体属性，请核对"}）`)
    .join("；");
  hint.textContent = skus.length >= 2
    ? `已自动识别变体属性：${text}。选用的 ${skus.length} 个 SKU 会各上架 1 条，并合并成同一张商品卡。`
    : `已自动识别变体属性：${text}。当前只选用 1 个 SKU，按单规格上传。`;
  hint.className = "hint";
  // 只做兜底填充：用户手填过的值不动
  if (input && !input.value) input.value = String(resolved[0].id);
}

// 组装上传条目：条目数严格等于选用的 SKU 数；变体属性自动识别，手填值优先。
function collectUploadOptions() {
  return {
    category: state.draft?.ozonCategory || {},
    pricing: state.draft?.pricing || {},
    weightGrams: Number($("#ozon-weight")?.value) || 500,
    depthMm: Number($("#ozon-depth")?.value) || 100,
    widthMm: Number($("#ozon-width")?.value) || 100,
    heightMm: Number($("#ozon-height")?.value) || 100,
    vat: $("#ozon-vat")?.value || "0",
    descriptionAttributeId: Number($("#ozon-desc-attr")?.value) || 4191,
    variantAttributeId: Number($("#ozon-variant-attr")?.value) || 0,
    selectedSkus: getSelectedSkus(),
    // v1.9.50 类目属性定义（含字典）必须传下去：否则枚举值只能发自由文本，
    // Ozon 会判「属性不正确：不要手输这些值，请从列表中选择一个属性值」。
    categoryAttributes: state.categoryAttributes || state.draft?.categoryAttributes || [],
    attributeValueIds: state.draft?.attributeValueIds || {},
    // 必填属性没填是 Ozon 最常见的 400 原因，自检要能查出来
    requiredAttributeIds: (state.categoryAttributes || []).filter((a) => a.is_required).map((a) => Number(a.id) || 0).filter(Boolean),
    attributeValues: state.draft?.attributeValues || {},
  };
}

async function buildUploadItems() {
  const { buildImportItems, assertReadyToImport } = await loadOzonApi();
  const options = collectUploadOptions();
  // 先做本地预检，把 Ozon 的英文 400 提前变成中文可操作提示
  assertReadyToImport(state.draft, options);
  const items = buildImportItems(state.draft, options);
  await pruneUnreachableImages(items);
  return items;
}

/**
 * 上传前剔除 Ozon 抓不到的图片（v1.9.50）。
 *
 * 这是「商品卡片中没有照片」的正解：Ozon 服务端回源下载图片，抓不到就直接封锁商品，
 * 而本地 base64、过期的图床临时链、带防盗链的地址都属于「一定抓不到」。
 * 全被剔完时直接报错拦住上传——传上去也是被封锁，不如在这里说清楚。
 */
async function pruneUnreachableImages(items) {
  const all = [...new Set(items.flatMap((item) => item.images || []).filter(Boolean))].slice(0, 12);
  if (!all.length) return [];
  let probe = { results: [], bad: 0 };
  try {
    probe = await probeImageUrls(all);
  } catch { return []; }   // 探测不可用时不凭空拦人，交给 Ozon 判断
  const badList = (probe.results || []).filter((item) => !item.ok);
  const badSet = new Set(badList.map((item) => item.url));
  if (badSet.size) {
    for (const item of items) {
      const kept = (item.images || []).filter((url) => !badSet.has(url));
      item.images = kept;
      if (!kept.includes(item.primary_image)) item.primary_image = kept[0] || "";
    }
  }
  if (items.every((item) => !(item.images || []).length)) {
    const detail = badList.slice(0, 3).map((item) => `${item.url.slice(0, 60)}（${item.reason}）`).join("；");
    throw new Error(
      `没有一张图片是 Ozon 能抓到的，传上去会被判「商品卡片中没有照片」并封锁商品，已拦下。原因：${detail}。`
      + "请到「④ 图片」换成能公开访问的图片直链，或先用 AI 套图生成再「加入草稿」。",
    );
  }
  if (badSet.size) toast(`已剔除 ${badSet.size} 张 Ozon 抓不到的图片（否则会被判「没有照片」封锁）`, "warn");
  return badList;
}

/* ---------------- 品牌合规（v1.9.61） ---------------- */

/**
 * Ozon 最典型的封锁理由是「缺少品牌文件（Бренд）」：商品上架时品牌属性留空、
 * 或填了受保护品牌却拿不出授权书，平台会在几天后直接封锁商品（截图里那种
 * 「商品将于 6 月 15 日被封锁」的通知就是它），严重时还会被品牌方投诉侵权。
 *
 * 插件拿不到授权文件，但能把这件事变成「上传前的自查」：
 *   · 品牌属性空着 → 一键填 Ozon 官方值「Нет бренда」（无品牌商品的正解）
 *   · 标题带品牌词、品牌属性却没申报 → 拦下来，这是最高发的被封组合
 *   · 图片地址带 logo / 标题带 ®™© 或「官方/正品」→ 提示先清干净
 */

/** 当前类目里所有品牌属性的取值现状 */
function brandAttributeState() {
  const values = state.draft?.attributeValues || {};
  return (state.categoryAttributes || [])
    .filter(isBrandAttribute)
    .map((attr) => ({ attr, id: String(attr.id), value: cleanText(values[String(attr.id)]) }));
}

/** 当前草稿的品牌合规风险（纯本地计算，不联网） */
function currentBrandRisk() {
  return collectBrandRisks({
    title: state.draft?.ru?.title || state.draft?.title,
    description: state.draft?.ru?.description || state.draft?.description,
    attributes: state.draft?.attributes,
    attributeValues: state.draft?.attributeValues,
    categoryAttributes: state.categoryAttributes,
    images: state.draft?.images,
  });
}

/** 渲染品牌合规徽章与结论行；返回风险对象（无草稿/无属性时返回 null） */
function renderBrandGuard() {
  const hint = $("#brand-guard-hint");
  if (!hint || !$("#brand-guard-status")) return null;
  if (!state.draft) {
    setBadge("#brand-guard-status", "品牌未检查");
    hint.className = "hint";
    hint.textContent = "载入草稿后可检查品牌合规。";
    return null;
  }
  const list = brandAttributeState();
  if (!list.length) {
    setBadge("#brand-guard-status", "品牌未检查");
    hint.className = "hint";
    // 属性没加载就说「无风险」是谎报——Ozon 的品牌属性要靠类目元数据才认得出来
    hint.textContent = (state.categoryAttributes || []).length
      ? "当前类目没有「Бренд」属性，无需处理品牌文件。"
      : "还没加载类目属性：先到「② 类目与属性」把类目选到最后一层，再回来点「品牌合规检查」。";
    return null;
  }
  const risk = currentBrandRisk();
  const real = list.filter((s) => s.value && !isNoBrandValue(s.value));
  const empty = list.filter((s) => !s.value);
  if (risk.level === "high") {
    setBadge("#brand-guard-status", `品牌 ${risk.items.filter((i) => i.level === "problem").length} 项必须处理`, "err");
  } else if (risk.level === "medium") {
    setBadge("#brand-guard-status", "品牌待确认", "warn");
  } else {
    setBadge("#brand-guard-status", "品牌合规 OK", "ok");
  }
  const parts = [];
  if (real.length) parts.push(`品牌属性填的是「${real[0].value}」`);
  else if (empty.length) parts.push(`品牌属性（ID ${empty.map((e) => e.id).join("、")}）还是空的`);
  else parts.push("品牌属性已填「无品牌」");
  parts.push(...risk.items.map((item) => item.title));
  hint.className = `hint ${risk.level === "high" ? "danger-text" : risk.level === "medium" ? "warn-text" : "ok-text"}`;
  hint.textContent = `${parts.join("；")}。展开「上传前自检」可以看到每一条的完整说明和改法。`;
  return risk;
}

/**
 * 一键把类目「Бренд」属性填成 Ozon 官方值「Нет бренда」。
 * 已有具体品牌值时**不静默覆盖**——那可能是真有授权的品牌商品，必须先问过用户。
 *
 * v1.9.64 新增两个开关，供「品牌字段默认无品牌」自动调用：
 *   · onlyEmpty=true —— 只处理空着的品牌属性（自动默认只补空，不动用户已填的）
 *   · silent=true    —— 不弹 toast（自动触发时不想刷屏；结果由品牌合规徽章体现）
 */
async function fillNoBrandAttributes({ silent = false, onlyEmpty = false } = {}) {
  if (!state.draft) {
    if (!silent) toast("请先载入草稿", "error");
    return 0;
  }
  const list = brandAttributeState();
  if (!list.length) {
    if (!silent) {
      toast(
        (state.categoryAttributes || []).length
          ? "当前类目没有「Бренд」属性，不需要填"
          : "还没加载类目属性：先到「② 类目与属性」把类目选到最后一层",
        "warn",
      );
    }
    return 0;
  }
  const emptyTargets = list.filter((s) => !s.value);
  const realTargets = onlyEmpty ? [] : list.filter((s) => s.value && !isNoBrandValue(s.value));
  if (!emptyTargets.length && !realTargets.length) {
    if (!silent) toast("品牌属性已经是「无品牌」，无需改动", "ok");
    return 0;
  }
  if (realTargets.length) {
    const ok = await confirmDialog(
      `品牌属性现在填的是「${realTargets.map((t) => t.value).join("、")}」。改成「Нет бренда」等于向 Ozon 声明这批货没有品牌，`
      + "平台不会再要求品牌授权文件。如果这个品牌你确实有授权，请点「取消」，并先把授权书/供货合同备好。",
      { confirmText: "确认改为「Нет бренда」", danger: true },
    );
    if (!ok) return toast("已取消，品牌属性保持不变", "info");
  }
  const values = { ...(state.draft.attributeValues || {}) };
  const ids = { ...(state.draft.attributeValueIds || {}) };
  const sources = { ...(state.draft.attributeSources || {}) };
  const unresolved = [];
  let filled = 0;
  for (const target of [...emptyTargets, ...realTargets]) {
    const attr = target.attr;
    // 本地字典（只留前 2000 条）优先，命中即用，省一次网络请求
    const picked = pickNoBrandFromDictionary(attr.dictionary);
    let value = picked?.value || "";
    let dictId = Number(picked?.id) || 0;
    if (!value) {
      // 本地没有就按官方接口反查全库（searchBrandDictionaryValue 会把命中项回写进 attr.dictionary）
      dictId = await searchBrandDictionaryValue(attr, "Нет бренда");
      if (dictId) {
        const hit = (attr.dictionary || []).find((item) => Number(item.id) === dictId);
        value = cleanText(hit?.value);
      }
    }
    // 字典里查不到「Нет бренда」时不要硬塞自由文本：Ozon 会判「请从列表中选择一个属性值」，
    // 反而制造一个新的上传失败，不如让用户到属性表手选
    if (!value) { unresolved.push(target.id); continue; }
    values[target.id] = value;
    if (dictId) ids[target.id] = dictId;
    sources[target.id] = "品牌合规";
    filled += 1;
  }
  if (filled) {
    state.draft = await saveDraft({
      id: state.draft.id,
      attributeValues: values,
      attributeValueIds: ids,
      attributeSources: sources,
    });
    renderAttributeDefs();
  }
  renderBrandGuard();
  if (unresolved.length) {
    if (!silent) toast(`品牌属性（ID ${unresolved.join("、")}）在 Ozon 字典里没找到「Нет бренда」，请到属性表手动选一个候选值`, "warn");
  } else if (filled && !silent) {
    toast(`已把 ${filled} 个品牌属性填成「无品牌」，上架后不会再被要求品牌补充文件`, "ok");
  }
  return filled;
}

/**
 * v1.9.64 品牌字段默认「无品牌」。
 * 属性表每次渲染后调用：只要有品牌属性还是空的，就自动填官方值「Нет бренда」。
 * 只在「空」的时候动手 —— 用户已经填了具体品牌（说明有授权）绝不去覆盖它。
 * 同一个草稿 + 同一批属性只尝试一次，失败（比如网络查不到字典）不反复重试，
 * 用户还可以点上传区的「一键填「无品牌」」手动再试。
 */
let brandDefaultKey = "";
async function applyBrandDefault() {
  if (!state.draft) return 0;
  const empty = brandAttributeState().filter((item) => !item.value);
  if (!empty.length) return 0;
  const key = `${state.draft.id}:${empty.map((item) => item.id).join(",")}`;
  if (brandDefaultKey === key) return 0;
  brandDefaultKey = key;
  try {
    return await fillNoBrandAttributes({ silent: true, onlyEmpty: true });
  } catch (error) {
    // 自动默认失败不该打断用户：品牌合规徽章会显示「还是空的」，手动按钮仍在
    return 0;
  }
}

/** 上传前自检：把硬伤和软提示分别列出来，不用等 Ozon 返回英文报错 */
async function runUploadCheck() {
  if (!state.draft) return toast("请先载入草稿", "error");
  const { collectImportDiagnostics, buildImportItems } = await loadOzonApi();
  const options = collectUploadOptions();
  const { problems, warnings } = collectImportDiagnostics(state.draft, options);
  // v1.9.50 把「这次到底会提交几条」先算出来：条目数必须等于选用的 SKU 数，
  // 数量对不上就在自检阶段暴露，而不是上传完才发现只上架了 1 个规格。
  const selectedCount = getSelectedSkus().length;
  let itemCount = 0;
  let countError = "";
  try {
    itemCount = buildImportItems(state.draft, options).length;
  } catch (error) {
    countError = error?.message || String(error);
  }
  if (countError) problems.unshift(countError);
  const rows = [];
  let index = 0;
  const countText = countError
    ? "无法生成上传条目"
    : `${itemCount} 条${selectedCount >= 2 ? `（选用 ${selectedCount} 个 SKU，一条一个规格）` : "（单规格）"}`;
  if (!problems.length && !warnings.length) {
    kv("#upload-result", [["自检", "全部通过，可以直接上传"], ["将上传条目", countText]]);
    $("#upload-errors-wrap").hidden = true;
    renderBrandGuard();
    await renderVariantAttrHint();
    toast("上传前自检通过", "ok");
    return true;
  }
  for (const text of problems) { index += 1; rows.push({ index, level: "必须修", text }); }
  for (const text of warnings) { index += 1; rows.push({ index, level: "建议", text }); }
  renderTable("#upload-errors-table", [
    { key: "index", label: "#" },
    { key: "level", label: "级别" },
    { key: "text", label: "说明" },
  ], rows);
  $("#upload-errors-wrap").hidden = false;
  kv("#upload-result", [
    ["自检", problems.length ? `${problems.length} 项必须修` : "无硬伤"],
    ["建议", warnings.length ? `${warnings.length} 项` : "无"],
    ["将上传条目", countText],
  ]);
  renderBrandGuard();
  await renderVariantAttrHint();
  toast(problems.length ? `有 ${problems.length} 项必须先解决` : "只有建议项，可以直接上传", problems.length ? "error" : "warn");
  return !problems.length;
}

/**
 * 轮询导入任务结果。Ozon 是异步导入：提交只回 task_id，真正的报错要到
 * /v1/product/import/info 里按 offer_id 逐条看，所以必须查一次才知道到底传上没有。
 */
async function pollImportResult(taskId) {
  if (!taskId) return;
  const rows = [];
  const allErrors = []; // v1.9.55 解析后的结构化报错（跨条目聚合去重用）
  for (let attempt = 0; attempt < 8; attempt += 1) {
    await new Promise((resolve) => setTimeout(resolve, 2500));
    let info = null;
    try {
      info = await call({ action: MESSAGE_ACTIONS.ozonImportInfo, taskId });
    } catch (error) {
      kv("#upload-result", [["状态", "已提交"], ["任务 ID", String(taskId)], ["结果查询", `失败：${error.message}`]]);
      return;
    }
    const items = info?.items || [];
    const status = String(info?.status || "");
    if (!items.length && status !== "imported" && status !== "failed" && attempt < 7) continue;
    for (const item of items) {
      // v1.9.55 报错先解析成结构化中文条目（同文案去重），再按条目聚合成一行短摘要；
      // 俄文原文不再整段糊进表格，完整明细放在下方「报错明细」区
      const parsed = classifyOzonImportErrors(item.errors || [], state.categoryAttributes);
      rows.push({
        offerId: item.offer_id || "",
        productId: item.product_id || "",
        status: item.status === "imported" || item.status === "success" ? "成功" : (item.status || "未知"),
        error: parsed.map((e) => `【${e.title}】${e.attrZh || e.attrName || ""}${(e.attrZh || e.attrName) ? "：" : ""}${e.advice}`).join("；"),
      });
      allErrors.push(...parsed);
    }
    break;
  }
  if (!rows.length) {
    kv("#upload-result", [["状态", "已提交"], ["任务 ID", String(taskId)], ["结果", "Ozon 还没返回结果，稍后点「查询已上架商品」确认"]]);
    return;
  }
  const failed = rows.filter((row) => row.status !== "成功");
  renderTable("#upload-errors-table", [
    { key: "offerId", label: "Offer ID" },
    { key: "productId", label: "Product ID" },
    { key: "status", label: "状态" },
    { key: "error", label: "问题与修改建议" },
  ], rows);
  $("#upload-errors-wrap").hidden = false;
  // 报错明细：按「标题」聚合计数，逐条给到属性名 + 中文结论 + 修改建议（俄文原文收进 title 悬浮）
  const detailWrap = $("#upload-error-detail-wrap");
  const detailBody = $("#upload-error-detail");
  if (detailWrap && detailBody) {
    const kinds = new Map();
    for (const e of allErrors) {
      const key = `${e.kind}|${e.attrName}`;
      if (!kinds.has(key)) kinds.set(key, { ...e, count: 0 });
      kinds.get(key).count += 1;
    }
    const list = [...kinds.values()];
    detailBody.innerHTML = list.length
      ? `<ul class="import-error-list">${list.map((e) => `<li class="err-${e.kind}"><strong>${e.title}</strong>${e.attrZh || e.attrName ? ` · ${e.attrZh || e.attrName}${e.attrZh && e.attrName && e.attrZh !== e.attrName ? `（${e.attrName}）` : ""}` : ""}${e.count > 1 ? ` ×${e.count} 条` : ""} —— ${e.advice}<span class="err-raw" title="${e.raw.replace(/"/g, "&quot;")}">原文：${e.raw.slice(0, 120)}</span></li>`).join("")}</ul>`
      : "";
    detailWrap.hidden = !list.length;
  }
  kv("#upload-result", [
    ["状态", failed.length ? `${failed.length} 条未成功` : "全部成功"],
    ["任务 ID", String(taskId)],
    ["成功 / 总数", `${rows.length - failed.length} / ${rows.length}`],
  ]);
  toast(failed.length ? `${failed.length} 条未成功，下方已把 Ozon 报错翻译成中文并给出改法` : "全部上传成功", failed.length ? "error" : "ok");
}

const CJK_PATTERN = /[\u4e00-\u9fa5]/;

/** Ozon 类目树只给 RU / EN，判断一下有没有中文名（决定匹配走中文还是俄语） */
function treeHasChinese(tree) {
  for (const node of (tree || []).slice(0, 30)) {
    if (CJK_PATTERN.test(String(node?.title || ""))) return true;
  }
  return false;
}

/** 载入持久化的中文类目缓存 */
async function loadCategoryZhCache() {
  try {
    const cached = await chrome.storage.local.get(STORAGE_KEYS.categoryZhCache);
    state.categoryZh = cached?.[STORAGE_KEYS.categoryZhCache] || {};
  } catch {
    state.categoryZh = {};
  }
}

async function persistCategoryZh() {
  try {
    await chrome.storage.local.set({ [STORAGE_KEYS.categoryZhCache]: state.categoryZh });
  } catch { /* 存不下就算了，下次重新翻 */ }
}

/**
 * 把 Ozon 原名批量翻成中文（带缓存，只翻没翻过的）。
 * to 传 "ru" 可用于把中文搜索词反查成俄语关键词。
 */
async function translateCategoryTexts(texts, to = "zh") {
  const list = (texts || []).map((item) => String(item || "").trim()).filter(Boolean);
  const unique = [...new Set(list)];
  const cache = to === "zh" ? state.categoryZh : state.zhKeyword;
  const missing = unique.filter((item) => !cache[item]);
  if (!missing.length) return list.map((item) => cache[item] || "");
  const data = await call({
    action: MESSAGE_ACTIONS.aiTranslateTexts,
    texts: missing,
    options: { to },
  });
  const translated = data?.translations || [];
  missing.forEach((item, index) => {
    if (translated[index]) cache[item] = translated[index];
  });
  await persistCategoryZh();
  return list.map((item) => cache[item] || "");
}

/** 类目树是俄/英文时，把当前渲染出来的名字补上中文（懒翻，一批最多 60 条） */
async function ensureTreeChinese() {
  const tree = state.categoryTree || [];
  if (!tree.length || treeHasChinese(tree)) return;
  const titles = (renderedCategoryTitles.length ? renderedCategoryTitles : tree.slice(0, 60).map((node) => cleanText(node.title)))
    .map((title) => cleanText(title))
    .filter(Boolean);
  const missing = [...new Set(titles.filter((title) => !state.categoryZh[title]))].slice(0, 60);
  if (!missing.length) return;
  categoryZhPasses += 1;
  try {
    await translateCategoryTexts(missing, "zh");
  } catch { /* 翻译失败不影响选类目 */ }
}

/** 俄语类目路径按「AI 给的俄语类目提示」打分：命中越长越可能是它；同时做领域消歧 */
function scoreCategoryLeafByHint(path, hint, topDomains = []) {
  const words = String(hint || "").toLowerCase().split(/[^\p{L}\p{N}]+/u).filter((word) => word.length >= 3);
  if (!words.length) return 0;
  const joined = (path || []).join(" ").toLowerCase();
  let score = 0;
  for (const word of words) if (joined.includes(word)) score += word.length;
  // 领域消歧：俄文类目名同样能命中领域词典（词典含俄文词）
  const leafDomains = domainsOfPath(path);
  if (topDomains.length) {
    const top = topDomains[0]?.domain;
    if (top && leafDomains.includes(top)) score += 10 + Math.min(8, topDomains[0]?.score || 0);
    else if (leafDomains.length) score *= 0.25;
  }
  return score;
}

/**
 * 懒加载本地内置的中文类目树（达瓦同款 bundle）。
 * 全中文、离线、带正确的 Ozon 数字 ID，彻底取代「向 Ozon API 拉俄/英文树 + AI 翻译」的旧流程，
 * 因此界面与匹配全程没有俄语，也不需要消耗 AI 额度。
 * 用动态 import 懒加载，避免面板一打开就解析 1MB 数据。
 */
let _localTreePromise = null;
function loadLocalCategoryTree() {
  if (_localTreePromise) return _localTreePromise;
  _localTreePromise = import("../../assets/ozon-category-tree.js")
    .then((mod) => {
      const bundle = mod.OZON_CATEGORY_TREE_BUNDLE || mod.default;
      const tree = (bundle && bundle.tree) || [];
      if (!Array.isArray(tree) || !tree.length) throw new Error("本地类目树为空");
      return tree;
    })
    .catch((err) => {
      console.warn("本地中文类目树加载失败，回退到 Ozon API：", err);
      return null;
    });
  return _localTreePromise;
}

/** 类目树（中文优先本地内置）。优先内存 → 本地中文树 → 本地缓存（旧路径）→ 后台接口兜底 */
async function ensureCategoryTree(force = false) {
  if (!force && state.categoryTree?.length) return state.categoryTree;
  // 1) 本地内置中文树：全中文、带 Ozon ID，无需 AI 翻译、无俄语
  const local = await loadLocalCategoryTree();
  if (local && local.length) {
    state.categoryTree = local;
    state.categoryTreeSource = "local";
    return state.categoryTree;
  }
  // 2) 旧缓存（历史 Ozon API 拉取的树，可能含俄语，仅兜底）
  if (!force) {
    const cached = await chrome.storage.local.get(STORAGE_KEYS.categoryCache);
    const cachedTree = cached?.[STORAGE_KEYS.categoryCache];
    if (Array.isArray(cachedTree) && cachedTree.length) {
      state.categoryTree = cachedTree;
      state.categoryTreeSource = "cache";
      return state.categoryTree;
    }
  }
  // 3) 实时 Ozon API 兜底（联网且本地树缺失时）
  const tree = await call({ action: MESSAGE_ACTIONS.ozonCategoryTree, payload: { language: "zh" } });
  state.categoryTree = tree || [];
  state.categoryTreeSource = "api";
  try { await chrome.storage.local.set({ [STORAGE_KEYS.categoryCache]: state.categoryTree }); } catch { /* 超大对象存不下就算了 */ }
  return state.categoryTree;
}

// —— v1.9.65 类目树加载状态提示：明确的「加载中 → 加载完成」切换，失败给出可操作原因 ——
const CATEGORY_TREE_SOURCE_LABEL = {
  local: "本地完整类目树（Ozon 官方 XLS 模板）",
  cache: "本地缓存（历史 Ozon API 拉取）",
  api: "Ozon API 实时拉取",
};

function categoryTreeSourceLabel() {
  return CATEGORY_TREE_SOURCE_LABEL[state.categoryTreeSource] || CATEGORY_TREE_SOURCE_LABEL.local;
}

/** 类目树加载状态条：#cat-tree-status 的 phase 取 idle / loading / ready / error */
function setCategoryTreeStatus(phase, text) {
  const node = $("#cat-tree-status");
  if (!node) return;
  const cls = phase === "loading" ? "hint warn-text"
    : phase === "ready" ? "hint ok-text"
      : phase === "error" ? "hint danger-text"
        : "hint";
  node.className = cls;
  node.textContent = text;
}

/** 统计类目树规模：顶层域 / 类目 / 末级类型（可上传 / 待同步） */
function countCategoryTree(tree) {
  let domains = 0, categories = 0, types = 0, pending = 0;
  for (const domain of tree || []) {
    domains += 1;
    for (const category of domain.children || []) {
      categories += 1;
      for (const leaf of category.children || []) {
        types += 1;
        if (!Number(leaf?.type_id)) pending += 1;
      }
    }
  }
  return { domains, categories, types, pending, usable: types - pending };
}

function categoryTreeSummary(stats) {
  if (!stats) return "规模未知";
  const tail = stats.pending ? `，可上传 ${stats.usable}，待同步 ${stats.pending}` : "，全部可上传";
  return `${stats.domains} 个顶层域 / ${stats.categories} 个类目 / ${stats.types} 个末级类型${tail}`;
}

/**
 * 带状态提示地加载类目树：先显示「加载中…」，完成后切成「加载完成（规模 · 来源 · 耗时）」。
 * 失败时不抛裸错误，而是把可操作的原因写到状态条上。
 */
async function loadCategoryTreeWithStatus({ force = false, label = "类目树" } = {}) {
  const startedAt = Date.now();
  setCategoryTreeStatus("loading", `${label}加载中…（正在解析完整类目树，请稍候）`);
  try {
    const tree = await ensureCategoryTree(force);
    if (!tree || !tree.length) {
      setCategoryTreeStatus("error", `${label}加载失败：没有读到任何类目。请检查网络后点「拉取类目树」重试。`);
      return tree || [];
    }
    const stats = countCategoryTree(tree);
    state.categoryTreeStats = stats;
    setCategoryTreeStatus("ready", `${label}加载完成：${categoryTreeSummary(stats)} · 来源：${categoryTreeSourceLabel()} · 耗时 ${Date.now() - startedAt}ms`);
    return tree;
  } catch (error) {
    setCategoryTreeStatus("error", `${label}加载失败：${error?.message || "未知错误"}。点「拉取类目树」可重试。`);
    throw error;
  }
}

/** 从树里找到指定 type_id 的叶子，把沿途的类目层级全部标记为展开 */
function expandToType(nodes, typeId, trail) {
  for (const node of nodes || []) {
    const title = cleanText(node.title || node.category_name || node.type_name || node.name || "");
    const categoryId = Number(node.description_category_id || node.category_id) || 0;
    const nodeTypeId = Number(node.type_id) || 0;
    const nodeKey = `${categoryId}>${nodeTypeId}>${title}`;
    if (nodeTypeId && nodeTypeId === typeId) {
      for (const key of trail) state.categoryExpanded.add(key);
      return true;
    }
    if (node.children?.length && expandToType(node.children, typeId, [...trail, nodeKey])) return true;
  }
  return false;
}

/**
 * 把类目树拍平成叶子（类型）节点列表，每个带从根到叶的中文路径。
 * v1.9.65：顶层域节点只有 category_name（没有 title），过去这里只读 title 会把域丢掉，
 * 于是 AI 看到的路径是「慢炖锅、面包机、空气烤架 / 空气炸锅」而界面 pathText 是
 * 「家用电器 / 慢炖锅、面包机、空气烤架 / 空气炸锅」——两边对不上。现在统一成完整三级路径，
 * 与 getCategoryPathText / expandToType 的口径一致，AI 拿到的是 Ozon 真实类目层级。
 */
function flattenCategoryLeaves(nodes, ancestors = [], out = []) {
  for (const node of nodes || []) {
    const path = [...ancestors, String(node.title || node.category_name || node.type_name || "").trim()].filter(Boolean);
    if (Number(node.type_id) > 0 || !(node.children || []).length) {
      out.push({ node, path });
    } else {
      flattenCategoryLeaves(node.children, path, out);
    }
  }
  return out;
}

/**
 * v1.9.65：Ozon 官方类目树的 26 个顶层域。
 * 它们出现在叶子路径的第一段，但属于粗粒度信号（「用品 / 儿童 / 家用」这类通用词），
 * 打分时只给最低权重、且不参与 2-gram 命中统计，避免压过真正的类目名与类型名。
 */
const CATEGORY_TREE_TOP_DOMAINS = new Set([
  "OZON食品", "乐器", "书籍", "住宅与花园", "儿童用品", "农场", "古董和收藏品",
  "吸烟产品和配件", "宠物用品", "家具", "家用电器", "小百货和配饰", "建筑和装修",
  "成人用品", "文具", "日化", "服装", "汽车用品", "爱好与创作", "电子产品",
  "电影、音乐、视频游戏、软件", "美容与卫生", "药店", "运动与休闲", "鞋类", "食品",
]);
const GENERIC_PATH_SEGMENT_RE = /^(儿童|家居|家具|家用|детск|дом|товар|разное)$/i;

/**
 * 类目匹配打分：中文标题与商品标题的公共片段 + 领域消歧。
 * 借鉴「达瓦」类目推荐器的两阶段思路：先用关键词词典判断商品落在哪个领域，
 * 再在领域内加权、跨领域减权，避免同根多义词（货架 vs 儿童游戏架）被误判。
 *
 * @param {string[]} path     类目路径（从根到末级类型，v1.9.65 起含顶层域）
 * @param {string}   text     商品可匹配文本（标题+描述+SKU+属性 已拼接）
 * @param {object}   product  原始草稿（用于领域推断）
 * @param {string[]} topDomains 商品推断出的领域名（按命中数降序），为空表示无法判断
 */
function scoreCategoryLeaf(path, text, product = {}, topDomains = []) {
  const title = String(text || "");
  if (!title) return 0;

  // v1.9.77 标题锚定：本地兜底只能作为「AI 不可用时的粗筛」，绝不能把整坨拼接文本
  // （描述 / SKU / 属性 / 1688 相关推荐轮播）里的杂词当成商品身份。
  // 要求末级类型名与**原始标题**有 ≥2 字交集，否则直接判 0——
  // 实测：空气炸锅商品若推荐位混进「钢琴 / 手风琴」，旧实现会让 8 个键盘乐器叶子
  // 靠类目段「键盘乐器」蹭分进候选（类型名本身在标题里根本没出现）。
  const rawTitle = String(product?.title || "").trim();
  const leafName = String(path[path.length - 1] || "").trim();
  if (rawTitle && leafName) {
    const lt = rawTitle.toLowerCase();
    const ln = leafName.toLowerCase();
    let anchored = ln.length >= 2 && lt.includes(ln);
    if (!anchored) {
      for (let i = 0; i + 2 <= ln.length; i++) {
        const gram = ln.slice(i, i + 2);
        if (/[\u4e00-\u9fa5]{2}/.test(gram) && lt.includes(gram)) { anchored = true; break; }
      }
    }
    if (!anchored) return 0;
  }

  let score = 0;
  for (const seg of path) {
    if (seg.length >= 2 && title.includes(seg)) {
      // v1.9.65：Ozon 官方 26 个顶层域（家用电器 / 住宅与花园 …）是粗粒度信号，只给 1 分，
      // 否则「住宅与花园」这种长域名一旦命中就会压过真正的类目名与类型名
      const generic = GENERIC_PATH_SEGMENT_RE.test(seg) || CATEGORY_TREE_TOP_DOMAINS.has(seg);
      score += generic ? 1 : seg.length * 3;
    }
  }
  // 2-gram 命中同理：顶层域已在上面按 1 分计入、并参与 domainsOfPath 消歧，
  // 再算进来只会把「用品 / 儿童 / 家用」这类通用词放大成噪声，所以剔掉
  const leafPath = path.filter((seg) => !CATEGORY_TREE_TOP_DOMAINS.has(seg)).join("").toLowerCase();
  let hits = 0;
  for (let i = 0; i + 2 <= title.length; i++) {
    const gram = title.slice(i, i + 2);
    if (/[\u4e00-\u9fa5]{2}/.test(gram) && leafPath.includes(gram.toLowerCase())) hits++;
  }

  // —— 领域消歧（达瓦思路核心）——
  const leafDomains = domainsOfPath(path);
  if (topDomains.length) {
    const top = topDomains[0]?.domain;
    const second = topDomains[1]?.domain;
    const leafTop = top && leafDomains.includes(top);
    const leafSecond = second && leafDomains.includes(second);
    if (leafTop) {
      // 叶子命中商品最可能的领域 → 显著加权（领域命中词越多权重越大）
      score += 10 + Math.min(8, topDomains[0]?.score || 0);
    } else if (leafSecond) {
      score += 4; // 命中第二可能领域，小幅加权
    } else if (leafDomains.length) {
      // 叶子命中了「其他领域」，但商品已有明确领域 → 减权，避免同根词误判
      score *= 0.25;
    }
    // 叶子领域为空（如纯通用词类目）→ 不调整，保留路径重合分
  }
  return Math.round(score + hits);
}

/**
 * 把本地打分的原始分归一化到 0-100% 的「匹配度」。
 * 用前三名里的最高分做分母，这样用户看到的是相对置信度，不是绝对分数。
 */
function normalizeMatchScore(score, topScore) {
  if (!topScore) return 0;
  return Math.min(100, Math.max(0, Math.round((score / topScore) * 100)));
}

/**
 * 采集后自动匹配 Ozon 类目（中文树）。
 * 返回匹配到的中文路径（没匹配到返回 ""）。
 * 关键变化：不再静默选一个，而是把 Top-N 候选渲染成卡片，让用户点选。
 */
/**
 * 采集后自动匹配 Ozon 类目（中文树）。
 * 返回匹配到的中文路径（没匹配到返回 ""）。
 *
 * v1.9.66 起改成「AI 在完整类目树范围内选」：
 *   ① 取 2~3 张产品外观图 → 压成 JPEG data URL（取不到就静默降级为纯文字）；
 *   ② 后台把 Ozon 官方完整类目树（26 域 / 542 类目 / 8600 类型，全部带数字 ID）写进提示词，
 *      AI 同时依据【产品标题名称】与【产品外观图片】两路信息，在树内选域 / 类目 / 类型；
 *   ③ AI 返回的是树里的行号，后台回查到真实节点才作数，面板再校验一遍 ID；
 *   ④ AI 不可用或选不出来时，回退到原来的本地打分候选——绝不静默选一个错的。
 * 候选始终渲染成卡片让用户点选确认，确认后才加载该类目属性。
 */
async function autoMatchCategory(draft) {
  if (!draft) return "";
  try {
    // v1.9.65：带「加载中 → 加载完成」状态提示，并把完整类目树（官方模板 26 域 / 542 类目 / 8600 类型）喂给匹配
    const tree = await loadCategoryTreeWithStatus({ label: "AI 匹配用的类目树" });
    if (!tree.length) return "";
    const allLeaves = flattenCategoryLeaves(tree);
    // 只有带 type_id 的末级「类型」才能上传；无 ID 的（正常为 0 个）不进候选，避免匹配到一个传不上去的类型
    const leaves = allLeaves.filter((item) => Number(item.node?.type_id) > 0);
    if (!leaves.length) return "";
    // v1.9.70：类目匹配只能依据**本次采集的原始商品数据**。
    // 旧实现把 draft.ru.title / categoryHint / description 也拼进来，这些字段可能是上一轮
    // 错误类目生成的旧 AI 内容，会把本次真实标题和图片带偏，形成「越匹配越错」的反馈环。
    // 俄文文案只用于展示/上架，不是商品身份依据，严禁参与类目候选打分。
    const text = [
      draft.title,
      draft.description,
      ...(draft.skus || []).flatMap((sku) => [sku.label, ...Object.values(sku.specs || {})]),
      ...(draft.attributes || []).map((a) => `${a.name || ""}${a.value || ""}`),
    ].filter(Boolean).join(" ");
    const chinese = treeHasChinese(tree);
    let hint = cleanText(draft.ru?.categoryHint) || cleanText(draft.ru?.title)
      || (draft.ru?.keywords || []).slice(0, 8).join(" ");
    if (!chinese && !hint && cleanText(draft.title)) {
      try {
        const [ru] = await translateCategoryTexts([draft.title], "ru");
        hint = cleanText(ru);
      } catch { /* 翻不出来就走下面的候选打分 */ }
    }

    // ================= v1.9.66 双通道：产品标题 + 产品外观图片 =================
    setCategoryTreeStatus("loading", "正在读取产品外观图片…");
    const images = await collectCategoryMatchImages(draft);
    let aiMatch = null;
    let aiError = "";
    try {
      setCategoryTreeStatus("loading", `AI 正在按「产品标题 + 外观图片」在完整类目树里匹配…（${images.length ? `已取到 ${images.length} 张外观图` : "未取到外观图，仅按标题文字"}）`);
      aiMatch = await call({
        action: MESSAGE_ACTIONS.aiMatchCategoryTree,
        product: draft,
        imageDataUrls: images,
      });
    } catch (error) {
      aiError = error?.message || "接口不可用";
    }

    // ---- 本地打分：既是 AI 结果之外的备选，也是 AI 不可用时的兜底 ----
    // 领域推断（达瓦两阶段匹配第一阶段）：先判断商品落在哪个领域，用于后续消歧
    const topDomains = detectProductDomains(draft).map((d) => ({ domain: d.domain, score: d.score }));
    const scored = [];
    for (const leaf of leaves) {
      const score = chinese
        ? scoreCategoryLeaf(leaf.path, text, draft, topDomains)
        : scoreCategoryLeafByHint(leaf.path, `${hint} ${draft.title || ""}`, topDomains);
      if (score > 0) scored.push({ leaf, score });
    }
    const threshold = 4;
    scored.sort((a, b) => b.score - a.score);
    const topScore = scored[0]?.score || 0;

    const candidates = [];
    const seenTypes = new Set();
    // 第一位：AI 在类目树里选出来的结果（树内真实节点，ID 已由后台回查校验）
    if (aiMatch?.typeId && aiMatch?.categoryId) {
      const typeId = Number(aiMatch.typeId);
      seenTypes.add(typeId);
      const aiPath = Array.isArray(aiMatch.path) && aiMatch.path.length
        ? aiMatch.path
        : [aiMatch.domain, aiMatch.category, aiMatch.type].filter(Boolean);
      candidates.push({
        node: aiMatch.node || { description_category_id: aiMatch.categoryId, category_id: aiMatch.categoryId, type_id: typeId },
        path: aiPath,
        score: Number.MAX_SAFE_INTEGER,
        confidence: Math.max(0, Math.min(100, Math.round((Number(aiMatch.confidence) || 0) * 100))),
        aiSelected: true,
        aiReason: cleanText(aiMatch.reason),
        imageGuided: images.length > 0 && aiMatch.imageUsed !== false,
        fromTree: true,
      });
    }
    // 其余：本地打分备选，供用户改选（同时覆盖 AI 失败的情况）
    for (const item of scored) {
      if (candidates.length >= 8) break; // 候选卡片最多 8 个，别把界面堆满
      if (item.score < threshold) break;
      const typeId = Number(item.leaf.node?.type_id) || 0;
      if (!typeId || seenTypes.has(typeId)) continue;
      seenTypes.add(typeId);
      candidates.push({
        node: item.leaf.node,
        path: item.leaf.path,
        score: item.score,
        // 本地兜底只有标题/原始文字，没有视觉证据，最高只能标为 55%，
        // 绝不能像旧版一样在相对归一化后显示「本地匹配度 100%」，误导用户以为已经按图片确认。
        confidence: Math.min(55, normalizeMatchScore(item.score, topScore)),
        textOnlyFallback: true,
      });
    }

    const summary = categoryTreeSummary(state.categoryTreeStats || countCategoryTree(tree));
    if (!candidates.length) {
      await renderCategoryCandidates([]);
      setCategoryTreeStatus("ready", `类目树加载完成：${summary} · 本次 AI 匹配没有找到足够贴近的候选，请手动展开类目树选择 · 来源：${categoryTreeSourceLabel()}`);
      return "";
    }

    state.categoryCandidates = candidates;
    await renderCategoryCandidates(candidates);

    const best = candidates[0];
    if (best.aiSelected) {
      if (!$("#ai-pipe-cat-confirm")?.checked && best.confidence >= 70) {
        // 关掉人工确认开关时才自动落选，否则一律等用户点卡片
        await pickCategoryCandidate(best);
        return best.path.join(" / ");
      }
      if (best.confidence < 70) {
        toast(`AI 类目置信度较低（${best.confidence}%），请人工确认：${best.aiReason || "商品类型与候选类目不够确定"}`, "warn");
      } else {
        toast(`AI 在类目树里推荐「${best.path.join(" / ")}」，请在下方候选卡片点选确认，确认后自动加载该类目属性`, "warn");
      }
    } else if (aiError) {
      toast(
        images.length
          ? `图片已取到 ${images.length} 张，但视觉类目模型未返回可用结果（${aiError}）。当前仅保留标题文字兜底，未按图片自动确认；请配置支持图片输入的视觉模型后重试。`
          : `AI 类目匹配失败：${aiError}，当前仅保留标题文字兜底，请人工确认`,
        "warn",
      );
    } else {
      // AI 正常答了但返回 -1（认为类目树里确实没有合适的），或后台判定失败
      toast(
        images.length
          ? `已取到 ${images.length} 张产品图，但 AI 没有在完整类目树里给出可用结果；下面仅显示标题文字兜底候选，请勿把“本地匹配度”当成图片确认结果。`
          : "AI 认为类目树里没有足够贴切的类目，已保留标题文字兜底候选，请人工确认",
        "warn",
      );
    }
    if (best.aiSelected && images.length && aiMatch?.imageUsed === false) {
      // 带图请求被服务端拒了（多数是当前模型不支持图片），后台已自动退回纯文字
      toast("当前 AI 模型不支持图片输入，本次只按产品标题匹配。想用「标题 + 外观图片」双通道，请在设置里换成支持视觉的模型。", "warn");
    }

    const channel = best.aiSelected
      ? `AI 在完整类目树内选类目（依据：产品标题${best.imageGuided ? ` + ${images.length} 张外观图片` : images.length ? "，当前模型不支持图片已退回纯文字" : "，本次未取到外观图"}）`
      : `标题文字兜底（AI 未给出可用结果${aiError ? `：${aiError}` : ""}${images.length ? "，图片未参与自动确认" : ""}）`;
    setCategoryTreeStatus("ready", `类目树加载完成：${summary} · ${channel} · 已从 ${leaves.length} 个可上传类型里筛出 ${candidates.length} 个候选 · 来源：${categoryTreeSourceLabel()}`);
    return candidates[0]?.path?.join(" / ") || "";
  } catch (error) {
    toast(`类目识别失败：${error?.message || "类目树或本地匹配不可用"}，请手动展开真实末级类目`, "error");
    return "";
  }
}

/**
 * 用户从候选卡片里点选一个类目：写入草稿、展开分支、拉属性。
 */
async function pickCategoryCandidate(candidate) {
  const categoryId = Number(candidate.node.description_category_id ?? candidate.node.category_id) || 0;
  const typeId = Number(candidate.node.type_id) || 0;
  if (!categoryId || !typeId) return;
  const chinese = treeHasChinese(state.categoryTree);
  let pathText = candidate.path.join(" / ");
  if (!chinese) {
    const zhSegments = await translateCategoryTexts(candidate.path, "zh");
    const zhPath = zhSegments.filter(Boolean).join(" / ");
    if (zhPath) pathText = zhPath;
    for (let i = 0; i < candidate.path.length; i += 1) {
      if (zhSegments[i]) state.categoryZh[candidate.path[i]] = zhSegments[i];
    }
    await persistCategoryZh();
  }
  state.draft = await saveDraft({
    id: state.draft.id,
    ozonCategory: { descriptionCategoryId: categoryId, typeId, pathText },
  });
  state.categoryNode = { ...candidate.node, category_id: categoryId, type_id: typeId };
  if (state.categoryTree?.length) expandToType(state.categoryTree, typeId, []);
  // 选好后清空候选卡片，避免重复点击
  state.categoryCandidates = [];
  await renderCategoryCandidates([]);
  renderCategoryTree();
  renderCategoryPick();
  loadCategoryAttributes(state.categoryNode).then(() => afterCategoryConfirmed()).catch(() => {});
  toast(`已选：${pathText}`, "ok");
}

let renderedCategoryTitles = [];   // 本次渲染实际出现在树里的节点名（翻译只翻这些，不翻整棵树）
let categoryZhPasses = 0;          // 防止「翻译→重绘→再翻译」无限循环

function renderCategoryTree({ translate = true } = {}) {
  const wrap = $("#cat-tree");
  wrap.innerHTML = "";
  renderedCategoryTitles = [];
  const keyword = cleanText($("#cat-search").value).toLowerCase();
  for (const node of state.categoryTree) {
    wrap.appendChild(renderCategoryNode(node, keyword, 0, 0, []));
  }
  renderCategoryPick();
  // 俄/英文树：把当前展开层级的名字补成中文；只有真的翻出新名字才重绘，避免无限循环
  if (translate) {
    const before = Object.keys(state.categoryZh).length;
    ensureTreeChinese().then(() => {
      if (Object.keys(state.categoryZh).length > before && categoryZhPasses <= 8) {
        renderCategoryTree({ translate: true });
      }
    }).catch(() => {});
  }
}

// Ozon /v1/description-category/tree 结构：一级/二级是「类目」(description_category_id)，
// 三级叶子是「类型」(type_id + type_name)。只有选了类型才有 type_id，
// 漏掉 type_name 会让最后一层渲染成空白，用户根本点不到 → 上传时 type_id=0 被 Ozon 拒绝。
function renderCategoryNode(node, keyword, depth = 0, parentCategoryId = 0, ancestors = []) {
  const title = cleanText(node.title || node.category_name || node.type_name || node.name || "");
  const categoryId = Number(node.description_category_id || node.category_id) || parentCategoryId || 0;
  const typeId = Number(node.type_id) || 0;
  const zhTitle = state.categoryZh[title] || "";
  const ruKeyword = CJK_PATTERN.test(keyword) ? (state.zhKeyword[cleanText($("#cat-search").value)] || "") : "";
  const haystack = `${title} ${zhTitle}`.toLowerCase();
  const matches = !keyword || haystack.includes(keyword) || (ruKeyword && haystack.includes(ruKeyword.toLowerCase()));
  // 从根到当前节点的中文路径，用于「已选：女装 / 连衣裙 / 夏季」这样的中文回显
  const path = [...ancestors, title].filter(Boolean);
  const nodeKey = `${categoryId}>${typeId}>${title}`;
  const hasChildren = Boolean(node.children?.length);
  // 搜索时全展开；平时按需展开，避免一次渲染上万条俄文节点
  const expanded = Boolean(keyword) || state.categoryExpanded.has(nodeKey);
  const container = el("div", {});
  if (matches && title) {
    renderedCategoryTitles.push(title);
    const picked = (state.categoryNode && (
      (typeId && Number(state.categoryNode.type_id) === typeId)
      || (!typeId && Number(state.categoryNode.category_id) === categoryId && !Number(state.categoryNode.type_id))
    )) || (state.pendingCategoryNode && typeId && Number(state.pendingCategoryNode.type_id) === typeId);
    const row = el("div", {
      class: `tree-item${picked ? " selected" : ""}${typeId ? " is-type" : ""}`,
      title: typeId ? `类型 ID ${typeId}` : `类目 ${categoryId}（点击展开子级，继续选择「类型」）`,
      onclick: async () => {
        // 类目层级（没有 type_id）：点行就是展开/收起，展开到底层「类型」再点选
        if (hasChildren && !typeId) {
          if (state.categoryExpanded.has(nodeKey)) state.categoryExpanded.delete(nodeKey);
          else state.categoryExpanded.add(nodeKey);
          renderCategoryTree();
          return;
        }
        if (!typeId) {
          toast(node.children?.length
            ? "这是类目层级，请继续展开到最后一层「类型」再选"
            : "该节点没有 type_id，无法作为上传类型，请换一个叶子节点", "error");
          return;
        }
        // 叶子「类型」节点：先进入待确认状态，用户点「确认选择」才写入草稿
        state.pendingCategoryNode = { ...node, category_id: categoryId, type_id: typeId, path };
        renderCategoryTree();
        renderCategoryConfirmBar();
      },
    });
    // 文字（含中文名）与展开箭头分开渲染，箭头点击只展开/收起
    row.textContent = "";
    const rowText = `${"— ".repeat(depth)}${title}${zhTitle ? `（${zhTitle}）` : ""}${hasChildren ? ` (${node.children.length})` : typeId ? ` · 类型 ${typeId}` : ""}`;
    if (hasChildren && !keyword) {
      row.appendChild(el("span", {
        class: "tree-caret",
        text: expanded ? "▾ " : "▸ ",
        onclick: (event) => {
          event.stopPropagation();
          if (state.categoryExpanded.has(nodeKey)) state.categoryExpanded.delete(nodeKey);
          else state.categoryExpanded.add(nodeKey);
          renderCategoryTree();
        },
      }));
    }
    row.appendChild(el("span", { text: rowText }));
    container.appendChild(row);
  }
  if (hasChildren && expanded) {
    const children = el("div", { class: "tree-children" });
    for (const child of node.children) children.appendChild(renderCategoryNode(child, keyword, depth + 1, categoryId, path));
    container.appendChild(children);
  }
  return container;
}

/** 渲染 AI 类目匹配候选卡片。Ozon 类目树只有 RU/EN，所以卡片必须先批量翻译成中文再显示。 */
async function renderCategoryCandidates(candidates) {
  const wrap = $("#cat-candidates");
  if (!wrap) return;
  wrap.innerHTML = "";
  if (!candidates.length) {
    wrap.hidden = true;
    return;
  }
  // 把卡片涉及的所有俄文节点名一次性翻译并缓存
  const titles = [...new Set(candidates.flatMap((c) => c.path))].filter((title) => !state.categoryZh[title]);
  if (titles.length) {
    try {
      const translated = await translateCategoryTexts(titles, "zh");
      titles.forEach((title, index) => {
        if (translated[index]) state.categoryZh[title] = translated[index];
      });
      await persistCategoryZh();
    } catch { /* 翻译失败仍用原文显示，不阻塞 */ }
  }

  wrap.hidden = false;
  // 显示候选卡片时，说明用户在主动选类目，清空之前的待确认状态（避免树里的高亮和卡片打架）
  state.pendingCategoryNode = null;
  renderCategoryConfirmBar();
  wrap.appendChild(el("div", { class: "cat-candidates-header" }, [
    el("strong", { text: "AI 推荐类目" }),
    el("span", { class: "muted", text: `（${candidates.length} 个候选，点卡片即可确认）` }),
  ]));
  const grid = el("div", { class: "cat-candidates-grid" });
  for (let index = 0; index < candidates.length; index += 1) {
    const c = candidates[index];
    const isAiPick = Boolean(c.aiSelected);
    const zhPath = c.path.map((title) => state.categoryZh[title] || title);
    const displayTitle = zhPath[zhPath.length - 1] || "未知类目";
    const displayPath = zhPath.join(" / ");
    const card = el("div", {
      class: `cat-candidate-card${isAiPick ? " is-ai-pick" : ""}`,
      title: "点击确认选择这个类目",
      onclick: () => pickCategoryCandidate(c),
    }, [
      el("div", { class: "cat-candidate-top" }, [
        el("span", { class: "cat-candidate-rank", text: String(index + 1) }),
        el("span", { class: "cat-candidate-title", text: displayTitle }),
        el("span", { class: "cat-candidate-score", text: `${c.aiSelected ? `AI 置信度 ${c.confidence}%` : `标题文字兜底 ${c.confidence}%`}` }),
      ]),
      el("div", { class: "cat-candidate-path", text: displayPath }),
      c.aiReason ? el("div", { class: "cat-candidate-reason", text: `${c.imageGuided ? "（已结合产品外观图片）" : ""}理由：${c.aiReason}` }) : null,
    ]);
    grid.appendChild(card);
  }
  wrap.appendChild(grid);
}

/** 类目树点选叶子后显示的确认条 */
function renderCategoryConfirmBar() {
  const bar = $("#cat-confirm-bar");
  const text = $("#cat-pending-text");
  if (!bar || !text) return;
  const pending = state.pendingCategoryNode;
  if (!pending || !pending.type_id) {
    bar.hidden = true;
    return;
  }
  const zhPath = pending.path.map((title) => state.categoryZh[title] || title).join(" / ");
  text.textContent = `待确认：${zhPath}（类目 ID ${pending.category_id} · 类型 ID ${pending.type_id}）`;
  bar.hidden = false;
}

/** 确认类目选择：写入草稿、清空候选与待确认状态、加载属性 */
async function confirmCategorySelection() {
  const pending = state.pendingCategoryNode;
  if (!pending || !pending.type_id) return;
  const { category_id, type_id, path } = pending;
  const zhPath = path.map((title) => state.categoryZh[title] || title).join(" / ");
  if (state.draft) {
    state.draft = await saveDraft({
      id: state.draft.id,
      ozonCategory: { descriptionCategoryId: category_id, typeId: type_id, pathText: zhPath },
    });
  }
  state.categoryNode = { ...pending };
  state.pendingCategoryNode = null;
  state.categoryCandidates = [];
  if (state.categoryTree?.length) expandToType(state.categoryTree, type_id, []);
  renderCategoryConfirmBar();
  await renderCategoryCandidates([]);
  renderCategoryTree();
  renderCategoryPick();
  loadCategoryAttributes({ category_id, type_id }).then(() => afterCategoryConfirmed()).catch(() => {});
  toast(`已确认类目：${zhPath}`, "ok");
}

// 把「当前选了什么类目/类型」明确写出来，避免用户以为选了其实没选到类型
function renderCategoryPick() {
  const node = $("#cat-picked");
  if (!node) return;
  const category = state.draft?.ozonCategory || {};
  const categoryId = Number(category.descriptionCategoryId) || 0;
  const typeId = Number(category.typeId) || 0;
  if (!categoryId) {
    node.className = "hint";
    node.textContent = state.pendingCategoryNode
      ? "已选好类目，请点上方「确认选择这个类目」按钮确认。"
      : "尚未选择类目类型。请点「拉取类目树」后逐层展开到最后一层「类型」并点选。";
    return;
  }
  if (!typeId) {
    node.className = "hint danger-text";
    node.textContent = `已选类目 ${categoryId}，但还没有选到「类型」（type_id = 0）→ 上传会被 Ozon 拒绝。请继续展开选择最后一层的类型。`;
    return;
  }
  node.className = "hint ok-text";
  const pathText = cleanText(category.pathText);
  node.textContent = `已选：${pathText ? `${pathText}（` : ""}类目 ID ${categoryId} · 类型 ID ${typeId}${pathText ? "）" : ""}（可上传）`;
  // 如果校验发现草稿类目与本地中文树不一致，追加醒目提示并引导重新选择
  if (state.draftCategoryStale?.reason) {
    const warn = document.createElement("span");
    warn.className = "danger-text";
    warn.textContent = ` 【${state.draftCategoryStale.reason}】`;
    node.appendChild(warn);
    const btn = document.createElement("button");
    btn.textContent = "重新选择类目";
    btn.style.marginLeft = "8px";
    btn.onclick = async () => {
      state.draftCategoryStale = null;
      state.draft = await saveDraft({ id: state.draft.id, ozonCategory: null });
      state.categoryNode = null;
      state.categoryAttributes = [];
      renderCategoryPick();
      renderAttributeDefs();
      renderCategoryTree();
    };
    node.appendChild(btn);
  }
}

/** 在本地的中文类目树里按 type_id 查找叶子节点 */
function findLeafByTypeId(nodes, typeId) {
  const target = Number(typeId) || 0;
  if (!target) return null;
  for (const node of nodes || []) {
    if (Number(node.type_id) === target) return node;
    if (node.children?.length) {
      const found = findLeafByTypeId(node.children, target);
      if (found) return found;
    }
  }
  return null;
}

/** 把草稿里旧的 ozonCategory 与本地中文树对齐：
 * - 如果 type_id 在树里能找到，但 descriptionCategoryId/pathText 不一致，自动修正为树的值。
 * - 如果 type_id 在树里找不到，说明该类目已被 Ozon 下线或 ID 变动，必须重新选择。
 * 返回 { ok, updated, leaf, reason }。
 */
async function syncDraftCategoryToTree(draft) {
  const category = draft?.ozonCategory || {};
  const typeId = Number(category.typeId) || 0;
  if (!typeId) return { ok: true, updated: false, leaf: null, reason: "" };
  try {
    // 已加载过就直接复用；首次加载（如刚打开面板/载入草稿）才走带状态提示的加载
    const tree = state.categoryTree?.length
      ? await ensureCategoryTree()
      : await loadCategoryTreeWithStatus({ label: "类目树" });
    if (!tree?.length) return { ok: true, updated: false, leaf: null, reason: "本地类目树尚未加载，无法校验" };
    const leaf = findLeafByTypeId(tree, typeId);
    if (!leaf) {
      return {
        ok: false,
        updated: false,
        leaf: null,
        reason: `草稿里的类型 ID ${typeId} 在本地中文类目树中找不到，可能是旧版本遗留或 Ozon 已调整类目。请重新选择类目。`,
      };
    }
    const expectedCatId = Number(leaf.description_category_id) || 0;
    const currentCatId = Number(category.descriptionCategoryId || category.description_category_id || category.category_id) || 0;
    const expectedPath = getCategoryPathText(tree, typeId) || leaf.title;
    const currentPath = cleanText(category.pathText);
    if (currentCatId !== expectedCatId || !currentPath || currentPath !== expectedPath) {
      const updated = {
        ...draft,
        ozonCategory: {
          descriptionCategoryId: expectedCatId,
          typeId,
          pathText: expectedPath,
        },
      };
      return {
        ok: true,
        updated: true,
        leaf,
        reason: `已自动修正类目信息：${expectedPath}（类目 ID ${expectedCatId} · 类型 ID ${typeId}）。旧记录中的类目 ID/路径与本地中文树不一致。`,
      };
    }
    return { ok: true, updated: false, leaf, reason: "" };
  } catch (error) {
    return { ok: true, updated: false, leaf: null, reason: `校验类目时出错：${error?.message || error}` };
  }
}

/**
 * 常见 Ozon 属性名/枚举值俄→中对照表（优先于 AI 翻译，减少额度并保证稳定）。
 * 键是 Ozon 返回的俄文原名（去首尾空格），值是中文显示名。
 *
 * v1.9.53 全表按「卖家后台类目属性」的中文口径统一，规则如下（后续新增词条请照此执行）：
 *   1. 单位一律用标准符号写进半角/全角括号：重量（kg）、高度（cm）、功率（W）、电压（V）、容量（L）、带包装重量（g）。
 *      不带单位后缀的属性名（вес / высота …）只写名词，不补单位。
 *   2. 适用对象系列统一为「适用 + 对象」：适用性别、适用年龄、适用季节、适用场景（含「商品/礼品适用场景」）。
 *      其中场景＝使用场景（назначение），不再用「用途」这种口语说法。
 *   3. 穿戴类尺码概念统一：物体长宽高＝尺寸，服装＝尺码（本项目暂无对应 Ozon 键），鞋＝鞋码。
 *   4. 等级系列统一用「级」后缀：入门级 / 进阶级 / 通用级 / 专业级 / 专家级；款式系列统一用「款」后缀。
 *   5. 属性名不带括号补充说明，不写冗余修饰（如「XX的XX」「XX参数」）；同一取值在任何类目下译文一致。
 *   6. 品牌名、专有名词、型号、颜色通名中的等形式标签、单位符号与代码占位符（XS/S/M、ТН ВЭД、Честный ЗНАК）均不翻译。
 */
const ATTRIBUTE_NAME_DICT = {
  // 通用
  "бренд": "品牌",
  "тип": "类型",
  "модель": "型号",
  "название модели": "型号名称",
  "цвет": "颜色",
  "размер": "尺寸",
  "материал": "材质",
  "состав": "成分",
  "вес, кг": "重量（kg）",
  "вес": "重量",
  "высота, см": "高度（cm）",
  "высота": "高度",
  "ширина, см": "宽度（cm）",
  "ширина": "宽度",
  "глубина, см": "深度（cm）",
  "глубина": "深度",
  "длина, см": "长度（cm）",
  "длина": "长度",
  "страна производства": "生产国",
  "гарантия": "保修期",
  "сезон": "适用季节",
  "пол": "适用性别",
  "возраст": "适用年龄",
  "назначение": "适用场景",
  "особенности": "特点",
  "комплектация": "套装配置",
  "количество в упаковке": "包装数量",
  "количество заводских упаковок": "出厂包装数量",
  "артикул производителя": "厂商货号",
  "форма": "形状",
  "узор": "图案",
  "стиль": "风格",
  "тип управления": "控制方式",
  "мощность, вт": "功率（W）",
  "мощность": "功率",
  "напряжение, в": "电压（V）",
  "напряжение": "电压",
  "объем, л": "容量（L）",
  "объем": "容量",
  // 家具
  "тип открывания дверей": "开门方式",
  "исполнение": "款式",
  "ориентация": "朝向",
  "вытяжной шкаф": "通风柜",
  // 服装
  "подкладка": "里料材质",
  "застежка": "闭合方式",
  "рукав": "袖型",
  "декольте": "领型",
  "длина изделия": "衣长",
  "длина рукава": "袖长",
  "талия": "腰围",
  "обхват груди": "胸围",
  "обхват бедер": "臀围",
  "обхват талии": "腰围",
  // 鞋靴
  "размер обуви": "鞋码",
  "высота каблука, см": "鞋跟高度（cm）",
  "высота каблука": "鞋跟高度",
  "материал верха": "鞋面材质",
  "материал подошвы": "鞋底材质",
  "тип застежки": "闭合方式",
  "водонепроницаемость": "防水性",
  // 常用枚举值（颜色）：避免每次都走 AI 才出中文
  "красный": "红色",
  "синий": "蓝色",
  "зеленый": "绿色",
  "желтый": "黄色",
  "жёлтый": "黄色",
  "черный": "黑色",
  "чёрный": "黑色",
  "белый": "白色",
  "серый": "灰色",
  "оранжевый": "橙色",
  "розовый": "粉色",
  "фиолетовый": "紫色",
  "коричневый": "棕色",
  "голубой": "天蓝色",
  "бежевый": "米色",
  "золотой": "金色",
  "серебряный": "银色",
  "многоцветный": "多色",
  "прозрачный": "透明",
  "разноцветный": "拼色",
  // 常用枚举值（尺码）：本身就是拉丁字号占位符，不翻译
  "xs": "XS",
  "s": "S",
  "m": "M",
  "l": "L",
  "xl": "XL",
  "xxl": "XXL",
  "xxxl": "XXXL",
  "один размер": "均码",
  // 常用枚举值（材质）：统一用材料本体名词（XX料/金属/木材），不加「制」「的」等修饰
  "пластик": "塑料",
  "металл": "金属",
  "дерево": "木材",
  "стекло": "玻璃",
  "хлопок": "棉",
  "полиэстер": "涤纶",
  "силикон": "硅胶",
  "резина": "橡胶",
  "кожа": "皮革",
  "нержавеющая сталь": "不锈钢",
  // 其它常用枚举值
  "да": "是",
  "нет": "否",
  "весна": "春季",
  "лето": "夏季",
  "осень": "秋季",
  "зима": "冬季",
  "мужской": "男",
  "женский": "女",
  "унисекс": "中性",
  "девочки": "女童",
  "мальчики": "男童",
  "новый": "新款",
  "классический": "经典款",
  // 类目属性高频项（对接 Ozon 卖家端常见字段，离线出中文，不依赖 AI）
  "нужен код маркировки": "需要诚信标签（Честный ЗНАК）",
  "вес с упаковкой, г": "带包装重量（g）",
  "вес с упаковкой": "带包装重量",
  "высота упаковки, см": "包装高度（cm）",
  "длина упаковки, см": "包装长度（cm）",
  "ширина упаковки, см": "包装宽度（cm）",
  "объем упаковки, л": "包装体积（L）",
  "объем упаковки": "包装体积",
  "аннотация": "商品描述",
  "страна изготовитель": "生产国",
  "страна-изготовитель": "生产国",
  "страна производства": "生产国",
  "размер упаковки (длина x ширина x высота), см": "包装尺寸（长×宽×高，cm）",
  "размер упаковки (длина × ширина × высота), см": "包装尺寸（长×宽×高，cm）",
  "цвет товара": "商品颜色",
  "наименование": "名称",
  "количество": "数量",
  "цена": "价格",
  "тн вэд код": "海关编码（ТН ВЭД）",
  "сертификат": "证书",
  "гарантийный срок": "保修期",
  "срок службы": "使用期限",
  "назначение подарка": "礼品适用场景",
  "тема рисунка": "图案主题",
  "тип одежды": "服装类型",
  // 滑雪/滑板运动类（超哥在卖的商品）与截图里高频漏翻的属性名
  "уровень подготовки": "技术水平",
  "радиус поворота": "转弯半径",
  "ростовка": "雪板长度",
  "геометрия": "几何参数",
  "жесткость": "硬度",
  "жёсткость": "硬度",
  "скользяк": "板底材质",
  "наименование модификации": "改型名称",
  "наименование суббренда": "子品牌名称",
  "страна изготовления": "生产国",
  "назначение товара": "商品适用场景",
  "код товара": "商品编码",
  // 高频枚举值补充（等级系列统一「X级」，与上面的「X款」系列各自成体系）
  "универсал": "通用级",
  "профессиональный": "专业级",
  "любительский": "业余级",
  "продвинутый": "进阶级",
  "начальный": "入门级",
  "эксперт": "专家级",
};

/** 把属性名/值按字典和缓存翻成中文；未命中且是俄文时走 AI 翻译并缓存。 */
async function translateAttributeName(text) {
  const raw = cleanText(text);
  if (!raw) return "";
  if (/[\u4e00-\u9fa5]/.test(raw)) return raw;
  const key = raw.toLowerCase();
  if (ATTRIBUTE_NAME_DICT[key]) return ATTRIBUTE_NAME_DICT[key];
  if (state.attributeZh[key]) return state.attributeZh[key];
  try {
    const [zh] = await translateCategoryTexts([raw], "zh");
    if (zh) state.attributeZh[key] = zh;
    return zh || raw;
  } catch {
    return raw;
  }
}

/**
 * 把属性名 / 枚举值翻译成中文显示。先查本地字典与翻译缓存，未命中的一次性批量
 * AI 翻译（而不是每个值一次请求，之前那样几百个值会触发限流、大部分回落成俄文）。
 * 结果显示在 displayName / displayValue 上，界面统一读这两个字段，从而「不要俄语」。
 * v1.9.56：品牌类属性的**候选值不翻**——品牌是专有名词（SHANBEN 被 AI 翻成「家用电器」
 * 就是反面教材），而且品牌字典动辄几万个值，拿去批量翻译既烧额度又全是错的。
 */
const BRAND_ATTR_RE = /бренд|brand/i;

async function translateAttributeNames(attributes = []) {
  const names = [...new Set(attributes.map((a) => cleanText(a.name)).filter(Boolean))];
  const values = [...new Set(attributes.flatMap((a) => (BRAND_ATTR_RE.test(cleanText(a.name)) ? [] : (a.dictionary || []).map((d) => cleanText(d.value)).filter(Boolean))))];
  const all = [...new Set([...names, ...values])];
  const needTranslate = all.filter((t) => {
    if (/[\u4e00-\u9fa5]/.test(t)) return false;            // 已经是中文
    if (ATTRIBUTE_NAME_DICT[t.toLowerCase()]) return false;  // 本地字典已覆盖
    if (state.categoryZh[t.toLowerCase()]) return false;      // 之前翻译过
    return true;
  });
  if (needTranslate.length) {
    try {
      await translateCategoryTexts(needTranslate, "zh"); // 一次批量翻译，结果写入 state.categoryZh
    } catch {
      /* 翻译失败不影响使用，保留原名 */
    }
  }
  const zhOf = (text) => {
    const raw = cleanText(text);
    if (!raw) return "";
    if (/[\u4e00-\u9fa5]/.test(raw)) return raw;
    const key = raw.toLowerCase();
    return ATTRIBUTE_NAME_DICT[key] || state.categoryZh[key] || raw;
  };
  // v1.9.58：官方离线库按 ID 对齐好的中文（displayName/displayValue）优先级最高，
  // AI 翻译只兜「离线库没对上」的 —— 否则 zhOf 查不到会返回俄文原名，把官方中文覆盖回去。
  const isZhText = (s) => /[\u4e00-\u9fa5]/.test(cleanText(s));
  for (const attr of attributes) {
    const name = cleanText(attr.name);
    if (name && !isZhText(attr.displayName)) attr.displayName = zhOf(name);
    if (Array.isArray(attr.dictionary)) {
      for (const item of attr.dictionary) {
        const value = cleanText(item.value);
        if (value && !isZhText(item.displayValue)) item.displayValue = zhOf(value);
      }
    }
  }
  return attributes;
}

/** 属性定义从草稿缓存恢复时没走过翻译：渲染后补一次中文并重绘（幂等）。
 * v1.9.41：上次翻译失败时 displayName 会被写成俄文原名——那不算「已翻译」，
 * 必须按「名称不是中文」重试，否则这块永远停留在俄文。 */
async function ensureAttributesChinese() {
  const attrs = state.categoryAttributes || [];
  if (!attrs.length) return;
  const isZh = (s) => /[\u4e00-\u9fa5]/.test(cleanText(s));
  const need = attrs.some((a) => cleanText(a.name) && !isZh(a.displayName))
    || attrs.some((a) => (a.dictionary || []).some((d) => cleanText(d.value) && !isZh(d.displayValue)));
  if (!need) return;
  try {
    await translateAttributeNames(attrs);
    renderAttributeDefs();
  } catch { /* 翻译失败保留原名，不影响填值 */ }
}

/** 根据 type_id 反查从根到叶的中文路径（用于修正旧草稿 pathText） */
function getCategoryPathText(nodes, typeId, ancestors = []) {
  const target = Number(typeId) || 0;
  if (!target) return "";
  for (const node of nodes || []) {
    const title = cleanText(node.title || node.category_name || node.type_name || "");
    const path = [...ancestors, title].filter(Boolean);
    if (Number(node.type_id) === target) return path.join(" / ");
    if (node.children?.length) {
      const found = getCategoryPathText(node.children, typeId, path);
      if (found) return found;
    }
  }
  return "";
}

/**
 * 加载类目属性（v1.9.55 改走「官方元数据」通道）：
 * 后台一次性拿全 定义 + 版本指纹 + 全部枚举候选值（24h 缓存，force 可强制回源）。
 * 过去每次都重新请求定义、候选值只拉必填+变体——字典不全界面就只能给文本框，
 * AI 没有候选值可挑只能自己编，上传发自由文本必被 Ozon 拒。
 */
async function loadCategoryAttributes(node, { force = false } = {}) {
  // v1.9.78：加载要「拉官方定义 → AI 翻译属性名 → 校验对账」三步，全程可能几十秒。
  // 旧实现按钮和状态条毫无反应，用户以为卡死（超哥：点了没反应，其实在运行）。
  // 现在按钮点击即置灰改字，状态条按阶段推进，让人看得见它在跑。
  const btn = $("#btn-attr-reload");
  const prevText = btn ? btn.textContent : "";
  if (btn) { btn.disabled = true; btn.textContent = "加载中…"; }
  setBadge("#attr-ai-status", "正在拉取官方属性定义…", "warn");
  try {
    const data = await call({
      action: MESSAGE_ACTIONS.ozonAttributeMeta,
      payload: {
        descriptionCategoryId: node.category_id,
        typeId: node.type_id,
        force,
      },
    });
    const list = Array.isArray(data?.attributes) ? data.attributes : [];
    state.attrMetaInfo = data?.meta || null;
    const list2 = Array.isArray(list) ? list : [];
    setBadge("#attr-ai-status", `已取到 ${list2.length} 项定义，正在翻译中文名…`, "warn");
    // 把属性名/枚举值翻译成中文显示；翻译结果缓存在 state.attributeZh
    if (list2.length) await translateAttributeNames(list2);
    state.categoryAttributes = list2;
    if (state.draft) state.draft = await saveDraft({ id: state.draft.id, categoryAttributes: state.categoryAttributes });
    renderAttributeDefs();
    renderAttrMetaHint();
    // 定义一到位就对一次账：越界值剔除、非法枚举就近修正、缺必填列清单（结果进报告区）
    setBadge("#attr-ai-status", "正在校验属性值…", "warn");
    await runAttributeCheck({ silent: true });
    setBadge("#attr-ai-status", `已加载 ${list2.length} 项属性`, "ok");
    return true;
  } catch (error) {
    state.categoryAttributes = [];
    renderAttributeDefs();
    // 失败原因留在状态徽标上，别只弹一下 toast 就没了
    setBadge("#attr-ai-status", `加载失败：${error.message}`, "err");
    toast(`类目属性加载失败：${error.message}`, "error");
    return false;
  } finally {
    if (btn) { btn.disabled = false; btn.textContent = prevText || "加载类目属性"; }
  }
}

/** 元数据来源提示行：让用户知道当前属性表是「刚回源」还是「缓存」，过期缓存会标警告 */
function renderAttrMetaHint() {
  const node = $("#attr-meta-hint");
  if (!node) return;
  const info = state.attrMetaInfo;
  if (!info) {
    node.hidden = true;
    return;
  }
  const age = Number(info.at) ? Math.round((Date.now() - Number(info.at)) / 60000) : 0;
  const ageText = age >= 60 ? `${Math.round(age / 60)} 小时前` : `${age} 分钟前`;
  const off = info.offline || null;
  // v1.9.57：离线库要么只出候选值（接口正常），要么整份顶上（接口挂了/没填密钥）
  const sourceParts = [];
  if (info.source === "offline") {
    sourceParts.push(`官方离线属性库${off?.name ? `（${off.name}）` : ""}`);
  } else {
    sourceParts.push(info.source === "network" ? "官方接口（刚回源）" : `本地缓存（${ageText}回源）`);
  }
  // v1.9.58：离线库对界面最大的贡献是「官方中文」——属性名/候选值按官方 ID 对齐模板中文名
  if (off?.zhNames) sourceParts.push(`${off.zhNames} 个属性名用官方模板中文`);
  if (off?.zhValues) sourceParts.push(`${off.zhValues} 个候选值带官方中文`);
  const source = sourceParts.join(" · ");
  const stale = info.source === "cache" && age > 24 * 60;
  let tail = stale ? " · 已超过 24 小时，建议点「强制刷新元数据」" : "";
  if (info.source === "offline") {
    // 离线库是类目级的（模板按 description_category_id 下发），比类型级宽——必须说清楚
    tail += " · 接口没走通，这是类目级全量属性，可能比该类型实际需要的多一些";
    if (off?.fallbackReason) tail += `（原因：${off.fallbackReason}）`;
  }
  node.textContent = `属性元数据：${source} · 指纹 ${String(info.fingerprint || "-").slice(0, 8)}${tail}`;
  node.className = stale || info.source === "offline" ? "hint warn" : "hint";
  node.hidden = false;
}

/**
 * 跑一次属性对账（v1.9.55）并渲染报告。
 * applyFixed=true（自动流程）时把「唯一命中」的修正与剔除直接写回草稿；
 * 手点「校验属性」也允许写回——所有写回动作都会在报告里逐条列出，不静默。
 */
async function runAttributeCheck({ silent = false } = {}) {
  const wrap = $("#attr-check-wrap");
  if (!wrap) return;
  const attrs = state.categoryAttributes || [];
  if (!attrs.length) {
    wrap.hidden = true;
    state.attrCheck = null;
    return;
  }
  const result = reconcileAttributes({
    definitions: attrs,
    values: state.draft?.attributeValues || {},
    valueIds: state.draft?.attributeValueIds || {},
    skus: state.draft?.skus || [],
  });
  // v1.9.56 超大字典（品牌）的「不在候选值里」不一定是真错：本地只存前 2000 条，
  // 全库几十万个值。对这类未命中项调官方 values/search 反查一次，查到就补进字典
  // 并重算（最多 5 项，避免对账变成批量请求）。
  const bigDictMisses = result.unmatched
    .map((item) => ({ item, attr: attrs.find((a) => String(a.id) === String(item.id)) }))
    // v1.9.57：判定放宽成「本地字典 < 官方候选值总数」。离线库裁掉的超大字典
    // （dictionary_state=huge，本地 0 条）过去因为字典长度不够阈值被漏掉，
    // 于是品牌这类属性永远走不到官方搜索反查。
    .filter(({ attr, item }) => attr
      && Number(attr.dictionary_id) > 0
      && item.value
      && ((attr.dictionary || []).length >= ATTR_DICT_COMBO_MIN
        || Number(attr.dictionary_total) > (attr.dictionary || []).length))
    .slice(0, 5);
  let resolvedAny = false;
  for (const { item, attr } of bigDictMisses) {
    const id = await searchBrandDictionaryValue(attr, item.value);
    if (id) resolvedAny = true;
  }
  const finalResult = resolvedAny ? reconcileAttributes({
    definitions: attrs,
    values: state.draft?.attributeValues || {},
    valueIds: state.draft?.attributeValueIds || {},
    skus: state.draft?.skus || [],
  }) : result;
  state.attrCheck = finalResult;
  const r = finalResult;
  // 修正 / 剔除 / 自动补 / 搜索补到的字典 ID 写回草稿（固定流程）：
  // 用户在报告里能看到每一条改了什么，不静默
  const dirty = r.removed.length + r.fixed.length + r.added.length + (resolvedAny ? 1 : 0);
  if (dirty && state.draft) {
    state.draft = await saveDraft({
      id: state.draft.id,
      attributeValues: r.values,
      attributeValueIds: { ...(state.draft.attributeValueIds || {}), ...r.valueIds },
    });
    renderAttributeDefs();
  }
  renderAttributeCheckReport();
  if (!silent && !dirty && r.ok) toast("属性校验通过：没有发现问题", "ok");
}

/** 属性校验报告的纯文本形态（复制 / 导出用，也作为渲染数据源） */
/** v1.9.58 报告辅助：按俄文属性名反查中文显示名（复合组 missingNames 只有名字没有 ID） */
function zhAttrName(rawName) {
  const raw = cleanText(rawName);
  if (!raw || isChineseText(raw)) return raw;
  const attr = (state.categoryAttributes || []).find((a) => cleanText(a.name) === raw);
  const zh = cleanText(attr?.displayName);
  return isChineseText(zh) ? zh : `${raw}（需确认）`;
}
/** v1.9.58 报告辅助：按属性 ID + 值原文反查候选值中文（修正/未命中项给用户看的是官方中文值） */
function zhOfAttrValue(attrId, value) {
  const attr = (state.categoryAttributes || []).find((a) => String(a.id) === String(attrId));
  const hit = (attr?.dictionary || []).find((d) => cleanText(d.value) === cleanText(value));
  const zh = cleanText(hit?.displayValue);
  return isChineseText(zh) ? zh : "";
}

function buildAttributeCheckText() {
  const r = state.attrCheck;
  if (!r) return "";
  // v1.9.58 全中文：报告里属性一律「中文名（俄文原文）」——中文来自官方模板离线库/AI 翻译，
  // 原文保留是为了能跟 Ozon 后台对上（超哥要求：不改含义、资料没有的标需确认）
  const nameOf = (item) => {
    const attr = (state.categoryAttributes || []).find((a) => String(a.id) === String(item.id));
    const zh = cleanText(attr?.displayName);
    const raw = cleanText(item.name);
    if (isChineseText(zh)) return zh && zh !== raw ? `${zh}（${raw}）` : zh;
    if (isChineseText(raw)) return raw;
    return raw ? `${raw}（需确认）` : `属性 ${item.id}`;
  };
  const lines = [];
  lines.push(`属性校验报告 · ${new Date().toLocaleString("zh-CN")}`);
  const cat = state.draft?.ozonCategory || {};
  if (Number(cat.typeId || 0)) lines.push(`类目：${cleanText(state.draft?.ozonCategoryPathText) || "-"}（category ${cat.descriptionCategoryId || cat.category_id || 0} / type ${cat.typeId}）`);
  const parts = [];
  if (r.removed.length) parts.push(`${r.removed.length} 项已剔除`);
  if (r.fixed.length) parts.push(`${r.fixed.length} 项已自动修正`);
  if (r.added.length) parts.push(`${r.added.length} 项已自动补`);
  if (r.unmatched.length) parts.push(`${r.unmatched.length} 项需人工选择`);
  if (r.missing.length) parts.push(`${r.missing.length} 项必填未填`);
  lines.push(`结论：${parts.length ? parts.join(" · ") : "未发现问题"} · 可上传：${r.ok ? "是" : "否"}`);
  const section = (title, rows, fmt) => {
    if (!rows.length) return;
    lines.push("", `【${title}】`);
    for (const row of rows) lines.push(`  · ${fmt(row)}`);
  };
  section("已剔除", r.removed, (x) => `${nameOf(x)}：原值「${x.value}」——${x.reason}，本次上传不再带该属性`);
  section("已自动修正", r.fixed, (x) => `${nameOf(x)}：${x.from} → ${x.to}${x.toZh && x.toZh !== x.to ? `（${x.toZh}）` : ""}`);
  section("已自动补全", r.added, (x) => `${nameOf(x)} = ${x.value}（${x.reason}）`);
  section("必填未填（请人工填写）", r.missing, (x) => `${nameOf(x)}（类型 ${attrTypeZh(x.type)}${x.unit ? `，单位 ${x.unit}` : ""}${x.dictSize ? `，${x.dictSize} 个候选值` : ""}）`);
  section("需人工选择（当前值不在候选值里）", r.unmatched, (x) => `${nameOf(x)}：当前「${x.value}」不在候选值中${x.dictSize >= 2000 ? `（本地存了前 ${x.dictSize} 条 + 官方全库按词搜索都未命中，请核对拼写）` : `（共 ${x.dictSize} 个候选）`}，请从下拉/建议里选`);
  section("复合属性组（填了组内一项就要填全组）", r.complex, (x) => `组 ${x.complexId}：已填 ${x.filledCount}/${x.total}，缺：${x.missingNames.map((n) => zhAttrName(n)).join("、")}`);
  section("提示", r.warnings, (x) => x);
  return lines.join("\n");
}

/** 渲染属性校验报告（#attr-check-wrap 在 HTML 里，报告体在这里生成） */
function renderAttributeCheckReport() {
  const wrap = $("#attr-check-wrap");
  const body = $("#attr-check-report");
  const summary = $("#attr-check-summary");
  if (!wrap || !body) return;
  const r = state.attrCheck;
  if (!r || !(state.categoryAttributes || []).length) {
    wrap.hidden = true;
    return;
  }
  const nameOf = (item) => {
    const attr = (state.categoryAttributes || []).find((a) => String(a.id) === String(item.id));
    const zh = cleanText(attr?.displayName);
    const raw = cleanText(item.name);
    if (isChineseText(zh)) return zh && zh !== raw ? `${zh}（${raw}）` : zh;
    if (isChineseText(raw)) return raw;
    return raw ? `${raw}（需确认）` : `属性 ${item.id}`;
  };
  const li = (cls, text) => `<li class="${cls}">${text}</li>`;
  const groups = [
    ["removed", "已剔除", "check-removed", (x) => `${nameOf(x)}：原值「${x.value}」——${x.reason}`],
    ["fixed", "已自动修正", "check-fixed", (x) => `${nameOf(x)}：${x.from} → ${x.to}${x.toZh && x.toZh !== x.to ? `（${x.toZh}）` : ""}`],
    ["added", "已自动补全", "check-added", (x) => `${nameOf(x)} = ${x.value}（${x.reason}）`],
    ["missing", "必填未填", "check-missing", (x) => `${nameOf(x)}（类型 ${attrTypeZh(x.type)}${x.unit ? `，单位 ${x.unit}` : ""}）`],
    ["unmatched", "需人工选择", "check-unmatched", (x) => `${nameOf(x)}：当前「${x.value}${zhOfAttrValue(x.id, x.value) ? `（${zhOfAttrValue(x.id, x.value)}）` : ""}」不在候选值中${x.dictSize >= 2000 ? "（本地前 2000 条 + 官方全库搜索都未命中，请核对拼写）" : `（共 ${x.dictSize} 个候选）`}`],
    ["complex", "复合属性组", "check-complex", (x) => `组 ${x.complexId}：已填 ${x.filledCount}/${x.total}，缺：${x.missingNames.map((n) => zhAttrName(n)).join("、")}`],
    ["warnings", "提示", "check-warn", (x) => x],
  ];
  const html = groups
    .filter(([key]) => Array.isArray(r[key]) && r[key].length)
    .map(([key, label, cls, fmt]) => `<li class="check-group"><strong>${label}（${r[key].length}）</strong><ul>${r[key].map((x) => li(cls, fmt(x))).join("")}</ul></li>`)
    .join("");
  body.innerHTML = html || '<li class="check-ok">未发现问题</li>';
  if (summary) {
    const bits = [];
    if (r.removed.length) bits.push(`剔除 ${r.removed.length}`);
    if (r.fixed.length) bits.push(`修正 ${r.fixed.length}`);
    if (r.unmatched.length) bits.push(`待手选 ${r.unmatched.length}`);
    if (r.missing.length) bits.push(`必填缺 ${r.missing.length}`);
    summary.textContent = bits.length ? bits.join(" · ") : "全部通过";
    summary.className = r.ok ? "check-summary ok" : "check-summary bad";
  }
  wrap.hidden = false;
}

/**
 * 本地字典（只有前 2000 条）反查不到时，调 Ozon values/search 按词查全库（v1.9.56）。
 * 命中要求「整串一致」才认（忽略大小写/空格），避免输入半个词匹配到错品牌；
 * 命中后把值**追加进本地字典**——这样对账（reconcileAttributes）和上传组装
 * （toOzonValue 按 dictionary_value_id 回查字典）都能认出它，不再误报「不在候选值里」。
 * 返回 dictionary_value_id（0 = 没查到；查询失败静默返回 0，不打断填写）。
 */
const valueSearchCache = new Map(); // 关键词 → 结果数组（面板会话内去重，避免同词反复请求）

async function searchBrandDictionaryValue(attr, typed) {
  const cat = state.draft?.ozonCategory || {};
  const categoryId = Number(cat.descriptionCategoryId || cat.description_category_id || cat.category_id) || 0;
  const typeId = Number(cat.typeId || cat.type_id) || 0;
  if (!typeId) return 0;
  const key = `${typeId}:${attr.id}:${typed.toLowerCase()}`;
  let hits = valueSearchCache.get(key);
  if (!hits) {
    try {
      const data = await call({
        action: MESSAGE_ACTIONS.ozonAttributeValueSearch,
        payload: {
          descriptionCategoryId: categoryId, typeId, attributeId: attr.id, query: typed,
        },
      });
      hits = Array.isArray(data) ? data : [];
    } catch {
      return 0; // 搜索接口挂了不影响：值仍按文本上传，只是可能没有 dictionary_value_id
    }
    valueSearchCache.set(key, hits);
  }
  const norm = (s) => cleanText(s).toLowerCase().replace(/\s+/g, "");
  const target = norm(typed);
  const hit = hits.find((item) => norm(item.value) === target);
  if (!hit || !Number(hit.id)) return 0;
  if (!Array.isArray(attr.dictionary)) attr.dictionary = [];
  if (!attr.dictionary.some((item) => Number(item.id) === Number(hit.id))) {
    attr.dictionary.push({ value: cleanText(hit.value), id: Number(hit.id), displayValue: "" });
  }
  return Number(hit.id);
}

/**
 * 拉枚举型属性的候选值（v1.9.50）。
 *
 * 属性定义接口不返回候选值，必须一个一个属性地单独拉。不拉的话：
 * attr.dictionary 恒为空 → 界面只能给文本框 → AI 也没有候选值只能自己编 →
 * 上传时发自由文本 → Ozon 判「属性不正确：不要手输这些值，请从列表中选择一个属性值」。
 * 默认只拉「必填 + 变体属性」这些最要紧的（其余由用户点「补齐候选值」按需拉），
 * 免得一进类目就打几十个请求。
 */
async function loadAttributeDictionaries(attrs = [], { onlyImportant = true } = {}) {
  const cat = state.draft?.ozonCategory || {};
  const typeId = Number(cat.typeId || cat.type_id) || 0;
  const categoryId = Number(cat.descriptionCategoryId || cat.description_category_id || cat.category_id) || 0;
  if (!typeId) return 0;
  if (state.attrDictLoading) return 0;
  const targets = (attrs || []).filter((attr) => {
    if (Array.isArray(attr.dictionary) && attr.dictionary.length) return false; // 已有候选值
    if (!(Number(attr.dictionary_id) > 0)) return false;                        // 非枚举型，没有候选值
    if (!onlyImportant) return true;
    return Boolean(attr.is_required) || Boolean(attr.is_aspect);
  });
  if (!targets.length) return 0;
  state.attrDictLoading = true;
  setBadge("#attr-ai-status", `拉取候选值 ${targets.length} 项…`, "warn");
  try {
    const map = await call({
      action: MESSAGE_ACTIONS.ozonAttributeValues,
      payload: { descriptionCategoryId: categoryId, typeId, attributeIds: targets.map((attr) => attr.id) },
    });
    let filled = 0;
    for (const attr of targets) {
      const values = map?.[String(attr.id)] || map?.[attr.id] || [];
      if (!Array.isArray(values) || !values.length) continue;
      attr.dictionary = values.map((item) => ({
        value: cleanText(item.value),
        id: Number(item.id) || null,
        displayValue: "",
      }));
      filled += 1;
    }
    if (filled) {
      await translateAttributeNames(targets);
      state.draft = await saveDraft({ id: state.draft.id, categoryAttributes: state.categoryAttributes });
      renderAttributeDefs();
    }
    toast(
      filled ? `已补齐 ${filled} 个枚举属性的候选值（改成下拉选择，不会再被判「请从列表中选择」）` : "没有拉到新的候选值",
      filled ? "ok" : "warn",
    );
    setBadge("#attr-ai-status", filled ? `候选值已补齐 ${filled} 项` : "候选值未补齐", filled ? "ok" : "warn");
    return filled;
  } catch (error) {
    setBadge("#attr-ai-status", `候选值拉取失败`, "err");
    toast(`候选值拉取失败：${error?.message || error}`, "error");
    return 0;
  } finally {
    state.attrDictLoading = false;
  }
}

/* 类目定了但属性定义还没拉时自动补拉（载入旧草稿、手动确认类目后都走这里）。
 * 同一「草稿+类目」只自动拉一次，失败后仍可点「加载类目属性」手动重试。 */
let attrAutoLoadKey = "";

async function autoLoadCategoryAttributes() {
  const draft = state.draft;
  const cat = draft?.ozonCategory || {};
  const typeId = Number(cat.typeId || cat.type_id) || 0;
  if (!typeId) return;
  if ((state.categoryAttributes || []).length) return;
  const key = `${draft.id}:${typeId}`;
  if (attrAutoLoadKey === key) return;
  attrAutoLoadKey = key;
  const node = state.categoryNode || {
    category_id: Number(cat.descriptionCategoryId || cat.description_category_id || cat.category_id) || 0,
    type_id: typeId,
  };
  const ok = await loadCategoryAttributes(node);
  if (!ok) attrAutoLoadKey = "";   // 失败允许下次进工作台时再试
  else await afterCategoryConfirmed();
}

/** 属性表：定义 + 可编辑取值（AI 填好后也能手工改，改动直接写回草稿） */
function renderAttributeDefs() {
  // v1.9.64 「JSON 富内容」(id 11254) 已搬到「主要信息（俄语）」区详细描述的下方：
  // 它的值是一整段 JSON，混在属性表里既占版面又容易被顺手改坏；而且它的内容本来就
  // 来自详细描述 + 商品图，跟描述放一起才顺手。
  const attrs = (state.categoryAttributes || [])
    .filter((attr) => String(attr.id) !== String(RICH_CONTENT_ATTR_ID));
  renderTable("#attr-def-table", [
    { key: "id", label: "属性 ID" },
    {
      key: "name",
      label: "名称",
      html: true,
      // v1.9.57 官方离线库带中文填写说明（「特性」说明原文）：挂在 title 上，鼠标悬停可见，
      // 不用点开也不占版面——属性怎么填才是这类目最容易踩坑的地方。
      // v1.9.58 全中文：官方模板/本地字典/AI 翻译都给不出中文的名称，保留原文并标「（需确认）」，
      // 不硬编一个中文塞进去（超哥要求：资料没有明确对应的，标注需要确认）。
      render: (row) => {
        const label = cleanText(row.displayName || row.name);
        const zhLabel = isChineseText(label) ? label : `${label}（需确认）`;
        const hint = cleanText(row.hint);
        return hint ? `<span title="${escapeHtml(hint)}">${escapeHtml(zhLabel)}</span>` : escapeHtml(zhLabel);
      },
    },
    { key: "is_required", label: "必填", render: (row) => (row.is_required ? "是" : "否") },
    { key: "type", label: "类型", render: (row) => attrTypeZh(row.type) },
    {
      key: "value",
      label: "属性值（可编辑）",
      html: true,
      render: (row) => renderAttributeValueCell(row),
    },
    {
      key: "source",
      label: "来源",
      render: (row) => state.draft?.attributeSources?.[String(row.id)] || (state.draft?.attributeValues?.[String(row.id)] ? "手工/已有" : "待填写"),
    },
    {
      key: "confidence",
      label: "置信度",
      render: (row) => {
        const c = state.draft?.attributeConfidence?.[String(row.id)];
        if (c === undefined || c === null || c === "未提供") return "—";
        const pct = Number.isFinite(Number(c)) ? `${Math.round(Number(c) * 100)}%` : String(c);
        return `<span class="attr-confidence ${Number(c) < 0.65 ? "low" : ""}">${pct}</span>`;
      },
    },
  ], attrs);
  for (const input of $$("#attr-def-table input.attr-value, #attr-def-table select.attr-value")) {
    input.addEventListener("change", async () => {
      if (!state.draft) return;
      const values = { ...(state.draft.attributeValues || {}) };
      const candidate = { ...values, [String(input.dataset.id)]: input.value.trim() };
      const own = state.categoryAttributes.find((attr) => String(attr.id) === String(input.dataset.id));
      if (own && validateAttributeValues([own], candidate).errors.length) {
        toast(validateAttributeValues([own], candidate).errors.join("；"), "error");
        input.value = values[String(input.dataset.id)] || "";
        return;
      }
      values[String(input.dataset.id)] = input.value.trim();
      // 枚举型属性从下拉框选的：把字典值 ID 一起存下来，上传时发 dictionary_value_id
      const valueIds = { ...(state.draft.attributeValueIds || {}) };
      let pickedId = Number(input.selectedOptions?.[0]?.dataset?.dictId) || 0;
      // v1.9.51 填入式选择（大字典，如品牌）：按输入的值反查字典拿 ID——大小写/首尾空格不敏感，
      // 要求整串一致，避免「输入半个品牌名」匹配到错的品牌。
      // v1.9.56：本地只存前 2000 条（品牌全库几十万个，拉全既慢又撑内存），
      // 本地查不到时调 Ozon 官方 values/search 按词反查——这才是「加载全部品牌数据库」。
      if (!pickedId && input.tagName === "INPUT") {
        const typed = String(input.value || "").trim();
        const lower = typed.toLowerCase();
        if (own && Array.isArray(own.dictionary) && typed) {
          const hit = own.dictionary.find((item) => String(item.value || "").trim().toLowerCase() === lower)
            || own.dictionary.find((item) => String(item.displayValue || item.value || "").trim().toLowerCase() === lower);
          if (hit) pickedId = Number(hit.id) || 0;
        }
        if (!pickedId && typed && Number(own?.dictionary_id) > 0) {
          pickedId = await searchBrandDictionaryValue(own, typed);
        }
      }
      if (pickedId) valueIds[String(input.dataset.id)] = pickedId;
      else delete valueIds[String(input.dataset.id)];
      state.draft = await saveDraft({ id: state.draft.id, attributeValues: values, attributeValueIds: valueIds });
      ensureAttributeValueHints();  // 值变了，中文提示跟着补
    });
  }
  // v1.9.41 取值列的中文提示：俄文值要上传给 Ozon（平台只认俄文），但界面同步给一行中文小字
  ensureAttributeValueHints();
  const status = $("#attr-ai-status");
  if (status) {
    // 富内容不算进「已填 N 项」——它在属性表里已经不存在了，计进去会让数字对不上眼见的行数
    const filled = Object.entries(state.draft?.attributeValues || {})
      .filter(([id, value]) => value && String(id) !== String(RICH_CONTENT_ATTR_ID)).length;
    const hasCategory = Number(state.draft?.ozonCategory?.typeId || 0) > 0;
    if (filled) setBadge("#attr-ai-status", `已填 ${filled} 项`, "ok");
    else if (!hasCategory) setBadge("#attr-ai-status", "未选类目", "");
    else if (!(state.categoryAttributes || []).length) setBadge("#attr-ai-status", "属性未加载，点上方按钮", "warn");
    else setBadge("#attr-ai-status", "未填写", "warn");
  }
  // 品牌属性是必填率最高的一项，属性表一刷新就同步上传区的品牌合规状态（v1.9.61）
  renderBrandGuard();
  // v1.9.64 品牌字段默认「无品牌」：只在属性为空时自动填，绝不覆盖已有的具体品牌
  void applyBrandDefault();
}

/** 枚举候选值超过这个数就改用「输入筛选」：品牌（Бренд）这类几千个值的字典，下拉根本没法选 */
const ATTR_DICT_COMBO_MIN = 30;

/** v1.9.64 品牌字段下方的小字说明：默认填「无品牌」的理由，以及什么时候必须改回去 */
const BRAND_DEFAULT_NOTE = '<div class="hint attr-brand-note">已默认按 <strong>无品牌（Нет бренда）</strong> 填写：商品本身没有品牌时这就是正解，Ozon 不会再要求品牌授权文件。如果你确实持有品牌授权，请在这里改成具体品牌，并把授权书 / 供货合同备好——填了具体品牌却拿不出文件，商品会被封锁，还可能被品牌方投诉。</div>';

/** 渲染属性取值单元格：小字典用下拉框，大字典（品牌等）用「填入式选择」——输入关键字筛选 + 建议列表 */
function renderAttributeValueCell(row) {
  const current = state.draft?.attributeValues?.[String(row.id)] || "";
  const dict = Array.isArray(row.dictionary) ? row.dictionary : [];
  // v1.9.55 对账后「值不在候选值里」的行标红，提示必须人工选
  const invalid = (state.attrCheck?.unmatched || []).some((item) => String(item.id) === String(row.id));
  const invalidCls = invalid ? " attr-invalid" : "";
  const esc = (s) => String(s ?? "").replace(/"/g, "&quot;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  // v1.9.64 品牌字段默认「无品牌」，并在字段下方用小字说明理由与例外——
  // 「缺少品牌文件」是 Ozon 最高发的封锁理由，而绝大多数铺货商品本来就没有品牌。
  const brandNote = isBrandAttribute(row) ? BRAND_DEFAULT_NOTE : "";
  if (dict.length > ATTR_DICT_COMBO_MIN) {
    // v1.9.51 填入式选择品牌：文本框打字过滤 + datalist 建议，选中即标准字典值。
    // 字典值 ID 在 change 处理器里按值反查（字典值就是唯一键），上传时照样发 dictionary_value_id。
    const options = dict.map((item) => {
      const label = cleanText(item.displayValue || item.value);
      return `<option value="${esc(item.value)}">${esc(label)}</option>`;
    }).join("");
    return `<input class="attr-value${invalidCls}" data-id="${row.id}" type="text" list="attr-dl-${row.id}" value="${esc(current)}" placeholder="${invalid ? "当前值不在候选值里，请从建议里选" : "输入关键字筛选（如品牌名），从建议里选"}" style="width:100%">`
      + `<datalist id="attr-dl-${row.id}">${options}</datalist>`
      + `<div class="attr-value-zh" data-zh-for="${row.id}" hidden></div>` + brandNote;
  }
  if (dict.length) {
    const options = [
      `<option value="" ${!current ? "selected" : ""}>-- 请选择 --</option>`,
      // data-dict-id 是关键：Ozon 只认字典值 ID，选完要把它一起写进草稿（attributeValueIds），
      // 上传时发 dictionary_value_id 而不是自由文本（否则被判「属性不正确」）
      ...dict.map((item) => {
        const label = cleanText(item.displayValue || item.value);
        const id = Number(item.id) || 0;
        return `<option value="${esc(item.value)}" data-dict-id="${id || ""}" ${String(current) === String(item.value) ? "selected" : ""}>${esc(label)}</option>`;
      }),
    ].join("");
    return `<select class="attr-value${invalidCls}" data-id="${row.id}" style="width:100%">${options}</select>` + brandNote;
  }
  // v1.9.57 超大字典（官方候选值 > 2000，离线库没留、接口也拉不全：品牌、汽车配件型号这类）：
  // 本地没有候选值可列，但值必须来自官方库 —— 给个明确的输入框，输入后走 values/search 反查，
  // 别让用户以为可以随手打（随手打的结果就是「属性不正确：请从列表中选择」）。
  if (!dict.length && Number(row.dictionary_total) > 0) {
    return `<input class="attr-value${invalidCls}" data-id="${row.id}" type="text" list="attr-dl-${row.id}" value="${esc(current)}" placeholder="官方候选值 ${Number(row.dictionary_total)} 条，输入后自动到官方库反查" style="width:100%">`
      + `<datalist id="attr-dl-${row.id}"></datalist>`
      + `<div class="attr-value-zh" data-zh-for="${row.id}" hidden></div>` + brandNote;
  }
  return `<input class="attr-value${invalidCls}" data-id="${row.id}" type="text" value="${esc(current)}" placeholder="${invalid ? "当前值不在候选值里，请重新填写" : esc(row.unit ? `单位：${row.unit}` : "")}" style="width:100%"><div class="attr-value-zh" data-zh-for="${row.id}" hidden></div>` + brandNote;
}

/** 已填属性值的现成中文（官方模板离线库对齐 / 本地字典 / 翻译缓存）；纯数字尺寸不翻 */
function attributeValueZh(value) {
  const raw = cleanText(value);
  if (!raw || /[\u4e00-\u9fa5]/.test(raw)) return "";
  if (/^[\d.,\s/xх×*+\-]+$/.test(raw)) return "";
  // v1.9.58：先看当前属性字典里有没有按官方 ID 对齐好的中文（displayValue）——
  // 官方模板的中文比 AI 翻译权威，能省一次翻译请求
  for (const attr of state.categoryAttributes || []) {
    const hit = (attr.dictionary || []).find((d) => cleanText(d.value) === raw);
    if (hit && /[\u4e00-\u9fa5]/.test(cleanText(hit.displayValue))) return cleanText(hit.displayValue);
  }
  const key = raw.toLowerCase();
  return ATTRIBUTE_NAME_DICT[key] || state.categoryZh[raw] || state.categoryZh[key] || "";
}

/** 批量翻译已填的俄文取值并填进中文提示行（不整体重绘，避免打断正在编辑的输入框）。
 * v1.9.56：品牌属性的值不送翻——品牌是专有名词，SHANBEN 被 AI 翻成「家用电器」就是
 * 这么来的（而且翻错的中文还会缓存进 state.categoryZh 反复显示）。 */
async function ensureAttributeValueHints() {
  const values = state.draft?.attributeValues || {};
  const brandAttrIds = new Set(
    (state.categoryAttributes || [])
      .filter((attr) => BRAND_ATTR_RE.test(cleanText(attr.name)))
      .map((attr) => String(attr.id)),
  );
  const missing = [...new Set(
    Object.entries(values)
      .filter(([id, v]) => v && !brandAttrIds.has(String(id)) && !attributeValueZh(v))
      .map(([, v]) => v),
  )].slice(0, 40);
  if (missing.length) {
    try { await translateCategoryTexts(missing, "zh"); } catch { /* 翻不出就保留俄文原值 */ }
  }
  for (const node of $$("#attr-def-table .attr-value-zh")) {
    const zh = brandAttrIds.has(String(node.dataset.zhFor)) ? "" : attributeValueZh(values[node.dataset.zhFor] || "");
    node.textContent = zh ? `中文：${zh}` : "";
    node.hidden = !zh;
  }
}

/**
 * 用 1688 采集到的商品属性直接回填 Ozon 属性值（不覆盖已有值）。
 * 映射规则：Ozon 属性名 → 中文名（ATTRIBUTE_NAME_DICT）→ 与 1688 属性参数同名匹配；
 * 另处理品牌/生产国两个高频项，以及与规格维度（颜色/尺码）同名的属性取第一个选用 SKU 的值。
 * 枚举型属性只回填字典里存在的值，绝不硬塞 Ozon 不认的值。
 */
function prefillAttributesFromProduct() {
  const values = { ...(state.draft?.attributeValues || {}) };
  const sources = { ...(state.draft?.attributeSources || {}) };
  const productAttrs = (state.draft?.attributes || [])
    .map((a) => ({ name: cleanText(a.name), value: cleanText(Array.isArray(a.values) ? a.values[0] : (a.value ?? a.val)) }))
    .filter((a) => a.name && a.value);
  const byName = new Map(productAttrs.map((a) => [a.name, a.value]));
  const findProductValue = (...keys) => {
    for (const key of keys) {
      if (!key || key.length < 2) continue;
      if (byName.has(key)) return byName.get(key);
      for (const [name, value] of byName) {
        if (name.includes(key) || key.includes(name)) return value;
      }
    }
    return "";
  };
  let filled = 0;
  for (const attr of state.categoryAttributes || []) {
    const id = String(attr.id);
    if (values[id]) continue;
    const ruName = cleanText(attr.name).toLowerCase();
    const zhName = cleanText(attr.displayName) || ATTRIBUTE_NAME_DICT[ruName] || "";
    let value = findProductValue(zhName);
    if (!value && /бренд/.test(ruName)) value = findProductValue("品牌", "brand");
    if (!value && /стран/.test(ruName)) {
      const dict = Array.isArray(attr.dictionary) ? attr.dictionary : [];
      const china = dict.find((d) => /китай|china|中国/i.test(d.value));
      value = china ? china.value : "Китай"; // Ozon 端生产国写俄文「中国」
    }
    if (!value && zhName) {
      // 与规格维度同名的属性（颜色/尺码/材质…）：取第一个选用 SKU 的规格值
      const sku = (state.draft.skus || []).find((item) => item.specs && cleanText(item.specs[zhName]));
      if (sku) value = cleanText(sku.specs[zhName]);
    }
    if (!value) continue;
    const dict = Array.isArray(attr.dictionary) ? attr.dictionary : [];
    if (dict.length && !dict.some((d) => d.value === value)) continue; // 枚举对不上就不填
    values[id] = value;
    sources[id] = "1688 采集";
    filled += 1;
  }
  return { values, sources, filled };
}

/** AI 按商品信息填写当前类目的属性值 */
async function aiFillCategoryAttributes() {
  if (!await ensureLicensed("AI 填类目属性")) return;
  if (!state.draft) return toast("请先载入草稿", "error");
  if (state.draftCategoryStale?.reason) {
    toast(`类目数据异常：${state.draftCategoryStale.reason} 请点「重新选择类目」后再试。`, "error");
    return 0;
  }
  // 还没拉属性定义时自动补拉（比如类目是 AI 自动匹配的，属性还没加载）
  if (!(state.categoryAttributes || []).length) {
    const cat = state.draft.ozonCategory || {};
    const node = state.categoryNode || {
      category_id: Number(cat.descriptionCategoryId || cat.description_category_id || cat.category_id) || 0,
      type_id: Number(cat.typeId || cat.type_id) || 0,
    };
    if (!node.type_id) {
      toast("还没选到类目「类型」，请先在「② 类目与属性」选到最后一层", "error");
      return 0;
    }
    await loadCategoryAttributes(node);
  }
  if (!(state.categoryAttributes || []).length) {
    toast("该类目没有拉到属性定义，可能是：1）Ozon 对该类目/类型组合无属性要求；2）本地中文树里的类目 ID 已过期。请重新选择一次类目。", "error");
    return 0;
  }
  // v1.9.64 加强识别：枚举型属性必须先有候选值再交给 AI —— 模型对着真实候选值挑，
  // 比它自己编一个词、再由 snapAttributeValues 去猜要准得多（差一个词形就会被判「属性不正确」）。
  if ((state.categoryAttributes || []).some((attr) => Number(attr.dictionary_id) > 0 && !(attr.dictionary || []).length)) {
    await loadAttributeDictionaries(state.categoryAttributes, { onlyImportant: true });
  }
  // 先用 1688 采集到的属性直接回填（品牌/材质/颜色/尺码等），AI 只补剩下的
  const pre = prefillAttributesFromProduct();
  if (pre.filled) {
    state.draft = await saveDraft({
      id: state.draft.id,
      attributeValues: pre.values,
      attributeSources: pre.sources,
    });
    renderAttributeDefs();
    toast(`已从 1688 采集属性自动回填 ${pre.filled} 项`, "ok");
  }
  const btn = $("#btn-attr-ai-fill");
  if (btn) { btn.disabled = true; btn.textContent = "AI 填写中…"; }
  setBadge("#attr-ai-status", "AI 填写中…", "warn");
  try {
    const data = await call({
      action: MESSAGE_ACTIONS.aiFillAttributes,
      product: state.draft,
      attributes: state.categoryAttributes,
    });
    const raw = data?.__raw || "";
    // v1.9.50 先做一次「就近落到 Ozon 字典」：枚举型属性只认字典值，
    // AI 给的值哪怕只差一个词形，上传时也会被判「属性不正确：请从列表中选择」。
    const snapped = snapAttributeValues(state.categoryAttributes, data?.values || {});
    const values = snapped.values;
    // v1.9.64 富内容（11254）不参与属性填写：即使模型硬塞了一个值也丢掉，
    // 它只由「详细描述」下方的富内容区生成（图片直链与宽高必须用采集到的真实数据）。
    delete values[String(RICH_CONTENT_ATTR_ID)];
    if (Array.isArray(data?.unknown) && data.unknown.length) {
      toast(`AI 无法确定属性（ID：${data.unknown.join("、")}），已保留待填写`, "warn");
    }
    if (snapped.unmatched.length) {
      toast(
        `${snapped.unmatched.length} 项 AI 值不在 Ozon 候选值里（${snapped.unmatched.slice(0, 5).map((u) => u.name).join("、")}），请到属性表从下拉里选一个`,
        "warn",
      );
    }
    let mergedValues = { ...(state.draft.attributeValues || {}), ...values };
    // AI 可以明确返回一部分属性；缺失必填项应展示为待补，而不是丢弃全部可用结果。
    const returnedDefinitions = state.categoryAttributes.filter((attr) => cleanText(values[String(attr.id)]));
    const invalid = validateAttributeValues(returnedDefinitions, values).errors;
    if (invalid.length) throw new Error(`AI 返回的属性无法使用：${invalid.join("；")}`);
    const filled = Object.values(values).filter(Boolean).length;
    if (!filled) {
      // 把 AI 原始返回简短展示出来，方便排查是 prompt 还是模型问题
      const preview = raw ? `（AI 原始返回：${raw.slice(0, 200)}…）` : "AI 认为现有商品信息不足以填写任何属性";
      throw new Error(`AI 未返回可用属性值。${preview}`);
    }
    const sources = { ...(state.draft.attributeSources || {}) };
    const confidence = { ...(state.draft.attributeConfidence || {}) };
    const lowConfidence = [];
    for (const attr of state.categoryAttributes) {
      const id = String(attr.id);
      if (values[id]) {
        const score = Number(data?.confidence?.[id]);
        confidence[id] = Number.isFinite(score) ? score : "未提供";
        if (Number.isFinite(score) && score < 0.65) {
          sources[id] = "AI 低置信，需复核";
          lowConfidence.push(`${cleanText(attr.displayName) || attr.name || id}（${Math.round(score * 100)}%）`);
        } else {
          sources[id] = "AI";
        }
      } else if (Array.isArray(data?.unknown) && data.unknown.includes(id)) {
        sources[id] = "AI 未确定";
      }
    }
    state.draft = await saveDraft({
      id: state.draft.id,
      attributeValues: mergedValues,
      // 落库时把字典值 ID 一起存：上传要用 dictionary_value_id，不能靠上传时再猜一次
      attributeValueIds: { ...(state.draft.attributeValueIds || {}), ...snapped.ids },
      attributeSources: sources,
      attributeConfidence: confidence,
      lastAiAttributeRaw: raw,
    });
    renderAttributeDefs();
    setBadge("#attr-ai-status", lowConfidence.length ? `已填 ${filled} 项，${lowConfidence.length} 项需复核` : `已填 ${filled} 项`, lowConfidence.length ? "warn" : "ok");
    let missingRequired = state.categoryAttributes.filter((attr) => attr.is_required && !mergedValues[String(attr.id)]);
    // v1.9.64 补漏一轮：第一轮要同时处理几十个属性，模型容易在必填项上也留空。
    // 缩小到「只有空着的必填项」再问一次，命中率明显更高；只在真有空缺时才发这一次请求，
    // 失败也不影响主流程（下面照旧列出「仍有 N 个必填属性待补」）。
    if (missingRequired.length) {
      try {
        const extra = await aiFillMissingRequired(missingRequired);
        if (extra) {
          mergedValues = { ...(state.draft.attributeValues || {}) };
          missingRequired = state.categoryAttributes.filter((attr) => attr.is_required && !mergedValues[String(attr.id)]);
          toast(`必填属性补填了 ${extra} 项`, "ok");
        }
      } catch { /* 补漏失败静默：主流程结果照常展示 */ }
    }
    const notices = [];
    if (missingRequired.length) notices.push(`仍有 ${missingRequired.length} 个必填属性待补`);
    if (lowConfidence.length) notices.push(`低置信需复核：${lowConfidence.join("、")}`);
    toast(
      notices.length ? `AI 已填写 ${filled} 项，${notices.join("；")}` : `AI 已填写 ${filled} 项类目属性`,
      notices.length ? "warn" : "ok",
    );
    // v1.9.56 AI 填完再静默对账一次：品牌这类超大字典，AI 填对了品牌名但值不在本地
    // 前 2000 条里时，对账会调官方 values/search 反查全库补上 dictionary_value_id。
    await runAttributeCheck({ silent: true });
    return filled;
  } catch (error) {
    setBadge("#attr-ai-status", "填写失败", "err");
    throw error;
  } finally {
    if (btn) { btn.disabled = false; btn.textContent = "AI 自动填写类目属性"; }
  }
}

/**
 * v1.9.64 只针对「空着的必填属性」再问一轮 AI。
 * 第一轮把几十个属性一起丢给模型时，必填项经常也被漏掉；把范围缩到必填项后命中率明显更高。
 * 返回补填成功的条数（0 表示没有新进展，调用方不必刷新）。
 */
async function aiFillMissingRequired(missing = []) {
  const targets = (missing || []).filter((attr) => attr && attr.id);
  if (!targets.length || !state.draft) return 0;
  const data = await call({
    action: MESSAGE_ACTIONS.aiFillAttributes,
    product: state.draft,
    attributes: targets,
    options: { onlyRequired: true },
  });
  const snapped = snapAttributeValues(targets, data?.values || {});
  const filledEntries = Object.entries(snapped.values).filter(([, value]) => cleanText(value));
  if (!filledEntries.length) return 0;
  const values = { ...(state.draft.attributeValues || {}) };
  const sources = { ...(state.draft.attributeSources || {}) };
  const confidence = { ...(state.draft.attributeConfidence || {}) };
  for (const [id, value] of filledEntries) {
    values[id] = value;
    sources[id] = "AI 补填必填";
    const score = Number(data?.confidence?.[id]);
    confidence[id] = Number.isFinite(score) ? score : "未提供";
  }
  state.draft = await saveDraft({
    id: state.draft.id,
    attributeValues: values,
    attributeValueIds: { ...(state.draft.attributeValueIds || {}), ...snapped.ids },
    attributeSources: sources,
    attributeConfidence: confidence,
  });
  renderAttributeDefs();
  return filledEntries.length;
}

/* ---------------- JSON 富内容（Ozon 属性 11254） ----------------
 * v1.9.64：从「类目与属性」表里搬到「主要信息（俄语）」区详细描述的下方。
 * 内容 = 图片直链 + 每张图的标题/正文；有富内容时 Ozon 卡片会用它**替代**详细描述。
 * 分工：图片与宽高由插件按采集数据拼（模型编的地址一定 404），模型只写文字。
 */

/** 当前草稿里的富内容 JSON 文本 */
function richContentText() {
  return cleanText(state.draft?.attributeValues?.[String(RICH_CONTENT_ATTR_ID)] || "");
}

/** 富内容状态行 + 说明小字（随文本框内容实时刷新，不写草稿） */
function updateRichContentStatus() {
  const text = cleanText($("#rich-content")?.value || "");
  const lenNode = $("#rich-content-len");
  if (lenNode) lenNode.textContent = text ? `${text.length} 字符` : "";
  const hint = $("#rich-content-hint");
  const declared = (state.categoryAttributes || []).some((attr) => String(attr.id) === String(RICH_CONTENT_ATTR_ID));
  const summary = summarizeRichContent(text);
  if (!summary.ok) {
    setBadge("#rich-content-status", "JSON 有问题", "err");
    if (hint) {
      hint.className = "hint danger-text";
      hint.textContent = `富内容 JSON 有问题：${summary.error}`;
    }
    return summary;
  }
  if (hint) {
    hint.className = "hint";
    if (declared) {
      hint.innerHTML = "富内容会<strong>替代详细描述</strong>显示在商品卡片里：图片直链与宽高取自采集到的商品图，AI 只负责写每张图的标题和正文。Ozon 只接受 jpg / jpeg / png 图片（不接受 gif）；用官方可视化编辑器 <span class=\"muted\">rich-content.ozon.ru</span> 可预览效果。";
    } else {
      hint.textContent = "当前类目没有声明「JSON 富内容」（属性 11254）：内容仍会随商品一起提交，但平台可能忽略它。换到带富内容的类目再用，或者先不管。";
    }
  }
  if (summary.widgets) setBadge("#rich-content-status", summary.text, "ok");
  else setBadge("#rich-content-status", "未生成", "");
  return summary;
}

/** 把草稿里的富内容回填到文本框（载入草稿 / 切草稿时调用） */
function renderRichContentBox() {
  const box = $("#rich-content");
  if (!box) return;
  box.value = richContentText();
  updateRichContentStatus();
}

/** 把富内容写进草稿（attributeValues["11254"]），上传链路会原样提交 */
async function saveRichContent(text) {
  if (!state.draft) return null;
  const values = { ...(state.draft.attributeValues || {}) };
  const sources = { ...(state.draft.attributeSources || {}) };
  const clean = cleanText(text);
  if (clean) {
    values[String(RICH_CONTENT_ATTR_ID)] = clean;
    if (!sources[String(RICH_CONTENT_ATTR_ID)]) sources[String(RICH_CONTENT_ATTR_ID)] = "手工";
  } else {
    delete values[String(RICH_CONTENT_ATTR_ID)];
    delete sources[String(RICH_CONTENT_ATTR_ID)];
  }
  state.draft = await saveDraft({ id: state.draft.id, attributeValues: values, attributeSources: sources });
  return state.draft;
}

/**
 * 生成富内容。
 * useAi=true：先让 AI 按「详细描述 + 商品图」写每张图的标题/正文（模型只写文字），
 *             失败或返回中文时自动降级到「按描述快速排版」；
 * useAi=false：直接按详细描述的段落配图，不调 AI（无 Key / 超时也能出一版可用的）。
 */
async function generateRichContent({ useAi = true } = {}) {
  if (!state.draft) return toast("请先载入草稿", "error");
  const description = cleanText($("#ru-desc")?.value || state.draft.ru?.description || "");
  const images = pickRichContentImages(state.draft, RICH_CONTENT_MAX_BLOCKS);
  if (!images.length) {
    return toast("没有可用作富内容的图片：Ozon 只接受 jpg / jpeg / png 直链（gif、webp 不行）。请先采集商品图，或到「图片」区换成 jpg/png 后重试。", "error");
  }
  if (!description) {
    return toast("请先填写上面的「详细描述」——富内容的文字就是从描述与图片来的。", "error");
  }
  if (useAi && !await ensureLicensed("AI 生成富内容")) return;
  const btn = $("#btn-rich-ai");
  if (useAi && btn) { btn.disabled = true; btn.textContent = "生成中…"; }
  if (useAi) setBadge("#rich-content-status", "生成中…", "warn");
  try {
    let json = "";
    let source = "AI";
    if (useAi) {
      let blocks = null;
      try {
        const data = await call({
          action: MESSAGE_ACTIONS.aiRichContent,
          product: state.draft,
          images,
          options: { description },
        });
        blocks = Array.isArray(data?.blocks) ? data.blocks : null;
      } catch (error) {
        toast(`AI 生成富内容失败（${error.message}），已改用「按描述快速排版」`, "warn");
      }
      if (blocks && blocks.length) json = buildRichContentJson(images, blocks);
      if (!json) {
        json = buildRichContentFallback(images, description, state.draft.ru?.title || "");
        source = "按描述排版";
      }
    } else {
      json = buildRichContentFallback(images, description, state.draft.ru?.title || "");
      source = "按描述排版";
    }
    if (!json) return toast("生成失败：没有可用的图片或描述段落", "error");
    const check = validateRichContentJson(json);
    if (!check.ok) throw new Error(check.error);
    const sources = { ...(state.draft.attributeSources || {}) };
    sources[String(RICH_CONTENT_ATTR_ID)] = `富内容·${source}`;
    await saveRichContent(json);
    state.draft = await saveDraft({ id: state.draft.id, attributeSources: sources });
    const box = $("#rich-content");
    if (box) box.value = json;
    const summary = updateRichContentStatus();
    toast(`富内容已生成（${summary.text}，来源：${source}）`, "ok");
  } catch (error) {
    setBadge("#rich-content-status", "生成失败", "err");
    toast(error.message, "error");
  } finally {
    if (useAi && btn) { btn.disabled = false; btn.textContent = "AI 生成富内容"; }
  }
}

/* ---------------- 库存 / 订单 ---------------- */

function bindOps() {
  $("#btn-stocks").addEventListener("click", async () => {
    try {
      const data = await call({ action: MESSAGE_ACTIONS.ozonStocks, payload: { limit: 200 } });
      renderTable("#stocks-table", [
        { key: "offer_id", label: "Offer ID" },
        { key: "product_id", label: "Product ID" },
        { key: "stock", label: "库存", render: (row) => row.stocks?.map((s) => s.present).join("/") || "" },
      ], data?.items || []);
      toast("库存已加载", "ok");
    } catch (error) {
      toast(error.message, "error");
    }
  });

  $("#btn-stock-update").addEventListener("click", async () => {
    if (!state.draft) return toast("请先载入草稿", "error");
    const warehouseId = Number($("#ops-warehouse-id").value) || 0;
    if (!warehouseId) return toast("更新库存需要填写 FBO 仓库 ID（warehouse_id）", "error");
    const stocks = (state.draft.skus || []).map((sku) => ({
      offer_id: buildStableModel(state.draft, sku, state.settings.skuPrefix),
      stock: Number(sku.stock) || 0,
    }));
    if (!stocks.length) return toast("草稿没有 SKU 库存数据", "error");
    try {
      await call({ action: MESSAGE_ACTIONS.ozonUpdateStocks, stocks, warehouseId });
      toast("库存更新已提交", "ok");
    } catch (error) {
      toast(error.message, "error");
    }
  });

  $("#btn-price-update").addEventListener("click", async () => {
    if (!state.draft?.pricing) return toast("请先在「定价」页给当前草稿定价", "error");
    // v1.9.47 逐个 SKU 更新，货号口径与上传完全一致（手工填的「上架 SKU」优先）。
    // 原来多 SKU 时只发一条、货号还退化成 draftId，Ozon 找不到该货号会整条失败。
    const skus = (state.draft.skus || []).length ? state.draft.skus : [null];
    const perSku = state.draft.pricing.perSku && typeof state.draft.pricing.perSku === "object"
      ? state.draft.pricing.perSku
      : {};
    const prices = skus.map((sku) => {
      const picked = (sku && perSku[sku.id]) || state.draft.pricing;
      const priceCny = Number(picked?.priceCny) || 0;
      const oldPriceCny = Number(picked?.oldPriceCny) || 0;
      const entry = {
        offer_id: buildStableModel(state.draft, sku, state.settings.skuPrefix),
        // v1.9.50 必须发人民币：商品的 currency_code 是 CNY（上架时就是这么建的），
        // 之前这里发的是卢布数值 priceRub —— 等于把 ₽ 当 ¥ 写进价格，Ozon 会报
        // 「价格错误：X CNY 不等于售价 Y CNY…不会显示新价格」，价格根本改不过来。
        price: String(priceCny || ""),
      };
      // Ozon 要求 old_price 严格大于 price，相等或更低会整条被拒——不带划线价也比被拒好
      if (oldPriceCny > priceCny) entry.old_price = String(oldPriceCny);
      return entry;
    }).filter((item) => item.offer_id && item.price && item.price !== "0");
    if (!prices.length) return toast("没有可更新的价格，先点「反推售价并应用」", "error");
    try {
      await call({ action: MESSAGE_ACTIONS.ozonUpdatePrices, prices });
      toast(`价格更新已提交（${prices.length} 条）`, "ok");
    } catch (error) {
      toast(error.message, "error");
    }
  });

  $("#btn-fbs").addEventListener("click", async () => {
    try {
      const data = await call({
        action: MESSAGE_ACTIONS.ozonFbsOrders,
        payload: { since: $("#fbs-since").value, to: $("#fbs-to").value },
      });
      renderTable("#fbs-table", [
        { key: "posting_number", label: "发货单号" },
        { key: "status", label: "状态" },
        { key: "created_at", label: "创建时间" },
        { key: "products", label: "商品", render: (row) => (row.products || []).map((p) => p.name).join("、") },
      ], data?.postings || []);
      toast(`已加载 ${data?.postings?.length || 0} 条订单`, "ok");
    } catch (error) {
      toast(error.message, "error");
    }
  });

  $("#btn-intel").addEventListener("click", async () => {
    const output = $("#intel-output");
    const tableWrap = $("#intel-table-wrap");
    output.hidden = false;
    tableWrap.hidden = true;
    output.textContent = "加载中：正在查找已登录的 seller.ozon.ru 页面并读取可见商品行…";
    try {
      const response = await chrome.runtime.sendMessage({ action: MESSAGE_ACTIONS.ozonSalesIntel });
      if (!response?.ok) {
        output.textContent = `读取失败：${response?.error || "后台没有返回错误原因"}`;
        toast(response?.error || "读取失败", "error");
        return;
      }
      const rows = Array.isArray(response.rows) ? response.rows : [];
      if (!rows.length) {
        output.textContent = "没有结果：当前页面没有识别到已渲染商品行。请打开商品列表/分析页并等待加载完成后重试。";
        toast("没有识别到商品行", "warn");
        return;
      }
      renderTable("#intel-table", rows[0].map((_, index) => ({
        key: String(index),
        label: `列 ${index + 1}`,
        render: (row) => row[index] || "",
      })), rows);
      tableWrap.hidden = false;
      output.textContent = `读取成功：${rows.length} 行（来源：${response.url || "seller.ozon.ru"}）`;
      toast(`已读取 ${rows.length} 行卖家后台商品数据`, "ok");
    } catch (error) {
      output.textContent = `读取失败：${error?.message || String(error)}`;
      toast(error?.message || "读取失败", "error");
    }
  });
}

/* ---------------- AI 自动化流水线（融合在工作台里，不是独立配置页） ---------------- */

const AI_PIPE_STEPS = [
  { id: "collection", label: "采集商品" },
  { id: "category", label: "AI 匹配类目" },
  { id: "copy", label: "AI 俄语文案" },
  { id: "pricing", label: "自动定价" },
  { id: "attributes", label: "AI 填类目属性" },
  { id: "images", label: "图片处理" },
  { id: "upload", label: "上传 Ozon" },
];

function renderPipeSteps() {
  const wrap = $("#ai-pipe-steps");
  if (!wrap) return;
  wrap.innerHTML = "";
  for (const step of AI_PIPE_STEPS) {
    wrap.appendChild(el("li", { class: "ai-pipe-step", dataset: { step: step.id } }, [
      el("span", { class: "dot" }),
      el("span", { text: step.label }),
      el("span", { class: "pipe-note" }),
    ]));
  }
}

function setPipeStep(id, status, note = "") {
  const node = document.querySelector(`.ai-pipe-step[data-step="${id}"]`);
  if (!node) return;
  node.className = `ai-pipe-step${status ? ` is-${status}` : ""}`;
  const noteNode = node.querySelector(".pipe-note");
  if (noteNode) noteNode.textContent = note ? `· ${note}` : "";
}

function resetPipe() {
  for (const step of AI_PIPE_STEPS) setPipeStep(step.id, "");
  setBadge("#ai-pipe-status", "待运行", "");
  const confirmBtn = $("#btn-ai-confirm-upload");
  if (confirmBtn) confirmBtn.hidden = true;
}

/** 跑一步：成功标绿，失败标红；fatal=false 时失败只警告、继续往下跑 */
async function pipeStep(id, fn, { fatal = true } = {}) {
  setPipeStep(id, "running");
  try {
    const note = await fn();
    setPipeStep(id, "done", note || "");
    return note;
  } catch (error) {
    const message = error?.message || String(error);
    setPipeStep(id, "error", message);
    if (fatal) throw error;
    return "";
  }
}

/** 图片阶段：先自动筛掉图标/水印图，可选再 AI 生一张补充图 */
async function prepareDraftImages({ draw = false } = {}) {
  const draft = state.draft;
  const images = draft?.images || [];
  if (!images.length) throw new Error("草稿没有图片，无法处理");
  const meta = draft.imageMeta || {};
  let kept = 0;
  for (const url of images) {
    if (isLikelyProductImage(url, meta)) {
      state.selectedImages.add(url);
      kept += 1;
    } else {
      state.selectedImages.delete(url);
    }
  }
  renderImageGallery();
  let note = `保留 ${kept}/${images.length} 张`;
  if (!draw) return note;
  // 带本产品图做参考（图生图）：自动生图同样必须「基于本产品」，否则会画出一个无关的东西
  let referenceImage = "";
  const sourceUrl = state.draft?.mainImage || (state.draft?.images || [])[0] || "";
  if (sourceUrl) {
    try { referenceImage = await fetchDataUrl(sourceUrl); } catch { /* 取不到就退回纯文生图 */ }
  }
  const data = await call({
    action: MESSAGE_ACTIONS.imageRedraw,
    context: cleanText([draft.ru?.productType, draft.ru?.title || draft.title].filter(Boolean).join(", ")),
    styleHint: cleanText($("#it-style")?.value || ""),
    referenceImage,
  });
  const remoteUrl = data?.url || "";
  // Ozon 只接受图片 URL，base64 无法直接上传
  if (!remoteUrl) throw new Error("AI 生图未返回图片 URL，无法写入草稿");
  state.draft = await saveDraft({ id: draft.id, images: [remoteUrl, ...(state.draft.images || [])] });
  renderEditor();
  return `${note} · AI 生图 1 张`;
}

/** AI 自动填写：类目 → 俄语文案 → 定价。采集后自动跑，也可单独调用 */
async function aiAutoFillDraft() {
  if (!state.draft) return;
  // 顺序有讲究：先生成俄语文案，AI 会顺带回一句「俄语类目提示」，
  // Ozon 类目树只有 RU/EN 名称，拿这句提示去匹配比拿中文标题硬匹配准得多。
  await pipeStep("copy", async () => {
    const data = await call({
      action: MESSAGE_ACTIONS.aiGenerateText,
      product: state.draft,
      options: {
        tone: $("#tone-select")?.value || "",
        extraKeywords: $("#kw-extra")?.value || "",
        // 用户已纠正过品类时以用户的为准，避免自动流程又把品类写泛
        productType: $("#ru-product-type")?.value || "",
      },
    });
    applyRu(data);
    state.draft = await saveDraft({ id: state.draft.id, ru: state.draft.ru });
    return `${(data?.title || "").slice(0, 20)}…`;
  }, { fatal: false });

  // 类目：AI 给出候选，默认等人工点选确认（开关关掉才自动落选）
  let categoryPending = false;
  await pipeStep("category", async () => {
    const path = await autoMatchCategory(state.draft);
    if (!path) throw new Error("未自动匹配到类目，请在「② 类目与属性」手选到最后一层类型");
    const picked = state.draft?.ozonCategory || {};
    if (Number(picked.typeId || picked.type_id) > 0) return path;
    categoryPending = true;
    return `${path}（待确认）`;
  }, { fatal: false });

  // 反推售价并写回草稿：按上架表口径算每个 SKU 的售价和利润率（取代之前的成本加成公式）
  await pipeStep("pricing", () => applyListingToDraft(), { fatal: false });

  // 类目没确认就先停在这儿：属性必须等类目定了再拉，避免白填一屏
  if (categoryPending) {
    setBadge("#ai-pipe-status", "待确认类目", "warn");
    state.pendingCategoryResume = true;
    return { categoryPending: true };
  }

  const cat = state.draft?.ozonCategory || {};
  if (Number(cat.typeId || cat.type_id) > 0) {
    if (!(state.categoryAttributes || []).length) {
      await loadCategoryAttributes(state.categoryNode || {
        category_id: Number(cat.descriptionCategoryId || cat.description_category_id || cat.category_id) || 0,
        type_id: Number(cat.typeId || cat.type_id) || 0,
      });
    }
    await pipeStep("attributes", async () => {
      const filled = await aiFillCategoryAttributes();
      return filled ? `已填 ${filled} 项` : "";
    }, { fatal: false });
  }
  return { categoryPending: false };
}

/**
 * 类目确认后要做的事：属性已经拉好了，提示数量；如果流水线正卡在「待确认类目」，
 * 就从「填属性 → 图片 → 上传」接着往下跑。
 */
async function afterCategoryConfirmed() {
  const count = (state.categoryAttributes || []).length;
  if (count) toast(`已加载该类目 ${count} 项属性`, "ok");
  // 属性一到手就做两件必做的事：
  // ① 识别变体属性（否则多规格会被静默降级成 1 条）；
  // ② 拉必填/变体属性的候选值（否则枚举属性只能手输，Ozon 必判「属性不正确」）。
  await renderVariantAttrHint();
  if (count) await loadAttributeDictionaries(state.categoryAttributes, { onlyImportant: true });
  if (state.pendingCategoryResume) await resumePipelineAfterCategory();
}

async function resumePipelineAfterCategory() {
  if (!state.pendingCategoryResume) return;
  state.pendingCategoryResume = false;
  setBadge("#ai-pipe-status", "运行中…", "warn");
  try {
    const cat = state.draft?.ozonCategory || {};
    if (Number(cat.typeId || cat.type_id) > 0) {
      await pipeStep("attributes", async () => {
        const filled = await aiFillCategoryAttributes();
        return filled ? `已填 ${filled} 项` : "";
      }, { fatal: false });
    }
    await pipeStep("images", () => prepareDraftImages({ draw: $("#ai-pipe-draw")?.checked }), { fatal: false });
    if ($("#ozon-review")?.checked) {
      setPipeStep("upload", "paused", "等待人工确认");
      setBadge("#ai-pipe-status", "待确认上传", "warn");
      const confirmBtn = $("#btn-ai-confirm-upload");
      if (confirmBtn) confirmBtn.hidden = false;
      toast("属性已填好，确认无误后点「确认上传 Ozon」", "warn");
      return;
    }
    await uploadDraftNow();
  } catch (error) {
    setBadge("#ai-pipe-status", "已中断", "err");
    toast(error.message, "error");
  }
}

async function uploadDraftNow() {
  if (!await ensureLicensed("上传到 Ozon")) return;
  await pipeStep("upload", async () => {
    const items = await buildUploadItems();
    if (!items.length) throw new Error("没有可上传的商品条目");
    const data = await call({ action: MESSAGE_ACTIONS.ozonImportProducts, items });
    kv("#upload-result", [
      ["状态", "已提交"],
      ["提交条目", String(items.length)],
      ["任务 ID", data?.task_id || "(未返回)"],
    ]);
    return `${items.length} 条 · 任务 ${data?.task_id || "-"}`;
  });
  // 上传完顺手把上架表导出来（跟用户自用的「上架表」同格式，带公式）
  if ($("#ai-pipe-export-listing")?.checked) {
    try {
      exportPreparedListing([state.draft], `ozon-上架表-${(state.draft.title || state.draft.id || "").slice(0, 20)}.xlsx`);
    } catch (error) {
      console.warn("[Ozon] 上架表导出失败：", error);
    }
  }
  setBadge("#ai-pipe-status", "已完成", "ok");
  toast("AI 流水线跑完，已提交上传", "ok");
}

/** 一键跑完：采集 → AI 类目 → AI 文案 → 定价 → 图片 → 上传（受人工审核开关控制） */
async function runAiPipeline() {
  if (!await ensureLicensed("AI 一键全流程")) return;
  if (!state.draft && !state.product) {
    const tabs = await refreshProductTabs();
    if (!tabs.length) {
      toast("请先打开 1688 / 淘宝 / 拼多多商品详情页", "error");
      return;
    }
  }
  resetPipe();
  setBadge("#ai-pipe-status", "运行中…", "warn");
  try {
    await pipeStep("collection", async () => {
      if (!state.product) {
        const tabs = await refreshProductTabs();
        if (!tabs.length) throw new Error("没检测到商品页");
        if (tabs.length > 1) throw new Error(`检测到 ${tabs.length} 个商品页，请先在上方选择要采集的页面`);
        await doCapture(tabs[0].id);
      }
      if (!state.product) throw new Error("采集失败");
      if (!state.draft) {
        state.draft = await saveDraft(draftFromProduct(state.product));
        await refreshDraftOptions(state.draft.id);
        renderEditor();
      }
      return `${(state.draft.skus || []).length} 个 SKU · ${(state.draft.images || []).length} 张图`;
    });

    // 达瓦式顺序第一步：先确认 1688 抓到的 SKU 用哪些
    await maybeConfirmSkus();

    const filled = await aiAutoFillDraft();

    // 达瓦式顺序第二步：类目等人工点确认，确认后自动接着跑属性/图片/上传
    if (filled?.categoryPending) {
      setPipeStep("category", "paused", "请在②里点选确认");
      setPipeStep("attributes", "paused", "选好类目后自动继续");
      setPipeStep("images", "paused", "");
      setPipeStep("upload", "paused", "");
      setBadge("#ai-pipe-status", "待确认类目", "warn");
      document.querySelector('.wstep[data-step="category"]')?.click();
      toast("已按采集信息排出候选类目，请在「② 类目与属性」点选确认，确认后自动加载类目属性", "warn");
      return;
    }

    await pipeStep("images", () => prepareDraftImages({ draw: $("#ai-pipe-draw")?.checked }), { fatal: false });

    if ($("#ozon-review")?.checked) {
      setPipeStep("upload", "paused", "等待人工确认");
      setBadge("#ai-pipe-status", "待确认上传", "warn");
      const confirmBtn = $("#btn-ai-confirm-upload");
      if (confirmBtn) confirmBtn.hidden = false;
      toast("信息已由 AI 填好，确认无误后点「确认上传 Ozon」", "warn");
      return;
    }
    await uploadDraftNow();
  } catch (error) {
    setBadge("#ai-pipe-status", "已中断", "err");
    toast(error.message, "error");
  }
}

function bindAiPipeline() {
  renderPipeSteps();
  resetPipe();
  $("#btn-ai-run").addEventListener("click", () => runAiPipeline());
  $("#btn-ai-confirm-upload").addEventListener("click", async () => {
    const btn = $("#btn-ai-confirm-upload");
    btn.hidden = true;
    btn.disabled = true;
    try {
      await uploadDraftNow();
    } catch (error) {
      setBadge("#ai-pipe-status", "上传失败", "err");
      toast(error.message, "error");
    } finally {
      btn.disabled = false;
    }
  });
  // 载入草稿后刷新流水线状态（不自动跑，避免误操作）
  renderPipeSteps();
}

/* ---------------- 象寄密钥列表（每个引擎一把，可多把并行） ---------------- */

// 界面上正在编辑的密钥行：{ id, vendor, key, keep }。keep=true 表示这是已保存的密钥（不显示明文）
function draftXiangjiKeyRows() {
  if (!state.xiangjiKeyRows) {
    state.xiangjiKeyRows = (state.settings?.xiangjiKeys || []).map((item) => ({
      id: item.id,
      vendor: item.vendor,
      key: "",
      keep: item.key,
    }));
  }
  return state.xiangjiKeyRows;
}

function renderXiangjiKeyTable() {
  const rows = draftXiangjiKeyRows();
  const summary = $("#xiangji-key-summary");
  const savedCount = rows.filter((row) => row.keep || row.key).length;
  const vendorCount = new Set(rows.filter((row) => row.keep || row.key).map((row) => row.vendor)).size;
  if (summary) {
    summary.textContent = savedCount
      ? `已配置 ${savedCount} 把密钥，覆盖 ${vendorCount} 个引擎（同一引擎多把密钥会并行使用）`
      : "还没有配置密钥";
  }

  renderTable("#xiangji-key-table", [
    {
      key: "vendor",
      label: "翻译引擎",
      html: true,
      render: (row) => `<select class="xj-vendor" data-id="${row.id}">${XIANGJI_VENDORS
        .map((v) => `<option value="${v.id}"${v.id === row.vendor ? " selected" : ""}>${v.label}</option>`)
        .join("")}</select>`,
    },
    {
      key: "key",
      label: "ImgTransKey",
      html: true,
      render: (row) => `<input class="xj-key" data-id="${row.id}" type="password" value=""
        placeholder="${row.keep ? "已保存 ••••••（留空表示不修改）" : "粘贴该引擎的图片翻译标识码"}">`,
    },
    {
      key: "ops",
      label: "",
      html: true,
      render: (row) => `<button class="danger mini xj-remove" data-id="${row.id}" type="button">删除</button>`,
    },
  ], rows);

  for (const select of $$("#xiangji-key-table select.xj-vendor")) {
    select.addEventListener("change", () => {
      const row = draftXiangjiKeyRows().find((item) => item.id === select.dataset.id);
      if (row) row.vendor = select.value;
    });
  }
  for (const input of $$("#xiangji-key-table input.xj-key")) {
    input.addEventListener("input", () => {
      const row = draftXiangjiKeyRows().find((item) => item.id === input.dataset.id);
      if (row) row.key = input.value.trim();
    });
  }
  for (const button of $$("#xiangji-key-table button.xj-remove")) {
    button.addEventListener("click", async () => {
      const id = button.dataset.id;
      const row = draftXiangjiKeyRows().find((item) => item.id === id);
      if (row?.keep) {
        const yes = await confirmDialog("删除这把已保存的密钥？", { confirmText: "删除", danger: true });
        if (!yes) return;
      }
      state.xiangjiKeyRows = draftXiangjiKeyRows().filter((item) => item.id !== id);
      renderXiangjiKeyTable();
    });
  }
}

// 把界面上的密钥行整理成可保存的列表（未改动且原本就有的行保留原 Key）
function collectXiangjiKeyRows() {
  return draftXiangjiKeyRows()
    .map((row) => ({ id: row.id, vendor: row.vendor, key: row.key || row.keep || "" }))
    .filter((row) => row.key);
}

/* ---------------- 图片服务的可用性检测 ---------------- */

// 象寄密钥检测：不创建任务、不上传图片，因此不消耗额度。
// vendor 为空时检测全部已配置的密钥（设置页用），传了则只测该引擎（工作台用）。
async function runXiangjiTest({ vendor = "", keys = null, badge = "#xiangji-status", tableSelector = "#xiangji-test-table", wrapSelector = "#xiangji-test-result" } = {}) {
  setBadge(badge, "测试中…", "warn");
  let response;
  try {
    response = await send({ action: MESSAGE_ACTIONS.imageTestXiangji, vendor, keys: keys || undefined });
  } catch (error) {
    setBadge(badge, "检测失败", "err");
    toast(error?.message || String(error), "error");
    return null;
  }
  const results = response?.results || [];
  if (tableSelector) {
    renderTable(tableSelector, [
      { key: "vendor", label: "翻译引擎" },
      { key: "keyMask", label: "密钥" },
      { key: "state", label: "检测结果" },
    ], results.map((item) => ({
      vendor: item.vendor || vendor || "—",
      keyMask: item.keyMask || "—",
      state: item.ok ? (item.note || "可用") : `不可用：${item.error || "未知原因"}`,
    })));
    const wrap = $(wrapSelector);
    if (wrap) wrap.hidden = !results.length;
  }
  if (response?.ok) {
    const usable = Number(response.usable ?? results.filter((item) => item.ok).length) || 0;
    setBadge(badge, `可用 ${usable}/${results.length}`, "ok");
    toast(`象寄密钥检测：${usable}/${results.length} 可用`, "ok");
  } else {
    setBadge(badge, "不可用", "err");
    toast(response?.error || "象寄密钥不可用", "error");
  }
  return response;
}

// AI 生图检测：走 /models 探针，不生成图片，因此不消耗额度
async function runImageTest({
  credentials = null, badge = "#image-status", resultSelector = "#image-test-result",
  writeBack = true, urlSelector = "#set-image-url",
} = {}) {
  setBadge(badge, "测试中…", "warn");
  let response;
  try {
    response = await send({ action: MESSAGE_ACTIONS.imageTestRedraw, credentials: credentials || undefined });
  } catch (error) {
    setBadge(badge, "检测失败", "err");
    toast(error?.message || String(error), "error");
    return null;
  }

  // 后台会顺手规范化 Base URL（补 https://、去全角冒号/零宽字符、裸域名补 /v1）。
  // 规范化结果与原输入不同时，把它写回输入框——否则用户会一直觉得「我明明填对了」。
  let fixedNote = "";
  const urlInput = urlSelector ? $(urlSelector) : null;
  if (response?.baseUrl && urlInput && cleanText(urlInput.value) !== response.baseUrl) {
    if (writeBack) {
      urlInput.value = response.baseUrl;
      renderImagePresetNote();
      fixedNote = `已把 Base URL 规范化为 ${response.baseUrl}，记得点「保存设置」`;
    } else {
      fixedNote = `建议把 Base URL 改成 ${response.baseUrl}`;
    }
  }

  const box = resultSelector ? $(resultSelector) : null;
  if (box) {
    const lines = [];
    if (response?.ok) {
      lines.push(response.note || "连接正常");
      // 把「这次拿哪个模型名去比对的」写出来：结论里的模型名来自输入框当时的填写，
      // 之后改了输入框结论不会自动变，写明可以避免「这个模型名哪来的」这种困惑
      lines.push(`检测所用模型：「${response.model || "（未填写）"}」`);
      if (response.endpoint) lines.push(`实际生图地址：${response.endpoint}`);
      if (response.modelCount) lines.push(`可用模型 ${response.modelCount} 个`);
      if (Array.isArray(response.models) && response.models.length && response.modelFound === false) {
        lines.push(`可用模型示例：${response.models.slice(0, 8).join("、")}`);
      }
    } else {
      lines.push(response?.error || "生图服务不可用");
    }
    if (fixedNote) lines.push(fixedNote);
    box.textContent = lines.join("\n");
    box.hidden = false;
  }

  const tail = fixedNote ? `（${fixedNote}）` : "";
  if (response?.ok && response.modelFound !== false) {
    setBadge(badge, "连接正常", "ok");
    toast(`${response.note || "生图连接正常"}${tail}`, "ok");
  } else if (response?.ok) {
    // 地址与 Key 通过，但模型名对不上：给警告而不是失败，避免挡住用户
    setBadge(badge, "模型名待确认", "warn");
    toast(`${response.note || "地址与 Key 可用，但模型名未在列表中找到"}${tail}`, "warn");
  } else {
    setBadge(badge, response?.probeUnsupported ? "无法探测" : "连接失败", "err");
    toast(`${response?.error || "生图连接失败"}${tail}`, "error");
  }
  return response;
}

/* ---------------- 设置 ---------------- */

function bindSettings() {
  const presetSelect = $("#set-preset");
  for (const preset of AI_PRESETS) {
    presetSelect.appendChild(el("option", { value: preset.id, text: preset.name }));
  }

  // 象寄翻译引擎：设置页与上架工作台共用同一份选项
  const vendorSelect = $("#set-xiangji-vendor");
  for (const vendor of XIANGJI_VENDORS) {
    vendorSelect.appendChild(el("option", { value: vendor.id, text: vendor.label }));
  }
  vendorSelect.addEventListener("change", async () => {
    state.settings = await saveSettings({ xiangjiVendor: vendorSelect.value });
    const local = $("#it-vendor");
    if (local) local.value = vendorSelect.value;
    toast("默认翻译引擎已保存", "ok");
  });

  $("#btn-xiangji-add-key").addEventListener("click", () => {
    const rows = draftXiangjiKeyRows();
    // 优先补一个「还没配过的引擎」，省得用户自己挑
    const used = new Set(rows.map((row) => row.vendor));
    const free = XIANGJI_VENDORS.find((vendor) => !used.has(vendor.id));
    rows.push({
      id: createId("xjk"),
      vendor: free ? free.id : (vendorSelect.value || XIANGJI_VENDORS[0].id),
      key: "",
      keep: "",
    });
    renderXiangjiKeyTable();
  });

  // AI 生图预设
  const imagePresetSelect = $("#set-image-preset");
  for (const preset of IMAGE_PRESETS) {
    imagePresetSelect.appendChild(el("option", { value: preset.id, text: preset.name }));
  }
  imagePresetSelect.addEventListener("change", () => {
    const preset = IMAGE_PRESETS.find((item) => item.id === imagePresetSelect.value);
    if (!preset) return;
    if (preset.id !== "custom") {
      $("#set-image-url").value = preset.baseUrl;
      $("#set-image-model").value = preset.defaultModel;
    }
    if (preset.defaultSize) $("#set-image-size").value = preset.defaultSize;
    const list = $("#image-model-options");
    list.innerHTML = "";
    for (const model of preset.models || []) list.appendChild(el("option", { value: model }));
    renderImagePresetNote();
  });
  // 手动改生图配置时：刷新「实际请求」提示，并清掉上一次的检测结论（结论里的模型名/地址会过时）
  for (const selector of ["#set-image-url", "#set-image-size", "#set-image-model", "#set-image-key"]) {
    const node = $(selector);
    if (!node) continue;
    node.addEventListener("input", () => {
      renderImagePresetNote();
      clearImageTestResult();
    });
  }
  // 换预设会重写地址与模型名，同样要清结论
  imagePresetSelect.addEventListener("change", clearImageTestResult);
  // AI 文案改配置后，旧的连接角标也失效
  for (const selector of ["#set-base-url", "#set-model", "#set-api-key"]) {
    $(selector)?.addEventListener("input", clearAiTestResult);
  }
  presetSelect.addEventListener("change", clearAiTestResult);
  // 粘贴整段渠道配置 JSON 时自动拆出地址与密钥
  bindApiConfigPaste("#set-image-url", "#set-image-key");
  bindApiConfigPaste("#set-base-url", "#set-api-key");

  presetSelect.addEventListener("change", () => {
    const preset = AI_PRESETS.find((item) => item.id === presetSelect.value);
    if (!preset) return;
    $("#set-base-url").value = preset.baseUrl;
    $("#set-model").value = preset.defaultModel;
    const list = $("#model-options");
    list.innerHTML = "";
    for (const model of preset.models || []) list.appendChild(el("option", { value: model }));
  });

  $("#btn-set-save").addEventListener("click", async () => {
    state.settings = await saveSettings({
      aiPresetId: presetSelect.value,
      aiBaseUrl: cleanText($("#set-base-url").value),
      aiModel: cleanText($("#set-model").value),
      // v1.9.49 视觉分析模型（出图前看参考图用；留空回落上面的主模型）
      aiVisionModel: cleanText($("#set-vision-model")?.value || ""),
      aiApiKey: $("#set-api-key").value.trim(),
      skuPrefix: cleanText($("#set-sku-prefix").value),
      bulkDelayMs: Number($("#set-bulk-delay").value) || 1500,
      // v1.9.86 更新源不再在设置页配置（已内置），这里不写 updateUrl——
      // 老客户手填过的值原样保留在设置里，checkForUpdate 里它优先于内置地址。
      xiangjiVendor: vendorSelect.value,
      // 密钥列表整体保存（含删除操作），空行会被丢弃
      xiangjiKeys: collectXiangjiKeyRows(),
      imagePresetId: imagePresetSelect.value,
      imageBaseUrl: cleanText($("#set-image-url").value),
      imageModel: cleanText($("#set-image-model").value),
      imageSize: cleanText($("#set-image-size").value) || "1024x1024",
      // 宽高比曾专供达瓦中转（它认 aspect_ratio），该预设已移除，统一留空走标准字段
      imageAspectRatio: "",
      imageApiKey: $("#set-image-key").value.trim(),
    });
    state.xiangjiKeyRows = null; // 重新从设置里生成，避免界面残留旧的编辑态
    fillSettingsForm();
    clearSettingsDirty();
    toast("设置已保存", "ok");
  });

  // 设置页里任何输入/下拉一变，就亮起「有未保存的改动」——
  // 防止「面板上填好了但没保存，实际跑的还是旧值」这种最难排查的错位。
  const settingsView = document.querySelector('[data-view="settings"]');
  if (settingsView) {
    for (const type of ["input", "change"]) {
      settingsView.addEventListener(type, () => markSettingsDirty());
    }
  }

  $("#btn-set-test").addEventListener("click", async () => {
    setBadge("#ai-status", "测试中…", "warn");
    // 带上界面上当前填的值：测的是「我刚填的这套」，不是上次保存的那套
    const response = await chrome.runtime.sendMessage({
      action: MESSAGE_ACTIONS.aiTestConnection,
      credentials: {
        baseUrl: cleanText($("#set-base-url").value),
        apiKey: $("#set-api-key").value.trim(),
        model: cleanText($("#set-model").value),
      },
    });
    // 后台会规范化 Base URL（补 https://、去全角冒号/零宽字符）；与原输入不同就写回输入框
    let fixed = "";
    if (response?.baseUrl && cleanText($("#set-base-url").value) !== response.baseUrl) {
      $("#set-base-url").value = response.baseUrl;
      fixed = `已把 Base URL 规范化为 ${response.baseUrl}，记得点「保存设置」`;
    }
    const tail = fixed ? `（${fixed}）` : "";
    if (response?.ok) {
      setBadge("#ai-status", "连接正常", "ok");
      toast(`连接正常${response.sample ? `：${response.sample}` : ""}${tail}`, "ok");
    } else {
      setBadge("#ai-status", "连接失败", "err");
      toast(`${response?.error || "连接失败"}${tail}`, "error");
    }
  });

  $("#btn-xiangji-test").addEventListener("click", () => {
    // 用「界面上当前的密钥行」来测，未保存的改动也能立刻验证
    const keys = collectXiangjiKeyRows();
    if (!keys.length) return toast("还没有可测试的密钥，请先添加", "error");
    runXiangjiTest({ keys });
  });

  $("#btn-image-test").addEventListener("click", () => {
    runImageTest({
      credentials: {
        baseUrl: cleanText($("#set-image-url").value),
        apiKey: $("#set-image-key").value.trim(),
        model: cleanText($("#set-image-model").value),
      },
    });
  });

  $("#btn-store-add").addEventListener("click", async () => {
    await openModal({
      title: "添加店铺",
      fields: STORE_FIELDS(),
      onSubmit: async (values) => {
        const name = cleanText(values.name);
        const clientId = cleanText(values.clientId);
        const apiKey = cleanText(values.apiKey);
        if (!name) throw new Error("请填写店铺名称");
        if (!clientId || !apiKey) throw new Error("请填写 Client-Id 与 Api-Key");
        const stores = [
          ...(state.settings.stores || []),
          { id: createId("store"), name, clientId, apiKey, skuPrefix: cleanText(values.skuPrefix) },
        ];
        state.settings = await saveSettings({ stores });
        renderStores();
        await renderBulkLists();
        toast("店铺已添加", "ok");
      },
    });
  });

  $("#btn-store-edit-default").addEventListener("click", () => editStore(""));

  $("#btn-export-all").addEventListener("click", async () => {
    const drafts = await listDrafts();
    if (!drafts.length) return toast("没有草稿", "error");
    exportXlsx(drafts, "ozon-drafts.xlsx");
    toast(`已导出 ${drafts.length} 条（XLSX）`, "ok");
  });

  $("#btn-export-listing-all").addEventListener("click", async () => {
    const drafts = await listDrafts();
    if (!drafts.length) return toast("没有草稿", "error");
    exportPreparedListing(drafts, "ozon-上架表-全部.xlsx");
  });

  $("#btn-export-csv").addEventListener("click", async () => {
    const drafts = await listDrafts();
    if (!drafts.length) return toast("没有草稿", "error");
    exportCsv(drafts, "ozon-drafts.csv");
    toast(`已导出 ${drafts.length} 条（CSV）`, "ok");
  });

  $("#btn-clear-all").addEventListener("click", async () => {
    const yes = await confirmDialog("确定清空全部草稿？此操作不可撤销。", { confirmText: "清空", danger: true });
    if (!yes) return;
    await clearDrafts();
    await refreshDraftOptions();
    toast("已清空");
  });

  // 预设下拉的选项是在本函数里才填进去的，而 init() 更早就调用过 fillSettingsForm()，
  // 那时下拉还是空的 → 保存的预设选不中。这里在选项就绪后重新回填一次。
  fillSettingsForm();
}

async function renderBulkLists() {
  const drafts = await listDrafts();
  const draftWrap = $("#bulk-drafts");
  draftWrap.innerHTML = "";
  if (!drafts.length) draftWrap.appendChild(el("p", { class: "muted", text: "还没有草稿" }));
  for (const draft of drafts) {
    const name = cleanText(draft.ru?.title || draft.title) || "(无标题)";
    const label = el("label", {}, [
      el("input", { type: "checkbox", class: "bulk-draft", value: draft.id }),
      el("span", {}, [
        name,
        el("div", { class: "sub", text: `${draft.skus?.length || 0} SKU · ${draft.images?.length || 0} 图${draft.pricing ? ` · ${draft.pricing.priceRub} RUB` : " · 未定价"}` }),
      ]),
    ]);
    // 每行带删除按钮：label 与按钮必须是兄弟节点，否则点删除会连带勾选/取消勾选
    const remove = el("button", {
      class: "danger mini",
      type: "button",
      text: "删除",
      title: `删除草稿「${name}」`,
      onclick: () => deleteDraftEverywhere(draft),
    });
    draftWrap.appendChild(el("div", { class: "check-row" }, [label, remove]));
  }

  const storeWrap = $("#bulk-stores");
  storeWrap.innerHTML = "";
  const stores = [{ id: "", name: "默认店铺" }, ...(state.settings.stores || [])];
  for (const store of stores) {
    storeWrap.appendChild(el("label", {}, [
      el("input", { type: "checkbox", class: "bulk-store", value: store.id }),
      el("span", { text: store.name }),
    ]));
  }

  updateBulkCount();
}

// 删除草稿：同步清理工作台状态与各处列表，避免删掉正在编辑的草稿后界面残留
async function deleteDraftEverywhere(draftOrId) {
  const id = typeof draftOrId === "string" ? draftOrId : draftOrId?.id;
  if (!id) return false;
  const name = typeof draftOrId === "string"
    ? id
    : (cleanText(draftOrId.ru?.title || draftOrId.title) || "(无标题)");
  const yes = await confirmDialog(`删除草稿「${name}」？该操作不可撤销。`, { confirmText: "删除", danger: true });
  if (!yes) return false;

  await deleteDraft(id);
  if (state.draft?.id === id) {
    state.draft = null;
    state.selectedImages.clear();
    state.selectedSkus.clear();
    renderEditor();
    updateWorkspaceVisibility();
  }
  await refreshDraftOptions();
  await renderBulkLists();
  toast("已删除草稿");
  return true;
}

function selectedBulkDraftIds() {
  return $$(".bulk-draft").filter((input) => input.checked).map((input) => input.value);
}

// 批量上传前的本地预检：返回还不能上传的草稿及原因（类目/类型/售价/名称）
async function preflightDrafts(ids) {
  const { assertReadyToImport } = await import("../background/ozon-api.js");
  const drafts = await listDrafts();
  const blocked = [];
  for (const id of ids) {
    const draft = drafts.find((item) => item.id === id);
    if (!draft) {
      blocked.push({ title: id, reason: "草稿不存在" });
      continue;
    }
    try {
      assertReadyToImport(draft, {
        category: draft.ozonCategory || {},
        pricing: draft.pricing || {},
        variantAttributeId: Number($("#ozon-variant-attr")?.value) || 0,
        selectedSkus: Array.isArray(draft.selectedSkus)
          ? (draft.skus || []).filter((sku) => draft.selectedSkus.includes(sku.id))
          : [],
      });
    } catch (error) {
      blocked.push({ title: cleanText(draft.ru?.title || draft.title) || "(无标题)", reason: error.message });
    }
  }
  return blocked;
}

function updateBulkCount() {
  const node = $("#bulk-count");
  if (node) node.textContent = `已选 ${selectedBulkDraftIds().length} 个草稿`;
}

function bindBulkUpload() {
  $("#bulk-drafts").addEventListener("change", (event) => {
    if (event.target.classList.contains("bulk-draft")) updateBulkCount();
  });

  $("#btn-bulk-refresh").addEventListener("click", async () => {
    await renderBulkLists();
    toast("列表已刷新");
  });

  $("#btn-bulk-delete").addEventListener("click", async () => {
    const ids = selectedBulkDraftIds();
    if (!ids.length) return toast("请先勾选要删除的草稿", "error");
    const yes = await confirmDialog(
      `删除选中的 ${ids.length} 个草稿？删掉后其采集内容、文案、定价、图片筛选结果都会一并丢失，且不可撤销。`,
      { confirmText: "删除", danger: true },
    );
    if (!yes) return;
    const removingCurrent = ids.includes(state.draft?.id);
    for (const id of ids) await deleteDraft(id);
    if (removingCurrent) {
      state.draft = null;
      state.selectedImages.clear();
      state.selectedSkus.clear();
      renderEditor();
      updateWorkspaceVisibility();
    }
    await refreshDraftOptions();
    await renderBulkLists();
    toast(`已删除 ${ids.length} 个草稿`);
  });

  $("#btn-bulk-start").addEventListener("click", async () => {
    if (!await ensureLicensed("批量上传 Ozon")) return;
    const draftIds = selectedBulkDraftIds();
    const storeIds = $$(".bulk-store").filter((input) => input.checked).map((input) => input.value).filter(Boolean);
    if (!draftIds.length) return toast("请至少选择一个草稿", "error");

    // 上传前逐条预检，避免整批提交后才在结果表里看到一堆 Ozon 英文 400
    const blocked = await preflightDrafts(draftIds);
    if (blocked.length) {
      setBadge("#bulk-status", "预检未通过", "err");
      renderTable("#bulk-table", [
        { key: "title", label: "商品" },
        { key: "reason", label: "无法上传的原因" },
      ], blocked);
      toast(`有 ${blocked.length} 个草稿还不能上传，原因见下表`, "error");
      return;
    }

    const storeCount = storeIds.length || 1;
    const total = draftIds.length * storeCount;
    const yes = await confirmDialog(
      `将提交 ${draftIds.length} 个草稿 × ${storeCount} 个店铺 = ${total} 次上传请求。确认执行？`,
      { confirmText: "开始上传" },
    );
    if (!yes) return;

    setBadge("#bulk-status", "上传中…", "warn");
    try {
      const data = await call({
        action: MESSAGE_ACTIONS.ozonBulkImport,
        draftIds,
        storeIds,
        options: {
          weightGrams: Number($("#ozon-weight").value) || undefined,
          depthMm: Number($("#ozon-depth").value) || undefined,
          widthMm: Number($("#ozon-width").value) || undefined,
          heightMm: Number($("#ozon-height").value) || undefined,
          vat: $("#ozon-vat").value,
          variantAttributeId: Number($("#ozon-variant-attr")?.value) || undefined,
        },
      });
      renderTable("#bulk-table", [
        { key: "store", label: "店铺" },
        { key: "title", label: "商品" },
        { key: "count", label: "条目", render: (row) => (row.count ?? 1) },
        { key: "ok", label: "结果", render: (row) => (row.ok ? "成功" : "失败") },
        { key: "taskId", label: "任务 ID" },
        { key: "error", label: "错误" },
      ], data?.results || []);
      setBadge("#bulk-status", `成功 ${data?.succeeded || 0}/${data?.total || 0}`, data?.succeeded === data?.total ? "ok" : "warn");
      toast(`批量上传结束：成功 ${data?.succeeded || 0} / ${data?.total || 0}`, "ok");
    } catch (error) {
      setBadge("#bulk-status", "失败", "err");
      toast(error.message, "error");
    }
  });
}

function maskSecret(value) {
  const text = cleanText(value);
  if (!text) return "";
  if (text.length <= 8) return "••••••";
  return `${text.slice(0, 4)}••••${text.slice(-4)}`;
}

function storeRows() {
  const settings = state.settings || {};
  return [
    {
      id: "",
      name: "默认店铺",
      clientId: settings.ozonClientId || "",
      apiKey: settings.ozonApiKey || "",
      skuPrefix: settings.skuPrefix || "",
      isDefault: true,
    },
    ...(settings.stores || []).map((store) => ({ ...store, isDefault: false })),
  ];
}

function renderStores() {
  renderTable("#store-table", [
    { key: "name", label: "店铺" },
    { key: "clientId", label: "Client-Id", render: (row) => maskSecret(row.clientId) || "未填写" },
    { key: "apiKey", label: "Api-Key", render: (row) => (row.apiKey ? "已保存 ••••••" : "未填写") },
    { key: "skuPrefix", label: "SKU 前缀" },
    {
      key: "_actions",
      label: "操作",
      html: true,
      render: (row) => [
        `<button data-store-test="${row.id}">测试</button>`,
        `<button data-store-edit="${row.id}">编辑</button>`,
        row.isDefault ? "" : `<button data-store-del="${row.id}" class="danger">删除</button>`,
      ].join(" "),
    },
  ], storeRows());

  for (const button of $$("#store-table button[data-store-test]")) {
    button.addEventListener("click", () => testStore(button.dataset.storeTest));
  }
  for (const button of $$("#store-table button[data-store-edit]")) {
    button.addEventListener("click", () => editStore(button.dataset.storeEdit));
  }
  for (const button of $$("#store-table button[data-store-del]")) {
    button.addEventListener("click", () => removeStore(button.dataset.storeDel));
  }

  // 重建下拉时保留当前选择，避免刷新表格后店铺被悄悄切回默认
  const select = $("#store-select");
  const previous = currentStoreId();
  select.innerHTML = '<option value="">默认店铺</option>';
  for (const store of state.settings.stores || []) {
    select.appendChild(el("option", { value: store.id, text: store.name }));
  }
  if ([...select.options].some((option) => option.value === previous)) select.value = previous;
}

async function testStore(id) {
  setBadge("#ozon-status", "测试中…", "warn");
  const response = await chrome.runtime.sendMessage({ action: MESSAGE_ACTIONS.ozonTestConnection, storeId: id });
  if (response?.ok) {
    setBadge("#ozon-status", `已连接（商品 ${response.data?.total ?? "?"}）`, "ok");
    toast("连接正常", "ok");
  } else {
    setBadge("#ozon-status", "连接失败", "err");
    toast(response?.error || "连接失败", "error");
  }
}

const STORE_FIELDS = (existing = {}) => [
  { key: "name", label: "店铺名称", value: existing.name || "", placeholder: "如：主店 / 二号店" },
  { key: "clientId", label: "Client-Id", value: existing.clientId || "", placeholder: "卖家后台 API 密钥页获取" },
  { key: "apiKey", label: "Api-Key", type: "password", value: existing.apiKey || "", hint: "留空表示不修改已保存的 Key" },
  { key: "skuPrefix", label: "SKU 前缀（可选）", value: existing.skuPrefix || "", placeholder: "用于区分多店 offer_id" },
];

async function editStore(id) {
  const row = storeRows().find((item) => item.id === id);
  if (!row) return;

  if (row.isDefault) {
    await openModal({
      title: "编辑默认店铺凭证",
      fields: [
        { key: "clientId", label: "Client-Id", value: row.clientId },
        { key: "apiKey", label: "Api-Key", type: "password", value: "", hint: "留空表示不修改已保存的 Key" },
      ],
      onSubmit: async (values) => {
        const patch = { ozonClientId: cleanText(values.clientId) };
        if (values.apiKey) patch.ozonApiKey = values.apiKey;
        state.settings = await saveSettings(patch);
        renderStores();
        toast("默认店铺凭证已保存", "ok");
      },
    });
    return;
  }

  await openModal({
    title: `编辑店铺：${row.name}`,
    fields: STORE_FIELDS(row),
    onSubmit: async (values) => {
      const stores = (state.settings.stores || []).map((store) =>
        store.id === id
          ? {
              ...store,
              name: cleanText(values.name) || store.name,
              clientId: cleanText(values.clientId),
              apiKey: values.apiKey ? values.apiKey : store.apiKey,
              skuPrefix: cleanText(values.skuPrefix),
            }
          : store,
      );
      state.settings = await saveSettings({ stores });
      renderStores();
      await renderBulkLists();
      toast("店铺已更新", "ok");
    },
  });
}

async function removeStore(id) {
  const row = storeRows().find((item) => item.id === id);
  if (!row) return;
  const ok = await confirmDialog(`确定删除店铺「${row.name}」？此操作不可撤销。`, { confirmText: "删除", danger: true });
  if (!ok) return;
  const stores = (state.settings.stores || []).filter((store) => store.id !== id);
  state.settings = await saveSettings({ stores });
  renderStores();
  await renderBulkLists();
  toast("店铺已删除");
}

function fillSettingsForm() {
  const s = state.settings;
  $("#set-preset").value = s.aiPresetId || "deepseek";
  $("#set-base-url").value = s.aiBaseUrl || "";
  $("#set-model").value = s.aiModel || "";
  $("#set-vision-model").value = s.aiVisionModel || "";
  $("#set-api-key").value = s.aiApiKey || "";
  $("#set-sku-prefix").value = s.skuPrefix || "";
  $("#set-bulk-delay").value = s.bulkDelayMs ?? 1500;
  // 象寄：Key 不回填（避免明文出现在页面上），已保存的行只显示占位提示
  state.xiangjiKeyRows = null;
  renderXiangjiKeyTable();
  $("#set-xiangji-vendor").value = s.xiangjiVendor || "DeepL";
  // 达瓦 ERP 中转预设已移除；老用户设置里残留的 dawaerp 归到「自定义」，避免下拉空选
  $("#set-image-preset").value = IMAGE_PRESETS.some((item) => item.id === s.imagePresetId) ? (s.imagePresetId || "") : (s.imagePresetId ? "custom" : "");
  $("#set-image-url").value = s.imageBaseUrl || "";
  $("#set-image-model").value = s.imageModel || "";
  $("#set-image-size").value = s.imageSize || "1024x1024";
  $("#set-image-key").value = s.imageApiKey || "";
  // 生图模型的候选名：按已保存的预设填上。否则这个输入框的下拉一直是空的
  // （只有手动切一次「服务预设」才会被填上），用户容易自己瞎填一个名字。
  const savedImagePreset = IMAGE_PRESETS.find((item) => item.id === s.imagePresetId);
  const imageModelList = $("#image-model-options");
  if (imageModelList) {
    imageModelList.innerHTML = "";
    for (const model of savedImagePreset?.models || []) imageModelList.appendChild(el("option", { value: model }));
  }
  // 出图尺寸的候选项：同样按预设填充。custom 预设没有 supportedSizes 时退回到静态默认列表
  renderImageSizeOptions();
  renderImagePresetNote();
  renderItVendorOptions();
  // 设置被改动后，上一次的检测结论就失效了，重置为「未测试」避免误导
  const xjResult = $("#xiangji-test-result");
  if (xjResult) xjResult.hidden = true;
  setBadge("#xiangji-status", "未测试", "");
  const imageResult = $("#image-test-result");
  if (imageResult) { imageResult.hidden = true; imageResult.textContent = ""; }
  setBadge("#image-status", "未测试", "");
  const preset = AI_PRESETS.find((item) => item.id === s.aiPresetId);
  const list = $("#model-options");
  list.innerHTML = "";
  for (const model of preset?.models || []) list.appendChild(el("option", { value: model }));
  renderStores();
  // 刚载入/刚保存完，界面与存储是一致的
  clearSettingsDirty();
}

/**
 * 清掉上一次的生图检测结论。
 * 必须在「生图配置被改动」时调用：结论里写着当时用的模型名/地址，
 * 改了输入框却不清结论，就会出现「框里是 gpt-image-2、结论却写着别的模型名」的错位，
 * 让人以为那个模型名是插件自己冒出来的。
 */
function clearImageTestResult() {
  const box = $("#image-test-result");
  if (box) { box.hidden = true; box.textContent = ""; }
  setBadge("#image-status", "未测试", "");
}

/** 同上，AI 文案连接检测的角标 */
function clearAiTestResult() {
  setBadge("#ai-status", "未测试", "");
}

/**
 * 「有未保存的改动」提示。
 * 存在两种状态不一致：面板上填了但没保存 → 后台仍按旧值跑。
 * 这个角标就是为它存在的，改任何设置项就会亮起来。
 */
function markSettingsDirty() {
  const badge = $("#settings-dirty");
  if (badge) badge.hidden = false;
}

function clearSettingsDirty() {
  const badge = $("#settings-dirty");
  if (badge) badge.hidden = true;
}

function renderImagePresetNote() {
  const box = $("#image-preset-note");
  if (!box) return;
  const presetId = $("#set-image-preset")?.value || "";
  const preset = IMAGE_PRESETS.find((item) => item.id === presetId);
  const baseUrl = cleanText($("#set-image-url")?.value);
  const size = cleanText($("#set-image-size")?.value);
  const parts = [];
  if (preset?.note) parts.push(preset.note);
  // 把「实际会请求哪个地址」直接摆出来：填错 / 少了 /v1 时一眼就能看出来
  const endpoint = imagesEndpoint(baseUrl);
  if (endpoint) {
    parts.push(`实际请求：POST ${endpoint}${size ? `（尺寸 ${size}）` : ""}`);
  } else if (!baseUrl) {
    parts.push("还没填 生图 Base URL，填好后这里会显示实际请求的地址。");
  }
  box.textContent = parts.join(" ");
  box.hidden = !parts.length;
  // 尺寸是否在当前预设的支持列表里 —— 单独成段，方便看清；尺寸候选项也跟着刷新
  renderImageSizeOptions();
  renderImageSizeHint();
  renderImageModelHint();
}

/**
 * 校验当前填的生图模型名是否在预设的 models 列表里。
 * - 在 → 提示一句「OK」；
 * - 不在 → 列出预设支持的模型，让用户立刻看出哪个名字应该用；
 * - 预设没列模型（如自定义）→ 提醒「直接填就行」。
 *
 * 这条提示的关键价值：哪怕存储里残留了一个历史值（如「通用」），打开设置页就立刻知道
 * 「这个模型名不在当前预设里」，免得实际生图时服务返回 400 还以为是别的问题。
 */
function renderImageModelHint() {
  const box = $("#image-model-hint");
  if (!box) return;
  const presetId = $("#set-image-preset")?.value || "";
  const preset = IMAGE_PRESETS.find((item) => item.id === presetId);
  const model = cleanText($("#set-image-model")?.value);
  if (!model) { box.textContent = ""; box.className = "hint"; box.hidden = true; return; }
  const presetModels = Array.isArray(preset?.models) ? preset.models : [];
  if (!presetModels.length) {
    box.textContent = `当前预设（${preset?.name || "自定义"}）未列出可用模型，可直接填写`;
    box.className = "hint"; box.hidden = false;
    return;
  }
  if (presetModels.includes(model)) {
    box.textContent = `当前模型「${model}」在「${preset?.name}」预设的可用模型列表里`;
    box.className = "hint ok-text"; box.hidden = false;
    return;
  }
  // 不在：列出预设支持的模型，让用户能直接对到；说明「这是你当前填的值」避免以为又是插件冒出来的
  box.textContent = `当前预设「${preset?.name}」支持的模型：${presetModels.join("、")}。你填的是「${model}」—— 不在列表里，保存后实际生图/重绘会用「${model}」去请求，服务大概率拒绝。建议：从下拉选一个，或把「服务预设」切回原本匹配的预设`;
  box.className = "hint warn-text"; box.hidden = false;
}

/**
 * 把当前预设的 supportedSizes 同步进 #image-size-options datalist；
 * 切预设时第一手给到候选，custom/空 supportedSizes 时退回到静态默认列表
 */
function renderImageSizeOptions() {
  const list = $("#image-size-options");
  if (!list) return;
  const presetId = $("#set-image-preset")?.value || "";
  const preset = IMAGE_PRESETS.find((item) => item.id === presetId);
  const model = cleanText($("#set-image-model")?.value);
  const supported = effectiveSupportedSizes(preset, model);
  const sizes = supported.length
    ? supported
    : ["1024x1024", "1024x1536", "1536x1024", "1344x1008", "1008x1344"];
  list.innerHTML = "";
  for (const size of sizes) list.appendChild(el("option", { value: size }));
}

/**
 * 校验当前输入的出图尺寸，把「在不在官方支持里」的结论写到 #image-size-hint
 * 错误（格式不对）直接给中文提示；警告（在列表外）保留但仍允许
 */
function renderImageSizeHint() {
  const box = $("#image-size-hint");
  if (!box) return;
  const presetId = $("#set-image-preset")?.value || "";
  const preset = IMAGE_PRESETS.find((item) => item.id === presetId);
  const size = cleanText($("#set-image-size")?.value);
  const model = cleanText($("#set-image-model")?.value);
  if (!size) { box.textContent = ""; box.className = "hint"; box.hidden = true; return; }
  const check = validateImageSize(preset, size, model);
  const supported = effectiveSupportedSizes(preset, model);
  if (!check.ok) {
    box.textContent = check.error;
    box.className = "hint danger-text";
    box.hidden = false;
    return;
  }
  if (check.warning) {
    box.textContent = check.warning + (supported.length ? `；候选项已按当前预设（${preset?.name || ""}）更新：${supported.join("、")}` : "");
    box.className = "hint warn-text";
    box.hidden = false;
    return;
  }
  // 正常：给一行小字确认，省得用户猜这是不是被记下来
  box.textContent = `当前预设（${preset?.name || "自定义"}）官方支持尺寸：${supported.join("、") || "未列明（自定义预设），按需填写"}`;
  box.className = "hint";
  box.hidden = false;
}

/**
 * 「整段渠道配置」智能粘贴。
 * new-api 系中转（含 api.siliconflow.cn）后台复制出来的是一段 JSON：
 *   {"_type":"newapi_channel_conn","key":"sk-xxx","url":"https://api.siliconflow.cn"}
 * 用户很自然地会把它整段粘进 Base URL 输入框，然后被格式校验挡下。
 * 这里在粘贴/失焦的瞬间就把它拆开：url 写进地址框，key 补进密钥框（已有值则不覆盖）。
 */
function bindApiConfigPaste(urlSelector, keySelector = "") {
  const input = $(urlSelector);
  if (!input) return;
  const apply = () => {
    const picked = extractApiConfig(input.value);
    if (!picked.url && !picked.key) return;
    const filled = [];
    if (picked.url) {
      input.value = normalizeApiBase(picked.url);
      filled.push("地址");
    }
    if (picked.key && keySelector) {
      const keyInput = $(keySelector);
      if (keyInput && !cleanText(keyInput.value)) {
        keyInput.value = picked.key;
        filled.push("密钥");
      }
    }
    input.dispatchEvent(new Event("input", { bubbles: true }));
    if (filled.length) toast(`已从粘贴的渠道配置里识别出${filled.join("和")}，记得点「保存设置」`, "ok");
  };
  // paste 事件里读不到新值，等一拍再解析
  input.addEventListener("paste", () => setTimeout(apply, 0));
  input.addEventListener("blur", apply);
}

/** 上架工作台里的翻译引擎下拉：只列出「已经配好密钥」的引擎，避免选了却用不了 */
function renderItVendorOptions() {
  const select = $("#it-vendor");
  if (!select) return;
  const configured = xiangjiConfiguredVendors(state.settings || {});
  const current = select.value || state.settings?.xiangjiVendor || "";
  select.innerHTML = "";

  const pool = configured.length ? XIANGJI_VENDORS.filter((v) => configured.includes(v.id)) : [];
  if (!pool.length) {
    select.appendChild(el("option", { value: "", text: "（尚未配置密钥）" }));
    select.disabled = true;
    return;
  }
  select.disabled = false;
  for (const vendor of pool) {
    const count = (state.settings?.xiangjiKeys || []).filter((item) => item.vendor === vendor.id).length;
    select.appendChild(el("option", { value: vendor.id, text: `${vendor.label}${count > 1 ? `（${count} 把密钥并行）` : ""}` }));
  }
  const prefer = configured.includes(current) ? current : (configured.includes(state.settings?.xiangjiVendor) ? state.settings.xiangjiVendor : configured[0]);
  select.value = prefer;
}

/* ---------------- 启动 ---------------- */

// ============ v1.9.59 订阅授权：状态条 + 激活窗 ============

/** 顶部授权徽章：试用中（绿）/ 已授权至 X（绿）/ 已到期（红，点击续费） */
function renderLicenseBadge(status) {
  const node = $("#license-badge");
  if (!node) return;
  if (!status) { node.hidden = true; return; }
  node.hidden = false;
  if (status.kind === "licensed") {
    node.textContent = `已授权 · ${new Date(status.exp).toLocaleDateString("zh-CN")} 到期${status.name ? ` · ${status.name}` : ""}`;
    node.className = "license-badge ok";
  } else if (status.kind === "trial") {
    node.textContent = `试用剩余 ${trialHoursLeft(status)} 小时 · 点我激活`;
    node.className = "license-badge trial";
  } else {
    node.textContent = status.reason && !/到期/.test(status.reason) ? "授权无效 · 点我处理" : "试用已结束 · 点我激活";
    node.className = "license-badge bad";
  }
  node.onclick = () => openLicenseModal("", status);
}

window.__openLicenseModal = (feature, preset) => openLicenseModal(feature, preset);

function openLicenseModal(feature, preset) {
  const old = document.querySelector(".license-overlay");
  if (old) old.remove();
  const overlay = el("div", { class: "modal-overlay license-overlay" });
  const midText = preset?.machineId ? formatMachineId(preset.machineId) : "读取中…";
  const copyMid = () => {
    const mid = $("#lic-mid-code")?.textContent || "";
    navigator.clipboard.writeText(mid.replace(/-/g, "")).then(() => toast("机器码已复制（无横线版）", "ok"));
  };
  const box = el("div", { class: "modal license-modal" }, [
    el("h3", { text: "激活订阅" }),
    feature ? el("p", { class: "hint", text: `「${feature}」是订阅功能。激活后立即可用，采集/草稿/核价/类目属性/导出等基础功能永久免费。` })
      : el("p", { class: "hint", text: "订阅功能激活页。基础功能（采集、草稿、核价、类目属性、导出）永久免费。" }),
    preset?.reason ? el("p", { class: "license-reason", text: preset.reason }) : null,
    el("div", { class: "license-mid" }, [
      el("span", { class: "k", text: "本机机器码" }),
      el("code", { id: "lic-mid-code", text: midText }),
      el("button", { class: "mini", type: "button", text: "复制", onclick: copyMid }),
    ]),
    el("p", { class: "hint", text: "把机器码发给客服（微信：OZON 插件购买入口见发布帖），收到激活码粘贴到下面即可。一码绑一机，换电脑找客服换绑。" }),
    el("textarea", { id: "lic-input", placeholder: "粘贴激活码（形如 xxx.yyy 的一长串）", rows: 3 }),
    el("div", { class: "row", style: "margin-top:10px" }, [
      el("button", { class: "primary", type: "button", text: "激活", id: "lic-activate" }),
      el("button", { type: "button", text: "关闭", id: "lic-close" }),
    ]),
  ]);
  overlay.append(box);
  document.body.append(overlay);
  const close = () => overlay.remove();
  overlay.addEventListener("click", (e) => { if (e.target === overlay) close(); });
  document.addEventListener("keydown", function onKey(e) { if (e.key === "Escape") { close(); document.removeEventListener("keydown", onKey); } });
  $("#lic-close").onclick = close;
  if (!preset?.machineId) {
    getMachineId().then((mid) => { $("#lic-mid-code").textContent = formatMachineId(mid); }).catch(() => { $("#lic-mid-code").textContent = "获取失败，重启面板重试"; });
  }
  $("#lic-activate").onclick = async () => {
    const btn = $("#lic-activate");
    btn.disabled = true;
    try {
      const result = await activateLicense($("#lic-input").value);
      if (!result.ok) { toast(result.reason, "error"); return; }
      toast(`激活成功，授权至 ${new Date(result.exp).toLocaleDateString("zh-CN")}`, "ok");
      close();
      renderLicenseBadge(await getLicenseStatus());
    } catch (error) {
      toast(`激活失败：${error.message}`, "error");
    } finally {
      btn.disabled = false;
    }
  };
}

async function ensureLicensed(feature) {
  const st = await getLicenseStatus();
  renderLicenseBadge(st);
  if (st.kind === "licensed" || st.kind === "trial") {
    if (st.kind === "trial" && st.trialLeftMs && st.trialLeftMs < 2 * 3600000) {
      toast(`试用还剩约 ${Math.round(st.trialLeftMs / 3600000)} 小时，用完后订阅功能需激活（基础功能不受影响）`, "warn");
    }
    return true;
  }
  openLicenseModal(feature, st);
  return false;
}

async function init() {
  state.settings = await loadSettings();
  await loadCategoryZhCache();
  getLicenseStatus().then(renderLicenseBadge).catch(() => {});
  fillSettingsForm();  renderListingForm();
  renderListingResult();
  await refreshDraftOptions();
  bindTabs();
  bindWorkspace();
  updateWorkspaceVisibility();
  bindCapture();
  bindEditor();
  bindSkuSelection();
  bindListing();
  bindImages();
  bindImageTranslate();
  bindOzon();
  bindBulkUpload();
  bindOps();
  bindAiPipeline();
  bindSettings();
  bindPlan();
  renderBulkLists();
  // 把当前加载的插件版本显示在顶栏：改完代码后如果这里没变成新版本号，
  // 说明扩展没重新加载（或者这个面板标签页还是旧页面）——扩展页面不会随扩展重载自动刷新，
  // 必须把这个标签页关掉重开。用户反馈「你根本没给我改动」多半就是这个原因。
  const versionNode = $("#ext-version");
  if (versionNode) {
    try { versionNode.textContent = `v${chrome.runtime.getManifest().version}`; }
    catch { versionNode.textContent = "v?"; }
    // v1.9.80：点版本号检查更新（更新源在「插件设置 → 通用 → 更新源地址」配置）
    versionNode.title = "点击检查新版本";
    versionNode.addEventListener("click", () => checkForUpdate(versionNode));
    // v1.9.87 打开面板 3 秒后自动查一次（6 小时节流，静默不打扰）
    setTimeout(() => autoCheckUpdate(versionNode), 3000);
  }
  refreshProductTabs();
}

/** 版本号比较：a>b 返回 1，a<b 返回 -1，相等 0（按 . 分段比数字，非数字段按 0） */
function compareVersions(a, b) {
  const pa = String(a || "").split(".").map((n) => Number(n) || 0);
  const pb = String(b || "").split(".").map((n) => Number(n) || 0);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    const x = pa[i] || 0, y = pb[i] || 0;
    if (x !== y) return x > y ? 1 : -1;
  }
  return 0;
}

/**
 * v1.9.80 检查更新：从更新源 JSON 拉 {version, url, notes}，
 * 比当前版本新就弹确认框，确认后走 chrome.downloads 下载 zip，
 * 并给出「解压覆盖 → chrome://extensions 重新加载」的安装指引。
 * 扩展不能自己换自己的代码（MV3 无静默自更新），下载 + 指引已是产品级上限。
 */
async function checkForUpdate(versionNode) {
  const current = (() => { try { return chrome.runtime.getManifest().version; } catch { return ""; } })();
  // v1.9.86 更新源内置：优先用发布者打进 constants.js 的地址；
  // 老客户在旧版本设置里手填过的仍然优先（灰度渠道），没填就直接走内置——点版本号即查，零配置。
  const url = cleanText(state.settings?.updateUrl) || cleanText(BUILT_IN_UPDATE_URL);
  if (!url) {
    // 只有开发者构建（没配内置地址）才会走到这里
    await confirmDialog(
      "这个构建没有内置更新源地址。\n\n请联系发布者获取最新安装包。",
      { confirmText: "知道了" },
    );
    return;
  }
  if (versionNode) versionNode.classList.add("checking");
  versionNode && (versionNode.textContent = "检查中…");
  try {
    const info = await fetchUpdateInfo({ force: true });
    if (info.error) throw new Error(info.error);
    if (!info.latest) throw new Error("更新源返回的 JSON 里没有 version 字段");
    if (compareVersions(info.latest, current) <= 0) {
      toast(`已是最新版本 v${current}`, "ok");
      return;
    }
    await promptUpdate({ current, ...info, versionNode });
  } catch (error) {
    toast(`检查更新失败：${error?.message || error}（更新源需允许跨域访问，或联系发布者确认地址）`, "error");
  } finally {
    if (versionNode) {
      versionNode.classList.remove("checking");
      versionNode.textContent = `v${current}`;
    }
  }
}

/**
 * v1.9.87 拉更新源信息（带 6 小时节流缓存，force 跳过）。
 * v1.9.89 双源回落：主源（GitHub raw）失败自动试备源（jsDelivr CDN 镜像同一仓库）。
 * 哪个源通拿到的 JSON 内容完全一样（备源就是 GitHub 的 CDN 缓存）；
 * viaMirror 会传给下载环节——主源 fetch 不通的机器，下 zip 也大概率不通，直接用镜像链。
 * 网络失败不写缓存、也不抛异常——返回 { error }，调用方决定怎么表现。
 */
async function fetchUpdateInfo({ force = false } = {}) {
  const sources = [
    cleanText(state.settings?.updateUrl),
    cleanText(BUILT_IN_UPDATE_URL),
    cleanText(BUILT_IN_UPDATE_MIRROR),
  ].filter(Boolean).filter((url, i, arr) => arr.indexOf(url) === i);
  if (!sources.length) return { error: "no-source" };
  if (!force) {
    try {
      const cached = await chrome.storage.local.get(STORAGE_KEYS.updateCheck);
      const hit = cached?.[STORAGE_KEYS.updateCheck];
      if (hit && Date.now() - (hit.at || 0) < 6 * 3600 * 1000) {
        return { ...hit.info, cached: true };
      }
    } catch { /* 读缓存失败当没有，继续打网络 */ }
  }
  let lastError = "no-source";
  for (let i = 0; i < sources.length; i += 1) {
    const url = sources[i];
    try {
      const response = await fetch(`${url}${url.includes("?") ? "&" : "?"}t=${Date.now()}`, { cache: "no-store" });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      const raw = await response.json();
      const info = {
        latest: cleanText(raw?.version),
        zipUrl: cleanText(raw?.url),
        zipUrl2: cleanText(raw?.url2),
        notes: cleanText(raw?.notes),
        viaMirror: i > 0 && !state.settings?.updateUrl,
      };
      if (info.latest) {
        chrome.storage.local.set({ [STORAGE_KEYS.updateCheck]: { at: Date.now(), info } }).catch(() => {});
      }
      return info;
    } catch (error) {
      lastError = error?.message || String(error);
    }
  }
  return { error: lastError };
}

/** 发现新版的统一弹窗：下载 zip + 三步指引 + 自动打开扩展管理页（v1.9.87）
 *  v1.9.89：检查走的备源（GitHub 不通）→ 下载也优先备源镜像链（url2），一次到位不折腾 */
async function promptUpdate({ current, latest, zipUrl, zipUrl2, notes, viaMirror, versionNode }) {
  const downloadUrl = (viaMirror && zipUrl2) ? zipUrl2 : zipUrl;
  if (!downloadUrl) {
    await confirmDialog(`发现新版本 v${latest}（当前 v${current}）\n\n${notes || ""}\n\n但更新源没给下载地址，请联系发布者。`, { confirmText: "知道了" });
    return;
  }
  const yes = await confirmDialog(
    `发现新版本 v${latest}（当前 v${current}）\n\n更新说明：${notes || "（发布者未填写）"}\n\n点「升级」自动下载更新包，然后：\n1. 解压，用新文件夹覆盖旧的扩展文件夹；\n2. 在即将自动打开的扩展管理页里，点 OWA 卡片上的重新加载↻；\n3. 关掉本面板标签页重新打开。\n\n（激活码、草稿、设置都在浏览器存储里，覆盖文件夹不会丢，不需要重新激活。）`,
    { confirmText: "升级" },
  );
  if (!yes) return;
  const filename = downloadUrl.split("/").pop().split("?")[0] || `OWA-V${latest}.zip`;
  await chrome.downloads.download({ url: downloadUrl, filename, saveAs: true });
  toast(`正在下载 ${filename}，下载完按弹窗里的三步安装`, "ok");
  // 替客户把 chrome://extensions 打开——指引第 2 步不用再自己输地址
  try { await chrome.tabs.create({ url: "chrome://extensions" }); } catch { /* 打不开不影响下载 */ }
  if (versionNode) versionNode.classList.remove("has-update");
}

/**
 * v1.9.87 打开面板自动查更新（3 秒后跑，6 小时节流）。
 * 静默：无新版/失败都不出声；有新版只把版本号徽章变红脉冲 + 一条 toast，
 * 不弹模态打断正在操作的客户——点徽章即走下载升级流程。
 */
async function autoCheckUpdate(versionNode) {
  try {
    const current = (() => { try { return chrome.runtime.getManifest().version; } catch { return ""; } })();
    if (!current) return;
    const info = await fetchUpdateInfo();
    if (info.error || !info.latest) return;
    if (compareVersions(info.latest, current) <= 0) return;
    if (versionNode) {
      versionNode.classList.add("has-update");
      versionNode.title = `发现新版本 v${info.latest}，点击升级`;
    }
    toast(`发现新版本 v${info.latest}（当前 v${current}），点左上角版本号即可升级`, "warn");
  } catch { /* 自动检查永远静默失败，不打扰 */ }
}

init().catch((error) => {
  console.error(error);
  toast(`面板初始化失败：${error?.message || error}`, "error");
});
