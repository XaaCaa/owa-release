// 逻辑冒烟测试：定价模型 + XLSX 产物可被标准 zip 读取
import fs from "fs";
import path from "path";
import vm from "node:vm";
import { execFileSync } from "node:child_process";
import { fileURLToPath, pathToFileURL } from "node:url";
import { priceForCost, normalizePricingTemplate, LOGISTICS_MODES, LEGACY_LOGISTICS_MODE_MAP } from "../src/shared/pricing.js";
import {
  OZON_CHANNELS, findOzonChannel, pickOzonChannel, ozonLogisticsCny,
  normalizeListingTemplate, DEFAULT_LISTING_TEMPLATE, evaluateListing, suggestPriceCny, computeListing,
  splitCostCny,
} from "../src/shared/pricing.js";
import { LISTING_HEADERS, draftToListingRows } from "../src/ui/exporter.js";
import { buildXlsxBlob, EXPORT_HEADERS, draftToRows } from "../src/ui/exporter.js";
import {
  buildRedrawPrompt, buildShotPrompt, findKind, findShot, allShots, expandSetShots, planSetShots,
  IMAGE_KINDS, DEFAULT_SET_KINDS, DEFAULT_SET_COUNT, MAX_SET_SHOTS,
  TEXT_MODES, FALLBACK_TITLES, MAX_REFERENCE_IMAGES, STYLE_BY_CATEGORY, pickStyleFor,
  IMAGE_HARD_RULES, STYLE_DIRECTIONS, assignSetDirections, INFO_LAYOUT_LINES, SKU_MAIN_SHOT,
  INFO_LAYOUT_VARIANTS, LAYOUT_LABELS, pickInfoLayout, pickFraming, assignShotVariants, nextShotVariant,
} from "../src/shared/image-prompts.js";
import {
  translateImagesWithXiangji, chunkImages, testXiangjiKey, testXiangjiKeys, testImageGeneration, redrawImage,
} from "../src/background/image-service.js";
import { normalizeXiangjiKeys, resolveXiangjiCredentials, xiangjiConfiguredVendors, resolveImageCredentials } from "../src/shared/settings.js";
// v1.9.73 策划师模式核心模块（纯函数，Node 可直测）
import {
  buildPlanMessages, parsePlanResult, buildPlannedPrompt, renderPlanMarkdown,
  PLAN_8_SHOTS, PLAN_ASPECT,
} from "../src/shared/image-plan.js";
import { IMAGE_PRESETS, validateImageSize, effectiveSupportedSizes, pickListingSetSize,
  IMAGE_SIZE_RATIOS, IMAGE_SIZE_TIERS, DEFAULT_SIZE_RATIO, DEFAULT_SIZE_TIER,
  sizeForRatio, sizeRatioValue, ratioLabelValue, resolveProviderSize, findSizeRatio,
} from "../src/shared/constants.js";
import { normalizeApiBase, imagesEndpoint, modelsEndpoint, extractApiConfig, highResImageUrl, normalizeImageUrl } from "../src/shared/utils.js";
import { offlineAttributeToDefinition, offlineDictionaryState, enrichAttributesFromOffline, attrTypeZh } from "../src/shared/offline-kb.js";
import { verifyLicense, normalizeMachineId, formatMachineId } from "../src/shared/license.js";
import { buildChatEndpoint } from "../src/background/ai-client.js";
import { buildImportItem, buildImportItems, fetchCategoryTree, assertReadyToImport, buildVariantAttributes, resolveVariantAttributes, matchDictionaryValue, buildAttributesFingerprint } from "../src/background/ozon-api.js";
import {
  buildAttributeMessages, parseAttributeResult, buildTranslateMessages, parseTranslateResult,
  buildCategoryPickMessages, parseCategoryPickResult,
  parseCategoryPickDetails, buildSpecDetectMessages, parseSpecDetectResult,
  buildSellingPointsMessages, parseSellingPointsResult,
  buildImagePlanMessages, parseImagePlanResult,
  buildArtDirectionMessages, parseArtDirectionResult,
  buildListingMessages, parseListingResult, applyListingResult,
  isPlaceholderProductType, inspectListingResult, weakListingError,
  buildRichContentMessages, parseRichContentPlanResult, RICH_CONTENT_SYSTEM_PROMPT,
  // v1.9.66 类目树全量约束匹配（产品标题 + 产品外观图片双通道）
  buildCategoryTreeIndex, renderCategoryTreeDomainList, renderCategoryTypeList, categoryImageParts,
  buildCategoryTreeDomainMessages, buildCategoryTreeTypeMessages,
  parseCategoryTreeDomainResult, parseCategoryTreeTypeResult, composeCategoryTreeMatch,
  SYSTEM_PROMPT, JSON_SCHEMA_HINT,
  SELLING_POINTS_SYSTEM_PROMPT, IMAGE_PLAN_SYSTEM_PROMPT,
} from "../src/shared/prompts.js";
import {
  RICH_CONTENT_ATTR_ID, RICH_CONTENT_MAX_BLOCKS, isRichContentImage, pickRichContentImages,
  buildRichContentJson, buildRichContentFallback, validateRichContentJson, summarizeRichContent,
} from "../src/shared/rich-content.js";
import { collectImportDiagnostics } from "../src/background/ozon-api.js";
import { collectBrandRisks, scanBrandWords, isNoBrandValue, pickNoBrandFromDictionary, isBrandAttribute } from "../src/shared/brand-risk.js";
import { isLikelyProductImage, productImageReason, filterProductImages } from "../src/shared/image-filter.js";
import { normalizeProduct, validateAttributeValues, buildProductModelName, matchSpecImage, buildStableModel, sanitizeOfferId, snapAttributeValues, normalizeAttributeDefinition, reconcileAttributes, classifyOzonImportErrors, productIdentity } from "../src/shared/product-model.js";
import { detectProductDomains, domainsOfPath, CATEGORY_DOMAINS } from "../src/shared/category-keywords.js";

const HERE = path.dirname(fileURLToPath(import.meta.url));

/**
 * 采集适配器现在通过 cache.scopeText() 取「商品主体区文本」（v1.9.69），
 * 测试桩只给 innerText 会直接报 not a function，这里包一层把两者都提供出来。
 */
const stubCache = (innerText) => ({ innerText, scopeText: innerText });
const ROOT = path.resolve(HERE, "..");
let failed = 0;

function check(name, condition, detail = "") {
  if (condition) console.log(`  [OK]   ${name}`);
  else { failed++; console.log(`  [FAIL] ${name} ${detail}`); }
}

/**
 * 找可用的 python 解释器。
 * 有些 Windows 机器上根本没有系统 python（只有 Microsoft Store 的占位提示），
 * 于是这里按 环境变量 → python → python3 → WorkBuddy 受管解释器 的顺序探测。
 */
function resolvePython() {
  const candidates = [
    process.env.OZON_PYTHON,
    "python",
    "python3",
    process.env.USERPROFILE
      ? path.join(process.env.USERPROFILE, ".workbuddy", "binaries", "python", "versions", "3.13.12", "python.exe")
      : "",
  ].filter(Boolean);
  for (const candidate of candidates) {
    try {
      execFileSync(candidate, ["-c", "print(1)"], { stdio: "pipe" });
      return candidate;
    } catch { /* 换下一个候选 */ }
  }
  return "";
}

console.log("=== 发布包配置 ===");
{
  const manifest = JSON.parse(fs.readFileSync(path.join(ROOT, "manifest.json"), "utf8"));
  const version = manifest.version;
  const packageScript = fs.readFileSync(path.join(HERE, "package.py"), "utf8");
  check("manifest 版本符合 semver", /^\d+\.\d+\.\d+(?:[-+][0-9A-Za-z.-]+)?$/.test(version), version);
  check("打包脚本从 manifest 读取版本", /manifest\.json/.test(packageScript));
  check("默认包名使用 OWA-V 前缀", /OWA-V.*\.zip/.test(packageScript));
  check("打包排除 node_modules 与临时目录", /node_modules/.test(packageScript) && /\.smoke-tmp/.test(packageScript));
  // v1.9.47 补丁：开发期 dot 临时文件（.tmp-* / .selftest-* / .smoke-*）必须被通配排除。
  // 曾漏掉 .selftest-summary.txt 与 .tmp-pack.txt，直接被打进发布包。
  check("打包通配排除 .tmp/.selftest/.smoke 临时文件", /\\\.\(tmp\|selftest\|smoke\)/.test(packageScript), packageScript.match(/re\.compile\(r"\^\\\.\([^"]*"\)/)?.[0] || "");
  // v1.9.72：.bak-20260930 这类手动备份曾被塞进发布包，排除通配兜住它。
  check("打包排除 .bak / .bak-* 备份文件", packageScript.includes('r"\\.bak([-.]|$)"'), packageScript.match(/re\.compile\(r"\\\.bak[^"]*"\)/)?.[0] || "(未找到)");
  const python = resolvePython();
  if (!python) {
    failed++;
    console.log("  [FAIL] 默认发布包生成 找不到可用的 python 解释器（可设 OZON_PYTHON 指向它）");
  } else {
    // 注意：这里必须走「默认输出路径」才能验证包名规则，但**不能删掉预先存在的发布包**——
    // 之前无条件 rmSync 会把刚打好的 OWA-V<版本>.zip 一起删掉（打包顺序一旦是「先打包再自检」就丢交付物）。
    const expected = path.join(path.dirname(ROOT), `OWA-V${version}.zip`);
    const preexisting = fs.existsSync(expected);
    try {
      execFileSync(python, [path.join(HERE, "package.py")], { cwd: ROOT, stdio: "pipe" });
      check("默认发布包生成", fs.existsSync(expected), expected);
      if (fs.existsSync(expected) && !preexisting) fs.rmSync(expected);
      if (preexisting) console.log("  [note] 检测到已存在的发布包，自检只校验不动它（打包产物保留）");
    } catch (error) {
      failed++;
      console.log(`  [FAIL] 默认发布包生成 ${String(error.stderr || error.message).trim()}`);
    }
  }
}

console.log("=== 图片 / 属性 / SKU 静态回归 ===");
{
  const panelSource = fs.readFileSync(path.join(ROOT, "src", "ui", "panel.js"), "utf8");
  const modelSource = fs.readFileSync(path.join(ROOT, "src", "shared", "product-model.js"), "utf8");
  const ozonSource = fs.readFileSync(path.join(ROOT, "src", "background", "ozon-api.js"), "utf8");
  check("图片预览支持 Esc、背景关闭与键盘入口",
    /openImagePreview/.test(panelSource) && /event\.key === "Escape"/.test(panelSource)
      && /event\.target === overlay/.test(panelSource));
  check("属性表展示来源与置信度", /attributeSources/.test(panelSource) && /attributeConfidence/.test(panelSource));
  check("SKU 缺失 ID 使用稳定序号而非随机 ID", /本地稳定序号（采集源缺失 ID）/.test(modelSource)
    && !/createId\(`sku/.test(modelSource));
  check("上传按 SKU 图片集合去重并限制 9 张", /imageVariant/.test(ozonSource)
    && /new Set\(\[\.\.\.skuImages/.test(ozonSource) && /slice\(0, 9\)/.test(ozonSource));
  check("属性表枚举型用 select 列出候选值", /renderAttributeValueCell/.test(panelSource) && /<select class="attr-value/.test(panelSource));
  check("SKU 生成优先走 AI 自动识别规格", /MESSAGE_ACTIONS\.aiDetectSpecOptions/.test(panelSource) && /AI 识别规格中/.test(panelSource));
  check("上传 JSON 包含 model_name", /model_name/.test(ozonSource));
  check("model_name 基于商品标题生成", /buildProductModelName/.test(modelSource));
  check("草稿进入工作台后自动渲染图片列表", /renderImageGallery\(\);/.test(panelSource)
    && /草稿进入工作台后立即显示采集到的图片/.test(panelSource));
  check("保存采集草稿时默认选中采集图片", /state\.selectedImages = new Set\(draft\.images \|\| \[\]\)/.test(panelSource));
  check("采集无图片时明确提示用户", /未识别到商品图片，请刷新商品页后重试/.test(panelSource)
    && /当前草稿没有可用商品图片/.test(panelSource));
}

console.log("=== 定价模型 ===");
const template = normalizePricingTemplate({
  exchangeRate: 12.5,
  targetMarginRate: 25,
  commissionRate: 15,
  adRate: 8,
  otherFeeRate: 2,
  domesticShippingCny: 8,
  logisticsRateCnyPerKg: 45,
  weightKg: 0.5,
  useVolumetricWeight: false,
  roundingStep: 10,
  strikeDiscount: 30,
});

const result = priceForCost(100, template);
// 成本 = 100*12.5 + 8*12.5 + 0.5*45*12.5 = 1250 + 100 + 281.25 = 1631.25
const expectedLanded = 100 * 12.5 + 8 * 12.5 + 0.5 * 45 * 12.5;
check("落地成本正确", Math.abs(result.landedCostRub - expectedLanded) < 0.01, `得到 ${result.landedCostRub}，期望 ${expectedLanded}`);
// 分母 = 1 - (15+8+2+25)/100 = 0.5 → 售价 = 3262.5 → 取整 3270
check("售价按利润率倒推", result.priceRub >= 3260 && result.priceRub <= 3280, `得到 ${result.priceRub}`);
check("实际利润率接近目标", Math.abs(result.actualMarginRate - 25) < 1.5, `得到 ${result.actualMarginRate}%`);
check("划线价高于售价", result.oldPriceRub > result.priceRub, `${result.oldPriceRub} vs ${result.priceRub}`);
check("利润为正", result.profitRub > 0, `${result.profitRub}`);

const extreme = priceForCost(100, normalizePricingTemplate({ commissionRate: 60, adRate: 30, targetMarginRate: 30 }));
check("费率之和过高时不会除零", Number.isFinite(extreme.priceRub) && extreme.denominatorBlocked, `得到 ${extreme.priceRub}`);

console.log("=== XLSX 产物 ===");
const draft = {
  id: "draft_test",
  title: "测试商品",
  ru: { title: "Тест", shortDescription: "коротко", description: "описание", keywords: ["a", "b"], categoryHint: "Дом" },
  costCny: 100,
  pricing: { ...result, priceCny: 200, oldPriceCny: 260 },
  images: ["https://example.com/1.jpg"],
  sourceUrl: "https://detail.1688.com/x",
  skus: [{ id: "s1", label: "红色/XL", price: 100, stock: 5, image: "" }],
  attributes: [],
};
const rows = [EXPORT_HEADERS, ...draftToRows(draft)];
check("导出行数正确", rows.length === 2, `得到 ${rows.length}`);
check("导出列数正确", rows.every((row) => row.length === EXPORT_HEADERS.length), "列宽不一致");

// Blob -> 文件（Node 22 支持 Blob.arrayBuffer）
const blob = buildXlsxBlob(rows);
const buffer = Buffer.from(await blob.arrayBuffer());
const outFile = path.join(HERE, "..", ".smoke-tmp", "test.xlsx");
fs.mkdirSync(path.dirname(outFile), { recursive: true });
fs.writeFileSync(outFile, buffer);
check("XLSX 已生成", buffer.length > 800, `${buffer.length} 字节`);

console.log("=== 象寄图片翻译 ===");
// 用假的 fetch 模拟象寄：创建任务返回 running，首次查询仍 running，第二次返回译文（且顺序打乱）
{
  const urls = ["https://img.example.com/a.jpg", "https://img.example.com/b.jpg"];
  let queryCount = 0;
  const realFetch = globalThis.fetch;
  globalThis.fetch = async (url, init) => {
    const body = JSON.parse(init.body);
    const json = (payload) => ({ ok: true, status: 200, json: async () => payload });
    if (String(url).includes("/translate/result")) {
      queryCount++;
      if (queryCount === 1) {
        return json({ code: 0, data: { results: [
          { code: 114, message: "running", task_id: "t1" },
          { code: 114, message: "running", task_id: "t2" },
        ] } });
      }
      return json({ code: 0, data: { results: [
        { code: 0, task_id: "t2", translated_image: "https://i.tosoiot.com/b-ru.jpg" },
        { code: 0, task_id: "t1", translated_image: "https://i.tosoiot.com/a-ru.jpg" },
      ] } });
    }
    check("创建任务带 X-API-Key", init.headers["X-API-Key"] === "KEY123", init.headers["X-API-Key"]);
    check("创建任务用 image_urls 批量提交", Array.isArray(body.image_urls) && body.image_urls.length === 2, JSON.stringify(body).slice(0, 80));
    check("源语言为中文", body.source_language === "CHS", body.source_language);
    check("目标语言为俄语", body.target_language === "RUS", body.target_language);
    check("翻译引擎透传", body.translation_vendor === "DeepL", body.translation_vendor);
    return json({ code: 0, data: { results: [
      { code: 114, message: "running", task_id: "t1" },
      { code: 114, message: "running", task_id: "t2" },
    ] } });
  };

  const results = await translateImagesWithXiangji({ apiKey: "KEY123", vendor: "DeepL", images: urls });
  globalThis.fetch = realFetch;

  check("两张图都拿到译文", results.every((item) => item.translated), JSON.stringify(results));
  check("译文按下标一一对应（乱序返回也能对上）", results[0].translated.endsWith("a-ru.jpg") && results[1].translated.endsWith("b-ru.jpg"), JSON.stringify(results.map((r) => r.translated)));
  check("轮询到 running 会继续等待", queryCount >= 2, `查询 ${queryCount} 次`);
  check("保留原图地址", results[0].original === urls[0]);
}
{
  let message = "";
  try {
    await translateImagesWithXiangji({ apiKey: "", images: ["https://x.com/1.jpg"] });
  } catch (error) {
    message = error.message;
  }
  check("缺 ImgTransKey 时给出中文提示", /ImgTransKey/.test(message), message);
}

console.log("=== 象寄多密钥 ===");
{
  // 两个引擎各一把：只应选中所选引擎的那把
  const settings = {
    xiangjiVendor: "DeepL",
    xiangjiKeys: [
      { id: "k1", vendor: "DeepL", key: "DEEPL_KEY" },
      { id: "k2", vendor: "Aliyun", key: "ALI_KEY" },
    ],
  };
  const picked = resolveXiangjiCredentials(settings, "DeepL");
  check("按引擎取密钥（DeepL 只拿到 DeepL 的）", picked.keys.length === 1 && picked.keys[0].key === "DEEPL_KEY", JSON.stringify(picked.keys));
  check("未指定引擎时跟随默认引擎", resolveXiangjiCredentials(settings).vendor === "DeepL");
  const missing = resolveXiangjiCredentials(settings, "Papago");
  check("该引擎没配密钥时严格不回落（避免用错引擎的 Key）", missing.keys.length === 0 && missing.all.length === 2, JSON.stringify(missing.keys));
  check("列出已配置密钥的引擎", xiangjiConfiguredVendors(settings).sort().join(",") === "Aliyun,DeepL", xiangjiConfiguredVendors(settings).join(","));

  // 同引擎多把 → 同一引擎的 keys 全部返回
  const multi = resolveXiangjiCredentials({
    xiangjiVendor: "DeepL",
    xiangjiKeys: [
      { id: "a", vendor: "DeepL", key: "D1" },
      { id: "b", vendor: "DeepL", key: "D2" },
      { id: "c", vendor: "Aliyun", key: "A1" },
    ],
  }, "DeepL");
  check("同引擎多把密钥全部返回", multi.keys.length === 2, JSON.stringify(multi.keys.map((k) => k.key)));

  // 旧版单 Key 自动迁移；重复的引擎+Key 去重
  const migrated = normalizeXiangjiKeys({ xiangjiApiKey: "LEGACY", xiangjiVendor: "Baidu" });
  check("旧版单个 xiangjiApiKey 自动迁移", migrated.length === 1 && migrated[0].key === "LEGACY" && migrated[0].vendor === "Baidu", JSON.stringify(migrated));
  const deduped = normalizeXiangjiKeys({ xiangjiKeys: [
    { id: "x", vendor: "DeepL", key: "SAME" },
    { id: "y", vendor: "DeepL", key: "SAME" },
  ] });
  check("同引擎同 Key 去重", deduped.length === 1, JSON.stringify(deduped));
  check("空 Key 行被丢弃", normalizeXiangjiKeys({ xiangjiKeys: [{ id: "z", vendor: "DeepL", key: "  " }] }).length === 0);

  check("图片按密钥数切块", JSON.stringify(chunkImages([1, 2, 3, 4], 2)) === "[[1,2],[3,4]]", JSON.stringify(chunkImages([1, 2, 3, 4], 2)));
  check("切块后不丢图片", chunkImages([1, 2, 3, 4, 5], 2).flat().length === 5);
}
{
  // 两把密钥：应各带自己的 X-API-Key、各提交一半图片，且译文按下标对上原图
  const urls = ["https://img.example.com/1.jpg", "https://img.example.com/2.jpg", "https://img.example.com/3.jpg", "https://img.example.com/4.jpg"];
  const seenKeys = new Set();
  const taskMap = new Map();
  const realFetch = globalThis.fetch;
  globalThis.fetch = async (url, init) => {
    const body = JSON.parse(init.body);
    const json = (payload) => ({ ok: true, status: 200, json: async () => payload });
    if (String(url).includes("/translate/result")) {
      const results = body.task_ids.map((id) => {
        const entry = taskMap.get(id);
        const index = urls.indexOf(entry.url);
        return { code: 0, task_id: id, translated_image: `https://i.tosoiot.com/ru-${index + 1}.jpg` };
      });
      return json({ code: 0, data: { results } });
    }
    seenKeys.add(init.headers["X-API-Key"]);
    const key = init.headers["X-API-Key"];
    const results = (body.image_urls || []).map((imageUrl, i) => {
      const id = `${key}-t${i}`;
      taskMap.set(id, { url: imageUrl });
      return { code: 114, message: "running", task_id: id };
    });
    return json({ code: 0, data: { results } });
  };

  const results = await translateImagesWithXiangji({
    keys: [
      { vendor: "DeepL", key: "K1" },
      { vendor: "DeepL", key: "K2" },
    ],
    vendor: "DeepL",
    images: urls,
  });
  globalThis.fetch = realFetch;

  check("两把密钥都参与了提交", seenKeys.size === 2, JSON.stringify([...seenKeys]));
  check("切块后每张图都有译文", results.length === 4 && results.every((item) => item.translated), JSON.stringify(results.map((r) => r.translated)));
  check("译文仍与各自原图一一对应（并行不乱序）",
    results[0].original === urls[0] && results[0].translated.endsWith("ru-1.jpg")
    && results[3].original === urls[3] && results[3].translated.endsWith("ru-4.jpg"),
    JSON.stringify(results.map((r) => `${r.original.split("/").pop()}->${r.translated.split("/").pop()}`)));
}

console.log("=== 生图提示词 ===");
check("重绘提示词要求无中文", /без китайских иероглифов/i.test(buildRedrawPrompt({ context: "кровать" })));
check("重绘提示词带商品上下文", buildRedrawPrompt({ context: "кровать" }).includes("кровать"));

console.log("=== OZON 上架套图：图片类型（对齐常见电商出图工具）===");
{
  const ids = IMAGE_KINDS.map((kind) => kind.id);
  const shotIds = allShots().map((shot) => shot.id);
  check("八种图片类型，顺序对齐出图位（卖点图紧跟主图，场景图收尾）",
    ids.join(",") === "single-main,main-set,benefits,detail,closeup,model,scene,package", ids.join(","));
  check("每种类型都有中文 label 与 note", IMAGE_KINDS.every((kind) => kind.label && kind.note), "");
  check("每种类型至少展开 1 张", IMAGE_KINDS.every((kind) => Array.isArray(kind.shots) && kind.shots.length), "");
  check("主图套图展开 4 张变体（白底/规格标注/侧面/局部特写）", findKind("main-set").shots.length === 4, String(findKind("main-set").shots.length));
  check("拍摄方案 id 唯一（同一种拍法被多个类型共用时只算一次）", new Set(shotIds).size === shotIds.length, shotIds.join(","));
  check("findKind / findShot 未知 id 返回 null", findKind("nope") === null && findShot("nope") === null);
  check("allShots 带上所属类型，便于面板显示",
    allShots().every((shot) => shot.kindId && shot.kindLabel), "");
  check("默认类型展开后首张是信息图卖点主图（关键词最醒目 + 卖点/参数色块 + 尺寸标注）",
    expandSetShots(DEFAULT_SET_KINDS)[0]?.id === "main"
      && expandSetShots(DEFAULT_SET_KINDS)[0]?.text === TEXT_MODES.INFO, "");
  check("勾选顺序不影响出图顺序：主图永远排最前（先选卖点图也一样）",
    expandSetShots(["benefits", "main-set"])[0]?.id === "main", expandSetShots(["benefits", "main-set"])[0]?.id);
  check("只出勾中的类型", expandSetShots(["scene"]).every((shot) => shot.kindId === "scene"), "");
  check("同时勾「单张主图」与「主图套图」时主图只出一次（不重复生成同一张）",
    expandSetShots(["single-main", "main-set"]).filter((shot) => shot.id === "main").length === 1,
    String(expandSetShots(["single-main", "main-set"]).filter((shot) => shot.id === "main").length));
  check("一个类型都不选时展开为空", expandSetShots([]).length === 0, "");
  check("每种文字模式都被用到（none/spec/title/table/info）",
    ["none", "spec", "title", "table", "info"].every((mode) => allShots().some((shot) => shot.text === mode)), "");
  check("兜底俄文标题覆盖全部带文字的信息图",
    allShots().filter((shot) => shot.text === TEXT_MODES.TITLE || shot.text === TEXT_MODES.TABLE)
      .every((shot) => FALLBACK_TITLES[shot.id]?.title), "");
}

console.log("=== OZON 上架套图：张数规划（类型 × 张数上限）===");
{
  // 超哥定的标准 8 张：主图（带关键卖点）1 + 卖点图 3 + 细节图 1 + 模特图 1 + 场景图 2
  const plan8 = planSetShots({ kinds: DEFAULT_SET_KINDS, count: 8 });
  const ids8 = plan8.map((shot) => shot.id).join(",");
  check("默认构成就是标准 8 张（1 主图 + 3 卖点 + 1 细节 + 1 模特 + 2 场景，顺序同出图位）",
    plan8.length === 8
      && ids8 === "main,benefit-1,benefit-2,benefit-3,closeup-texture,model,scene-life,scene-hand",
    ids8);
  check("图位顺序对齐超哥的八张清单：主图→卖点①②③→细节→模特→场景×2",
    plan8.slice(1, 4).every((shot) => shot.kindId === "benefits")
      && plan8[4].kindId === "closeup" && plan8[5].kindId === "model"
      && plan8.slice(6).every((shot) => shot.kindId === "scene"), ids8);
  check("场景/细节/模特在默认构成里不超量（DEFAULT_KIND_LIMITS 生效）",
    expandSetShots(DEFAULT_SET_KINDS).filter((shot) => shot.kindId === "closeup").length === 1
      && expandSetShots(DEFAULT_SET_KINDS).filter((shot) => shot.kindId === "scene").length === 2
      && expandSetShots(DEFAULT_SET_KINDS).length === 8, "");
  check("张数上限生效", planSetShots({ kinds: DEFAULT_SET_KINDS, count: 4 }).length === 4, "");
  check("张数超上限时按 MAX_SET_SHOTS 夹住", planSetShots({ kinds: DEFAULT_SET_KINDS, count: 99 }).length <= MAX_SET_SHOTS, "");
  check("类型排不满时不硬凑重复图", planSetShots({ kinds: ["single-main"], count: 8 }).length === 1, "");
  check("张数非法时回落默认值", planSetShots({ kinds: DEFAULT_SET_KINDS, count: 0 }).length === DEFAULT_SET_COUNT, "");
  check("默认张数是 8", DEFAULT_SET_COUNT === 8, String(DEFAULT_SET_COUNT));
  check("v1.9.51 预设张数档位已移除（③ 张数改手填）",
    !fs.readFileSync(path.join(HERE, "../src/shared/image-prompts.js"), "utf8").includes("SET_COUNT_OPTIONS"), "");
  check("自定义图片类型会追加一张（且保留拍法描述）",
    (() => {
      const list = planSetShots({ kinds: [], count: 8, custom: "包装盒与全部配件平铺展示" });
      return list.length === 1 && list[0].scene === "包装盒与全部配件平铺展示" && list[0].id === "custom";
    })(), "");
  check("自定义类型排不进张数上限时不出现",
    planSetShots({ kinds: ["main-set"], count: 2, custom: "x" }).length === 2, "");
  check("规格标注图会带上俄文参数标签",
    planSetShots({ kinds: ["main-set"], count: 4, labels: ["Объём 2,5 л", "Мощность 2400 Вт"] })
      .find((shot) => shot.id === "main-spec")?.labels.length === 2, "");
  check("AI 为单张图写的标签优先于通用标签",
    planSetShots({ kinds: ["detail"], count: 2, labels: ["общий"], titles: { "detail-spec": { title: "T", labels: ["свой"] } } })
      .find((shot) => shot.id === "detail-spec")?.labels[0] === "свой", "");
  check("非规格类图不塞标签", planSetShots({ kinds: ["scene"], count: 2, labels: ["x"] })[0].labels.length === 0, "");
  check("没给标题时用兜底俄文标题填上（信息图不会没字）",
    planSetShots({ kinds: ["benefits"], count: 3 })[0].title === FALLBACK_TITLES["benefit-1"].title, "");
}

console.log("=== OZON 上架套图：单张提示词（图生图约束）===");
{
  const ctx = "электрический чайник";
  const main = buildShotPrompt({ shot: "main", context: ctx });
  const spec = buildShotPrompt({ shot: "main-spec", context: ctx, labels: ["Мощность 2400 Вт"] });
  const benefit = buildShotPrompt({
    shot: "benefit-1", context: ctx, points: "складной, лёгкий",
    title: "БЕЗОПАСНОСТЬ НА ПЕРВОМ МЕСТЕ", subtitle: "Защита от работы без воды",
  });
  const table = buildShotPrompt({ shot: "detail-spec", context: ctx, labels: ["Объём 2,5 л"] });
  const scene = buildShotPrompt({ shot: "scene-life", context: ctx });
  const fallback = buildShotPrompt({ shot: "nope", context: "коляска" });
  const customShot = { id: "custom", scene: "товар рядом с упаковкой", text: TEXT_MODES.NONE };

  check("主图提示词：非白底彩色底 + 关键词最醒目的信息图排版",
    /не чисто-белый/i.test(main) && !/белый фон \(RGB/i.test(main)
      && /ГЛАВНОЕ КЛЮЧЕВОЕ СЛОВО/i.test(main) && /самое заметное место кадра/i.test(main)
      && /только на русском языке/i.test(main), "");
  check("主图排版照参考图：左侧色块信息栏 + 底部细节小图 + 四周尺寸标注线",
    /вертикальный информационный блок/i.test(main)
      && /песочная\/бежевая или акцентная/i.test(main)
      && /фото-врезка ключевого узла/i.test(main)
      && /размерные линии со стрелками и цифрами в мм/i.test(main), "");
  check("信息图排版规则共 8 条且强调不遮挡商品",
    INFO_LAYOUT_LINES.length === 8 && /НЕ перекрывают товар/i.test(INFO_LAYOUT_LINES.join(" ")), String(INFO_LAYOUT_LINES.length));
  check("信息图主图会把卖点与参数都要求写进色块",
    buildShotPrompt({ shot: "main", context: ctx, points: "складной", labels: ["400×400 мм"] })
      .includes("складной")
      && buildShotPrompt({ shot: "main", context: ctx, labels: ["400×400 мм"] }).includes("400×400 мм"), "");
  check("每张都带「保持商品本体不变」（不加就会画出别的东西）",
    [main, spec, benefit, table, scene].every((prompt) => /сохрани сам товар без изменений/i.test(prompt))
    && /сохрани сам товар без изменений/i.test(buildShotPrompt({ shot: customShot, context: ctx })), "");
  check("所有图一律禁纯白底（不要白底图）",
    [main, spec, benefit, table, scene, buildShotPrompt({ shot: "closeup-texture", context: ctx })]
      .every((prompt) => /не чисто-белый/i.test(prompt)), "");
  check("无字图也把卖点写进提示词（只作取景重点，图上不出现字）",
    buildShotPrompt({ shot: "scene-life", context: ctx, points: "складной" }).includes("складной"), "");
  check("明确要求不增删商品部件、不换成别的商品", /Не добавляй и не убирай элементы товара/.test(main), "");
  check("非文字图要求无文字、无 logo、无品牌", /водяных знаков и логотипов брендов/i.test(scene), "");
  check("带文字的图要求只用俄语", /только на русском языке/i.test(benefit) && /только на русском языке/i.test(table), "");
  check("卖点图把俄文标题写进提示词（图上要画什么字，先定死）", benefit.includes("БЕЗОПАСНОСТЬ НА ПЕРВОМ МЕСТЕ"), "");
  check("卖点图把副标题写进提示词", benefit.includes("Защита от работы без воды"), "");
  check("卖点图把勾选的卖点写进提示词", benefit.includes("складной") && benefit.includes("лёгкий"), "");
  check("规格标注图把俄文参数写进提示词", spec.includes("Мощность 2400 Вт"), "");
  check("参数表要求「参数 — 值」的表格形式",
    /параметр — значение/i.test(table) && /Технические характеристики/i.test(table), "");
  check("补充信息写进提示词（照片上看不到的规格也算数）",
    buildShotPrompt({ shot: "main", extraInfo: "额定功率 2400 Вт" }).includes("额定功率 2400 Вт"), "");
  check("未知方案 id 回落通用重绘提示词", fallback === buildRedrawPrompt({ context: "коляска" }), "");
  check("自定义图片类型也走「保持本体不变」的图生图提示词（不回落通用重绘）",
    buildShotPrompt({ shot: customShot, context: ctx }) !== buildRedrawPrompt({ context: ctx })
    && /Коммерческое фото товара/.test(buildShotPrompt({ shot: customShot, context: ctx })), "");
  check("每张都要求照片级真实、高分辨率", /Фотореалистично/.test(main), "");
  check("不传 shot 时回落通用重绘提示词", buildShotPrompt({ context: "коляска" }) === buildRedrawPrompt({ context: "коляска" }), "");
}

console.log("=== OZON 上架套图：品类自动风格（对齐热销卡片视觉语言）===");
{
  check("风格表覆盖 10 类（9 个品类 + 通用兜底）", STYLE_BY_CATEGORY.length === 10, String(STYLE_BY_CATEGORY.length));
  check("数码与厨房拿到不同风格",
    pickStyleFor("беспроводные наушники") !== pickStyleFor("электрический чайник")
      && /неонов/i.test(pickStyleFor("беспроводные наушники"))
      && /деревянная/i.test(pickStyleFor("чайник")), pickStyleFor("чайник"));
  check("中文商品词也能匹配品类风格", /пастел/i.test(pickStyleFor("婴儿睡袋")), pickStyleFor("婴儿睡袋"));
  check("品类路径（俄文）也能匹配", /outdoor|солнечн/i.test(pickStyleFor("", "Спорт и развлечения > Рыбалка")), pickStyleFor("", "Спорт > Рыбалка"));
  check("匹配不到落到通用风格", pickStyleFor("что-то неизвестное") === STYLE_BY_CATEGORY.at(-1).style, "");
  check("参考图上限常量 = 3（qwen-image-edit 只接受 0-3 张）", MAX_REFERENCE_IMAGES === 3, String(MAX_REFERENCE_IMAGES));
}

console.log("=== 出图硬约束：俄罗斯面孔 / 产品零改动 / 风格方向 ===");
{
  const ctx = "детская коляска";
  const main = buildShotPrompt({ shot: "main", context: ctx });
  const model = buildShotPrompt({ shot: "model", context: ctx });
  const scene = buildShotPrompt({ shot: "scene-life", context: ctx, points: "складной" });
  const studioDir = STYLE_DIRECTIONS.find((item) => item.id === "studio");
  const homeDir = STYLE_DIRECTIONS.find((item) => item.id === "home");

  check("硬规则共 5 条（人物/禁中文元素/俄文/产品不变/只改环境）", IMAGE_HARD_RULES.length === 5, String(IMAGE_HARD_RULES.length));
  check("硬规则要求人物只能是俄罗斯人（斯拉夫/高加索特征）",
    /славянская\/европеоидная внешность/i.test(IMAGE_HARD_RULES.join(" ")), "");
  check("硬规则禁止中国人/东亚面孔与中文、中式元素",
    /китайцы|восточноазиатские/i.test(IMAGE_HARD_RULES.join(" "))
      && /иероглифы/i.test(IMAGE_HARD_RULES.join(" ")), "");
  check("硬规则要求产品本体零改动（形状/比例/尺寸/颜色/材质/logo/包装）",
    /сохрани форму, пропорции, размер, цвет, материал, логотип и упаковку/i.test(IMAGE_HARD_RULES.join(" ")), "");
  check("硬规则限定只能改环境/光影/构图/人物",
    /МЕНЯТЬ РАЗРЕШЕНО ТОЛЬКО/i.test(IMAGE_HARD_RULES.join(" ")), "");
  check("每张图的提示词都带上全部硬规则",
    IMAGE_HARD_RULES.every((rule) => [main, model, scene].every((prompt) => prompt.includes(rule))), "");
  check("通用重绘也带同一套硬约束",
    IMAGE_HARD_RULES.every((rule) => buildRedrawPrompt({ context: ctx }).includes(rule)), "");

  check("风格方向 6 个（棚拍/极简/居家/街景/暖调/节日）",
    STYLE_DIRECTIONS.length === 6 && STYLE_DIRECTIONS.map((item) => item.id).join(",")
      === "studio,premium,home,street,warm,festive", STYLE_DIRECTIONS.map((item) => item.id).join(","));
  const shots8 = planSetShots({ kinds: DEFAULT_SET_KINDS, count: 8 });
  const dirs = assignSetDirections(shots8);
  const dirCount = dirs.reduce((acc, item) => ({ ...acc, [item.id]: (acc[item.id] || 0) + 1 }), {});
  check("标准 8 张会分到多个风格方向（成套图风格多样）",
    Object.keys(dirCount).length >= 3, JSON.stringify(dirCount));
  check("同一方向最多 2 张（同方向风格统一、不成套图全一个样）",
    Object.values(dirCount).every((n) => n <= 2), JSON.stringify(dirCount));
  check("主图/棚拍方向打头", dirs[0]?.id === "studio", String(dirs[0]?.id));

  check("默认不开白底：棚拍方向也不出纯白",
    /НЕ чисто-белый/i.test(buildShotPrompt({ shot: "main", context: ctx, direction: studioDir }))
      && !/Чистый белый фон/i.test(buildShotPrompt({ shot: "main", context: ctx, direction: studioDir })), "");
  check("勾选「允许纯白底」+ 棚拍方向才出纯白（白底是可选项，非平台强制）",
    /Чистый белый фон/i.test(buildShotPrompt({ shot: "main", context: ctx, direction: studioDir, allowWhiteBg: true })), "");
  check("非棚拍方向即使开了白底也不强制纯白（居家/街景仍是有景背景）",
    !/Чистый белый фон/i.test(buildShotPrompt({ shot: "scene-life", context: ctx, direction: homeDir, allowWhiteBg: true })), "");
  check("风格方向写进提示词的 Стиль",
    buildShotPrompt({ shot: "scene-life", context: ctx, styleHint: homeDir.style }).includes("домашняя обстановка"), "");
}

console.log("=== SKU 主图：每个变体基于自己的原图出信息图主图 ===");
{
  const ctx = "стойка для телевизора";
  const skuPrompt = buildShotPrompt({
    shot: SKU_MAIN_SHOT, context: ctx,
    title: "СТОЙКА ДЛЯ ТЕЛЕВИЗОРА", subtitle: "26-60 дюймов",
    points: "ручной подъём, встроенная розетка", labels: ["400×400 мм", "1160-1595 мм"],
  });
  check("SKU 主图方案存在且走信息图模式", SKU_MAIN_SHOT.id === "sku-main" && SKU_MAIN_SHOT.text === TEXT_MODES.INFO, SKU_MAIN_SHOT.id);
  check("findShot 能解析出 SKU 主图方案（不进图片类型勾选表）",
    findShot("sku-main")?.id === "sku-main" && !IMAGE_KINDS.some((kind) => kind.id === "sku-main"), "");
  check("SKU 主图引用「那个变体自己的形态」（同色/同配置/同尺寸）",
    /ровно тот вариант товара, что на приложенном референсе/i.test(skuPrompt), "");
  check("SKU 主图带硬约束（俄罗斯面孔 / 产品零改动 / 只许俄文）",
    IMAGE_HARD_RULES.every((rule) => skuPrompt.includes(rule)), "");
  check("SKU 主图把关键词、副标题、卖点、参数都写进提示词",
    skuPrompt.includes("СТОЙКА ДЛЯ ТЕЛЕВИЗОРА") && skuPrompt.includes("26-60 дюймов")
      && skuPrompt.includes("встроенная розетка") && skuPrompt.includes("1160-1595 мм"), "");
  check("SKU 主图没给标题时落兜底俄文（不会出现没字的信息图）",
    /КЛЮЧЕВОЕ СЛОВО|ГЛАВНОЕ ПРЕИМУЩЕСТВО/i.test(buildShotPrompt({ shot: SKU_MAIN_SHOT, context: ctx })), "");
  check("信息图主图也会带上参数标签（planSetShots 的 needsLabels 含 info）",
    planSetShots({ kinds: DEFAULT_SET_KINDS, count: 8, labels: ["400×400 мм"] })
      .find((shot) => shot.id === "main")?.labels.length === 1, "");
}

console.log("=== OZON 上架套图：尺寸比例库（1K/2K/4K）===");
{
  const sf = IMAGE_PRESETS.find((item) => item.id === "siliconflow");
  const qwen = IMAGE_PRESETS.find((item) => item.id === "aliyun-qwen");
  const custom = IMAGE_PRESETS.find((item) => item.id === "custom");

  check("比例库覆盖出图工具里的常见比例（13 种）", IMAGE_SIZE_RATIOS.length === 13, String(IMAGE_SIZE_RATIOS.length));
  check("比例 id 不重复", new Set(IMAGE_SIZE_RATIOS.map((item) => item.id)).size === IMAGE_SIZE_RATIOS.length, "");
  check("默认比例是 Ozon 推荐的 3:4", DEFAULT_SIZE_RATIO === "3:4", DEFAULT_SIZE_RATIO);
  check("默认档位 1K，档位为 1K/2K/4K", DEFAULT_SIZE_TIER === "1K" && IMAGE_SIZE_TIERS.join(",") === "1K,2K,4K", IMAGE_SIZE_TIERS.join(","));
  check("3:4 的 1K 尺寸是 896x1200（与出图工具一致）", sizeForRatio("3:4", "1K") === "896x1200", sizeForRatio("3:4", "1K"));
  check("1:1 的 1K 尺寸是 1024x1024", sizeForRatio("1:1", "1K") === "1024x1024", sizeForRatio("1:1", "1K"));
  check("每个比例在每个档位都有尺寸",
    IMAGE_SIZE_TIERS.every((tier) => IMAGE_SIZE_RATIOS.every((item) => /^\d+x\d+$/.test(sizeForRatio(item.id, tier)))), "");
  check("4K 由 2K 翻倍（3:4 → 3072x4096）", sizeForRatio("3:4", "4K") === "3072x4096", sizeForRatio("3:4", "4K"));
  check("未知比例返回空串", sizeForRatio("nope", "1K") === "", "");
  check("尺寸串解析宽高比（896x1200 ≈ 0.747）", sizeRatioValue("896x1200").toFixed(4) === "0.7467", sizeRatioValue("896x1200").toFixed(4));
  check("比例文案解析数值（3:4 → 0.75）", ratioLabelValue("3:4") === 0.75, String(ratioLabelValue("3:4")));
  check("findSizeRatio 未知 id 返回 null", findSizeRatio("nope") === null);

  const sfAdapt = resolveProviderSize(sf, "Kwai-Kolors/Kolors", "896x1200", "3:4");
  check("硅基流动不支持 896x1200 → 自动改用最接近的 960x1280",
    sfAdapt.size === "960x1280" && sfAdapt.exact === false, JSON.stringify(sfAdapt));
  check("适配结果回报原始请求尺寸，面板据此提示用户", sfAdapt.requested === "896x1200", sfAdapt.requested);
  const qwenAdapt = resolveProviderSize(qwen, "qwen-image-3.0", "1024x1024", "1:1");
  check("百炼支持 1024x1024 → 精确命中不做改动", qwenAdapt.size === "1024x1024" && qwenAdapt.exact === true, JSON.stringify(qwenAdapt));
  const customAdapt = resolveProviderSize(custom, "x", "896x1200", "3:4");
  check("自定义服务没声明支持列表 → 原样使用不瞎改",
    customAdapt.size === "896x1200" && customAdapt.exact === true, JSON.stringify(customAdapt));
  check("空尺寸不报错", resolveProviderSize(sf, "x", "", "").size === "", "");
  check("横版比例也能在服务支持列表里找到对应尺寸",
    /^\d+x\d+$/.test(resolveProviderSize(sf, "x", "1200x896", "4:3").size), resolveProviderSize(sf, "x", "1200x896", "4:3").size);

  check("pickListingSetSize 仍能挑出最接近 3:4 的竖版（兜底）",
    pickListingSetSize(sf, "Kwai-Kolors/Kolors") === "960x1280", pickListingSetSize(sf, "Kwai-Kolors/Kolors"));
  check("百炼预设把图生图模型 qwen-image-edit 列为候选（套图用得上）",
    (qwen?.models || []).includes("qwen-image-edit"), "");
  check("百炼预设提示里点名图生图要用 qwen-image-edit", /qwen-image-edit/.test(qwen?.note || ""), "");
}

console.log("=== 上架套图：俄文卖点与出图标题方案（AI）===");
{
  const product = { title: "Электрический чайник" };
  const pointMsgs = buildSellingPointsMessages(product, { extraInfo: "额定功率 2400 Вт", count: 5 });
  check("卖点提示词要求纯俄文、JSON、不用最高级",
    /только русский текст/i.test(pointMsgs[0].content) && /JSON/.test(pointMsgs[0].content)
    && /превосходной степени/i.test(pointMsgs[0].content), "");
  check("卖点提示词带上补充信息（照片上看不到的规格）", pointMsgs[1].content.includes("2400 Вт"), "");
  check("卖点提示词指定条数", /Сформулируй 5 главных преимуществ/.test(pointMsgs[1].content), "");
  check("卖点提示词禁止编造数字", /без выдуманных цифр/i.test(pointMsgs[0].content), "");

  check("卖点解析：{\"points\":[...]} 形式", (parseSellingPointsResult('{"points":["Пункт один","Пункт два"]}') || []).length === 2, "");
  check("卖点解析：裸数组也认", (parseSellingPointsResult('["Пункт один"]') || []).length === 1, "");
  check("卖点解析：丢掉混进来的中文（图上只会是俄文）",
    JSON.stringify(parseSellingPointsResult('{"points":["Пункт","中文卖点"]}')) === '["Пункт"]',
    JSON.stringify(parseSellingPointsResult('{"points":["Пункт","中文卖点"]}')));
  check("卖点解析：去重", (parseSellingPointsResult('{"points":["A","A","B"]}') || []).length === 2, "");
  check("卖点解析：限量", (parseSellingPointsResult(JSON.stringify({ points: ["a", "b", "c", "d"] }), 2) || []).length === 2, "");
  check("卖点解析：解析不出返回 null", parseSellingPointsResult("没有 JSON") === null);
  check("卖点解析：全是中文时判失败（不返回半成品）", parseSellingPointsResult('{"points":["中文"]}') === null);

  const shots = [{ id: "benefit-1", label: "卖点图 · ①" }, { id: "detail-spec", label: "详情图 · 参数表" }];
  const planMsgs = buildImagePlanMessages(product, shots, { points: ["Тихий", "Лёгкий"] });
  check("标题方案提示词要求俄文大写短标题",
    /ЗАГЛАВНЫМИ буквами/i.test(planMsgs[0].content) && /только русский язык/i.test(planMsgs[0].content), "");
  check("标题方案提示词列出待拟标题的图位", /benefit-1/.test(planMsgs[1].content) && /detail-spec/.test(planMsgs[1].content), "");
  check("标题方案提示词把已确认卖点带上", planMsgs[1].content.includes("Тихий"), "");
  check("标题方案提示词要求参数表额外给 labels", /labels/.test(planMsgs[1].content), "");
  check("标题方案要求相邻图不重复同一卖点", /не должны повторять/i.test(planMsgs[1].content), "");

  const plan = parseImagePlanResult('{"plan":[{"id":"benefit-1","title":"БЕЗОПАСНОСТЬ НА ПЕРВОМ МЕСТЕ","subtitle":"Защита от воды"},{"id":"detail-spec","title":"ТЕХНИЧЕСКИЕ ХАРАКТЕРИСТИКИ","labels":["Объём 2,5 л","Мощность 2400 Вт"]}]}');
  check("标题方案解析出 shotId → 标题", plan?.["benefit-1"]?.title === "БЕЗОПАСНОСТЬ НА ПЕРВОМ МЕСТЕ", JSON.stringify(plan));
  check("标题方案解析出副标题", plan?.["benefit-1"]?.subtitle === "Защита от воды", "");
  check("标题方案解析出规格标签", JSON.stringify(plan?.["detail-spec"]?.labels) === '["Объём 2,5 л","Мощность 2400 Вт"]', JSON.stringify(plan?.["detail-spec"]));
  check("标题里带中文的整条丢掉（图上不能出现中文）",
    parseImagePlanResult('{"plan":[{"id":"a","title":"中文标题"}]}') === null, "");
  check("标签里带中文的丢掉、其余保留",
    JSON.stringify(parseImagePlanResult('{"plan":[{"id":"a","title":"T","labels":["中文","Объём 2,5 л"]}]}')?.a?.labels) === '["Объём 2,5 л"]', "");
  check("标题方案解析不出返回 null", parseImagePlanResult("没有 JSON") === null);
}

console.log("=== 上传 payload ===");
const item = buildImportItem(draft, {
  category: { descriptionCategoryId: 123, typeId: 456 },
  pricing: draft.pricing,
  weightGrams: 800,
  skuPrefix: "SHOP1-",
});
check("offer_id 优先使用真实 SKU 型号并带店铺前缀", item.offer_id === "SHOP1-s1" && item.model === item.offer_id, item.offer_id);
check("类目用 description_category_id（v3）", item.description_category_id === 123 && item.category_id === 123, JSON.stringify({ c: item.description_category_id }));
check("价格取定价结果（人民币）", item.price === "200", item.price);
check("价格是 CNY 数值（不是 RUB 卢布数）", Number(item.price) < 100000 && item.currency_code === "CNY", `${item.price} ${item.currency_code}`);
check("重量单位正确", item.weight === 800 && item.weight_unit === "g");
check("图片数量受限", item.images.length <= 15);
check("attributes 为 v3 的 complex_id 结构", item.attributes.every((a) => a.complex_id === 0 && Number(a.id) > 0 && Array.isArray(a.values)), JSON.stringify(item.attributes).slice(0, 120));
check("俄语描述写入描述属性 4191", item.attributes.some((a) => a.id === 4191 && a.values[0].value === "описание"), "");
check("上传 payload 包含 model_name", typeof item.model_name === "string" && item.model_name.length > 0, item.model_name);
check("不再发送已下线的顶级 service_type", !("service_type" in item), "");

const noPrefix = buildImportItem(draft, { pricing: draft.pricing });
check("无前缀时单 SKU offer_id 使用 SKU id", noPrefix.offer_id === "s1", noPrefix.offer_id);

console.log("=== 多规格（选用 SKU）===");
// 单 SKU：1 条
{
  const items = buildImportItems(draft, { pricing: draft.pricing, selectedSkus: draft.skus });
  check("选用 1 个 SKU 时出 1 条", items.length === 1, `得到 ${items.length}`);
}
// v1.9.50 回归「上传了 4 个规格，系统只上架了一个」：没手填变体属性 ID 也必须按规格数出条
{
  const fourDraft = {
    ...draft,
    images: ["https://example.com/1.jpg"],
    skus: [
      { id: "s1", specs: { 颜色: "黑色" }, label: "黑色", price: 300 },
      { id: "s2", specs: { 颜色: "白色" }, label: "白色", price: 320 },
      { id: "s3", specs: { 颜色: "绿色" }, label: "绿色", price: 310 },
      { id: "s4", specs: { 颜色: "灰色" }, label: "灰色", price: 330 },
    ],
    categoryAttributes: [{ id: 10096, name: "Цвет", is_aspect: true, dictionary_id: 5 }],
    pricing: { ...result, priceCny: 200, oldPriceCny: 260, perSku: { s1: { priceCny: 111, oldPriceCny: 222 } } },
  };
  const items = buildImportItems(fourDraft, {
    pricing: fourDraft.pricing,
    selectedSkus: fourDraft.skus,
    categoryAttributes: fourDraft.categoryAttributes,
  });
  check("未手填变体属性也按规格数出条（4 个规格 → 4 条）", items.length === 4, `得到 ${items.length}`);
  check("有单独定价的 SKU 用自己那档价", items[0].price === "111" && items[0].old_price === "222", `${items[0].price}/${items[0].old_price}`);
  check("没单独定价的 SKU 回落整单价（不是 0、也不是别人的价）", items[1].price === "200", items[1].price);
  check("4 条共用 model_name（才能合并成一张卡）", new Set(items.map((it) => it.model_name)).size === 1);
  check("4 条 offer_id 互不相同", new Set(items.map((it) => it.offer_id)).size === 4, JSON.stringify(items.map((it) => it.offer_id)));
  check("每条写进自己的规格值",
    items.map((it) => it.attributes.find((a) => a.id === 10096)?.values?.[0]?.value).join(",") === "黑色,白色,绿色,灰色",
    JSON.stringify(items.map((it) => it.attributes.find((a) => a.id === 10096)?.values?.[0]?.value)));
}
// 多规格但识别不出变体属性、也没手填 → 必须明确报错，不能静默只上 1 条
{
  const stuck = {
    ...draft,
    skus: [
      { id: "s1", specs: { 颜色: "黑色" }, label: "黑色", price: 300 },
      { id: "s2", specs: { 颜色: "白色" }, label: "白色", price: 320 },
    ],
    categoryAttributes: [{ id: 9048, name: "Бренд" }],
  };
  let message = "";
  try {
    buildImportItems(stuck, { pricing: stuck.pricing, selectedSkus: stuck.skus, categoryAttributes: stuck.categoryAttributes });
  } catch (error) {
    message = error?.message || String(error);
  }
  check("多规格识别不出变体属性时明确报错（不再静默只上 1 条）",
    /变体属性/.test(message) && /10096/.test(message), message);
}
// 配置变体属性 ID + 2 个选用 SKU：每个 SKU 一条，各自价格与规格值
{
  const multiDraft = {
    ...draft,
    images: ["https://example.com/1.jpg", "https://example.com/2.jpg"],
    skus: [
      { id: "s1", label: "红色/XL", price: 100, stock: 5, image: "" },
      { id: "s2", label: "蓝色/L", price: 200, stock: 0, image: "https://example.com/blue.jpg" },
    ],
    pricing: { ...result, priceCny: 200, oldPriceCny: 260, perSku: { s2: { priceCny: 150, oldPriceCny: 180, priceRub: 9999, oldPriceRub: 12999 } } },
  };
  const items = buildImportItems(multiDraft, {
    pricing: multiDraft.pricing,
    selectedSkus: multiDraft.skus,
    variantAttributeId: 10096,
  });
  check("两个选用 SKU 出两条", items.length === 2, `得到 ${items.length}`);
  check("两条 offer_id 互不相同", items[0].offer_id !== items[1].offer_id, `${items[0].offer_id} / ${items[1].offer_id}`);
  check("同一 SKU 重建 payload 型号保持稳定", buildImportItems(multiDraft, {
    pricing: multiDraft.pricing, selectedSkus: multiDraft.skus, variantAttributeId: 10096,
  })[0].offer_id === items[0].offer_id, items[0].offer_id);
  check("变体属性写入 attributes", items.every((it) => it.attributes.some((a) => a.id === 10096)), JSON.stringify(items[0].attributes));
  check("规格值分别为红/蓝", items[0].attributes.find((a) => a.id === 10096).values[0].value === "红色/XL"
    && items[1].attributes.find((a) => a.id === 10096).values[0].value === "蓝色/L", "");
  check("第二条用 SKU 自己的售价（人民币）", items[1].price === "150" && items[1].old_price === "180", `${items[1].price}/${items[1].old_price}`);
  check("第一条回落整单定价（人民币）", items[0].price === "200", items[0].price);
  check("SKU 专属图被置为主图首位", items[1].primary_image === "https://example.com/blue.jpg", items[1].primary_image);
  check("多 SKU 共享同一 model_name 才能合并卡片", items[0].model_name === items[1].model_name && items[0].model_name.length > 0, `${items[0].model_name} / ${items[1].model_name}`);
  check("单条图片不超 15", items.every((it) => it.images.length <= 15));
}
// 只选用 1 个 SKU：即使用了变体属性也保持单条
{
  const items = buildImportItems(draft, { pricing: draft.pricing, selectedSkus: [draft.skus[0]], variantAttributeId: 10096 });
  check("仅选用 1 个 SKU 时仍是 1 条", items.length === 1, `得到 ${items.length}`);
}

console.log("=== SKU 规格维度 → Ozon 真实变体属性（达瓦式多轴变体）===");
// 每个 SKU 的规格维度（颜色/尺码/材质）自动匹配该类目属性定义，生成「真变体」
{
  // 类目属性定义（模拟某服装类目返回的 RU 名属性）
  const categoryAttributes = [
    { id: 8229, name: "Цвет" },          // 颜色
    { id: 8230, name: "Размер" },        // 尺码
    { id: 8231, name: "Материал" },      // 材质
    { id: 9048, name: "Бренд" },         // 品牌
  ];
  const sku = { id: "s1", specs: { 颜色: "红色", 尺码: "XL", 材质: "棉" }, label: "红色/XL" };
  const variants = buildVariantAttributes(sku, categoryAttributes);
  check("颜色维度匹配到 Цвет 属性", variants.some((v) => v.id === 8229 && v.values[0].value === "红色"), JSON.stringify(variants));
  check("尺码维度匹配到 Размер 属性", variants.some((v) => v.id === 8230 && v.values[0].value === "XL"), JSON.stringify(variants));
  check("材质维度匹配到 Материал 属性", variants.some((v) => v.id === 8231 && v.values[0].value === "棉"), JSON.stringify(variants));
  check("没有对应类目属性的维度（如品牌）不会被编出来", !variants.some((v) => v.id === 9048), JSON.stringify(variants));
  check("每个维度只生成一条属性（不重复 id）", new Set(variants.map((v) => v.id)).size === variants.length, JSON.stringify(variants));
}

// 整条上传：带 specs 的 SKU 应把各维度写成真实变体属性，而非只挂一个规格标签
{
  const catAttrs = [
    { id: 8229, name: "Цвет" },
    { id: 8230, name: "Размер" },
  ];
  const multiDraft = {
    ...draft,
    ozonCategory: { descriptionCategoryId: 17028933, typeId: 96529 },
    skus: [
      { id: "s1", specs: { 颜色: "红色", 尺码: "XL" }, label: "红色/XL", price: 100, stock: 5, image: "" },
      { id: "s2", specs: { 颜色: "蓝色", 尺码: "L" }, label: "蓝色/L", price: 200, stock: 0, image: "https://example.com/blue.jpg" },
    ],
    pricing: { ...result, priceCny: 200, oldPriceCny: 260 },
  };
  const items = buildImportItems(multiDraft, {
    category: multiDraft.ozonCategory,
    pricing: multiDraft.pricing,
    selectedSkus: multiDraft.skus,
    categoryAttributes: catAttrs,
    variantAttributeId: 10096, // 旧的单轴配置应被 specs 匹配覆盖
  });
  check("两个 SKU 各出一条", items.length === 2, `得到 ${items.length}`);
  check("SKU1 写颜色+尺码两条真实变体", items[0].attributes.filter((a) => a.id === 8229 || a.id === 8230).length === 2, JSON.stringify(items[0].attributes));
  check("SKU1 颜色值为红", items[0].attributes.find((a) => a.id === 8229).values[0].value === "红色", "");
  check("SKU2 颜色值为蓝", items[1].attributes.find((a) => a.id === 8229).values[0].value === "蓝色", "");
  check("旧的单轴 variantAttributeId 不重复出现（specs 已覆盖）", !items[0].attributes.some((a) => a.id === 10096), JSON.stringify(items[0].attributes));
  check("多 SKU 仍共享 model_name 才能合并", items[0].model_name === items[1].model_name);
}

// 兜底：SKU 没有 specs 时，回落到界面配置的单轴 variantAttributeId + 规格标签（旧行为不变）
{
  const legacyDraft = {
    ...draft,
    skus: [
      { id: "s1", label: "红色/XL", price: 100, stock: 5, image: "" },
      { id: "s2", label: "蓝色/L", price: 200, stock: 0, image: "" },
    ],
  };
  const items = buildImportItems(legacyDraft, { pricing: draft.pricing, selectedSkus: legacyDraft.skus, variantAttributeId: 10096 });
  check("无 specs 时回落单轴变体属性（多 SKU）",
    items.length === 2 && items.every((it) => it.attributes.some((a) => a.id === 10096)),
    JSON.stringify(items[0].attributes));
  check("回落变体值取规格标签（红色/XL、蓝色/L）",
    items[0].attributes.find((a) => a.id === 10096).values[0].value === "红色/XL"
      && items[1].attributes.find((a) => a.id === 10096).values[0].value === "蓝色/L",
    JSON.stringify(items.map((it) => it.attributes.find((a) => a.id === 10096)?.values?.[0]?.value)));
}

// 回归：options.category 为空对象 {} 时不能误把 draft.ozonCategory 忽略成 0
{
  const catDraft = {
    ...draft,
    ozonCategory: { descriptionCategoryId: 17028933, typeId: 96529 },
  };
  const fallback = buildImportItem(catDraft, { category: {}, pricing: result });
  check("options.category 为空时回落到 draft.ozonCategory",
    fallback.description_category_id === 17028933 && fallback.type_id === 96529,
    JSON.stringify(fallback));
}

console.log("=== 产品图筛选（采集与面板共用规则）===");
{
  check("URL 带 logo 直接排除", !isLikelyProductImage("https://x.com/assets/logo_new.png"));
  check("URL 带 icon 直接排除", !isLikelyProductImage("https://x.com/static/icon-cart.svg"));
  check("正常产品图（无尺寸信息）保留", isLikelyProductImage("https://cbu01.alicdn.com/img/ibank/O1CN01.jpg"));

  const main = "https://cbu01.alicdn.com/img/ibank/main.jpg";
  check("大图（1200×1200）保留", isLikelyProductImage(main, { [main]: { width: 1200, height: 1200 } }));
  const tiny = "https://cbu01.alicdn.com/img/ibank/tiny.png";
  check("小图（48×48）判为图标", !isLikelyProductImage(tiny, { [tiny]: { width: 48, height: 48 } }));
  const strip = "https://cbu01.alicdn.com/img/ibank/banner.jpg";
  check("细长条（600×80）判为非产品图", !isLikelyProductImage(strip, { [strip]: { width: 600, height: 80 } }));
  const wide = "https://cbu01.alicdn.com/img/ibank/wide.jpg";
  check("宽幅产品图（800×400）保留", isLikelyProductImage(wide, { [wide]: { width: 800, height: 400 } }));
  check("判定理由带尺寸", /图标（48×48）/.test(productImageReason(tiny, { [tiny]: { width: 48, height: 48 } })), productImageReason(tiny, { [tiny]: { width: 48, height: 48 } }));

  const list = [main, tiny, strip, wide, "https://x.com/logo.png"];
  const kept = filterProductImages(list, {
    [main]: { width: 1200, height: 1200 },
    [tiny]: { width: 48, height: 48 },
    [strip]: { width: 600, height: 80 },
    [wide]: { width: 800, height: 400 },
  });
  check("批量筛选只留产品图", kept.length === 2 && kept.includes(main) && kept.includes(wide), JSON.stringify(kept));
}

console.log("=== 本地内置中文类目树（达瓦同款，全中文、无俄语）===");
{
  const treePath = path.join(ROOT, "assets", "ozon-category-tree.js");
  check("中文类目树文件已内置", fs.existsSync(treePath), treePath);
  const mod = await import(pathToFileURL(treePath).href);
  const bundle = mod.OZON_CATEGORY_TREE_BUNDLE || mod.default;
  check("bundle 是有效的类目树", bundle && Array.isArray(bundle.tree) && bundle.tree.length > 0, JSON.stringify(bundle?.stats));
  // v1.9.65：类目树改由 Ozon 官方 XLS 模板重建（26 域 / 542 类目 / 8600 类型，type_id 全部来自模板 info 的「类型」属性）
  check("统计信息：26 顶层域 / 542 类目 / 8600 类型（全部带 type_id）",
    bundle.stats.domains === 26 && bundle.stats.categories === 542 && bundle.stats.leaves === 8600
    && bundle.stats.typesWithId === 8600 && bundle.stats.typesPending === 0,
    JSON.stringify(bundle.stats));
  check("bundle schemaVersion 升到 2（官方模板重建）", bundle.schemaVersion === 2, String(bundle.schemaVersion));
  // 抽样：前 25 个一级类目名应全是中文（无俄语）
  const level1 = bundle.tree.map((n) => n.title || n.category_name);
  check("一级类目全中文（无俄语/英文混杂）", level1.every((t) => /^[\u4e00-\u9fa5（）·／、\w\s-]+$/.test(t)) && !level1.some((t) => /[а-яА-Я]/.test(t)), JSON.stringify(level1.slice(0, 8)));
  // 抽样叶子：带 type_id + type_name 且为中文
  let sampleLeaf = null;
  const walk = (arr) => { for (const n of arr) { if ((n.type_id || (n.children && !n.children.length))) { sampleLeaf = n; return; } if (n.children) walk(n.children); } };
  walk(bundle.tree);
  check("叶子节点带 Ozon type_id（上传必需）", sampleLeaf && Number(sampleLeaf.type_id) > 0, JSON.stringify(sampleLeaf));
  check("叶子节点带中文 type_name", sampleLeaf && /[\u4e00-\u9fa5]/.test(String(sampleLeaf.type_name || sampleLeaf.title)), JSON.stringify(sampleLeaf));
  check("节点带 description_category_id（上传必需）", sampleLeaf && Number(sampleLeaf.description_category_id) > 0, JSON.stringify(sampleLeaf));
  // 关键：被中文路径打分函数 treeHasChinese 判定为「已中文」
  check("中文树会被判定为已中文（不再触发 AI 俄→中翻译）", level1.slice(0, 30).some((t) => /[\u4e00-\u9fa5]/.test(t)));
}

console.log("=== 类目树归一化 ===");
// v1 树：一级/二级是类目，三级叶子是类型（type_name + type_id）
{
  const realFetch = globalThis.fetch;
  globalThis.fetch = async () => ({
    ok: true,
    status: 200,
    json: async () => ({
      result: [{
        description_category_id: 17028922,
        category_name: "Дом и сад",
        children: [{
          description_category_id: 17028933,
          category_name: "Мебель",
          children: [{ type_id: 96529, type_name: "Стеллаж" }],
        }],
      }],
    }),
  });
  const tree = await fetchCategoryTree({ clientId: "1", apiKey: "k" }, { language: "ru" });
  globalThis.fetch = realFetch;

  const root = tree[0];
  const child = root.children[0];
  const type = child.children[0];
  check("一级类目名归一化到 title", root.title === "Дом и сад", root.title);
  check("类型节点用 type_name 作为 title（原来会渲染成空白）", type.title === "Стеллаж", type.title);
  check("类型节点带 type_id", type.type_id === 96529, String(type.type_id));
  check("类型节点继承父级 description_category_id", type.description_category_id === 17028933 && type.category_id === 17028933, String(type.description_category_id));
  check("类目节点 type_id 为 0（不可直接上传）", root.type_id === 0, String(root.type_id));
}

console.log("=== 上传前预检 ===");
{
  const ready = { ...draft, ozonCategory: { descriptionCategoryId: 17028933, typeId: 96529 } };
  let passed = true;
  try { assertReadyToImport(ready, { category: ready.ozonCategory, pricing: result }); } catch { passed = false; }
  check("类目/类型/价格齐全时通过", passed);

  let typeMessage = "";
  try { assertReadyToImport({ ...draft, ozonCategory: { descriptionCategoryId: 17028933, typeId: 0 } }, { pricing: result }); }
  catch (error) { typeMessage = error.message; }
  check("type_id 为 0 时给中文提示（对应 Ozon 的 type_id must be greater than 0）",
    /类型/.test(typeMessage) && /type_id/.test(typeMessage), typeMessage);

  let priceMessage = "";
  try { assertReadyToImport({ ...draft, ozonCategory: { descriptionCategoryId: 1, typeId: 2 }, pricing: { priceCny: 0 } }); }
  catch (error) { priceMessage = error.message; }
  check("售价为 0 时给中文提示", /售价/.test(priceMessage), priceMessage);

  let catMessage = "";
  try { assertReadyToImport(draft, { pricing: { priceCny: 200 } }); }
  catch (error) { catMessage = error.message; }
  check("完全没选类目时给中文提示", /类目/.test(catMessage), catMessage);
}

console.log("=== 图片服务可用性检测 ===");
{
  const realFetch = globalThis.fetch;
  const makeRes = (status, payload) => ({ ok: status >= 200 && status < 300, status, json: async () => payload });
  let probeUrl = "";
  let probeBody = null;
  let probeAuth = "";
  const stub = (status, payload) => async (url, init) => {
    probeUrl = String(url);
    probeAuth = init?.headers?.Authorization || init?.headers?.["X-API-Key"] || "";
    probeBody = init?.body ? JSON.parse(init.body) : null;
    return makeRes(status, payload);
  };

  globalThis.fetch = stub(401, { code: 401, message: "invalid key" });
  const bad = await testXiangjiKey({ apiKey: "BADKEY0001", vendor: "DeepL" });
  check("象寄 401 判为密钥不可用", bad.ok === false && /无效|过期/.test(bad.error), JSON.stringify(bad));

  globalThis.fetch = stub(200, { code: 0, data: { results: [] } });
  const good = await testXiangjiKey({ apiKey: "GOODKEY000001", vendor: "DeepL" });
  check("象寄返回 code 0 判为可用", good.ok === true, JSON.stringify(good));
  check("探测用不存在的 task_id，不创建任务（不消耗额度）",
    probeUrl.endsWith("/task/v1/image/translate/result") && Array.isArray(probeBody?.task_ids) && probeBody.task_ids.length === 1
    && !("image_urls" in (probeBody || {})), `${probeUrl} ${JSON.stringify(probeBody)}`);
  check("检测带 X-API-Key 鉴权头（不是 Bearer）", probeAuth === "GOODKEY000001", probeAuth);
  check("密钥只回掩码，不回明文", !("key" in good) && /^GOOD••••0001$/.test(good.keyMask || ""), JSON.stringify(good));

  globalThis.fetch = stub(200, { code: 1001, message: "任务不存在" });
  const unknownTask = await testXiangjiKey({ apiKey: "GOODKEY000001", vendor: "Aliyun" });
  check("象寄业务错误（任务不存在）仍判可用", unknownTask.ok === true, JSON.stringify(unknownTask));

  globalThis.fetch = stub(200, { code: 1002, message: "key quota exceeded" });
  const quota = await testXiangjiKey({ apiKey: "GOODKEY000001", vendor: "Baidu" });
  check("象寄提示额度/密钥问题时判为不可用", quota.ok === false, JSON.stringify(quota));

  globalThis.fetch = stub(200, { code: 0, data: { results: [] } });
  const batch = await testXiangjiKeys({ keys: [{ vendor: "DeepL", key: "AAAABBBB" }, { vendor: "Aliyun", key: "CCCCDDDD" }] });
  check("多把密钥批量检测并汇总", batch.ok === true && batch.usable === 2 && batch.total === 2, JSON.stringify({ u: batch.usable, t: batch.total }));
  check("空密钥列表给中文提示", (await testXiangjiKeys({ keys: [] })).results.length === 0);

  // AI 生图：走 /models 探针
  let imgUrl = "";
  let imgAuth = "";
  globalThis.fetch = async (url, init) => {
    imgUrl = String(url);
    imgAuth = init?.headers?.Authorization || "";
    return makeRes(200, { data: [{ id: "Kwai-Kolors/Kolors" }, { id: "Qwen/Qwen-Image" }] });
  };
  const imgOk = await testImageGeneration({ baseUrl: "https://api.siliconflow.cn/v1/", apiKey: "SK1234567890", model: "Kwai-Kolors/Kolors" });
  check("生图检测走 GET /models（不生成图片，不消耗额度）", imgUrl === "https://api.siliconflow.cn/v1/models", imgUrl);
  check("生图检测带 Bearer 鉴权", imgAuth === "Bearer SK1234567890", imgAuth);
  check("生图连接正常并能确认模型名存在", imgOk.ok === true && imgOk.modelFound === true, JSON.stringify(imgOk));

  globalThis.fetch = async () => makeRes(200, { data: [{ id: "Qwen/Qwen-Image" }] });
  const imgModelMiss = await testImageGeneration({ baseUrl: "https://api.siliconflow.cn/v1", apiKey: "SK", model: "Kwai-Kolors/Kolors" });
  check("模型名对不上时仍判连接可用但标记 modelFound=false", imgModelMiss.ok === true && imgModelMiss.modelFound === false, JSON.stringify(imgModelMiss));
  check("模型名对不上时，提示写明这个模型名来自「生图模型名称」输入框（避免以为插件自己冒出来的）",
    /生图模型名称/.test(imgModelMiss.note) && /Kwai-Kolors\/Kolors/.test(imgModelMiss.note), imgModelMiss.note);
  check("提示回带本次比对的模型名，面板可原样展示", imgModelMiss.model === "Kwai-Kolors/Kolors", imgModelMiss.model);

  globalThis.fetch = async () => makeRes(401, { error: { message: "invalid api key" } });
  const imgBadKey = await testImageGeneration({ baseUrl: "https://api.siliconflow.cn/v1", apiKey: "BAD", model: "x" });
  check("生图 Key 无效时给中文提示", imgBadKey.ok === false && /Key/.test(imgBadKey.error), imgBadKey.error);

  globalThis.fetch = async () => makeRes(404, {});
  const imgNoProbe = await testImageGeneration({ baseUrl: "https://api.siliconflow.cn/v1", apiKey: "SK", model: "x" });
  check("服务未开放 /models 时明确说明无法免额度验证", imgNoProbe.ok === false && imgNoProbe.probeUnsupported === true, JSON.stringify(imgNoProbe));

  const imgNoUrl = await testImageGeneration({ baseUrl: "", apiKey: "SK", model: "x" });
  check("缺少 Base URL 时给中文提示", imgNoUrl.ok === false && /Base URL/.test(imgNoUrl.error), imgNoUrl.error);

  // ===== 异步出图轮询（中转站常见的「先返 task_id，再轮询取图」流程） =====
  // POST 阶段返回任务号
  globalThis.fetch = async (url, init) => {
    const u = String(url);
    if (init?.method === "POST") return makeRes(200, { task_id: "img_async_1" });
    // 轮询阶段：第二个候选端点 /edits/{id} 返回图片
    if (/\/edits\/img_async_1/.test(u)) return makeRes(200, { data: [{ url: "https://i/out-async.png" }] });
    return makeRes(404, { error: "not found" });
  };
  const rAsync = await redrawImage({
    baseUrl: "https://demo-relay.example/v1", apiKey: "DK", model: "gpt-image-2", context: "床", size: "1024x1024",
  });
  check("异步出图能轮询取回图片 URL", rAsync?.url === "https://i/out-async.png", JSON.stringify(rAsync));

  // 状态明确失败：不傻等到超时
  globalThis.fetch = async (url, init) => {
    if (init?.method === "POST") return makeRes(200, { task_id: "img_async_2" });
    return makeRes(200, { status: "failed", error: "model rejected" });
  };
  let asyncErr = "";
  try {
    await redrawImage({ baseUrl: "https://demo-relay.example/v1", apiKey: "DK", model: "x", context: "床" });
  } catch (e) { asyncErr = String(e?.message || e); }
  check("异步任务服务端明确失败时立即报错",
    /失败/.test(asyncErr) && /img_async_2/.test(asyncErr), asyncErr);

  globalThis.fetch = realFetch;
}

console.log("=== AI 生图预设（达瓦 ERP 中转已移除）===");
{
  check("不再提供达瓦 ERP 中转预设", !IMAGE_PRESETS.some((item) => item.id === "dawaerp"), "");
  check("预设里没有任何 dawaerp.cn 残留", !JSON.stringify(IMAGE_PRESETS).includes("dawaerp"), "");
  check("硅基流动仍是排在首位的推荐预设", IMAGE_PRESETS[0]?.id === "siliconflow", IMAGE_PRESETS[0]?.id);

  const creds = resolveImageCredentials({
    imageBaseUrl: "https://api.siliconflow.cn/v1", imageApiKey: "SK", imageModel: "Kwai-Kolors/Kolors", imageSize: "1024x1024",
  });
  check("生图凭据带出图尺寸", creds.size === "1024x1024" && creds.model === "Kwai-Kolors/Kolors", JSON.stringify(creds));

  // 出图尺寸校验：格式错 → 拦住；不在官方列表 → 警告但放行；custom → 不管
  const sf = IMAGE_PRESETS.find((item) => item.id === "siliconflow");
  const custom = IMAGE_PRESETS.find((item) => item.id === "custom");
  const openai = IMAGE_PRESETS.find((item) => item.id === "openai");

  check("预设都声明了 supportedSizes", IMAGE_PRESETS.every((p) => Array.isArray(p.supportedSizes)), "");
  check("预设的 defaultSize 一定在 supportedSizes 里（否则默认值自己就报警）",
    IMAGE_PRESETS.every((p) => !p.supportedSizes.length || p.supportedSizes.includes(p.defaultSize)),
    IMAGE_PRESETS.map((p) => `${p.id}:${p.defaultSize}`).join(" "));

  check("尺寸在支持列表里：通过且无警告", (() => {
    const r = validateImageSize(sf, "1024x1024", "Kwai-Kolors/Kolors");
    return r.ok === true && !r.warning;
  })(), JSON.stringify(validateImageSize(sf, "1024x1024", "Kwai-Kolors/Kolors")));

  check("尺寸格式不对：直接拦住并给中文提示", (() => {
    const r = validateImageSize(sf, "1024*1024", "Kwai-Kolors/Kolors");
    return r.ok === false && /格式不对/.test(r.error);
  })(), JSON.stringify(validateImageSize(sf, "1024*1024", "Kwai-Kolors/Kolors")));

  check("尺寸为空：拦住", validateImageSize(sf, "  ", "x").ok === false, "");

  check("尺寸不在列表里：放行但给警告（写清是哪个预设支持的）", (() => {
    const r = validateImageSize(sf, "2048x2048", "Kwai-Kolors/Kolors");
    return r.ok === true && /2048x2048/.test(r.warning) && /硅基流动/.test(r.warning);
  })(), JSON.stringify(validateImageSize(sf, "2048x2048", "Kwai-Kolors/Kolors")));

  check("OpenAI + dall-e-3 的越界尺寸给更具体的提示（只认 1024/1792 系列）", (() => {
    const r = validateImageSize(openai, "1024x1536", "dall-e-3");
    return r.ok === true && /dall-e-3/.test(r.warning) && /1792/.test(r.warning);
  })(), JSON.stringify(validateImageSize(openai, "1024x1536", "dall-e-3")));

  check("OpenAI + gpt-image-1 的 1024x1536 属于支持列表（不误报）",
    (() => { const r = validateImageSize(openai, "1024x1536", "gpt-image-1"); return r.ok === true && !r.warning; })(), "");

  // sizesByModel 收紧：dall-e-3 的有效列表必须是它自己的那份，而不是并集
  check("sizesByModel 命中时优先于 supportedSizes",
    effectiveSupportedSizes(openai, "dall-e-3").join(",") === "1024x1024,1792x1024,1024x1792",
    effectiveSupportedSizes(openai, "dall-e-3").join(","));
  check("模型不在 sizesByModel 里时回落到预设并集",
    effectiveSupportedSizes(openai, "gpt-image-1").includes("auto"),
    effectiveSupportedSizes(openai, "gpt-image-1").join(","));
  check("模型名大小写不敏感（DALL-E-3 也能命中）",
    effectiveSupportedSizes(openai, "DALL-E-3").length === 3, effectiveSupportedSizes(openai, "DALL-E-3").join(","));

  check("custom 预设不校验尺寸（用户自己清楚）",
    (() => { const r = validateImageSize(custom, "2048x2048", "x"); return r.ok === true && !r.warning; })(), "");

  const realFetch = globalThis.fetch;
  const okJson = (payload) => ({ ok: true, status: 200, json: async () => payload });
  let sentUrl = "";
  let sentBody = null;

  globalThis.fetch = async (url, init) => {
    sentUrl = String(url);
    sentBody = JSON.parse(init.body);
    return okJson({ data: [{ url: "https://i.tosoiot.com/out.png" }] });
  };
  const sfOut = await redrawImage({ baseUrl: "https://api.siliconflow.cn/v1", apiKey: "SK", model: "Kwai-Kolors/Kolors", context: "床", size: "1024x1024" });
  check("硅基流动请求打在 /v1/images/generations", sentUrl === "https://api.siliconflow.cn/v1/images/generations", sentUrl);
  check("生图请求保持标准字段（不附带 aspect_ratio，避免严格接口 400）",
    !("aspect_ratio" in sentBody) && !("aspectRatio" in sentBody) && sentBody.size === "1024x1024",
    JSON.stringify(sentBody).slice(0, 120));
  check("能解析远端图片地址", sfOut.url === "https://i.tosoiot.com/out.png", JSON.stringify(sfOut));

  globalThis.fetch = async (url, init) => { sentUrl = String(url); sentBody = JSON.parse(init.body); return okJson({ data: [{ b64_json: "AAA" }] }); };
  await redrawImage({ baseUrl: "https://api.siliconflow.cn/v1/", apiKey: "SK", model: "FLUX.1-schnell", context: "床", size: "1024x1024" });
  check("带结尾斜杠的 Base URL 仍走 /images/generations", sentUrl === "https://api.siliconflow.cn/v1/images/generations", sentUrl);

  // 服务端排异步队列时（中转站 async task 流程）已改为轮询取图，由下一段用例覆盖；
  // 这里不再需要旧的「throw 异步未实现」测试。

  // ===== 阿里云百炼 Qwen-Image：官方明确「图像生成不走 OpenAI 兼容模式」=====
  // /compatible-mode/v1/images/generations 实测 404，必须走 DashScope 原生
  // POST {origin}/api/v1/services/aigc/multimodal-generation/generation。
  globalThis.fetch = async (url, init) => {
    sentUrl = String(url);
    sentBody = JSON.parse(init.body);
    return okJson({ output: { choices: [{ message: { content: [{ image: "https://dashscope-result/out.png" }] } }] } });
  };
  const qwenOut = await redrawImage({
    baseUrl: "https://dashscope.aliyuncs.com/api/v1", apiKey: "SK", model: "qwen-image-3.0", context: "床", size: "1024x1536",
  });
  check("Qwen-Image 走 DashScope 原生 multimodal-generation 端点",
    sentUrl === "https://dashscope.aliyuncs.com/api/v1/services/aigc/multimodal-generation/generation", sentUrl);
  check("Qwen-Image 请求体是 DashScope 原生格式（input.messages + parameters）",
    typeof sentBody?.input?.messages?.[0]?.content?.[0]?.text === "string"
    && sentBody?.parameters?.watermark === false
    && typeof sentBody?.parameters?.prompt_extend === "boolean",
    JSON.stringify(sentBody).slice(0, 160));
  check("Qwen-Image 尺寸转成 DashScope 的「宽*高」（1024*1536）", sentBody?.parameters?.size === "1024*1536", sentBody?.parameters?.size);
  check("Qwen-Image 返回的图片 URL 被正确提取", qwenOut.url === "https://dashscope-result/out.png", JSON.stringify(qwenOut));

  // 用户填裸域名 / compatible-mode/v1 也统一归到原生端点
  globalThis.fetch = async (url, init) => { sentUrl = String(url); return okJson({ output: { choices: [{ message: { content: [{ image: "https://x/a.png" }] } }] } }); };
  await redrawImage({ baseUrl: "https://dashscope.aliyuncs.com", apiKey: "SK", model: "qwen-image-3.0", context: "x" });
  check("裸域名也归到原生端点", sentUrl === "https://dashscope.aliyuncs.com/api/v1/services/aigc/multimodal-generation/generation", sentUrl);
  await redrawImage({ baseUrl: "https://dashscope.aliyuncs.com/compatible-mode/v1", apiKey: "SK", model: "qwen-image-3.0", context: "x" });
  check("填了 /compatible-mode/v1 也归到原生端点（兼容模式生图不存在）", sentUrl === "https://dashscope.aliyuncs.com/api/v1/services/aigc/multimodal-generation/generation", sentUrl);

  // 工作空间专属域名走原生端点
  globalThis.fetch = async (url, init) => { sentUrl = String(url); return okJson({ output: { choices: [{ message: { content: [{ image: "https://x/b.png" }] } }] } }); };
  await redrawImage({ baseUrl: "https://ws-abc123.cn-beijing.maas.aliyuncs.com/api/v1", apiKey: "SK", model: "qwen-image-3.0-pro", context: "x" });
  check("工作空间域名走原生端点",
    sentUrl === "https://ws-abc123.cn-beijing.maas.aliyuncs.com/api/v1/services/aigc/multimodal-generation/generation", sentUrl);

  // 工作空间域名报 OSS 鉴权错误时，自动回退标准域名重试
  {
    const tried = [];
    globalThis.fetch = async (url, init) => {
      tried.push(String(url));
      if (/maas\.aliyuncs\.com/.test(String(url))) {
        return { ok: false, status: 400, json: async () => ({ error: { message: "required OSS authorization headers are missing or invalid" } }) };
      }
      return okJson({ output: { choices: [{ message: { content: [{ image: "https://std/out.png" }] } }] } });
    };
    const fallbackOut = await redrawImage({
      baseUrl: "https://ws-abc123.cn-beijing.maas.aliyuncs.com/api/v1", apiKey: "SK", model: "qwen-image-3.0", context: "x",
    });
    check("maas 工作空间域名 OSS 报错时自动回退标准域名", fallbackOut.url === "https://std/out.png", JSON.stringify(fallbackOut));
    check("回退请求打到 dashscope.aliyuncs.com 的原生端点",
      tried.length === 2 && /maas\.aliyuncs\.com/.test(tried[0]) && tried[1] === "https://dashscope.aliyuncs.com/api/v1/services/aigc/multimodal-generation/generation",
      JSON.stringify(tried));
  }

  const qwenProbe = await testImageGeneration({ baseUrl: "https://dashscope.aliyuncs.com/api/v1", apiKey: "SK", model: "qwen-image-3.0" });
  check("Qwen-Image 检测注明走原生端点且无法免额度验证",
    qwenProbe.ok === true && qwenProbe.probeUnsupported === true
    && /multimodal-generation/.test(qwenProbe.endpoint || ""), JSON.stringify(qwenProbe));

  globalThis.fetch = realFetch;

  // 权限回归：缺对应主机权限，后台 fetch 会被直接拦掉
  const manifest = JSON.parse(fs.readFileSync(path.join(HERE, "../manifest.json"), "utf8"));
  const hosts = manifest.host_permissions || [];
  check("manifest 不再授予 dawaerp.cn 主机权限（达瓦中转已移除）", !hosts.some((item) => /dawaerp\.cn/.test(item)), JSON.stringify(hosts.filter((item) => /dawaerp/.test(item))));
  check("manifest 授予硅基流动主机权限", hosts.some((item) => /siliconflow\.cn/.test(item)));
  check("manifest 授予百炼工作空间域名 *.maas.aliyuncs.com 主机权限",
    hosts.some((item) => /maas\.aliyuncs\.com/.test(item)), JSON.stringify(hosts.filter((item) => /maas/.test(item))));
  check("manifest 授予阿里云 OSS 结果图域名 *.aliyuncs.com 主机权限",
    hosts.some((item) => /aliyuncs\.com/.test(item)), JSON.stringify(hosts.filter((item) => /aliyuncs/.test(item))));
}

console.log("=== Base URL 规范化（生图/文案共用）===");
{
  check("去掉结尾多余的斜杠", normalizeApiBase("https://demo-relay.example/v1/") === "https://demo-relay.example/v1", normalizeApiBase("https://demo-relay.example/v1/"));
  check("全角冒号纠正为半角（中文输入法常见）", normalizeApiBase("https：//demo-relay.example/v1") === "https://demo-relay.example/v1", normalizeApiBase("https：//demo-relay.example/v1"));
  check("全角斜杠纠正为半角", normalizeApiBase("https://demo-relay.example／v1") === "https://demo-relay.example/v1", normalizeApiBase("https://demo-relay.example／v1"));
  check("去掉零宽字符（从网页复制的 URL 会带，肉眼看不见）", normalizeApiBase("https://demo-relay.example/v1\u200b\ufeff") === "https://demo-relay.example/v1", normalizeApiBase("https://demo-relay.example/v1\u200b\ufeff"));
  check("去掉 URL 里的空格（含全角空格）", normalizeApiBase(" https://demo-relay.example / v1 ") === "https://demo-relay.example/v1", normalizeApiBase(" https://demo-relay.example / v1 "));
  check("只填域名时自动补 https://", normalizeApiBase("demo-relay.example/v1") === "https://demo-relay.example/v1", normalizeApiBase("demo-relay.example/v1"));
  check("空值返回空串", normalizeApiBase("   ") === "", normalizeApiBase("   "));

  // 用户真实反馈：把 new-api 后台复制出来的「整段渠道配置 JSON」粘进了地址框
  const channelJson = '{"_type":"newapi_channel_conn","key":"sk-demo","url":"https://demo-relay.example"}';
  const pickedCfg = extractApiConfig(channelJson);
  check("从渠道配置 JSON 里拆出 url", pickedCfg.url === "https://demo-relay.example", JSON.stringify(pickedCfg));
  check("从渠道配置 JSON 里拆出 key", pickedCfg.key === "sk-demo", JSON.stringify(pickedCfg));
  check("嵌套一层的配置也能拆",
    extractApiConfig('{"data":{"base_url":"https://x.cn/v1","api_key":"sk-a"}}').url === "https://x.cn/v1",
    JSON.stringify(extractApiConfig('{"data":{"base_url":"https://x.cn/v1","api_key":"sk-a"}}')));
  check("不是 JSON 的普通 URL 不被误拆", extractApiConfig("https://x.cn/v1").url === "", JSON.stringify(extractApiConfig("https://x.cn/v1")));
  check("单引号 / 非严格 JSON 用正则兜底",
    extractApiConfig("{'key':'sk-b', 'url':'https://y.cn'}").url === "https://y.cn",
    JSON.stringify(extractApiConfig("{'key':'sk-b', 'url':'https://y.cn'}")));
  check("normalizeApiBase 直接吃整段 JSON 也能出地址", normalizeApiBase(channelJson) === "https://demo-relay.example", normalizeApiBase(channelJson));
  check("JSON 里的地址同样会补 /v1（生图端点）",
    imagesEndpoint(channelJson) === "https://demo-relay.example/v1/images/generations", imagesEndpoint(channelJson));

  check("裸域名自动补 /v1（这是「URL 看着没错却 404」的根因）",
    imagesEndpoint("https://demo-relay.example/") === "https://demo-relay.example/v1/images/generations", imagesEndpoint("https://demo-relay.example/"));
  check("裸域名无斜杠也补 /v1", imagesEndpoint("https://demo-relay.example") === "https://demo-relay.example/v1/images/generations", imagesEndpoint("https://demo-relay.example"));
  check("带 /v1 的 base 正常拼接", imagesEndpoint("https://api.siliconflow.cn/v1") === "https://api.siliconflow.cn/v1/images/generations", imagesEndpoint("https://api.siliconflow.cn/v1"));
  check("已经是完整端点时原样返回", imagesEndpoint("https://x.cn/v1/images/generations") === "https://x.cn/v1/images/generations", imagesEndpoint("https://x.cn/v1/images/generations"));
  check("非 /v1 的自定义路径不被乱改", imagesEndpoint("https://x.cn/api") === "https://x.cn/api/images/generations", imagesEndpoint("https://x.cn/api"));
  check("探测端点由同一 base 推出（测的就是要请求的域名）",
    modelsEndpoint("https://demo-relay.example/") === "https://demo-relay.example/v1/models", modelsEndpoint("https://demo-relay.example/"));

  // 端到端：用户填了「带全角冒号 + 没有 /v1」的地址，检测与生图都要能正常走通
  const realFetch = globalThis.fetch;
  let seenUrl = "";
  globalThis.fetch = async (url, init) => {
    seenUrl = String(url);
    return { ok: true, status: 200, json: async () => ({ data: [{ id: "gpt-image-2" }] }) };
  };
  const tricky = "https：//demo-relay.example/";
  const probe = await testImageGeneration({ baseUrl: tricky, apiKey: "DK", model: "gpt-image-2" });
  check("全角冒号 + 缺 /v1 的地址也能检测通过", probe.ok === true && probe.modelFound === true, JSON.stringify(probe?.error || probe?.note));
  check("检测打到正确的 /v1/models", seenUrl === "https://demo-relay.example/v1/models", seenUrl);
  check("检测结果回带规范化后的 Base URL（面板据此纠正输入框）", probe.baseUrl === "https://demo-relay.example", probe.baseUrl);
  check("检测结果回带实际生图地址", probe.endpoint === "https://demo-relay.example/v1/images/generations", probe.endpoint);

  // 端到端：整段渠道配置 JSON 直接粘进地址框，检测也要能走通（本轮用户的实际场景）
  const jsonProbe = await testImageGeneration({ baseUrl: channelJson, apiKey: "sk-demo", model: "gpt-image-2" });
  check("整段渠道配置 JSON 粘进地址框也能检测通过",
    jsonProbe.ok === true && seenUrl === "https://demo-relay.example/v1/models",
    JSON.stringify({ ok: jsonProbe.ok, seenUrl, error: jsonProbe.error }));

  globalThis.fetch = async (url, init) => { seenUrl = String(url); return { ok: true, status: 200, json: async () => ({ data: [{ url: "https://i/out.png" }] }) }; };
  await redrawImage({ baseUrl: tricky, apiKey: "DK", model: "gpt-image-2", context: "床", size: "1008x1344" });
  check("同一个地址拿去真正生图也打对了端点", seenUrl === "https://demo-relay.example/v1/images/generations", seenUrl);
  globalThis.fetch = realFetch;

  const notUrl = await testImageGeneration({ baseUrl: "随便写的", apiKey: "DK", model: "x" });
  check("确实不是 URL 时给出中文提示并回显读到值", notUrl.ok === false && /格式不对/.test(notUrl.error) && /随便写的/.test(notUrl.error), notUrl.error);

  // 配置里拆出来的裸域名，AI 文案端也要能补 /v1（与生图规则一致）
  const notUrlBlob = await testImageGeneration({ baseUrl: '{"url":"不是地址","key":"sk-x"}', apiKey: "DK", model: "x" });
  check("地址仍不合法时，不会把整段配置 JSON 回显到报错里",
    notUrlBlob.ok === false && /格式不对/.test(notUrlBlob.error) && !/\{/.test(notUrlBlob.error),
    notUrlBlob.error);

  check("AI 文案：裸域名补 /v1", buildChatEndpoint("https://demo-relay.example") === "https://demo-relay.example/v1/chat/completions", buildChatEndpoint("https://demo-relay.example"));
  check("AI 文案：带尾斜杠的裸域名同样补 /v1", buildChatEndpoint("https://demo-relay.example/") === "https://demo-relay.example/v1/chat/completions", buildChatEndpoint("https://demo-relay.example/"));
  check("AI 文案：已带 /v1 不重复补", buildChatEndpoint("https://x.cn/v1") === "https://x.cn/v1/chat/completions", buildChatEndpoint("https://x.cn/v1"));
  check("AI 文案：完整端点原样返回", buildChatEndpoint("https://x.cn/v1/chat/completions") === "https://x.cn/v1/chat/completions", buildChatEndpoint("https://x.cn/v1/chat/completions"));
  check("AI 文案：自定义路径不被乱改", buildChatEndpoint("https://x.cn/api") === "https://x.cn/api/chat/completions", buildChatEndpoint("https://x.cn/api"));
  check("AI 文案：整段渠道配置 JSON 也能拆出地址", buildChatEndpoint(channelJson) === "https://demo-relay.example/v1/chat/completions", buildChatEndpoint(channelJson));
}

console.log("=== Ozon 物流渠道 ===");
{
  check("物流渠道是 Ozon 命名且带默认头程单价",
    LOGISTICS_MODES.length >= 4 && LOGISTICS_MODES.every((m) => /^Ozon /.test(m.label) && m.defaultRate > 0 && m.etaDays),
    JSON.stringify(LOGISTICS_MODES.map((m) => m.id)));
  check("旧版渠道 id 自动迁移（sea→ozon_sea）", LEGACY_LOGISTICS_MODE_MAP.sea === "ozon_sea" && LEGACY_LOGISTICS_MODE_MAP.air === "ozon_air");
  check("旧配置读入自动迁移", normalizePricingTemplate({ logisticsMode: "sea" }).logisticsMode === "ozon_sea");
  check("未知渠道回落默认", normalizePricingTemplate({ logisticsMode: "whatever" }).logisticsMode === "ozon_air");
  check("新渠道原样保留", normalizePricingTemplate({ logisticsMode: "ozon_express" }).logisticsMode === "ozon_express");
}

console.log("=== 上传前自检（Ozon 400 中文排查）===");
{
  const baseDraft = {
    id: "d1", title: "连衣裙", ru: { title: "Платье" },
    images: ["https://img.example/1.jpg"], pricing: { priceCny: 200 }, attributeValues: {},
  };
  const baseOptions = {
    category: { descriptionCategoryId: 1, typeId: 2 },
    pricing: { priceCny: 200 },
    weightGrams: 500, depthMm: 100, widthMm: 100, heightMm: 100,
    requiredAttributeIds: [], attributeValues: {},
  };
  const ok = collectImportDiagnostics(baseDraft, baseOptions);
  check("完整草稿自检应无硬伤", ok.problems.length === 0, JSON.stringify(ok));

  const noTitle = collectImportDiagnostics({ ...baseDraft, title: "", ru: {} }, baseOptions);
  check("无俄语标题会列为硬伤", noTitle.problems.some((t) => /名称/.test(t)), JSON.stringify(noTitle.problems));

  const noType = collectImportDiagnostics(baseDraft, { ...baseOptions, category: { descriptionCategoryId: 1 } });
  check("未选到「类型」是硬伤", noType.problems.some((t) => /type_id/.test(t)), JSON.stringify(noType.problems));

  const noImage = collectImportDiagnostics({ ...baseDraft, images: [] }, baseOptions);
  check("没图是硬伤", noImage.problems.some((t) => /图/.test(t)), JSON.stringify(noImage.problems));

  const priceZero = collectImportDiagnostics(baseDraft, { ...baseOptions, pricing: { priceCny: 0 } });
  check("售价 0 是硬伤", priceZero.problems.some((t) => /售价/.test(t)), JSON.stringify(priceZero.problems));

  const oldEqPrice = collectImportDiagnostics(baseDraft, { ...baseOptions, pricing: { priceCny: 1000, oldPriceCny: 1000 } });
  check("划线价不高于售价是软提示（不会失败）", oldEqPrice.problems.length === 0 && oldEqPrice.warnings.some((t) => /划线价/.test(t)),
    JSON.stringify(oldEqPrice));

  const missingReq = collectImportDiagnostics(baseDraft, { ...baseOptions, requiredAttributeIds: [9048], attributeValues: {} });
  check("必填属性没填是硬伤", missingReq.problems.some((t) => /必填/.test(t)), JSON.stringify(missingReq.problems));
}

console.log("=== 俄语文案：品类保真（足球鞋不许写成跑步鞋）===");
{
  check("系统提示词明令不许歪曲商品类型", /НЕ ИСКАЖАЙ ТИП ТОВАРА/.test(SYSTEM_PROMPT), SYSTEM_PROMPT.slice(0, 220));
  check("系统提示词点名禁止把专用鞋写成「для бега»", /для бега/.test(SYSTEM_PROMPT) && /ЗАПРЕЩЕНО/.test(SYSTEM_PROMPT));
  check("系统提示词禁止编造品牌/材质/数字", /не придумывай бренды/.test(SYSTEM_PROMPT));
  check("JSON 结构里要求返回 productType", /"productType"/.test(JSON_SCHEMA_HINT) || /productType/.test(JSON_SCHEMA_HINT));
  check("JSON 结构里要求返回 usage", /"usage"/.test(JSON_SCHEMA_HINT));

  const boot = {
    title: "足球鞋 男 训练比赛专用 钉鞋",
    platform: "1688",
    description: "人造草地碎钉足球鞋，适合足球训练与比赛",
    attributes: [{ name: "适用场地", value: "人造草地" }],
    skus: [{ label: "40码/黑红", price: 88 }],
    ozonCategory: { path: ["Обувь", "Спортивная обувь", "Футбольные бутсы"] },
  };

  const free = buildListingMessages(boot, {})[1].content;
  check("未指定品类时不注入硬约束", !/ТИП ТОВАРА ЗАДАН ПОЛЬЗОВАТЕЛЕМ/.test(free));
  check("已选类目路径会传给模型", /Категория Ozon \(уже выбрана\): Обувь > Спортивная обувь > Футбольные бутсы/.test(free), free.slice(-420));

  const locked = buildListingMessages(boot, { productType: "Футбольные бутсы" })[1].content;
  check("用户指定的品类作为硬约束注入", /ТИП ТОВАРА ЗАДАН ПОЛЬЗОВАТЕЛЕМ: «Футбольные бутсы»/.test(locked), locked.slice(-420));
  check("硬约束明确要求不许改用途", /Пиши строго в рамках этого типа, не меняй назначение/.test(locked));
  check("空白品类不会变成假硬约束", !/ТИП ТОВАРА ЗАДАН ПОЛЬЗОВАТЕЛЕМ/.test(buildListingMessages(boot, { productType: "   " })[1].content));

  const parsed = parseListingResult('{"productType":"Футбольные бутсы","usage":"для футбола","title":"Футбольные бутсы для игры на траве","keywords":"бутсы, обувь"}');
  check("解析出 productType 与 usage", parsed?.productType === "Футбольные бутсы" && parsed?.usage === "для футбола", JSON.stringify(parsed));
  check("keywords 字符串也能切成数组", Array.isArray(parsed?.keywords) && parsed.keywords.length === 2, JSON.stringify(parsed?.keywords));

  const alias = parseListingResult('{"product_type":"Кроссовки для баскетбола","purpose":"для баскетбола","title":"х"}');
  check("兼容 product_type / purpose 别名", alias?.productType === "Кроссовки для баскетбола" && alias?.usage === "для баскетбола", JSON.stringify(alias));
  const overlong = parseListingResult(`{"productType":"${"я".repeat(120)}"}`);
  check("过长的 productType 被截断到 80 字符", overlong?.productType.length === 80, String(overlong?.productType.length));
  check("没有 productType 字段时回落为空串（不炸）", parseListingResult('{"title":"только заголовок"}')?.productType === "");

  const applied = applyListingResult({ ru: { title: "старый" } }, parsed);
  check("生成结果写进草稿：productType / usage / title 都带上",
    applied.ru.productType === "Футбольные бутсы" && applied.ru.usage === "для футбола"
      && applied.ru.title === "Футбольные бутсы для игры на траве", JSON.stringify(applied.ru));
  const kept = applyListingResult({ ru: { productType: "Футбольные бутсы", usage: "для футбола", title: "t" } }, { title: "новый", productType: "", usage: "" });
  check("新结果缺字段时保留草稿里已有的品类", kept.ru.productType === "Футбольные бутсы" && kept.ru.usage === "для футбола", JSON.stringify(kept.ru));

  // 卖点 / 出图方案也要带上已确定的品类，否则图上的卖点又会被泛化成「运动鞋」
  const brief = buildSellingPointsMessages({ ...boot, ru: { productType: "Футбольные бутсы", title: "Футбольные бутсы для травы" } }, {})[1].content;
  check("卖点提示词带上已确定的品类", /Уже определённый тип товара: Футбольные бутсы/.test(brief), brief.slice(0, 300));
  check("卖点提示词带上 Ozon 标题", /Заголовок для Ozon: Футбольные бутсы для травы/.test(brief));
  check("卖点系统提示词禁止改用途", /не меняй назначение товара/.test(SELLING_POINTS_SYSTEM_PROMPT) && /футбольные бутсы/.test(SELLING_POINTS_SYSTEM_PROMPT));
  check("出图方案系统提示词禁止泛化用途", /назначение товара не менять и не обобщать/.test(IMAGE_PLAN_SYSTEM_PROMPT));
  const plan = buildImagePlanMessages({ ...boot, ru: { productType: "Футбольные бутсы" } }, [{ id: "main", label: "主图" }])[1].content;
  check("出图方案提示词也带上品类", /Уже определённый тип товара: Футбольные бутсы/.test(plan), plan.slice(0, 300));
}

console.log("=== 类目 AI 二次精选（候选驱动） ===");
{
  const cands = [
    { path: ["Дом и сад", "Мебель", "Детская кроватка"] },
    { path: ["Дом и сад", "Мебель", "Кровати"] },
    { path: ["Одежда", "Платья"] },
  ];
  const msgs = buildCategoryPickMessages({ title: "实木婴儿床", platform: "1688" }, cands);
  check("类目提示词带候选列表", /Кандидаты категорий Ozon:/.test(msgs[1].content) && /path=Дом и сад.*Детская кроватка/.test(msgs[1].content), msgs[1].content.slice(-300));
  check("类目提示词带商品标题", /实木婴儿床/.test(msgs[1].content), msgs[1].content.slice(-200));
  check("类目提示词要求 JSON 答案", /\{"index":/.test(msgs[0].content), msgs[0].content.slice(-200));

  check("AI 选 1 → 0", parseCategoryPickResult('{"index":1}', 3) === 0);
  check("AI 选 3 → 2", parseCategoryPickResult('{"index":3}', 3) === 2);
  check("越界判失败", parseCategoryPickResult('{"index":9}', 3) === -1);
  check("0 判失败（编号从 1 开始）", parseCategoryPickResult('{"index":0}', 3) === -1);
  check("AI 答案编号是数字串也行", parseCategoryPickResult('{"index":"1"}', 3) === 0);
  check("非 JSON 判失败", parseCategoryPickResult("没有 JSON", 3) === -1);
  check("```json 围栏也能解析", parseCategoryPickResult('```json\n{"index":2}\n```', 3) === 1);
  const detailedPick = parseCategoryPickDetails('{"index":2,"category_id":11,"type_id":22,"path":"家居 / 货架","confidence":0.86,"reason":"商品用于收纳"}', 3);
  check("类目 AI 结果保留候选 ID、置信度和理由",
    detailedPick?.index === 1 && detailedPick.categoryId === 11 && detailedPick.typeId === 22
      && detailedPick.confidence === 0.86 && detailedPick.reason === "商品用于收纳", JSON.stringify(detailedPick));
  const categoryPrompt = buildCategoryPickMessages({
    title: "儿童房置物架",
    description: "用于收纳书籍和玩具的货架",
    images: ["https://img.example/shelf.jpg"],
  }, [{ path: ["家居", "货架"], node: { category_id: 11, type_id: 22 } }])[1].content;
  check("类目提示词包含候选 ID 和商品功能约束",
    /category_id=11; type_id=22/.test(categoryPrompt)
      && /назначение|функц/i.test(categoryPrompt)
      && /货架/.test(categoryPrompt), categoryPrompt.slice(-500));
}

console.log("=== 类目识别：领域词典消歧（借鉴达瓦两阶段匹配）===");
{
  check("领域词典覆盖主流品类", CATEGORY_DOMAINS.length >= 10, `共 ${CATEGORY_DOMAINS.length} 个领域`);
  const storage = detectProductDomains({ title: "实木货架 厨房置物架 收纳储物 落地多层展示架" });
  check("货架类商品优先命中家居收纳领域", storage[0]?.domain === "家居收纳", JSON.stringify(storage.map((d) => d.domain)));
  const toy = detectProductDomains({ title: "儿童积木拼装玩具 益智早教公仔" });
  check("玩具类商品优先命中儿童玩具领域", toy[0]?.domain === "儿童玩具/游乐", JSON.stringify(toy.map((d) => d.domain)));
  const phone = detectProductDomains({ title: "iPhone 手机壳 钢化膜 数据线 type-c 充电器" });
  check("3C 配件命中数码配件领域", phone.some((d) => d.domain === "3C数码配件"), JSON.stringify(phone.map((d) => d.domain)));
  check("货架路径被识别为家居收纳领域", domainsOfPath(["Дом и сад", "Мебель", "Стеллаж"]).includes("家居收纳"));
  check("儿童游戏架路径不会被误判为收纳（含儿童/玩具领域）", domainsOfPath(["Детские товары", "Игровые комплексы", "Детская площадка"]).some((d) => d === "儿童玩具/游乐" || d === "儿童家具/围栏"));
}

console.log("=== AI 自动识别规格维度 ===");
{
  const msgs = buildSpecDetectMessages({
    title: "夏季纯棉T恤",
    platform: "1688",
    skus: [{ label: "白色/S" }, { label: "白色/M" }, { label: "黑色/S" }],
  });
  check("规格识别提示词包含商品标题", /夏季纯棉T恤/.test(msgs[1].content));
  check("规格识别提示词要求 options JSON", /"options"/.test(msgs[1].content));
  const parsed = parseSpecDetectResult('{"options": [{"name": "Цвет", "values": ["белый", "чёрный"]}, {"name": "Размер", "values": ["S", "M", "L"]}]}');
  check("规格识别解析返回选项数组", parsed?.length === 2 && parsed[0].values.length === 2, JSON.stringify(parsed));
  const empty = parseSpecDetectResult('{"options": []}');
  check("规格识别解析空 options 返回 null", empty === null);
}

console.log("=== OZON 上架表口径（对齐用户自用的「上架表」）===");
{
  // 表里「计价方式」页各渠道的最新报价（a × 重量g + b）
  const byId = (id) => findOzonChannel(id);
  check("六个 Ozon 渠道齐全且都有 a/b", OZON_CHANNELS.length === 6
    && OZON_CHANNELS.every((c) => Number(c.logistics.a) > 0 && Number(c.logistics.b) > 0),
    JSON.stringify(OZON_CHANNELS.map((c) => c.id)));
  check("超级轻小件 a/b 对齐计价方式页", byId("super_light").logistics.a === 0.0281 && byId("super_light").logistics.b === 3.37);
  check("低客单标准 a/b 对齐计价方式页", byId("low_standard").logistics.a === 0.0191 && byId("low_standard").logistics.b === 25.83);
  check("小件低客单 a/b 对齐计价方式页", byId("small_low").logistics.a === 0.0281 && byId("small_low").logistics.b === 17.79);
  check("大件低客单 a/b 对齐计价方式页", byId("big_low").logistics.a === 0.0191 && byId("big_low").logistics.b === 40.44);
  check("小件高客单 a/b 对齐计价方式页", byId("small_high").logistics.a === 0.0281 && byId("small_high").logistics.b === 24.71);
  check("大件高客单 a/b 对齐计价方式页", byId("big_high").logistics.a === 0.0258 && byId("big_high").logistics.b === 69.64);

  check("国际物流 U = a × 重量 + b", ozonLogisticsCny(6500, { a: 0.0191, b: 40.44 }) === 164.59,
    String(ozonLogisticsCny(6500, { a: 0.0191, b: 40.44 })));
  check("自动判定渠道：6.5kg + 1500¥ → 大件高客单", pickOzonChannel({ weightG: 6500, priceCny: 1500 }).id === "big_high");
  check("自动判定渠道：300g + 50¥ → 超级轻小件", pickOzonChannel({ weightG: 300, priceCny: 50 }).id === "super_light");
  check("自动判定渠道：1kg + 300¥ → 小件低客单", pickOzonChannel({ weightG: 1000, priceCny: 300 }).id === "small_low");

  // 用表里 X1 农场第 3 行验算正向链路：J=204.25 K=1519.84 M=0.65 P=0.03 R=0.1 T=6500
  // U=0.01768*6500+37.44=152.36 → N=531.944 Q=15.9583 S=53.1944 V=310.4313 W=308.2583 X=104.0083 Y=0.5092
  const U = 0.01768 * 6500 + 37.44;
  const row = evaluateListing({
    costCny: 204.25, priceCny: 1519.84, logisticsCny: U,
    template: { discountRate: 0.65, adRate: 3, commissionRate: 10 },
  });
  check("表里第 3 行：活动售价 N = 531.94", Math.abs(row.promoCny - 531.94) < 0.02, String(row.promoCny));
  check("表里第 3 行：店铺利润 X = 104.01", Math.abs(row.profitCny - 104.01) < 0.02, String(row.profitCny));
  check("表里第 3 行：采购利润率 Y = 50.9%", Math.abs(row.purchaseMarginRate - 0.509) < 0.002, String(row.purchaseMarginRate));
  check("表里第 3 行：物流利润率 AA = X/(J+U)", Math.abs(row.logisticsMarginRate - 104.01 / (204.25 + U)) < 0.002,
    String(row.logisticsMarginRate));

  // 反推：给定目标采购利润率 50.9%，应能倒回接近 1519.84 的售价
  const back = suggestPriceCny({
    costCny: 204.25, logisticsCny: U, targetProfitRate: 50.9,
    discountRate: 0.65, adRate: 3, commissionRate: 10, withdrawalRate: 0.993, roundingStep: 0.01,
  });
  check("按目标利润率反推售价能回到表里的 1519.84", Math.abs(back - 1519.84) < 1.5, String(back));

  // computeListing 端到端：渠道/物流/售价/利润率都能算出来
  const full = computeListing({
    costCny: 204.25, weightG: 6500, lengthCm: 60, widthCm: 20, heightCm: 50,
    template: { discountRate: 0.65, adRate: 3, commissionRate: 10, targetProfitRate: 50 },
  });
  check("computeListing 给出渠道与 a/b", Boolean(full.channelId) && full.logisticsA > 0 && full.logisticsB > 0,
    `${full.channelId} ${full.logisticsA}/${full.logisticsB}`);
  check("computeListing 体积重 = 长×宽×高/12000", Math.abs(full.volumetricKg - (60 * 20 * 50) / 12000) < 0.001,
    String(full.volumetricKg));
  check("computeListing 售价为正且利润率达标", full.priceCny > 0 && full.purchaseMarginRate >= 0.49,
    `${full.priceCny} / ${full.purchaseMarginRate}`);
  check("computeListing 支持锁定渠道", computeListing({ costCny: 100, weightG: 1000, template: { channelId: "super_light" } }).channelId === "super_light");

  check("核价模板默认汇率 10.5 / 提现 0.993 / 体积重除数 12000",
    DEFAULT_LISTING_TEMPLATE.exchangeRate === 10.5 && DEFAULT_LISTING_TEMPLATE.withdrawalRate === 0.993
    && DEFAULT_LISTING_TEMPLATE.volumetricDivisor === 12000);
  check("核价模板 clamp：折扣不能超过 95%", normalizeListingTemplate({ discountRate: 2 }).discountRate === 0.95);

  // 导出的上架表：31 列，且核心列带公式
  check("上架表表头 31 列（A→AE）", LISTING_HEADERS.length === 31, String(LISTING_HEADERS.length));
  check("上架表表头首列是序号、末列是密度", LISTING_HEADERS[0] === "序号" && LISTING_HEADERS[30] === "密度");
  const draft = {
    id: "d1", platform: "1688", title: "吊扇灯", sourceUrl: "https://detail.1688.com/offer/1.html",
    logistics: { freightCny: 11 },
    parcel: { weightKg: 6.5, lengthCm: 60, widthCm: 20, heightCm: 50 },
    skus: [{ id: "s1", label: "42寸银色 / 均码", price: 215.25, basePrice: 204.25, calc: full }],
  };
  const outRows = draftToListingRows(draft, { exchangeRate: 10.5, withdrawalRate: 0.993, volumetricDivisor: 12000 }, 3);
  const one = outRows[0];
  check("上架表导出：采集原价进 G 列", one[6] === 204.25, String(one[6]));
  check("上架表导出：运费进 H 列", one[7] === 11, String(one[7]));
  check("上架表导出：重量换算成 g 进 T 列", one[19] === 6500, String(one[19]));
  check("上架表导出：J 拿货成本 = G+H 公式", one[9]?.f === "G3+H3", JSON.stringify(one[9]));
  check("上架表导出：L 售价₽ = K×汇率 公式", one[11]?.f === "K3*10.5", JSON.stringify(one[11]));
  check("上架表导出：V 结算 = N-Q-S-U 公式", one[21]?.f === "N3-Q3-S3-U3", JSON.stringify(one[21]));
  check("上架表导出：W 提现 = V×0.993 公式", one[22]?.f === "V3*0.993", JSON.stringify(one[22]));
  check("上架表导出：X 利润 = W-J 公式", one[23]?.f === "W3-J3", JSON.stringify(one[23]));
  check("上架表导出：AE 密度 = 高×宽×长/12000", one[30]?.f === "AD3*AC3*AB3/12000", JSON.stringify(one[30]));
  check("上架表导出：U 国际物流带渠道 a/b", /^\(0\.\d+\*T3\+[\d.]+\)$/.test(String(one[20]?.f || "")), JSON.stringify(one[20]));
  check("上架表导出：长宽高写入 AB/AC/AD", one[27] === 60 && one[28] === 20 && one[29] === 50,
    `${one[27]},${one[28]},${one[29]}`);
  const noCalc = draftToListingRows({ ...draft, skus: [{ id: "s1", label: "x", price: 100 }] }, { exchangeRate: 10.5 }, 5);
  check("上架表导出：没算过价的 SKU 也不会崩", noCalc.length === 1 && noCalc[0][10] === 0, JSON.stringify(noCalc[0]?.[10]));

  // v1.9.30：拿货成本拆「采购成本 + 国内运费」（自动采集，表单可覆盖）
  const parts1 = splitCostCny({ sku: { basePrice: 129, price: 144 }, draft: { logistics: { freightCny: 15 } } });
  check("成本拆分：采购价 129 + 运费 15 = 144", parts1.purchase === 129 && parts1.freight === 15 && parts1.cost === 144, JSON.stringify(parts1));
  const parts2 = splitCostCny({ sku: { basePrice: 129, price: 144 }, draft: { logistics: { freightCny: 15 } }, template: { purchaseCost: 130, domesticFreight: 20 } });
  check("成本拆分：表单手填优先于采集值", parts2.purchase === 130 && parts2.freight === 20 && parts2.cost === 150, JSON.stringify(parts2));
  const parts3 = splitCostCny({ sku: { price: 144 }, draft: { logistics: { freightCny: 15 } } });
  check("成本拆分：老数据没有 basePrice 时从含运费价里扣，不重复计", parts3.purchase === 129 && parts3.cost === 144, JSON.stringify(parts3));
  const parts4 = splitCostCny({ sku: { price: 100 }, draft: {} });
  check("成本拆分：没有运费时成本就是采购价", parts4.purchase === 100 && parts4.freight === 0 && parts4.cost === 100, JSON.stringify(parts4));
  const parts5 = splitCostCny({ sku: { price: 144 }, draft: { logistics: { freightCny: 15 } }, template: { domesticFreight: 0 } });
  check("成本拆分：表单运费填 0 时回落到采集运费", parts5.freight === 15, JSON.stringify(parts5));
}

console.log("=== 采集精度（content script 工具）===");
{
  // content script 是挂在 window 上的经典脚本，这里在 vm 里加载同一份源码来测它的纯函数
  const src = fs.readFileSync(path.join(HERE, "../src/content/adapter-base.js"), "utf8");
  const ctx = { console, setTimeout, clearTimeout, setInterval, clearInterval, performance };
  ctx.window = ctx;
  ctx.location = { origin: "https://detail.1688.com" };
  ctx.document = {
    querySelector: () => null,
    querySelectorAll: () => [],
    documentElement: { innerHTML: "" },
    body: { innerText: "" },
  };
  vm.createContext(ctx);
  vm.runInContext(src, ctx);
  const utils = ctx.__OZON_ADAPTERS__.utils;

  check("标题去掉【包邮】与结尾平台名", utils.sanitizeTitle("【包邮】纯棉短袖T恤 男士 夏季 - 1688.com") === "纯棉短袖T恤 男士 夏季",
    utils.sanitizeTitle("【包邮】纯棉短袖T恤 男士 夏季 - 1688.com"));
  check("标题去掉开头的营销词", utils.sanitizeTitle("包邮 纯棉T恤") === "纯棉T恤", utils.sanitizeTitle("包邮 纯棉T恤"));
  check("标题去掉 emoji", utils.sanitizeTitle("🔥爆款🔥 保温杯") === "保温杯", utils.sanitizeTitle("🔥爆款🔥 保温杯"));
  check("正常标题原样保留（不误删商品词）", utils.sanitizeTitle("纯棉短袖T恤") === "纯棉短袖T恤", utils.sanitizeTitle("纯棉短袖T恤"));
  check("超长标题按上限截断", utils.sanitizeTitle("A".repeat(300), 200).length === 200);

  const range = utils.parsePriceRange("¥12.50 - 15.80");
  check("区间价解析出最小/最大值", range.min === 12.5 && range.max === 15.8, JSON.stringify(range));
  const single = utils.parsePriceRange("12.50起");
  check("单价解析 min=max", single.min === 12.5 && single.max === 12.5 && !single.range, JSON.stringify(single));
  const noisy = utils.parsePriceRange("月销 1200 件 ¥9.90");
  check("价格里混入销量时不会把销量当价格", noisy.min === 9.9 && noisy.max === 9.9, JSON.stringify(noisy));
  check("无价格文本返回 0", utils.parsePriceRange("").min === 0);

  // v1.9.31：价格脏数据（DOM 拼接 / 销量混入）不能当成本
  const dirty1 = utils.parsePriceRange("¥100.001起批");
  check("价格解析：三位小数是 DOM 拼接脏数据，直接丢弃", dirty1.min === 0, JSON.stringify(dirty1));
  const dirty2 = utils.parsePriceRange("¥100.00 1起批");
  check("价格解析：「¥100.00 1起批」只取 100，起批量 1 不当价格", dirty2.min === 100 && dirty2.max === 100, JSON.stringify(dirty2));
  const dirty3 = utils.parsePriceRange("7天成交750+ 月销100+");
  check("价格解析：「750+」这类销量数字不当价格", dirty3.min === 0, JSON.stringify(dirty3));
  const okPrice = utils.parsePriceRange("¥129.00 - 158.00");
  check("价格解析：正常区间价不受影响", okPrice.min === 129 && okPrice.max === 158, JSON.stringify(okPrice));

  const skus = utils.dedupeSkus([
    { id: "a", specs: { 颜色: "红" }, price: 1 },
    { id: "b", specs: { 颜色: "红" }, price: 2 },
    { id: "c", specs: { 颜色: "蓝" }, price: 3 },
    { id: "d", specs: {}, price: 0 },
  ]);
  check("重复规格的 SKU 只留一条", skus.length === 2, JSON.stringify(skus.map((s) => s.id)));
  check("既无规格又无价格的空 SKU 被丢弃", !skus.some((s) => s.id === "d"), JSON.stringify(skus.map((s) => s.id)));

  // 三个适配器都应写入区间价上限、并调用标题清洗
  for (const [file, label] of [["adapter-1688.js", "1688"], ["adapter-taobao.js", "淘宝"], ["adapter-pdd.js", "拼多多"]]) {
    const code = fs.readFileSync(path.join(HERE, `../src/content/${file}`), "utf8");
    check(`${label} 写入区间价上限（max）`, /max:\s*price\.max/.test(code), "");
    check(`${label} 采到的标题会做清洗`, /sanitizeTitle\(/.test(code), "");
  }
  // 回归：1688 旧写法把 ?? 和三元混在一起，会取错 SKU 价格
  const code1688 = fs.readFileSync(path.join(HERE, "../src/content/adapter-1688.js"), "utf8");
  check("1688 SKU 价格不再用 ?? 混三元（取价优先级 bug 回归）",
    !/\?\?[^;\n]*!\s*=\s*null\s*\?/.test(code1688), "");

  // 1688 SKU 表格行解析：用户只看「规格 / 价格 / 库存」三列
  const ctx2 = { console, setTimeout, clearTimeout, setInterval, clearInterval, performance };
  ctx2.window = ctx2;
  ctx2.location = { origin: "https://detail.1688.com" };
  ctx2.document = { querySelector: () => null, querySelectorAll: () => [], documentElement: { innerHTML: "" }, body: { innerText: "" } };
  vm.createContext(ctx2);
  vm.runInContext(fs.readFileSync(path.join(HERE, "../src/content/adapter-base.js"), "utf8"), ctx2);
  vm.runInContext(code1688, ctx2);
  const sku1688 = ctx2.__OZON_ADAPTERS__.sku1688;

  const row1 = sku1688.parseSkuRow(["小号 米白 可自由组合", "¥78", "42123箱"]);
  check("1688 SKU 行拆出规格名", row1.label === "小号 米白 可自由组合", JSON.stringify(row1));
  check("1688 SKU 行拆出价格 ¥78", row1.price === 78, JSON.stringify(row1));
  check("1688 SKU 行拆出库存 42123箱", row1.stock === 42123, JSON.stringify(row1));

  // 真实页面常见：整行塞在一个节点里（规格+价+库存混排）
  const blob = sku1688.parseSkuRow(["小号 米白 可自由组合¥78库存42123箱"]);
  check("1688 SKU 单格混排也能拆出规格/价格/库存",
    blob && blob.label === "小号 米白 可自由组合" && blob.price === 78 && blob.stock === 42123, JSON.stringify(blob));
  // 碎片行（只有价格或只有库存）不是一条 SKU，必须丢弃
  check("1688 SKU 碎片行「¥78」被丢弃", sku1688.parseSkuRow(["¥78"]) === null);
  check("1688 SKU 碎片行「库存42123箱」被丢弃", sku1688.parseSkuRow(["库存42123箱"]) === null);
  check("1688 纯规格行（无价格无库存）不当 SKU", sku1688.parseSkuRow(["小号 米白 可自由组合"]) === null);
  check("1688 运费解析「运费 ¥11 起」", sku1688.parseFreightCny("运费 ¥11 起") === 11);
  check("1688 运费解析「快递 ¥8」", sku1688.parseFreightCny("快递 ¥8") === 8);
  check("1688 规格值过滤价格/库存碎片", !sku1688.isSpecNoise("米白") && sku1688.isSpecNoise("¥78") && sku1688.isSpecNoise("库存42123箱"));

  const row2 = sku1688.parseSkuRow(["中号 米白 可自由组合", "¥88.50", "3,210件"]);
  check("1688 SKU 行支持千分位与小数价", row2.price === 88.5 && row2.stock === 3210, JSON.stringify(row2));

  // ==================== v1.9.82 矩阵式 SKU 行展开（超哥截图：猫窝 2色×2码只采到 1 条）====================
  {
    const matrixOptions = [
      { name: "颜色", values: ["手提房灰色【带电热毯】", "手提房蓝色【带电热毯】"] },
      { name: "大小", values: ["中号", "大号"] },
    ];
    // 矩阵价库行：颜色名不在行上，一行按颜色排开两组价库
    const mid = sku1688.expandSkuMatrixRow("中号 ¥41.6 库存9930个 ¥41.6 库存9930个", matrixOptions);
    check("矩阵：价库行展开成 2 条（颜色维度回来）",
      Array.isArray(mid) && mid.length === 2
      && mid[0].specs.大小 === "中号" && mid[0].specs.颜色 === "手提房灰色【带电热毯】"
      && mid[1].specs.颜色 === "手提房蓝色【带电热毯】", JSON.stringify(mid));
    check("矩阵：展开保留各自价格与库存",
      mid[0].price === 41.6 && mid[0].stock === 9930 && mid[1].price === 41.6 && mid[1].stock === 9930, JSON.stringify(mid));
    // 两色价格不同也能分别落到对应颜色
    const diff = sku1688.expandSkuMatrixRow("中号 ¥41.6 库存9930个 ¥43.6 库存120个", matrixOptions);
    check("矩阵：两色价格/库存不同分别归属",
      diff[0].price === 41.6 && diff[1].price === 43.6 && diff[1].stock === 120, JSON.stringify(diff));
    // 整块容器（无换行、两行挤一起）：切片分组后仍能全展开
    const blobAll = sku1688.expandSkuLineToSkus("规格 颜色 大小 中号 ¥41.6 库存9930个 ¥41.6 库存9930个 大号 ¥49.6 库存9997个 ¥49.6 库存9997个", matrixOptions);
    check("矩阵：整块容器展开成 4 条（2色×2码全回来）",
      Array.isArray(blobAll) && blobAll.length === 4
      && new Set(blobAll.map((s) => `${s.specs.颜色}|${s.specs.大小}`)).size === 4, JSON.stringify(blobAll));
    // 安全护栏：普通完整行不触发矩阵（走原逻辑，返回 null）
    check("矩阵护栏：完整单行（含两维+一组价库）不触发矩阵展开",
      sku1688.expandSkuMatrixRow("手提房灰色【带电热毯】 中号 ¥41.6 库存9930个", matrixOptions) === null, "");
    // 安全护栏：缺 2 个维度不猜
    const threeOpts = [...matrixOptions, { name: "款式", values: ["标准", "豪华"] }];
    check("矩阵护栏：缺 2 个维度时不展开（避免错配）",
      sku1688.expandSkuMatrixRow("中号 ¥41.6 库存9930个 ¥41.6 库存9930个", threeOpts) === null, "");
    // 安全护栏：配对数 ≠ 缺失维度候选数不展开
    check("矩阵护栏：价库组数≠颜色数时不展开",
      sku1688.expandSkuMatrixRow("中号 ¥41.6 库存9930个 ¥43.6 库存120个 ¥45.6 库存50个", matrixOptions) === null, "");
    // 安全护栏：同维度出现两个值（窗口跨行）不展开
    check("矩阵护栏：同一维度命中两个值时不展开",
      sku1688.expandSkuMatrixRow("中号 大号 ¥41.6 库存9930个 ¥49.6 库存9997个", matrixOptions) === null, "");
    check("导出：expandSkuMatrixRow / expandSkuLineToSkus 已挂到 sku1688",
      typeof sku1688.expandSkuMatrixRow === "function" && typeof sku1688.expandSkuLineToSkus === "function", "");
  }

  const row3 = sku1688.parseSkuRow(["规格", "价格", "库存"]);
  check("1688 SKU 表头行被丢弃", row3 === null, JSON.stringify(row3));

  const row4 = sku1688.parseSkuRow(["大号 黑色", "98", "500"]);
  check("1688 SKU 无 ¥ 时第一个数字当价格、第二个当库存", row4.price === 98 && row4.stock === 500, JSON.stringify(row4));

  const specs = sku1688.splitSpecLabel("小号 米白 可自由组合", [
    { name: "尺码", values: ["小号", "中号", "大号"] },
    { name: "颜色", values: ["米白", "黑色"] },
  ]);
  check("1688 规格串按维度还原成键值", specs["尺码"] === "小号" && specs["颜色"] === "米白" && specs["规格"] === "可自由组合", JSON.stringify(specs));
  check("1688 无维度时规格串整体保留", sku1688.splitSpecLabel("小号 米白", [])["规格"] === "小号 米白", JSON.stringify(sku1688.splitSpecLabel("小号 米白", [])));
  check("1688 有价有库的清单得分更高",
    sku1688.scoreSkuList([{ price: 10, stock: 5, label: "a" }]) > sku1688.scoreSkuList([{ price: 0, stock: 0, label: "a" }]));
  check("1688 SKU 采集优先用表格行", /pickSkuTableRows\(specOptions\)/.test(code1688) && /scoreSkuList\(list\)/.test(code1688), "");
  check("1688 采集规格时同时收集规格图", /images\[`\$\{name\}\:\$\{label\}\`\]/.test(code1688), "");

  // v1.9.40 回归：新版 1688 店招/公司卡片被 h1 命中，公司名被当成商品标题（超哥截图案例）
  {
    const adapterBase = fs.readFileSync(path.join(HERE, "../src/content/adapter-base.js"), "utf8");
    const makeTitleCtx = (nodes, docTitle) => {
      const ctx = { console, setTimeout, clearTimeout, setInterval, clearInterval, performance };
      ctx.window = ctx;
      ctx.location = { origin: "https://detail.1688.com" };
      ctx.document = {
        title: docTitle,
        querySelector(sel) {
          const node = nodes[sel];
          if (!node) return null;
          return {
            textContent: node.textContent ?? "",
            getAttribute: (attr) => (attr === "content" ? node.content ?? "" : ""),
          };
        },
        querySelectorAll: () => [],
        documentElement: { innerHTML: "" },
        body: { innerText: "" },
      };
      vm.createContext(ctx);
      vm.runInContext(adapterBase, ctx);
      vm.runInContext(code1688, ctx);
      return ctx.__OZON_ADAPTERS__.sku1688;
    };
    const PRODUCT = "丹安娜鸟新款单板滑雪板成人专业雪板平花板全能板碳纤维一件代发";
    const COMPANY = "威海丹泰体育用品有限公司";
    const t1 = makeTitleCtx({
      'meta[name="og:title"]': { content: "" },
      'meta[property="og:title"]': { content: PRODUCT },
      ".d-title": { textContent: COMPANY },
      h1: { textContent: COMPANY },
    }, `${PRODUCT} - 阿里巴巴`);
    check("1688 标题不采公司名：h1 被店招误命中时改用 og:title", t1.pickTitle() === PRODUCT, t1.pickTitle());
    check("1688 og:title 用 property 属性也能取到（旧写法只查 name 基本取不到）",
      t1.pickTitle() === PRODUCT, "");
    const t2 = makeTitleCtx({
      'meta[name="og:title"]': { content: "" },
      'meta[property="og:title"]': { content: "" },
      h1: { textContent: COMPANY },
    }, `${PRODUCT} - 阿里巴巴`);
    check("1688 og:title 缺失时用 document.title 清洗成商品标题", t2.pickTitle() === PRODUCT, t2.pickTitle());
    const t3 = makeTitleCtx({
      'meta[property="og:title"]': { content: "" },
      h1: { textContent: COMPANY },
    }, "");
    // v1.9.63 行为变更：全部候选都是公司名时改为返回空串。
    // 旧行为是把公司名当商品标题发给 AI，模型只能回「原始数据中只标注了官方名称」这种废话，
    // 用户看到的是「AI 不认识这个商品」，根本想不到根因是采集把店铺名当成了标题。
    // 现在留空 + capture() 写一条诊断，用户才知道要去补标题。
    check("全部候选都是公司名时返回空串（不再把店铺名当商品标题）", t3.pickTitle() === "", t3.pickTitle());
    check("looksLikeCompanyName：公司名判真、商品标题判假",
      t1.looksLikeCompanyName(COMPANY) === true
        && t1.looksLikeCompanyName(PRODUCT) === false
        && t1.looksLikeCompanyName("义乌市XX电子商务厂") === true, "");
  }
  // v1.9.60：生成函数多了第三个参数 specDisabled（不可选组合标记），断言放宽到前两个参数
  check("1688 按规格维度生成 SKU 会挂规格图", /buildSkusFromOptions\(specOptions, specImages/.test(code1688), "");

  // v1.9.29 图片采集精度：主图 / 图集缩略图 / 详情长图 分组抓，不再一股脑全页扫
  check("1688 主图有大图专用选择器", /const GALLERY_MAIN_SELECTORS = \[/.test(code1688), "");
  check("1688 图集缩略图有专用选择器", /const GALLERY_THUMB_SELECTORS = \[/.test(code1688), "");
  check("1688 详情长图有专用容器", /const DETAIL_IMAGE_SELECTORS = \[/.test(code1688), "");
  check("1688 图片采集排除推荐位/店铺卡片", /const IMAGE_EXCLUDE_ZONES = \[/.test(code1688), "");
  check("1688 分组采集不再退回全页扫（noPageFallback）", /noPageFallback:\s*true/.test(code1688), "");
  check("1688 缩略图/详情长图允许小图（懒加载没有 naturalWidth）", /allowSmall:\s*true/.test(code1688), "");
  check("1688 详情长图会读 background-image", /includeBackground:\s*true/.test(code1688), "");
  check("1688 主图按尺寸挑而不是取第一张", /pickMainImage\(ordered, imageMeta\)/.test(code1688), "");
  check("1688 capture 单独返回详情长图", /detailImages,/.test(code1688), "");
  // v1.9.74：调用签名加了 specOptions（规格维度要传进文本行兜底，否则规格值全堆在「规格」键下）
  check("1688 SKU 价格矩阵有文本行兜底", /pickSkuRowsFromText\(cache, specOptions\)/.test(code1688) && /textSkus/.test(code1688), "");
  check("1688 SKU 采购价优先作为成本来源（脏价格防污染）", /已改用 SKU 采购价/.test(code1688), "");
  check("1688 SKU 行取图改用统一懒加载属性解析", /U\.imageSource\(rowImg\)/.test(code1688), "");
  check("1688 规格色卡图支持 background-image", /function nodeImageUrl\(node, img\)/.test(code1688), "");
  check("collectImages 支持排除区域与背景图", typeof utils.backgroundImageUrls === "function", "");

  const mainPicked = sku1688.pickMainImage(
    ["https://x/thumb.jpg", "https://x/main.jpg", "https://x/long.jpg"],
    {
      "https://x/thumb.jpg": { width: 60, height: 60 },
      "https://x/main.jpg": { width: 1000, height: 1000 },
      "https://x/long.jpg": { width: 800, height: 3000 },
    },
  );
  check("1688 主图挑正方形大图而不是细长图", mainPicked === "https://x/main.jpg", String(mainPicked));
  check("1688 没有尺寸信息时主图退回第一张",
    sku1688.pickMainImage(["https://x/a.jpg", "https://x/b.jpg"], {}) === "https://x/a.jpg", "");
  check("1688 图片面积打分", sku1688.imageAreaScore({ width: 800, height: 1000 }) === 800000, "");

  const detailProduct = normalizeProduct({
    platform: "1688",
    sourceUrl: "https://detail.1688.com/offer/1.html",
    images: ["https://cdn.1688.com/a.jpg"],
    detailImages: ["https://cdn.1688.com/b.jpg", "https://cdn.1688.com/a.jpg"],
  });
  check("详情长图单独存，并与主图集去重",
    detailProduct.detailImages.length === 1 && detailProduct.detailImages[0] === "https://cdn.1688.com/b.jpg",
    JSON.stringify(detailProduct.detailImages));
  const draftsCode = fs.readFileSync(path.join(HERE, "../src/ui/drafts.js"), "utf8");
  check("草稿会保存详情长图", /detailImages:\s*product\.detailImages \|\| \[\]/.test(draftsCode), "");

  // v1.9.31：SKU 价格矩阵文本行兜底（新版 1688 类名混淆，表格行选择器抓不到时）
  const lineCache = stubCache(() => [
    "规格 价格 库存",
    "1.2-1.2米灰色（海洋球+手拉环+收纳袋）",
    "¥100",
    "库存6698袋",
    "1.8-2.0米灰色（海洋球+手拉环+收纳袋）",
    "¥134",
    "库存3516袋",
  ].join("\n"));
  const textSkus1 = sku1688.pickSkuRowsFromText(lineCache);
  check("SKU 文本行兜底：三行一组能还原规格/价格/库存",
    textSkus1.length === 2 && textSkus1[0].price === 100 && textSkus1[0].stock === 6698 && textSkus1[1].price === 134,
    JSON.stringify(textSkus1));
  const blobCache = stubCache(() => "1.2米灰色（海洋球+手拉环）¥100 库存6698袋\n1.8米灰色（海洋球+手拉环）¥134 库存3516袋");
  const textSkus2 = sku1688.pickSkuRowsFromText(blobCache);
  check("SKU 文本行兜底：整行混排也能拆开",
    textSkus2.length === 2 && textSkus2[0].label.includes("1.2米灰色") && textSkus2[1].stock === 3516,
    JSON.stringify(textSkus2));
  const emptyCache = stubCache(() => "商品参数\n材质 塑料\n库存充足");
  check("SKU 文本行兜底：没有价格的正文不会被误判成 SKU", sku1688.pickSkuRowsFromText(emptyCache).length === 0, "");

  /* v1.9.34：变体缩略图。
   * 面板「确认采集到的 1688 SKU」的「图」列整列「无图」，上传时每个变体也就没有自己的主图——
   * 根因是文本行兜底只有规格/价格/库存，没有图。这里用一个最小假 DOM 回归新的行级抓图。 */
  const tnode = (value) => ({ text: value, nodeValue: value, textContent: value, children: [], tagName: null, attributes: {} });
  const enode = (tag, attrs = {}, children = []) => {
    const node = {
      tagName: tag.toUpperCase(),
      attributes: attrs,
      children: [],
      nodeValue: null,
      naturalWidth: attrs.naturalWidth || 0,
      naturalHeight: attrs.naturalHeight || 0,
      get textContent() { return this.children.map((child) => child.textContent || "").join(""); },
      getAttribute(name) { return Object.prototype.hasOwnProperty.call(this.attributes, name) ? this.attributes[name] : null; },
      querySelectorAll(selector) {
        const want = String(selector).toLowerCase();
        const out = [];
        const walk = (current) => {
          for (const child of current.children || []) {
            if (child.tagName && (want === "*" || child.tagName.toLowerCase() === want)) out.push(child);
            walk(child);
          }
        };
        walk(this);
        return out;
      },
    };
    for (const child of children) {
      child.parentElement = node;
      node.children.push(child);
    }
    return node;
  };
  const mountBody = (body) => {
    const list = [];
    const collect = (current) => {
      if (current.tagName === null) { list.push(current); return; }
      for (const child of current.children || []) collect(child);
    };
    collect(body);
    let index = -1;
    ctx2.document = {
      body,
      querySelector: () => null,
      querySelectorAll: () => [],
      createTreeWalker: () => ({ nextNode: () => (index += 1, index < list.length ? list[index] : null) }),
    };
    ctx2.NodeFilter = { SHOW_TEXT: 4 };
  };
  const skuRowNode = (label, price, stock, imgSrc, imgSize = 60) => enode("div", {}, [
    enode("img", { src: imgSrc, naturalWidth: imgSize, naturalHeight: imgSize }),
    enode("span", {}, [tnode(label)]),
    enode("span", {}, [tnode(price)]),
    enode("span", {}, [tnode(stock)]),
  ]);

  mountBody(enode("body", {}, [
    enode("div", {}, [tnode("库存充足，欢迎下单")]),
    enode("div", {}, [
      skuRowNode("标准款双向推-卡其色(EVA/八轮)", "¥129", "库存4333件", "https://c.1688.com/khaki.jpg"),
      skuRowNode("标准款双向推-亚麻灰(EVA/八轮)", "¥129", "库存4523件", "https://c.1688.com/gray.jpg"),
      skuRowNode("豪华款双向推-卡其色(EVA/八轮)", "¥139", "库存2662件", "https://c.1688.com/lux.jpg"),
    ]),
  ]));
  const domRows = sku1688.pickSkuRowsFromDom();
  check("SKU 变体图：每个变体都抓到了自己的缩略图",
    domRows.length === 3 && domRows.every((row) => /^https:\/\/c\.1688\.com\//.test(row.image)),
    JSON.stringify(domRows.map((row) => [row.label, row.image])));
  check("SKU 变体图：行内价格与库存照旧解析出来",
    domRows[0].price === 129 && domRows[0].stock === 4333 && domRows[2].price === 139,
    JSON.stringify(domRows.map((row) => [row.price, row.stock])));
  check("SKU 变体图：只有库存没有价格的块不会被当成 SKU",
    !domRows.some((row) => /欢迎下单/.test(row.label)), JSON.stringify(domRows.map((row) => row.label)));
  check("SKU 变体图：外层多行容器不会被误当成一行（库存词出现多次就放弃）",
    domRows.every((row) => row.label.length <= 40), JSON.stringify(domRows.map((row) => row.label.length)));

  // 图标（< 24px）不算变体图；整行只有图标时宁可不记这一行，也不挂个图标上去
  mountBody(enode("body", {}, [
    enode("div", {}, [
      enode("img", { src: "https://c.1688.com/arrow.png", naturalWidth: 12, naturalHeight: 12 }),
      enode("span", {}, [tnode("标准款-卡其色 ¥129 库存4333件")]),
    ]),
  ]));
  check("SKU 变体图：小图标不会被当成变体图", sku1688.pickSkuRowsFromDom().length === 0, JSON.stringify(sku1688.pickSkuRowsFromDom()));

  // 1688 色卡常把图铺在 background-image 上，没有 <img> 也要能取到
  mountBody(enode("body", {}, [
    enode("div", {}, [
      enode("span", { style: "background-image: url('https://c.1688.com/bg.jpg')" }, [tnode("亚麻蓝 ¥129 库存8194件")]),
    ]),
  ]));
  const bgRows = sku1688.pickSkuRowsFromDom();
  check("SKU 变体图：没有 img 时退回 background-image",
    bgRows.length === 1 && bgRows[0].image === "https://c.1688.com/bg.jpg", JSON.stringify(bgRows));

  // 补图策略：文本行选出的 SKU 要能按标签 / 规格值分别挂上 DOM 图与色卡图
  const domRowSkus = [
    { label: "标准款双向推-卡其色(EVA/八轮)", image: "https://c.1688.com/khaki.jpg" },
    { label: "标准款双向推-亚麻灰（EVA/八轮）", image: "https://c.1688.com/gray.jpg" },
  ];
  const specImageMap = { "颜色:亚麻蓝": "https://c.1688.com/swatch-blue.jpg" };
  const targetSkus = [
    { id: "a", label: "标准款双向推-卡其色(EVA/八轮)", specs: {}, image: "" },
    { id: "b", label: "标准款双向推-亚麻灰（EVA/八轮）", specs: {}, image: "" }, // 半角/全角括号差异
    { id: "c", label: "标准款双向推-亚麻蓝(EVA/八轮)", specs: { 颜色: "亚麻蓝" }, image: "" },
    { id: "d", label: "豪华款双向推-亚麻红(EVA/八轮)", specs: {}, image: "https://c.1688.com/keep.jpg" },
  ];
  const filledCount = sku1688.attachSkuImages(targetSkus, domRowSkus, specImageMap);
  check("变体补图：标签完全一致时挂上 DOM 行图", targetSkus[0].image === "https://c.1688.com/khaki.jpg", targetSkus[0].image);
  check("变体补图：半角/全角括号差异也能匹配上", targetSkus[1].image === "https://c.1688.com/gray.jpg", targetSkus[1].image);
  check("变体补图：退回规格色卡图", targetSkus[2].image === "https://c.1688.com/swatch-blue.jpg", targetSkus[2].image);
  check("变体补图：已有图不被覆盖", targetSkus[3].image === "https://c.1688.com/keep.jpg", targetSkus[3].image);
  check("变体补图：返回补图条数", filledCount === 3, String(filledCount));

  // 采集流程要真的用上这两个函数，否则抓了也不挂
  check("采集流程会抓 DOM 行变体图并补到 SKU 上",
    /pickSkuRowsFromDom\(\)/.test(code1688) && /attachSkuImages\(skus, domRowSkus, specImages\)/.test(code1688), "");
  check("DOM 行抓不到图时给出中文提示（不再静默无图）",
    /没抓到变体图/.test(code1688) && /已配上变体图/.test(code1688), "");
  // 上传侧：变体的图必须排在自己 images 的最前面，才能成为该变体的主图
  const ozonApiCode = fs.readFileSync(path.join(HERE, "../src/background/ozon-api.js"), "utf8");
  check("上传时变体图排在 images 首位（primary_image 就是它）",
    /const images = \[\.\.\.new Set\(\[\.\.\.skuImages, \.\.\.commonImages\]\)\]/.test(ozonApiCode)
      && /primary_image: cleanText\(limitedImages\[0\]/.test(ozonApiCode), "");
  check("面板 SKU 确认弹窗会渲染 sku.image", /sku-confirm-thumb/.test(fs.readFileSync(path.join(HERE, "../src/ui/panel.js"), "utf8")), "");
}

console.log("=== AI 自动填写类目属性 / 中文类目 ===");
{
  const attributes = [
    { id: 8229, name: "Тип товара", is_required: true, dictionary: [{ value: "Платье" }, { value: "Брюки" }] },
    { id: 9048, name: "Бренд", is_required: true },
  ];
  const messages = buildAttributeMessages({ title: "碎花连衣裙 夏季", platform: "1688", attributes: [{ name: "材质", value: "棉" }] }, attributes);
  const user = messages[messages.length - 1].content;
  check("属性填写提示词带上属性 ID 与必填标记", /8229 \| Тип товара \[必填\]/.test(user), user.slice(-200));
  check("属性填写提示词带上可选值字典", /候选值，必须原样选用: Платье \| Брюки/.test(user), user.slice(-200));
  check("属性填写提示词带上商品标题", /碎花连衣裙/.test(user));
  // v1.9.58：有中文显示名的属性，提示词给「中文 (俄文原名)」——采集源是中文，模型看中文名匹配更准
  const zhMessages = buildAttributeMessages({ title: "碎花连衣裙 夏季", platform: "1688", attributes: [] },
    [{ id: 8229, name: "Тип товара", displayName: "商品类型", is_required: true }]);
  const zhUser = zhMessages[zhMessages.length - 1].content;
  check("属性清单优先给中文名并保留俄文原名", /8229 \| 商品类型 \(Тип товара\) \[必填\]/.test(zhUser), zhUser.slice(-200));
  const sysPrompt = zhMessages[0].content;
  check("系统提示说明中文名只是辅助、值必须回俄文", /китайским переводом/.test(sysPrompt) && /по-русски/.test(sysPrompt));

  const parsed = parseAttributeResult('```json\n{"values": {"8229": "Платье", "9048": "", "abc": "x"}}\n```');
  check("属性结果解析出 id→值", parsed?.values?.["8229"] === "Платье", JSON.stringify(parsed));
  check("属性结果丢掉非数字 id 与空值", parsed?.values?.["abc"] === undefined && !("9048" in (parsed?.values || {})), JSON.stringify(parsed));
  check("属性结果解析不出来时返回 null", parseAttributeResult("不是 JSON") === null);

  const trMsgs = buildTranslateMessages(["Платья", "Женская одежда"], { to: "zh" });
  check("批量翻译提示词逐条编号", /1\. Платья\n2\. Женская одежда/.test(trMsgs[1].content), trMsgs[1].content.slice(-120));
  check("批量翻译要求等长 JSON 数组", /JSON-массивом строк/.test(trMsgs[1].content));
  check("批量翻译解析等长结果", JSON.stringify(parseTranslateResult('["连衣裙","女装"]', 2)) === '["连衣裙","女装"]');
  check("批量翻译条数不一致时判失败", parseTranslateResult('["连衣裙"]', 2) === null);
  check("批量翻译解析不出数组时判失败", parseTranslateResult('{"a":1}', 1) === null);

  // 上传时 AI 填好的属性要能带出去，且不与手工映射的属性重复
  const draft = {
    id: "d1",
    title: "连衣裙",
    ru: { title: "Платье", description: "Описание" },
    attributes: [{ name: "材质", value: "棉" }],
    attributeValues: { 9048: "NoName", 8229: "Платье" },
  };
  const item = buildImportItem(draft, { attributeMap: { 材质: 12345 }, descriptionAttributeId: 4191, category: { descriptionCategoryId: 1, typeId: 2 } });
  const ids = item.attributes.map((a) => a.id);
  check("AI 填写的类目属性会随商品一起上传", ids.includes(9048) && ids.includes(8229), JSON.stringify(ids));
  check("手工映射的属性仍然保留", ids.includes(12345), JSON.stringify(ids));
  check("同一属性 ID 不会重复写两次", ids.filter((id) => id === 8229).length === 1, JSON.stringify(ids));
  check("描述属性仍然写入", ids.includes(4191), JSON.stringify(ids));
  const strictDefs = [
    { id: 1, name: "材质", is_required: true, dictionary: [{ value: "棉" }, { value: "涤纶" }] },
    { id: 2, name: "重量", type: "number", unit: "г", min: 1 },
  ];
  check("属性校验阻止缺失必填和非法枚举",
    !validateAttributeValues(strictDefs, { 1: "未知" }).ok
      && validateAttributeValues(strictDefs, { 1: "棉", 2: "10 г" }).ok);
  check("属性校验阻止无效数值", !validateAttributeValues(strictDefs, { 1: "棉", 2: "abc" }).ok);
  const normalized = normalizeProduct({
    platform: "1688", sourceUrl: "https://example.test/item?id=1", title: "测试商品",
    skus: [{ label: "红色 / M" }, { label: "蓝色 / L" }, { id: "bad", label: "" }],
  });
  check("SKU 归类保留同商品组和无法识别项",
    normalized.skus[0].skuGroup === normalized.skus[1].skuGroup
      && normalized.skus[2].skuClassification.status === "unclassified");
}

console.log("=== SKU 图片分类与规格图 ===");
{
  const codePanel = fs.readFileSync(path.join(HERE, "../src/ui/panel.js"), "utf8");
  const codeDrafts = fs.readFileSync(path.join(HERE, "../src/ui/drafts.js"), "utf8");
  check("草稿保存 specImages（规格值→图片）", /specImages:\s*product\.specImages/.test(codeDrafts));
  check("面板生成 SKU 组合时会用归一化匹配规格图", /matchSpecImage\(specImages, item\.name, item\.value\)/.test(codePanel));
  check("SKU 表格渲染图片缩略图", /sku-thumb/.test(codePanel));
  check("SKU 图片点击可调选择器", /openSkuImagePicker/.test(codePanel));
}

console.log("=== 规格值→图片 归一化匹配（红 vs 红色）===");
{
  const specImages = { "颜色:红": "https://x.com/red.jpg", "尺码:M": "https://x.com/m.jpg" };
  check("严格匹配命中", matchSpecImage(specImages, "颜色", "红") === "https://x.com/red.jpg");
  check("归一化匹配：红色→红", matchSpecImage(specImages, "颜色", "红色") === "https://x.com/red.jpg", matchSpecImage(specImages, "颜色", "红色"));
  check("归一化匹配：大小写/空格", matchSpecImage(specImages, "尺码", " m ") === "https://x.com/m.jpg");
  check("无匹配返回空串", matchSpecImage(specImages, "颜色", "蓝") === "");
  check("空规格图返回空串", matchSpecImage({}, "颜色", "红") === "");
}

console.log("=== AI 自动化流水线（融合，而非独立配置页）===");
{
  const html = fs.readFileSync(path.join(HERE, "../src/ui/panel.html"), "utf8");
  const js = fs.readFileSync(path.join(HERE, "../src/ui/panel.js"), "utf8");
  check("已移除独立的「自动化流水线」配置卡片",
    !/id="stages"/.test(html) && !/id="btn-auto-start"/.test(html) && !/id="auto-min-price"/.test(html));
  check("AI 流水条长在工作台里",
    /id="ai-pipe"/.test(html) && /id="btn-ai-run"/.test(html) && /id="ai-pipe-steps"/.test(html));
  check("AI 流水条紧贴工作台上沿（不是页面底部的独立卡片）",
    html.indexOf('id="ai-pipe"') > 0
    && html.indexOf('id="ai-pipe"') < html.indexOf('id="workspace"')
    && html.indexOf('id="ai-pipe"') < html.indexOf('id="bulk-table"'),
    "");
  check("一键跑完串联 采集→类目→文案→定价→图片→上传",
    /async function runAiPipeline/.test(js)
    && /aiAutoFillDraft\(\)/.test(js)
    && /prepareDraftImages\(/.test(js)
    && /uploadDraftNow\(\)/.test(js));
  check("保存草稿后 AI 自动填写类目/文案/价格", /await aiAutoFillDraft\(\);/.test(js));
  check("上传人工审核改为就地确认，不再要求去别的页面",
    !/请改用「自动化」页/.test(js) && /confirmDialog\("已开启人工审核/.test(js));
  check("旧的 automation.js 已删除", !fs.existsSync(path.join(HERE, "../src/ui/automation.js")));
  check("panel.js 不再 import 旧自动化模块", !/from "\.\/automation\.js"/.test(js));
}

console.log("=== 采集后的达瓦式顺序（先确认 SKU → 再选类目 → 才拉属性）===");
{
  const html = fs.readFileSync(path.join(HERE, "../src/ui/panel.html"), "utf8");
  const js = fs.readFileSync(path.join(HERE, "../src/ui/panel.js"), "utf8");
  check("流水线头部提供「采集后先确认 SKU」「类目需人工确认」开关",
    /id="ai-pipe-sku-confirm"/.test(html) && /id="ai-pipe-cat-confirm"/.test(html));
  check("SKU 区与属性区提供手动入口",
    /id="btn-sku-confirm"/.test(html) && /id="btn-attr-reload"/.test(html));
  check("采集后先弹 SKU 确认框",
    /async function maybeConfirmSkus/.test(js) && /function openSkuConfirmModal/.test(js));

  const capture = js.slice(js.indexOf("async function doCapture"), js.indexOf("function formatCaptureTiming"));
  check("doCapture 采集完就先确认 SKU（在提示采集成功之前）",
    capture.includes("maybeConfirmSkus")
    && capture.indexOf("maybeConfirmSkus") < capture.indexOf('setBadge("#capture-platform", data.platform, "ok")'));

  const run = js.slice(js.indexOf("async function runAiPipeline"), js.indexOf("function bindAiPipeline"));
  check("一键流程：先确认 SKU，再跑 AI 填充",
    run.includes("maybeConfirmSkus") && run.indexOf("maybeConfirmSkus") < run.indexOf("aiAutoFillDraft"));
  check("一键流程：类目没确认时停在「待确认类目」",
    run.includes("categoryPending") && /setPipeStep\("category", "paused"/.test(run));

  const fill = js.slice(js.indexOf("async function aiAutoFillDraft"), js.indexOf("async function uploadDraftNow"));
  check("类目没确认就不往下填属性", /categoryPending[\s\S]{0,240}return \{ categoryPending: true \}/.test(fill));

  const match = js.slice(js.indexOf("async function autoMatchCategory"), js.indexOf("let renderedCategoryTitles"));
  // v1.9.66 行为不变：仍然只在「关掉人工确认开关 + 置信度达标」时才自动落选，
  // 只是自动落选的对象从 candidates[0] 变成了 AI 在树内选出的 best（候选第一位）
  check("AI 高置信度也不再自动落选，除非关掉「类目需人工确认」",
    /if \(!\$\("#ai-pipe-cat-confirm"\)\?\.checked && best\.confidence >= 70\) \{[\s\S]{0,260}pickCategoryCandidate\(best\)/.test(match));

  check("点候选卡片确认后加载类目属性并续跑流水线",
    /loadCategoryAttributes\(state\.categoryNode\)\.then\(\(\) => afterCategoryConfirmed\(\)\)/.test(js));
  check("类目树点「确认选择这个类目」后同样加载属性",
    /loadCategoryAttributes\(\{ category_id, type_id \}\)\.then\(\(\) => afterCategoryConfirmed\(\)\)/.test(js));
  check("类目确认后自动接上 填属性 → 图片 → 上传",
    /async function resumePipelineAfterCategory/.test(js)
    && /async function afterCategoryConfirmed/.test(js));
}

console.log("=== 类目属性自动补拉与 zh→ru 回落 ===");
{
  const js = fs.readFileSync(path.join(HERE, "../src/ui/panel.js"), "utf8");
  const api = fs.readFileSync(path.join(HERE, "../src/background/ozon-api.js"), "utf8");
  check("载入草稿/确认类目后自动补拉属性定义",
    /async function autoLoadCategoryAttributes/.test(js)
    && /ensureAttributesChinese\(\);[\s\S]{0,140}autoLoadCategoryAttributes\(\);/.test(js));
  check("同一草稿+类目只自动拉一次（防渲染循环）", /attrAutoLoadKey === key/.test(js));
  check("加载失败原因留在状态徽标上", /加载失败：\$\{error\.message\}/.test(js));
  const load = js.slice(js.indexOf("async function loadCategoryAttributes"), js.indexOf("function renderAttributeDefs"));
  check("loadCategoryAttributes 返回成功与否（供补拉判断重试）",
    /return true;/.test(load) && /return false;/.test(load));
  check("属性接口 zh 请求失败不再阻断 ru 回落", /catch \(zhError\)/.test(api));
}

console.log("=== 图片函数模块级与流水线备注（imageThumb is not defined 回归）===");
{
  const js = fs.readFileSync(path.join(HERE, "../src/ui/panel.js"), "utf8").replace(/\r\n/g, "\n");
  const start = js.indexOf("function bindImageTranslate");
  const end = js.indexOf("\nfunction ", start + 10);
  check("imageThumb / openImagePreview 不再嵌在翻译按钮处理器里（模块级可见）",
    start > 0 && !/function imageThumb/.test(js.slice(start, end)) && !/function openImagePreview/.test(js.slice(start, end)));
  check("模块级存在 imageThumb 与 openImagePreview 定义",
    /(?:^|\n)function imageThumb\(/.test(js) && /(?:^|\n)function openImagePreview\(/.test(js));
  check("自动定价返回文字而非对象数组（不再显示 [object Object]）",
    /return rows\.length \? `已定价 \$\{rows\.length\} 个 SKU`/.test(js));
}

console.log("=== 图生图请求体（基于本产品图出图，不再自由发挥）===");
{
  const realFetch = globalThis.fetch;
  const okJson = (payload) => ({ ok: true, status: 200, json: async () => payload });
  const REF = "data:image/png;base64,UFJPRFVDVA==";
  let sentBody = null;

  // 1) DashScope 原生：参考图必须排在文字前面，否则不会按「编辑这张图」处理
  globalThis.fetch = async (url, init) => {
    sentBody = JSON.parse(init.body);
    return okJson({ output: { choices: [{ message: { content: [{ image: "https://dashscope-result/set.png" }] } }] } });
  };
  const refOut = await redrawImage({
    baseUrl: "https://dashscope.aliyuncs.com/api/v1", apiKey: "SK", model: "qwen-image-edit",
    context: "детская коляска", shot: "main", referenceImage: REF, size: "1008x1344",
  });
  const content = sentBody?.input?.messages?.[0]?.content || [];
  check("DashScope 参考图排在文字之前（图生图的硬要求）",
    content[0]?.image === REF && typeof content[1]?.text === "string", JSON.stringify(content).slice(0, 120));
  check("DashScope 图生图只带一个参考图（只传了一张）", content.filter((item) => item?.image).length === 1, String(content.length));
  check("DashScope 图生图能取回图片", refOut.url === "https://dashscope-result/set.png", JSON.stringify(refOut));

  // 1b) 多张参考图（v1.9.38：参考全部产品图）——全部排在文字前，去重且限量
  const REF2 = "data:image/png;base64,U0tVMQ==";
  const REF3 = "data:image/png;base64,U0tVMg==";
  await redrawImage({
    baseUrl: "https://dashscope.aliyuncs.com/api/v1", apiKey: "SK", model: "qwen-image-edit",
    context: "детская коляска", shot: "main", referenceImage: REF,
    referenceImages: [REF, REF2, "", REF3], size: "1008x1344",
  });
  const multiContent = sentBody?.input?.messages?.[0]?.content || [];
  const multiImages = multiContent.filter((item) => item?.image).map((item) => item.image);
  check("多张参考图全部排在文字之前", multiImages.join(",") === [REF, REF2, REF3].join(","), JSON.stringify(multiImages.slice(0, 2)).slice(0, 80));
  check("多张参考图去重且跳过空值", new Set(multiImages).size === multiImages.length && multiImages.length === 3, String(multiImages.length));

  // 1c) 参考图张数超限要截到 MAX_REFERENCE_IMAGES（qwen-image-edit 只接受 0-3 张，v1.9.38 传 4 张曾整单报错）
  await redrawImage({
    baseUrl: "https://dashscope.aliyuncs.com/api/v1", apiKey: "SK", model: "qwen-image-edit",
    context: "детская коляска", shot: "main", referenceImage: REF,
    referenceImages: [REF2, REF3, "data:image/png;base64,U0tVMw==", "data:image/png;base64,U0tVNA=="],
  });
  const cappedImages = (sentBody?.input?.messages?.[0]?.content || []).filter((item) => item?.image).map((item) => item.image);
  check("参考图超过上限时截断（4 张 → 3 张，不再触发 0-3 限制报错）",
    cappedImages.length === 3 && cappedImages.join(",").startsWith([REF, REF2, REF3].join(",")), String(cappedImages.length));

  // 2) DashScope 不传参考图 → 纯文生图（content 只有 text）
  globalThis.fetch = async (url, init) => {
    sentBody = JSON.parse(init.body);
    return okJson({ output: { choices: [{ message: { content: [{ image: "https://dashscope-result/t2i.png" }] } }] } });
  };
  await redrawImage({ baseUrl: "https://dashscope.aliyuncs.com/api/v1", apiKey: "SK", model: "qwen-image-3.0", context: "кровать" });
  check("不传参考图时不塞 image 项（退回纯文生图）",
    !(sentBody?.input?.messages?.[0]?.content || []).some((item) => item?.image), JSON.stringify(sentBody?.input).slice(0, 120));

  // 3) shot 会被拼进提示词（DashScope 侧看 text）
  globalThis.fetch = async (url, init) => {
    sentBody = JSON.parse(init.body);
    return okJson({ output: { choices: [{ message: { content: [{ image: "https://x/s.png" }] } }] } });
  };
  await redrawImage({
    baseUrl: "https://dashscope.aliyuncs.com/api/v1", apiKey: "SK", model: "qwen-image-edit",
    context: "коляска", shot: "scene-life", referenceImage: REF,
  });
  const shotText = sentBody?.input?.messages?.[0]?.content?.find((item) => item?.text)?.text || "";
  check("shot=scene-life 把「实景使用」方案拼进提示词", /интерьере/.test(shotText), shotText.slice(0, 80));
  check("shot 提示词里带「保持商品本体不变」", /сохрани сам товар без изменений/i.test(shotText), "");

  // 3b) 整张方案对象直传（自定义图片类型走这条）
  globalThis.fetch = async (url, init) => {
    sentBody = JSON.parse(init.body);
    return okJson({ output: { choices: [{ message: { content: [{ image: "https://x/c.png" }] } }] } });
  };
  await redrawImage({
    baseUrl: "https://dashscope.aliyuncs.com/api/v1", apiKey: "SK", model: "qwen-image-edit",
    context: "коляска", shot: { id: "custom", scene: "товар в подарочной упаковке", text: "none" }, referenceImage: REF,
  });
  const customText = sentBody?.input?.messages?.[0]?.content?.find((item) => item?.text)?.text || "";
  check("方案对象直传也能拼出拍法", /подарочной упаковке/.test(customText), customText.slice(0, 80));
  check("方案对象直传仍带「保持商品本体不变」", /сохрани сам товар без изменений/i.test(customText), "");

  // 4) OpenAI 兼容（硅基流动 Kolors）：图生图靠 body.image 字段
  globalThis.fetch = async (url, init) => {
    sentBody = JSON.parse(init.body);
    return okJson({ data: [{ url: "https://i.tosoiot.com/i2i.png" }] });
  };
  const compatOut = await redrawImage({
    baseUrl: "https://api.siliconflow.cn/v1", apiKey: "SK", model: "Kwai-Kolors/Kolors",
    context: "коляска", shot: "detail-spec", referenceImage: REF, size: "960x1280",
    title: "ТЕХНИЧЕСКИЕ ХАРАКТЕРИСТИКИ", labels: ["Объём 2,5 л"],
  });
  check("OpenAI 兼容接口用 image 字段传参考图", sentBody?.image === REF, JSON.stringify(sentBody).slice(0, 120));
  check("OpenAI 兼容接口仍带 prompt 与尺寸", typeof sentBody?.prompt === "string" && sentBody?.size === "960x1280", "");
  check("标题与规格标签一路拼进兼容接口的 prompt",
    sentBody?.prompt.includes("ТЕХНИЧЕСКИЕ ХАРАКТЕРИСТИКИ") && sentBody?.prompt.includes("Объём 2,5 л"), "");
  check("OpenAI 兼容图生图能取回图片", compatOut.url === "https://i.tosoiot.com/i2i.png", JSON.stringify(compatOut));

  // 5) 不传参考图 → 不出现 image 字段（纯文生图，兼容接口不会 400）
  globalThis.fetch = async (url, init) => {
    sentBody = JSON.parse(init.body);
    return okJson({ data: [{ url: "https://i.tosoiot.com/t2i.png" }] });
  };
  await redrawImage({ baseUrl: "https://api.siliconflow.cn/v1", apiKey: "SK", model: "Kwai-Kolors/Kolors", context: "床" });
  check("不传参考图时请求体没有 image 字段", !("image" in sentBody), JSON.stringify(Object.keys(sentBody)));

  globalThis.fetch = realFetch;
}

console.log("=== 套图面板接线（面板 → 后台 → 生图）===");
{
  const raw = fs.readFileSync(path.join(HERE, "../src/ui/panel.js"), "utf8");
  const js = raw.replace(/\r\n/g, "\n");
  const htmlRaw = fs.readFileSync(path.join(HERE, "../src/ui/panel.html"), "utf8");
  const html = htmlRaw.replace(/\r\n/g, "\n");
  const worker = fs.readFileSync(path.join(HERE, "../src/background/service-worker.js"), "utf8").replace(/\r\n/g, "\n");
  const promptsSrc = fs.readFileSync(path.join(HERE, "../src/shared/image-prompts.js"), "utf8");
  const cssSrc = fs.readFileSync(path.join(HERE, "../src/ui/panel.css"), "utf8").replace(/\r\n/g, "\n");

  check("面板有套图区块（set-gen-block）", /id="set-gen-block"/.test(html), "");
  check("六步齐全：图片类型/尺寸比例/张数/商品信息/卖点/风格",
    ["set-gen-kinds", "set-gen-ratios", "set-gen-count", "set-gen-extra", "set-gen-points-list", "set-gen-style"]
      .every((id) => html.includes(`id="${id}"`)), "");
  check("面板有参考图选择器 #set-gen-source", /id="set-gen-source"/.test(html), "");
  check("面板有 1K/2K/4K 档位选择", /id="set-gen-tier"/.test(html), "");
  check("面板有 AI 生成卖点 / 清空 按钮", /id="btn-set-gen-points"/.test(html) && /id="btn-set-gen-points-clear"/.test(html), "");
  check("面板有「生成前用 AI 拟俄文标题」开关", /id="set-gen-points-ai"/.test(html), "");
  check("面板有自定义图片类型输入框", /id="set-gen-kind-custom"/.test(html), "");
  check("旧的图位勾选区已移除（改为按图片类型展开）", !html.includes('id="set-gen-shots"'), "");
  check("面板有生成/下载/并入草稿三个按钮",
    ["btn-set-gen", "btn-set-gen-download", "btn-set-gen-apply"].every((id) => html.includes(`id="${id}"`)), "");

  check("图片类型渲染成可勾选卡片并按勾选回写 state", /input\.setgen-kind:checked/.test(js), "");
  check("比例卡片按当前档位显示尺寸", /sizeForRatio\(ratio\.id, state\.setGenTier\)/.test(js), "");
  check("v1.9.51 张数是手填数字输入框（1~15，非法值自动纠正）",
    /id="set-gen-count" type="number" min="1" max="15"/.test(html)
      && /state\.setGenCount = value;/.test(js)
      && /张数没填或不是数字/.test(js)
      && /一次最多生成 \$\{MAX_SET_SHOTS\} 张/.test(js), "");
  check("尺寸会按服务支持范围适配（不支持时自动换最接近的）",
    /resolveProviderSize\(preset, model, wanted, state\.setGenRatio\)/.test(js), "");
  check("卖点勾选后才写进提示词", /state\.setGenPoints\.filter\(\(item\) => item\.on\)/.test(js), "");
  check("生成前先让 AI 拟俄文标题（失败回退兜底标题）",
    /async function fetchSetGenPlan\(/.test(js) && /FALLBACK_TITLES/.test(promptsSrc), "");
  check("AI 拟标题失败只提示、不阻断出图", /AI 拟标题失败/.test(js) && !/return toast\("AI 拟标题失败/.test(js), "");
  check("v1.9.50 并发出图（并发池，硬上限 3 防限流）",
    /const concurrency = Math\.min\(3, Math\.max\(1, Number\(\$\("#set-gen-concurrency"\)/.test(js)
      && /Array\.from\(\{ length: Math\.min\(concurrency, shots\.length\) \}, generateOne\)/.test(js), "");
  check("每张都带本产品参考图", /referenceImage: refs\.referenceImage,\n\s*\}\);/.test(js), "");
  check("参考图先转 data URL（1688 有防盗链）", /referenceImage = await fetchDataUrl\(sourceUrl\)/.test(js), "");
  check("v1.9.38/50 参考全部产品图：并行取 + 命中缓存（上限 MAX_REFERENCE_IMAGES=3）",
    /cachedRefDataUrl\(sourceUrl\)/.test(js)
      && /1 \+ extraUrls\.length >= MAX_REFERENCE_IMAGES/.test(js)
      && /usedRefUrls/.test(js)
      && /Promise\.all\(extraUrls\.map/.test(js), "");
  check("把整个拍摄方案对象发给后台（卖点每张都传：无字图也按卖点取景）", /shot,\n\s*(?:\/\/[^\n]*\n\s*)?points,/.test(js), "");
  check("标题 / 副标题 / 规格标签 / 补充信息一起发出去",
    /title: shot\.title \|\| ""/.test(js) && /labels: shot\.labels \|\| \[\]/.test(js) && /extraInfo,/.test(js), "");
  check("生成后逐张 renderSetGenGrid（边出边看）",
    /state\.setGen\.push\(\{ shot: shot\.id, label: shot\.label, title: shot\.title \|\| "", dataUrl: src/.test(js), "");
  check("失败的那张单独记错误、不中断其余图",
    /state\.setGen\.push\(\{ shot: shot\.id, label: shot\.label, title: shot\.title \|\| "", dataUrl: "", url: "", error:/.test(js), "");
  check("结果卡片显示俄文标题（便于核对图上文字）", /item\?\.title \? `\$\{shot\.label\}｜\$\{item\.title\}` : shot\.label/.test(js), "");
  check("图位板按双列排（.setgen-board 两列网格）", /\.setgen-board \{[\s\S]{0,120}repeat\(2, minmax\(0, 1fr\)\)/.test(cssSrc), "");
  check("数字在图片底下：每个格子带编号徽标 + 底部说明", /slot-cap/.test(js) && /slot-no/.test(js) && /\.setgen-slot \.slot-no/.test(cssSrc), "");
  check("图位板放在图片类型区下方（生成的图片就显示在这里）",
    html.indexOf('id="set-gen-grid"') > -1
      && html.indexOf('id="set-gen-grid"') < html.indexOf('id="set-gen-tier"')
      && html.indexOf('id="set-gen-grid"') > html.indexOf('id="set-gen-kinds"'), "");
  check("未生成的图位显示占位（待生成），图片生成后填进对应格子",
    /setgen-slot-empty/.test(js) && /results\.get\(shot\.id\)/.test(js), "");
  check("卡片文字不再被复选框挤成竖排（全局 input width:100% 已收回）",
    /\.setgen-card input \{ width: auto;/.test(cssSrc) && /\.setgen-card \.txt \{ flex: 1; min-width: 0; \}/.test(cssSrc), "");
  check("汇总提示会说清实际出几张 / 尺寸怎么适配",
    /实际生成 \$\{shots\.length\} 张/.test(js) && /会自动改用最接近的/.test(js), "");

  // v1.9.41 属性表全部中文：名称漏翻要重试、取值列带中文提示
  check("属性名翻译失败（displayName 是俄文残留）时 ensureAttributesChinese 会重试",
    /!isZh\(a\.displayName\)/.test(js) && /!isZh\(d\.displayValue\)/.test(js), "");
  check("本地字典覆盖滑雪/滑板等截图漏翻项",
    /"уровень подготовки": "技术水平"/.test(js) && /"радиус поворота": "转弯半径"/.test(js)
      && /"универсал": "通用级"/.test(js), "");
  check("取值单元格带中文提示行（俄文值要上传，界面给中文小字）",
    /attr-value-zh/.test(js) && /data-zh-for="\$\{row\.id\}"/.test(js), "");
  check("中文提示批量翻译且不整体重绘（不打断正在编辑的输入框）",
    /async function ensureAttributeValueHints/.test(js) && /translateCategoryTexts\(missing, "zh"\)/.test(js)
      && /node\.textContent = zh \? `中文：\$\{zh\}` : ""/.test(js), "");
  check("中文提示行有样式（小字、灰色、可换行）",
    /\.attr-value-zh \{ color: var\(--muted\); font-size: 11px/.test(cssSrc), "");
  // v1.9.42 单张重出 + 白底开关 + 风格方向接线
  check("图位板每张都有「重出此图」按钮（违规图单独重做）",
    /slot-redo/.test(js) && /text: "重出此图"/.test(js) && /async function regenerateSetShot/.test(js), "");
  check("重出会沿用该图原来的风格方向与已拟标题",
    /prev\?\.direction \|\| assignSetDirections\(\[shot\]\)\[0\]/.test(js) && /state\.setGenTitles\?\.\[shot\.id\]/.test(js), "");
  check("面板有「允许纯白底」开关", html.includes('id="set-gen-bg-white"') && /#set-gen-bg-white"\)\?\.checked/.test(js), "");
  check("风格方向传给后台（direction / allowWhiteBg）",
    /direction,\n\s*allowWhiteBg,/.test(js) && /const directions = assignSetDirections\(shots\)/.test(js), "");
  check("后台透传风格方向与白底开关",
    /direction: message\.direction \|\| null/.test(worker) && /allowWhiteBg: Boolean\(message\.allowWhiteBg\)/.test(worker), "");
  check("图位标注显示风格方向（第几张是什么风格一目了然）",
    /item\?\.direction\?\.label/.test(js) && /\.setgen-slot \.slot-redo/.test(cssSrc), "");

  // v1.9.43 每个 SKU 基于自己的原图出 AI 主图
  check("SKU 表格每行有「AI 主图」按钮", /button\.sku-ai/.test(js) && /data-id="\$\{escapeHtml\(row\.id\)\}" type="button" title="用该变体自己的原图生成信息图主图"/.test(js), "");
  check("面板有「为全部 SKU 生成 AI 主图」批量按钮",
    html.includes('id="btn-sku-ai-main"') && /为全部 SKU 生成 AI 主图/.test(html)
      && /generateSkuMainImages\(\{ onlySelected: false \}\)/.test(js), "");
  check("SKU 主图的参考图 = 该变体自己的原图（v1.9.81 优先 originalImage，防 AI 生 AI）",
    /async function fetchSkuReference\(sku\)/.test(js) && /const sourceUrl = sku\.originalImage \|\| sku\.image \|\| \(sku\.images \|\| \[\]\)\[0\] \|\| ""/.test(js), "");
  check("SKU 主图调用 shot=SKU_MAIN_SHOT（信息图排版）且只带该变体一张参考图",
    /shot: SKU_MAIN_SHOT/.test(js) && /referenceImages: \[referenceImage\],/.test(js), "");
  check("v1.9.81 AI 主图自动替换该变体主图（sku.image 指向 AI 图，原图存 originalImage）",
    /sku\.image = uploadable;/.test(js) && /sku\.originalImage = original/.test(js)
    && /sku\.images = \[uploadable, \.\.\.keep\]/.test(js) && /slice\(0, 9\)/.test(js), "");
  check("只有可上传的 http(s) 地址才进图集（纯 base64 预览不当上传图）",
    /const uploadable = \/\^https\?:\\\/\\\/\/i\.test\(remoteUrl\)/.test(js), "");
  check("批量生成串行执行并回写界面与状态",
    /async function generateSkuMainImages/.test(js) && /renderListingResult\(\);\n  \}/.test(js), "");
  check("SKU 行同时显示原图与 AI 主图缩略图",
    /sku-ai-thumb/.test(js) && /title="AI 主图（点击查看大图）"/.test(js), "");

  // ==================== v1.9.44：放大清晰度 / 翻译范围 / 图片区收敛 / AI 主图列 ====================
  console.log("=== v1.9.44：看图清晰度 + 翻译范围 + 图片区收敛 + AI 主图列 ===");

  // 1) 放大图片不发虚
  check("新增 highResImageUrl（点开放大前先把地址升到高清）",
    typeof highResImageUrl === "function", String(typeof highResImageUrl));
  check("去掉 alicdn 的双扩展名尺寸后缀（_400x400 / _400x400q90 / _50x50c）",
    highResImageUrl("https://cbu01.alicdn.com/img/ibank/abc.jpg_400x400.jpg") === "https://cbu01.alicdn.com/img/ibank/abc.jpg"
      && highResImageUrl("https://cbu01.alicdn.com/img/ibank/abc.jpg_400x400q90.jpg") === "https://cbu01.alicdn.com/img/ibank/abc.jpg"
      && highResImageUrl("https://cbu01.alicdn.com/img/ibank/abc.jpg_50x50c.jpg") === "https://cbu01.alicdn.com/img/ibank/abc.jpg",
    highResImageUrl("https://cbu01.alicdn.com/img/ibank/abc.jpg_400x400q90.jpg"));
  check("去掉 _Q75 质量后缀 / _.webp 转码后缀 / .sum.jpg 汇总后缀",
    highResImageUrl("https://cbu01.alicdn.com/img/ibank/abc.jpg_Q75.jpg") === "https://cbu01.alicdn.com/img/ibank/abc.jpg"
      && highResImageUrl("https://cbu01.alicdn.com/img/ibank/abc.jpg_.webp") === "https://cbu01.alicdn.com/img/ibank/abc.jpg"
      && highResImageUrl("https://cbu01.alicdn.com/img/ibank/abc.jpg.sum.jpg") === "https://cbu01.alicdn.com/img/ibank/abc.jpg",
    highResImageUrl("https://cbu01.alicdn.com/img/ibank/abc.jpg_.webp"));
  check("只有后缀没有双扩展名的写法（_60x60.jpg / .400x400.jpg）也裁掉",
    highResImageUrl("https://cbu01.alicdn.com/img/ibank/abc_60x60.jpg") === "https://cbu01.alicdn.com/img/ibank/abc.jpg"
      && highResImageUrl("https://cbu01.alicdn.com/img/ibank/abc.400x400.jpg") === "https://cbu01.alicdn.com/img/ibank/abc.jpg",
    highResImageUrl("https://cbu01.alicdn.com/img/ibank/abc_60x60.jpg"));
  check("去掉 OSS 的 x-oss-process 缩放参数，其它 query 参数保留",
    highResImageUrl("https://x.aliyuncs.com/a.jpg?x-oss-process=image/resize,w_400") === "https://x.aliyuncs.com/a.jpg"
      && highResImageUrl("https://x.aliyuncs.com/a.jpg?v=2&x-oss-process=image/resize,w_400") === "https://x.aliyuncs.com/a.jpg?v=2",
    highResImageUrl("https://x.aliyuncs.com/a.jpg?v=2&x-oss-process=image/resize,w_400"));
  check("非图床主机不动刀（自己的 photo_1920x1080.jpg 不能被改坏，否则打开就是 404）",
    highResImageUrl("https://my-own-cdn.com/photo_1920x1080.jpg") === "https://my-own-cdn.com/photo_1920x1080.jpg",
    highResImageUrl("https://my-own-cdn.com/photo_1920x1080.jpg"));
  check("dataUrl / blob 原样返回（AI 出图预览不参与改写）",
    highResImageUrl("data:image/png;base64,AAA") === "data:image/png;base64,AAA"
      && highResImageUrl("blob:https://x/1") === "blob:https://x/1", "");
  check("看图器改成「只缩不放」——不再用 width:100% 把小图硬拉到面板宽度",
    /\.image-preview-img \{ display: block; max-width: 100%; max-height: 100%; width: auto; height: auto;/.test(cssSrc)
      && !/\.image-preview-modal > img \{[^}]*width: 100%/.test(cssSrc), "");
  check("看图器带 适应窗口 / 原始尺寸 / ± 缩放 / 滚轮缩放 / 新窗口",
    /text: "适应窗口"/.test(js) && /text: "原始尺寸"/.test(js)
      && /addEventListener\("wheel"/.test(js) && /text: "新窗口"/.test(js), "");
  check("预览前自动取高清原图（highResImageUrl 接进面板）",
    /import \{[^}]*highResImageUrl[^}]*\} from "\.\.\/shared\/utils\.js"/.test(js)
      && /const source = highResImageUrl\(raw\) \|\| raw;/.test(js), "");

  // 2) 象寄翻译不再只翻第一张
  check("「仅第一张」限制已删除（面板里不再有 it-scope 下拉）",
    !/id="it-scope"/.test(html) && !/仅第一张/.test(html) && !/仅第一张/.test(js), "");
  check("翻译一律处理全部已勾选图片（+ 已选用 SKU 专属图）",
    /const plan = buildTranslatePlan\(\);/.test(js), "");

  // 3) 图片区只留「图片翻译」「AI 图片」两项
  check("「OZON 上架套图」已更名为「AI 图片」",
    html.includes("<summary>AI 图片（基于本产品图生成）</summary>")
      && !/OZON 上架套图（基于本产品图生成）/.test(html), "");
  check("AI 单张重绘 / 本地水印 已从图片区移除，绑定改成可选链（脚本不会断在找不到的按钮上）",
    !/<summary>AI 单张重绘/.test(html) && !/本地水印<\/summary>/.test(html)
      && /\$\("#btn-it-redraw"\)\?\.addEventListener/.test(js)
      && /\$\("#btn-it-test-redraw"\)\?\.addEventListener/.test(js)
      && /\$\("#btn-wm-apply"\)\?\.addEventListener/.test(js)
      && /\$\("#btn-wm-download"\)\?\.addEventListener/.test(js), "");
  check("商品详情长图挪到「采集结果」卡（功能保留，只是不占图片处理区）",
    /id="capture-diagnostics"[\s\S]{0,400}<details id="detail-img-block"/.test(html), "");
  {
    const from = html.indexOf('id="image-grid"');
    const mediaCard = html.slice(from, html.indexOf("</section>", from));
    const count = (mediaCard.match(/<details/g) || []).length;
    // v1.9.72 移除 WorkBuddy 生图助手后回到两个折叠项（v1.9.71 曾扩成 3 个并点名 wb-gen-block）。
    check("图片处理区是「图片翻译」「AI 图片」两个折叠项",
      count === 2 && /id="set-gen-block"/.test(mediaCard) && /id="it-vendor"/.test(mediaCard), `实际 ${count} 个`);
  }

  // 4) SKU 表：生成全部 AI 主图 + 新增「AI 主图」列（放大 / 对比）
  check("SKU 表「图片」列后面新增「AI 主图」列",
    /key: "aiMain",\s*\n\s*label: "AI 主图"/.test(js), "");
  check("未生成时该列显示占位而不是空白",
    /<span class="sku-ai-empty">未生成<\/span>/.test(js) && /\.sku-ai-empty \{/.test(cssSrc), "");
  check("每行有「对比」按钮，弹窗支持并排 + 滑块两种模式",
    /button\.sku-ai-compare/.test(js) && /function openImageComparePreview/.test(js)
      && /addMode\("并排对比", "side", renderSide\)/.test(js)
      && /addMode\("滑块对比", "slider", renderSlider\)/.test(js), "");
  check("对比弹窗支持「还没生成」状态（右侧给占位说明，能对比生成前后）",
    /该 SKU 还没生成 AI 主图/.test(js) && /还没生成 AI 主图。\\n点 SKU 表/.test(js), "");
  check("AI 主图缩略图点开是单独放大（高清 + 只缩不放）",
    /\$\$\("#sku-table \.sku-ai-thumb"\)/.test(js)
      && /openImagePreview\(img\.src, .SKU \$\{img\.dataset\.id\} AI 主图/.test(js), "");
  check("对比弹窗样式齐（分割线 / 左右标签 / 滑块 / 占位块）",
    /\.compare-divider \{/.test(cssSrc) && /\.compare-tag\.left/.test(cssSrc)
      && /\.compare-range \{/.test(cssSrc) && /\.compare-placeholder \{/.test(cssSrc), "");

  check("后台把方案对象透传给提示词构造", /shot: message\.shot \|\| ""/.test(worker), "");
  check("后台透传多张参考图", /referenceImages: Array\.isArray\(message\.referenceImages\)/.test(worker), "");
  check("风格留空时按品类自动选（pickStyleFor 接进面板）", /pickStyleFor\(/.test(js), "");
  check("后台新增俄文卖点 / 标题方案两个 action",
    /MESSAGE_ACTIONS\.aiSellingPoints/.test(worker) && /MESSAGE_ACTIONS\.aiImagePlan/.test(worker), "");
  check("文字 / 标签 / 补充信息一路传到提示词",
    /title: message\.title \|\| ""/.test(worker) && /labels: Array\.isArray\(message\.labels\)/.test(worker)
    && /extraInfo: message\.extraInfo \|\| ""/.test(worker), "");
  check("提示词构造支持方案对象直传（自定义图片类型）",
    /typeof shot === "object" \? shot : findShot\(shot\)/.test(promptsSrc), "");

  check("单张重绘也带参考图（不再自由发挥）", /let referenceImage = "";/.test(js), "");
  check("流水线自动生图同样带参考图",
    /const sourceUrl = state\.draft\?\.mainImage \|\| \(state\.draft\?\.images \|\| \[\]\)\[0\] \|\| ""/.test(js), "");
  check("套图只在草稿图片变化时刷新参考图候选", /syncSetGenSources\(\);/.test(js), "");
  check("面板 JS/CSS 里不再残留旧图位命名", !/renderSetGenShots|set-shot/.test(js), "");
}

// ==================== v1.9.45：主界面布局（顶栏收窄 / 铺满宽度 / 核价并进 SKU 表） ====================
{
  console.log("=== v1.9.45：主界面布局优化 ===");
  const html = fs.readFileSync(path.join(HERE, "../src/ui/panel.html"), "utf8").replace(/\r\n/g, "\n");
  const js = fs.readFileSync(path.join(HERE, "../src/ui/panel.js"), "utf8").replace(/\r\n/g, "\n");
  const cssSrc = fs.readFileSync(path.join(HERE, "../src/ui/panel.css"), "utf8").replace(/\r\n/g, "\n");
  const domSrc = fs.readFileSync(path.join(HERE, "../src/ui/dom.js"), "utf8").replace(/\r\n/g, "\n");

  // 1) 顶端那一块压低
  check("顶栏压成一行（标题不再单独占一行，整条 min-height 44px）",
    cssSrc.includes(".topbar {\n  position: sticky;\n  top: 0;\n  z-index: 10;")
      && cssSrc.includes("padding: 4px 14px;\n  min-height: 44px;\n  display: flex;\n  align-items: center;")
      && !cssSrc.includes("padding: 12px 20px 0;"), "");
  check("标题取消 10px 下边距并缩到 14px（原来是两行结构）",
    cssSrc.includes(".topbar h1 {\n  margin: 0;\n  font-size: 14px;")
      && !cssSrc.includes("margin: 0 0 10px;\n  font-size: 16px;"), "");
  check("页签改成胶囊（不再挂 0 0 圆角贴着下边框的两行式标签栏）",
    cssSrc.includes(".tab {\n  border: none;\n  background: transparent;\n  padding: 5px 11px;\n  border-radius: 8px;"), "");
  check("吸顶偏移跟着顶栏一起上移（步骤条 45px / 左列 104px）",
    cssSrc.includes("top: 45px; /* v1.9.45 顶栏变矮了") && cssSrc.includes("top: 104px; /* v1.9.45"), "");

  // 2) 各板块铺满宽度
  check("内容区去掉 1320px 居中上限，改成铺满",
    cssSrc.includes(".content {\n  max-width: none;\n  margin: 0;")
      && !cssSrc.includes("max-width: 1320px;"), "");
  check("工作台左列（图片列）跟着放宽，不再卡在 400px",
    /grid-template-columns: minmax\(320px, clamp\(360px, 28vw, 560px\)\) minmax\(0, 1fr\);/.test(cssSrc)
      && !/grid-template-columns: minmax\(300px, 400px\)/.test(cssSrc), "");
  check("SKU 确认弹窗跟着放宽", /\.sku-confirm-modal \{ width: min\(1120px, 94vw\)/.test(cssSrc), "");

  // 3) 核价区与 SKU 区合并
  check("核价区不再是独立一块：listing-card 变成 sku-card 内部的折叠区",
    /id="sku-card"[\s\S]{0,4000}<details id="listing-card">/.test(html)
      && !/<div id="listing-card">/.test(html), "");
  check("原来的「OZON 核价（上架表口径）」标题已删，只剩一个卡片标题",
    !html.includes("OZON 核价（上架表口径）"), "");
  check("全局参数（含包裹尺寸/汇率/费率/物流系数）收进折叠区，明细表也跟着进去",
    /<summary>全局核价参数与全部 SKU 核价一览<\/summary>[\s\S]{0,2000}<div class="grid" id="listing-form">/.test(html)
      && /<summary>全局核价参数与全部 SKU 核价一览<\/summary>[\s\S]{0,3000}<table id="listing-table">/.test(html), "");
  check("#step-price 里现在只有「SKU 与成本」+「采集到的属性」两个小节",
    (html.slice(html.indexOf('id="step-price"'), html.indexOf('id="attr-card"')).match(/<h3/g) || []).length === 1, "");

  // 4) 售价计算挂到每个 SKU 下面
  check("renderTable 支持「行内详情行」（第 4 个参数 options.detail）",
    /export function renderTable\(selector, columns, rows, options = \{\}\)/.test(domSrc)
      && /class: "row-detail", hidden: true/.test(domSrc)
      && /colspan: String\(columns\.length\)/.test(domSrc), "");
  check("SKU 表每一行都挂一个自己的核价面板容器",
    /detail: \(row\) => `<div class="sku-calc-box" data-id="\$\{escapeHtml\(row\.id\)\}"><\/div>`/.test(js), "");
  check("核价明细由 renderSkuCalcDetails 按 SKU id 填进各自的面板",
    /function renderSkuCalcDetails\(rows\)/.test(js)
      && /\$\$\("#sku-table \.sku-calc-box"\)/.test(js)
      && /renderSkuCalcDetails\(rows\);/.test(js), "");
  check("明细口径齐（渠道/采购成本/国内运费/拿货成本/售价/活动价/国际物流/佣金/广告/利润/三种利润率/体积重）",
    ["渠道", "采购成本", "国内运费", "拿货成本", "售价", "活动价", "国际物流", "佣金", "广告", "店铺利润",
      "采购利润率", "销售利润率", "物流利润率", "体积重"]
      .every((label) => new RegExp(`\\["${label}`).test(js)), "");
  check("每行有「核价 ▴/▾」开关，点开就地把该 SKU 的明细展开",
    /button class="mini sku-calc-toggle"/.test(js)
      && /const tr = button\.closest\("tr"\)\?\.nextElementSibling;/.test(js)
      && /tr\.hidden = !open;/.test(js), "");
  check("展开状态记在 skuCalcToggle 里，重渲染不跳回去（v1.9.46 起默认就展开）",
    /const skuCalcToggle = new Map\(\)/.test(js) && /function isSkuCalcOpen\(id\)/.test(js)
      && /return skuCalcToggle\.has\(id\) \? skuCalcToggle\.get\(id\) : true;/.test(js)
      && !/calcDefaultOpen/.test(js), "");
  check("没采集到 SKU（单规格）时另给一块独立核价面板，核价不会整块消失",
    html.includes('id="sku-single-calc"') && /standalone\.hidden = !singleRow;/.test(js), "");
  check("反推/保存/导出/恢复默认 四个按钮跟在 SKU 表下面（同一个卡片内）",
    /<table id="sku-table"[\s\S]{0,200}<div id="sku-single-calc"[\s\S]{0,400}<button class="primary" id="btn-listing-apply">/.test(html), "");
  check("renderListingResult 不再因找不到 #listing-table 就提前退出（核价明细是主输出）",
    !/const table = \$\("#listing-table"\);\n  if \(!table\) return;/.test(js)
      && /renderSkuCalcDetails\(rows\);\n  renderTable\("#listing-table", \[/.test(js), "");
  check("渠道系数 a/b 提示在没数据时会清空（不留上一次的残留值）",
    /hint\.value = rows\.length\n/.test(js), "");
  check("核价面板样式齐（行内详情行 / 明细网格 / 单规格块 / SKU 表高度放开）",
    /#sku-table tr\.row-detail > td \{/.test(cssSrc)
      && /\.sku-calc-grid \{ display: grid; grid-template-columns: repeat\(auto-fill, minmax\(150px, 1fr\)\);/.test(cssSrc)
      && /\.sku-calc-standalone \{/.test(cssSrc)
      && /#sku-card \.table-wrap \{ max-height: 72vh; \}/.test(cssSrc), "");
}

// ==================== v1.9.46：AI 主图刷新 bug / 每 SKU 核算常显 / 三处独立滚动 ====================
{
  console.log("=== v1.9.46：AI 主图刷新 + 每 SKU 常显核算 + 独立滚动 ===");
  const html = fs.readFileSync(path.join(HERE, "../src/ui/panel.html"), "utf8").replace(/\r\n/g, "\n");
  const js = fs.readFileSync(path.join(HERE, "../src/ui/panel.js"), "utf8").replace(/\r\n/g, "\n");
  const cssSrc = fs.readFileSync(path.join(HERE, "../src/ui/panel.css"), "utf8").replace(/\r\n/g, "\n");

  // 1) 「单个 AI 主图生成完还是显示未生成」的 bug
  check("新增 refreshSkuSection()：SKU 表 + 核价一起刷",
    /function refreshSkuSection\(\) \{/.test(js)
      && /renderSkuSection\(state\.draft\.skus \|\| \[\], state\.draft\.specOptions \|\| \[\]\);/.test(js), "");
  check("单个「AI 主图」生成成功后走 refreshSkuSection（原来只刷核价，那格一直显示未生成）",
    /refreshSkuSection\(\);\n        toast\("该 SKU 的 AI 主图已排到它图集的首位"/.test(js), "");
  check("批量生成每张出完也刷表体，且进度徽标在重画之后补设（否则被说明文字覆盖）",
    /refreshSkuSection\(\);\n    setBadge\("#sku-notice", progress, "warn"\);/.test(js)
      && /const progress = `AI 主图 \$\{index \+ 1\}\/\$\{list\.length\}：/.test(js), "");

  // 2) 每个 SKU 底下常显核算
  check("核价面板默认展开（未记录时返回 true），不再按 SKU 数量决定",
    /function isSkuCalcOpen\(id\) \{/.test(js)
      && /return skuCalcToggle\.has\(id\) \? skuCalcToggle\.get\(id\) : true;/.test(js)
      && !/calcDefaultOpen/.test(js), "");
  check("每 SKU 核算的列与「全局核价一览」表完全对齐（16 格，同名同序）",
    ["渠道", "采购成本 ¥", "国内运费 ¥", "拿货成本 ¥", "售价 ¥", "售价 ₽", "活动价 ¥", "活动价 ₽",
      "国际物流 ¥", "佣金 ¥", "广告 ¥", "店铺利润 ¥", "采购利润率", "销售利润率", "物流利润率", "体积重 kg"]
      .every((label) => js.includes(`["${label}"`)), "");
  check("单个 SKU 面板里 ¥ 与 ₽ 的售价/活动价拆成四格（原来挤在一格里显示）",
    js.includes('["售价 ¥"') && js.includes('["售价 ₽"')
      && js.includes('["活动价 ¥"') && js.includes('["活动价 ₽"')
      && /money\(calc\.priceCny\)/.test(js) && /money\(calc\.promoCny\)/.test(js), "");

  // 3) 三处独立滚动
  check("左侧图片栏自己滚（吸顶 + max-height + overflow-y）",
    /\.work-media \{[\s\S]{0,400}max-height: calc\(100vh - 116px\);[\s\S]{0,120}overflow-y: auto;/.test(cssSrc), "");
  check("单列布局下取消左栏的滚动窗口（否则窄屏被卡在半屏高）",
    /\.work-media \{ position: static; max-height: none; overflow: visible; \}/.test(cssSrc), "");
  check("图片列表自己滚，11 张以上不再撑长页面",
    /#image-grid \{ max-height: 46vh; overflow-y: auto;/.test(cssSrc), "");
  check("「图片翻译」「AI 图片」各有一个独立的滑动窗口（.details-body 包住各自内容）",
    /\.details-body \{\n  max-height: 56vh;\n  overflow-y: auto;/.test(cssSrc)
      // v1.9.72 移除 WorkBuddy 生图助手，独立滚动壳回到 2
      && (html.match(/<div class="details-body">/g) || []).length === 2, "");
}

// ==================== v1.9.47：每行可编辑的「上架 SKU」（Ozon offer_id） ====================
{
  console.log("=== v1.9.47：上架 SKU（offer_id） ===");
  const html = fs.readFileSync(path.join(HERE, "../src/ui/panel.html"), "utf8").replace(/\r\n/g, "\n");
  const js = fs.readFileSync(path.join(HERE, "../src/ui/panel.js"), "utf8").replace(/\r\n/g, "\n");
  const api = fs.readFileSync(path.join(HERE, "../src/background/ozon-api.js"), "utf8").replace(/\r\n/g, "\n");

  // 1) offer_id 合法化
  check("新增 sanitizeOfferId（Ozon 货号只留字母/数字/- _ .）",
    typeof sanitizeOfferId === "function" && sanitizeOfferId("") === "", "");
  check("中文被替换后清掉首尾符号（纯中文店名会只剩日期部分）",
    sanitizeOfferId("我的店20260921") === "20260921"
      && sanitizeOfferId("OZON 店 20260921") === "OZON-20260921"
      && sanitizeOfferId("------abc------") === "abc",
    sanitizeOfferId("OZON 店 20260921"));
  check("空格转成 -，连续符号不叠加",
    sanitizeOfferId("a b") === "a-b" && sanitizeOfferId("a   b") === "a-b", sanitizeOfferId("a   b"));
  check("按 Ozon 上限截到 50 字符", sanitizeOfferId("x".repeat(60)).length === 50, String(sanitizeOfferId("x".repeat(60)).length));
  check("全被清空时返回 fallback", sanitizeOfferId("中文货号", "fb") === "fb", sanitizeOfferId("中文货号", "fb"));

  // 2) buildStableModel 的两级优先
  check("手填的「上架 SKU」就是最终 offer_id（不再叠加店铺前缀）",
    buildStableModel({}, { id: "abc", offerId: "MY-01" }, "PFX-") === "MY-01",
    buildStableModel({}, { id: "abc", offerId: "MY-01" }, "PFX-"));
  check("留空时用写到草稿里的自动货号",
    buildStableModel({}, { id: "abc", offerIdAuto: "OZON20260921170509-1" }, "PFX-") === "OZON20260921170509-1", "");
  check("两级都没有时保持老逻辑（前缀 + 稳定 ID）",
    buildStableModel({ id: "draft1" }, null, "PFX-") === "PFX-draft1"
      && buildStableModel({ id: "d" }, { id: "abc" }, "") === "abc", "");
  check("手填了非法字符全被吃掉时回落到老逻辑，不会返回空货号",
    buildStableModel({ id: "d" }, { id: "abc", offerId: "我的货号" }, "") === "abc",
    buildStableModel({ id: "d" }, { id: "abc", offerId: "我的货号" }, ""));

  // 3) 面板接线
  check("SKU 表「规格」后新增可编辑的「上架 SKU」列",
    /key: "offerId",\n\s*label: "上架 SKU",/.test(js) && /class="sku-offer-id"/.test(js), "");
  check("留空时的占位灰字就是自动货号（多 SKU 带序号），一眼能看会上什么货号",
    /cleanText\(row\.offerIdAuto\)\n\s*\|\| offerIdAutoValue\(offerIdPreviewBase, skus\.indexOf\(row\), skus\.length\)/.test(js), "");
  check("自动货号 = 店铺名 + 年月日 + 时间（时分秒）",
    /function offerIdAutoBase\(\)/.test(js)
      && /return sanitizeOfferId\(`\$\{offerIdStoreLabel\(\)\}\$\{stamp\}\`, `ozon\$\{stamp\}`\);/.test(js)
      && /return `\$\{now\.getFullYear\(\)\}\$\{pad\(now\.getMonth\(\) \+ 1\)\}\$\{pad\(now\.getDate\(\)\)\}`/.test(js), "");
  check("多 SKU 自动补 -1 / -2 序号（否则 Ozon 收到重复 offer_id，6 个变体会只剩 1 条商品）",
    /return total > 1 \? `\$\{base\}-\$\{index \+ 1\}` : base;/.test(js), "");
  check("店铺名取当前 Ozon 店铺，没有则用采集到的 1688 店铺名",
    /function offerIdStoreLabel\(\)/.test(js) && /name !== "默认店铺"/.test(js), "");
  check("自动货号首次渲染就算好并写回草稿（导出上架表 / 上传 / 更新拿同一个值）",
    /async function ensureSkuOfferIds\(\)/.test(js) && /void ensureSkuOfferIds\(\);/.test(js)
      && /state\.draft = await saveDraft\(\{ id: draft\.id, skus: state\.draft\.skus \}\);/.test(js), "");
  check("手填后回显合法化结果，清空则回到自动货号",
    /\$\$\("#sku-table input\.sku-offer-id"\)/.test(js)
      && /input\.value = safe;/.test(js)
      && /sku\.offerId = safe;/.test(js), "");
  check("panel.js 引入 sanitizeOfferId，面板提示也写清了留空规则",
    /import \{[^}]*sanitizeOfferId[^}]*\} from "\.\.\/shared\/product-model\.js"/.test(js)
      && /留空就用灰字显示的自动货号 = 店铺名 \+ 年月日 \+ 时间/.test(html), "");
  check("多变体上传时把该 SKU 本体传给 buildStableModel（不然手填货号会被忽略）",
    /modelSku: sku,\n\s*variantAttrs,/.test(api), "");
}

// ==================== v1.9.48：淘宝/天猫按分类采 SKU + 分类图/详情长图 + 规格可编辑 ====================
{
  console.log("=== v1.9.48：淘宝/天猫采集优化（按分类采 SKU / 分类图 + 详情长图 / 规格可编辑） ===");
  const taobaoSrc = fs.readFileSync(path.join(HERE, "../src/content/adapter-taobao.js"), "utf8").replace(/\r\n/g, "\n");
  const baseSrc = fs.readFileSync(path.join(HERE, "../src/content/adapter-base.js"), "utf8").replace(/\r\n/g, "\n");
  const js = fs.readFileSync(path.join(HERE, "../src/ui/panel.js"), "utf8").replace(/\r\n/g, "\n");
  const css = fs.readFileSync(path.join(HERE, "../src/ui/panel.css"), "utf8").replace(/\r\n/g, "\n");
  const html = fs.readFileSync(path.join(HERE, "../src/ui/panel.html"), "utf8").replace(/\r\n/g, "\n");
  const modelSrc = fs.readFileSync(path.join(HERE, "../src/shared/product-model.js"), "utf8").replace(/\r\n/g, "\n");

  // ---- 1) 纯函数回归：在 vm 里真跑一遍适配器 ----
  const ctx3 = { console, setTimeout, clearTimeout, setInterval, clearInterval, performance };
  ctx3.window = ctx3;
  ctx3.location = { origin: "https://detail.tmall.com", href: "https://detail.tmall.com/item.htm?id=1" };
  ctx3.Event = function Event(type) { this.type = type; };
  ctx3.document = {
    querySelector: () => null,
    querySelectorAll: () => [],
    documentElement: { innerHTML: "", scrollTop: 0, scrollHeight: 0 },
    body: { innerText: "" },
    dispatchEvent: () => {},
  };
  ctx3.window.innerHeight = 800;
  ctx3.window.dispatchEvent = () => {};
  vm.createContext(ctx3);
  vm.runInContext(baseSrc, ctx3);
  vm.runInContext(taobaoSrc, ctx3);
  const tb = ctx3.__OZON_ADAPTERS__.skuTaobao;
  check("淘宝适配器暴露了可回归的纯函数", Boolean(tb && tb.readInlineSkuModel), "");

  const skuBase = {
    props: [
      {
        pid: "1627207",
        name: "颜色分类",
        values: [
          { vid: "1", name: "5.0L【金属内腔】可悦款", image: "//img.alicdn.com/a.jpg_100x100.jpg" },
          { vid: "2", name: "2.6L-绿色", image: "//img.alicdn.com/b.jpg_100x100.jpg" },
        ],
      },
      // 分期 / 数量这类块出现在同一个 SKU 区里，也必须被排掉
      { pid: "20105", name: "数量", values: [{ vid: "9", name: "1件" }] },
    ],
    skus: [
      { skuId: "591", propPath: "1627207:1", quantity: "100" },
      { skuId: "592", propPath: "1627207:2", quantity: "3" },
    ],
  };
  const skuCore = {
    sku2info: {
      591: { price: { priceText: "161.09" }, quantity: "100" },
      592: { price: { priceText: "199.00" }, quantity: "3" },
    },
  };
  const scriptsText = `var g = {"skuBase":${JSON.stringify(skuBase)},"skuCore":${JSON.stringify(skuCore)},"other":{"nested":1}};`;
  const fakeCache = { ...stubCache(() => ""), scripts: () => scriptsText, html: () => "", jsonLd: () => [] };

  check("大括号配平取嵌套对象（普通正则会在第一个内层 } 就截断）",
    tb.sliceBalancedObject('{"skuBase":{"a":{"b":1}},"z":2}', "skuBase") === '{"a":{"b":1}}',
    String(tb.sliceBalancedObject('{"skuBase":{"a":{"b":1}},"z":2}', "skuBase")));
  check("被转义后塞进 JS 字符串的内联 JSON 也能解析", tb.parseLooseJson('{\\"a\\":1}')?.a === 1, "");

  const inline = tb.readInlineSkuModel(fakeCache);
  check("能从内联 skuBase 取出规格维度（这是卖家后台配的真规格）",
    inline && inline.options.length === 1 && inline.options[0].name === "颜色分类" && inline.options[0].values.length === 2,
    JSON.stringify(inline && inline.options));
  check("排掉混在 SKU 区里的「数量」等非规格块",
    Boolean(inline) && !inline.options.some((option) => option.name === "数量"),
    JSON.stringify(inline && inline.options.map((o) => o.name)));
  check("每个规格值都拿到自己的分类色卡图（缩略图后缀升到原图）",
    inline.images["颜色分类:5.0L【金属内腔】可悦款"] === "https://img.alicdn.com/a.jpg"
      && inline.images["颜色分类:2.6L-绿色"] === "https://img.alicdn.com/b.jpg",
    JSON.stringify(inline.images));
  check("按 propPath 组合出 SKU 的规格（不再是满页瞎找出来的假维度）",
    inline.skus.length === 2
      && inline.skus[0].specs["颜色分类"] === "5.0L【金属内腔】可悦款"
      && inline.skus[1].specs["颜色分类"] === "2.6L-绿色",
    JSON.stringify(inline.skus.map((s) => s.specs)));
  check("SKU 的售价与库存取自 skuCore（161.09 / 100、199 / 3）",
    inline.skus[0].price === 161.09 && inline.skus[0].stock === 100
      && inline.skus[1].price === 199 && inline.skus[1].stock === 3,
    JSON.stringify(inline.skus.map((s) => [s.price, s.stock])));
  check("SKU 直接挂上自己的分类色卡图",
    inline.skus[0].image === "https://img.alicdn.com/a.jpg" && inline.skus[1].image === "https://img.alicdn.com/b.jpg",
    JSON.stringify(inline.skus.map((s) => s.image)));

  // 分期月供 / 价格库存片段不能当规格值
  check("拦掉分期月供文案（15期 / 20+/месяц）",
    tb.isNoiseSpecValue("15期") && tb.isNoiseSpecValue("20+/месяц") && tb.isNoiseSpecValue("月供15元"), "");
  check("拦掉混进规格值的价格与库存片段",
    tb.isNoiseSpecValue("¥161.09") && tb.isNoiseSpecValue("库存42123") && tb.isNoiseSpecValue(""), "");
  check("正常规格值不被误杀",
    !tb.isNoiseSpecValue("5.0L【金属内腔】可悦款") && !tb.isNoiseSpecValue("2.6L-绿色") && !tb.isNoiseSpecValue("XL"), "");

  // 笛卡尔积 + 挂图
  const combos = tb.buildSkusFromOptions(
    [{ name: "颜色分类", values: ["红", "蓝"] }, { name: "尺码", values: ["S", "M"] }],
    { "颜色分类:红": "https://x/r.jpg" },
  );
  check("按规格维度生成组合（2×2=4 条）", combos.length === 4, String(combos.length));
  check("生成的 SKU 自动挂上分类色卡图",
    combos.find((sku) => sku.specs["颜色分类"] === "红").image === "https://x/r.jpg"
      && !combos.find((sku) => sku.specs["颜色分类"] === "蓝").image, "");
  const filled = tb.attachSpecImages([{ id: "s1", specs: { 颜色分类: "蓝" } }], { "颜色分类:蓝": "https://x/b.jpg" });
  check("没有图的 SKU 会按「维度名:值」补上分类图", filled === 1, String(filled));
  check("主图挑正方形大图（详情长图那种细长条降权）",
    tb.pickMainImage(["https://x/tall.jpg", "https://x/sq.jpg"], {
      "https://x/tall.jpg": { width: 800, height: 2000 },
      "https://x/sq.jpg": { width: 1000, height: 1000 },
    }) === "https://x/sq.jpg", "");

  // ---- 2) 源码断言：只在这个容器的范围内找规格 + 图片分三组 ----
  check("只在 SKU 选择区容器里找规格分组（不再满页找「标题 + 短选项」）",
    /const SKU_CONTAINER_SELECTORS = \[/.test(taobaoSrc)
      && /const scopes = containers\.length \? containers : \[document\];/.test(taobaoSrc), "");
  check("分期/月供这类块名被列进规格名噪音表",
    /SPEC_NAME_NOISE_PATTERN =\s*\n\s*\/\([^\n]*分期[^\n]*月供/.test(taobaoSrc), "");
  check("规格值噪音表拦掉价格、库存与期数月供",
    taobaoSrc.includes("SPEC_VALUE_NOISE_PATTERN") && taobaoSrc.includes("месяц") && taobaoSrc.includes("月供"), "");
  check("详情长图有独立的容器表",
    // v1.9.62 pickDetailImages 增加 exclude 形参（剔除与图集重复的详情图），断言按新签名放宽
    /const DETAIL_IMAGE_SELECTORS = \[/.test(taobaoSrc) && /function pickDetailImages\(/.test(taobaoSrc), "");
  check("详情长图采集前先做一次懒加载轻扫（滚到底再回原位）",
    /async function sweepForLazyImages\(/.test(taobaoSrc)
      && /scroller\.scrollTop = startY;/.test(taobaoSrc)
      && /await cache\.time\("详情长图懒加载", \(\) => sweepForLazyImages\(\)\);/.test(taobaoSrc), "");
  check("采集结果同时带上 detailImages 与 specImages",
    /detailImages,\n\s*specImages,/.test(taobaoSrc), "");
  check("页面被翻译过（规格里出现西里尔字母）时会明确告警",
    /CYRILLIC_PATTERN\.test\(option\.name\)/.test(taobaoSrc) && /疑似被浏览器翻译过/.test(taobaoSrc), "");
  check("阿里图床单下划线尺寸后缀在采集阶段就去掉（分类图拿到原图）",
    /alicdn\|taobaocdn\|tbcdn/.test(baseSrc) && /_\[qQ\]\?\\d\+x\\d\+/.test(baseSrc), "");

  // ---- 3) 面板与数据模型 ----
  check("SKU 表「规格」列改成可编辑输入框",
    /label: "规格",\n\s*html: true,/.test(js) && /class="sku-label-input"/.test(js), "");
  check("改规格写回草稿；只有一个规格维度时同步该维度的值",
    /sku\.label = next;/.test(js) && /syncSingleSpecValue\(sku, next\);/.test(js)
      && /function syncSingleSpecValue\(sku, label\)/.test(js)
      && /if \(keys\.length !== 1\) return;/.test(js), "");
  check("规格输入框有最小宽度，不会被表格压成一条缝",
    /\.sku-label-input \{ min-width: 140px; \}/.test(css), "");
  check("面板提示写清「规格」可以直接改",
    /「规格」一列也<strong>可以直接改<\/strong>/.test(html), "");
  check("specImages 在 normalizeProduct 里统一规范化（去缩略图后缀、丢空值）",
    /product\.specImages\[specKey\] = url;/.test(modelSrc) && /specImages: Object\.freeze\(\{\}\)/.test(modelSrc), "");
}

// ==================== v1.9.49：出图去模板化（视觉分析 + 逐图独立方案 + 重出换方向） ====================
{
  console.log("=== v1.9.49：生成图片去模板化（逐图定制 / 版式轮换 / 重出换方向） ===");
  const js = fs.readFileSync(path.join(HERE, "../src/ui/panel.js"), "utf8").replace(/\r\n/g, "\n");
  const html = fs.readFileSync(path.join(HERE, "../src/ui/panel.html"), "utf8").replace(/\r\n/g, "\n");
  const promptsSrc = fs.readFileSync(path.join(HERE, "../src/shared/prompts.js"), "utf8").replace(/\r\n/g, "\n");
  const swSrc = fs.readFileSync(path.join(HERE, "../src/background/service-worker.js"), "utf8").replace(/\r\n/g, "\n");
  const imgSvcSrc = fs.readFileSync(path.join(HERE, "../src/background/image-service.js"), "utf8").replace(/\r\n/g, "\n");
  const domSrc = fs.readFileSync(path.join(HERE, "../src/ui/dom.js"), "utf8").replace(/\r\n/g, "\n");

  // ---- 1) 版式变体库：不再只有一套固定模板 ----
  check("信息图版式有 5 套独立骨架（不再反复套同一模板）",
    INFO_LAYOUT_VARIANTS.length === 5 && LAYOUT_LABELS.length === 5, String(INFO_LAYOUT_VARIANTS.length));
  check("每套版式都带「色块不压商品」底线",
    INFO_LAYOUT_VARIANTS.every((variant) => /НЕ перекрывают товар/i.test(variant.join(" "))), "");
  check("5 套版式彼此内容不同（不是同一套复制五份）",
    new Set(INFO_LAYOUT_VARIANTS.map((variant) => variant[0])).size === 5, "");
  check("兼容旧引用：INFO_LAYOUT_LINES 仍是第 0 套（左侧信息栏，8 条）",
    INFO_LAYOUT_LINES === INFO_LAYOUT_VARIANTS[0] && INFO_LAYOUT_LINES.length === 8, "");
  check("pickInfoLayout 种子取模安全（负数/超大都落在 0-4）",
    pickInfoLayout(-1) === INFO_LAYOUT_VARIANTS[4] && pickInfoLayout(5) === INFO_LAYOUT_VARIANTS[0]
      && pickInfoLayout(123) === INFO_LAYOUT_VARIANTS[123 % 5], "");
  check("buildShotPrompt 按 layoutSeed 换版式（种子不同 → 提示词不同）",
    (() => {
      const a = buildShotPrompt({ shot: "main", context: "x" });
      const b = buildShotPrompt({ shot: "main", context: "x", layoutSeed: 1 });
      const c = buildShotPrompt({ shot: "main", context: "x", layoutSeed: 4 });
      return /вертикальный информационный блок/i.test(a)
        && /баннер/i.test(b) && /журнальный минимализм/i.test(c)
        && a !== b && b !== c;
    })(), "");
  check("第 0 套版式保持旧断言的关键词（老用例不回归）",
    /песочная\/бежевая или акцентная/i.test(buildShotPrompt({ shot: "main", context: "x" }))
      && /размерные линии со стрелками/i.test(buildShotPrompt({ shot: "main", context: "x" })), "");

  // ---- 2) 取景变化库 ----
  check("取景变化库 8 项（第 0 项=不指定，保持旧行为）",
    pickFraming(0) === "" && /правилу третей/i.test(pickFraming(3)) && /боке/i.test(pickFraming(6)), "");
  check("framingSeed 会把机位写进「Кадр」",
    /Кадр: [^.]*камера чуть сверху/i.test(buildShotPrompt({ shot: "scene-life", context: "x", framingSeed: 1 })), "");
  check("不传 framingSeed 时机位不加料（自定义/兜底方案不受影响）",
    buildShotPrompt({ shot: "scene-life", context: "x" }) === buildShotPrompt({ shot: "scene-life", context: "x", framingSeed: 0 }), "");

  // ---- 3) 逐张轮换与重出跳变 ----
  {
    const shots = planSetShots({ kinds: DEFAULT_SET_KINDS, count: 8 });
    const variants = assignShotVariants(shots);
    const infoShots = shots.filter((shot) => shot.text === TEXT_MODES.INFO);
    const infoLayouts = variants.filter((_, i) => shots[i].text === TEXT_MODES.INFO).map((v) => v.layoutSeed);
    check("一批 8 张里信息图各拿不同版式种子",
      new Set(infoLayouts).size === infoLayouts.length && infoLayouts.length >= 1, JSON.stringify(infoLayouts));
    check("取景种子逐张递增且不为 0（每张机位都有变化）",
      variants.every((v, i) => v.framingSeed > 0 && (i === 0 || v.framingSeed > variants[i - 1].framingSeed)), "");
    check("非信息图不吃版式种子（layoutSeed=0 保持默认）",
      variants.filter((_, i) => shots[i].text !== TEXT_MODES.INFO).every((v) => v.layoutSeed === 0), "");
    check("标准 8 张两两版式+机位组合不重复",
      new Set(variants.map((v) => `${v.layoutSeed}:${v.framingSeed}`)).size === variants.length, "");
  }
  check("重出时种子强制跳变（绝不重复上一次的画法）",
    (() => {
      const next = nextShotVariant({ layoutSeed: 2, framingSeed: 5 });
      return next.layoutSeed === 3 && next.framingSeed === 8;
    })(), "");
  check("reworkNote 会压成「离开上一版」的硬指令",
    /ПЕРЕДЕЛКА/i.test(buildShotPrompt({ shot: "main", context: "x", reworkNote: "текст давит на товар" }))
      && buildShotPrompt({ shot: "main", context: "x", reworkNote: "背景太暗" }).includes("背景太暗"), "");
  check("reworkNote 留空时不加多余段落（正常批量出图不受影响）",
    !/ПЕРЕДЕЛКА/i.test(buildShotPrompt({ shot: "main", context: "x" })), "");
  check("artDirection（该图专属导演方案）写进提示词",
    /Режиссура именно этого кадра/i.test(buildShotPrompt({ shot: "main", context: "x", artDirection: "тёплый свет слева" })), "");

  // ---- 4) 视觉分析（看参考图 → 逐图定制） ----
  check("视觉分析走独立消息动作 aiArtDirection",
    /aiArtDirection: "ai_art_direction"/.test(fs.readFileSync(path.join(HERE, "../src/shared/constants.js"), "utf8").replace(/\r\n/g, "\n"))
      && /case MESSAGE_ACTIONS\.aiArtDirection:/.test(swSrc), "");
  check("分析提示词要求先对比图与图的差异再逐图定制",
    /СРАВНИ фото между собой/i.test(promptsSrc) && /СОБСТВЕННОЕ решение/i.test(promptsSrc)
      && /не повторяй одну схему/i.test(promptsSrc), "");
  check("分析请求把参考图作为 image_url 附在文字前（视觉模型格式）",
    /type: "image_url"/.test(promptsSrc) && /buildArtDirectionMessages/.test(swSrc), "");
  check("视觉模型可单独配置，留空回落主模型",
    /aiVisionModel: ""/.test(fs.readFileSync(path.join(HERE, "../src/shared/settings.js"), "utf8").replace(/\r\n/g, "\n"))
      && /resolveVisionCredentials/.test(swSrc), "");
  {
    const parsed = parseArtDirectionResult(JSON.stringify({
      comparison: "фото различаются по свету",
      shots: [
        { id: "main", layout: 3, artDirection: "жёсткий свет слева, товар на тёмной подложке", why: "металл" },
        { id: "benefit-1", layout: 99, artDirection: "мягкий утренний свет на кухне" },
        { id: "nope-1", layout: 1, artDirection: "中文方案要丢掉" },
        { id: "bad", layout: 0, artDirection: "" },
      ],
    }));
    check("解析视觉分析：layout 夹到 0-4、混中文的方案丢弃、空方案丢弃",
      parsed?.shots?.main?.layout === 3
        && parsed?.shots?.["benefit-1"]?.layout === 4
        && !parsed?.shots?.["nope-1"] && !parsed?.shots?.bad, JSON.stringify(parsed));
    check("解析失败/无有效方案时返回 null（面板走降级轮换）",
      parseArtDirectionResult("not json") === null && parseArtDirectionResult('{"shots":[]}') === null, "");
    check("buildArtDirectionMessages 参考图最多带 3 张",
      (() => {
        const msgs = buildArtDirectionMessages({ title: "x" }, [{ id: "main", label: "主图", text: "info" }],
          { referenceImages: ["a", "b", "c", "d"] });
        return msgs[1].content.filter((part) => part.type === "image_url").length === 3;
      })(), "");
  }

  // ---- 5) 面板接线 ----
  check("批量生成前先做视觉分析（勾选 set-gen-art-ai 才做，失败降级不阻断）",
    /aiArtDirection/.test(js) && /\$\("#set-gen-art-ai"\)\?\.checked/.test(js)
      && /视觉分析失败/.test(js) && /改用逐张轮换版式出图/.test(js), "");
  check("每张图把 layoutSeed/framingSeed/artDirection 传给生图",
    /layoutSeed: variant\.layoutSeed,/.test(js) && /framingSeed: variant\.framingSeed,/.test(js)
      && /artDirection: shot\.artDirection \|\| ""/.test(js), "");
  check("图位板标注每张图用的是「独立方案」还是「版式/机位」",
    /独立方案/.test(js) && /版式 \$\{\(?\(Number\(item\.variant\?\.layoutSeed\)/.test(js), "");
  check("重出此图先问「哪里不满意」，反馈进提示词且强制换版式/机位",
    /重出「\$\{shot\.label\}」/.test(js) && /type: "textarea"/.test(js)
      && /nextShotVariant\(prev\?\.variant/.test(js) && /reworkNote,/.test(js), "");
  check("取消重出弹窗时不发请求",
    /if \(feedback === null\) return;/.test(js), "");
  check("批量 SKU 主图逐张换版式（传 index 作种子，不再整套模板脸）",
    /generateSkuMainImage\(sku\.id, index\)/.test(js)
      && /layoutSeed: seed,/.test(js) && /framingSeed: \(seed % 7\) \+ 1,/.test(js), "");
  check("重开一批生成时清掉上一批的视觉分析结果",
    /state\.setGenArt = null;/.test(js), "");
  check("面板 HTML 有「逐图定制」开关与说明",
    /id="set-gen-art-ai"/.test(html) && /逐图定制方案/.test(html) && /不套同一模板/.test(html), "");
  check("设置页有视觉分析模型输入框（含候选列表）",
    /id="set-vision-model"/.test(html) && /qwen-vl-max/.test(html)
      && /aiVisionModel: cleanText\(\$\("#set-vision-model"\)/.test(js), "");
  check("openModal 支持 textarea 字段",
    /field\.type === "textarea"/.test(domSrc), "");
  check("redrawImage 与 service-worker 透传新参数",
    /layoutSeed, framingSeed, artDirection, reworkNote,/.test(imgSvcSrc)
      && /layoutSeed: Number\(message\.layoutSeed\) \|\| 0,/.test(swSrc)
      && /reworkNote: message\.reworkNote \|\| ""/.test(swSrc), "");
}

// ============================================================================
// v1.9.50：规格数量对应 / 类目属性字典值 / 价格语义 / 图片可达性 / 生图速度
// ============================================================================
{
  const js = fs.readFileSync(path.join(HERE, "../src/ui/panel.js"), "utf8").replace(/\r\n/g, "\n");
  const html = fs.readFileSync(path.join(HERE, "../src/ui/panel.html"), "utf8").replace(/\r\n/g, "\n");
  const swSrc = fs.readFileSync(path.join(HERE, "../src/background/service-worker.js"), "utf8").replace(/\r\n/g, "\n");
  const ozonApiSrc = fs.readFileSync(path.join(HERE, "../src/background/ozon-api.js"), "utf8").replace(/\r\n/g, "\n");
  const constantsSrc = fs.readFileSync(path.join(HERE, "../src/shared/constants.js"), "utf8").replace(/\r\n/g, "\n");

console.log("=== v1.9.50 变体属性自动识别（不再靠用户手填 10096）===");
{
  const def = normalizeAttributeDefinition({
    id: 10096, name: "Цвет", is_aspect: true, is_required: true, dictionary_id: 42, type: "String",
  });
  check("属性定义读得到 is_aspect（Ozon 的变体属性标记）", def.is_aspect === true, String(def.is_aspect));
  check("属性定义读得到 dictionary_id（判断是不是枚举型）", def.dictionary_id === 42, String(def.dictionary_id));

  const catAttrs = [
    { id: 10096, name: "Цвет", is_aspect: true, dictionary_id: 42 },
    { id: 9048, name: "Цветовая гамма" },              // 名字也含 цвет，但不是变体属性
    { id: 8229, name: "Размер", is_aspect: true },
  ];
  // 同名两个候选时必须挑 is_aspect 那个，否则合并不成一张卡
  const resolved = resolveVariantAttributes(
    [
      { id: "s1", specs: { 颜色: "黑色", 尺码: "L" } },
      { id: "s2", specs: { 颜色: "白色", 尺码: "XL" } },
    ],
    catAttrs,
  );
  check("规格维度映射到变体属性（优先 is_aspect）",
    resolved.length === 2 && resolved[0].id === 10096 && resolved[1].id === 8229,
    JSON.stringify(resolved.map((r) => `${r.dim}->${r.id}`)));
  check("识别结果带 isAspect 标记（界面要显示来源）", resolved.every((r) => r.isAspect === true), JSON.stringify(resolved));
  check("汇总了各 SKU 出现过的规格值",
    resolved[0].values.join(",") === "黑色,白色", JSON.stringify(resolved[0].values));

  // 维度名连字典都没收录、类目里又只有一个变体属性 → 认那一个
  const lonely = resolveVariantAttributes([{ id: "s1", specs: { 奇葩维度: "A" } }], [{ id: 555, name: "Цвет", is_aspect: true }]);
  check("唯一变体属性作为兜底（维度名对不上也能挂上）", lonely.length === 1 && lonely[0].id === 555, JSON.stringify(lonely));

  // 没有变体属性的类目：不能瞎编
  const none = resolveVariantAttributes([{ id: "s1", specs: { 颜色: "黑" } }], [{ id: 9048, name: "Бренд" }]);
  check("类目没有变体属性时不编造属性 ID", none.length === 0, JSON.stringify(none));
}

console.log("=== v1.9.50 枚举属性走 dictionary_value_id（Ozon「不要手输」的根治）===");
{
  const dict = [
    { id: 501, value: "Чёрный" },
    { id: 502, value: "Белый" },
    { id: 503, value: "Дерево" },
  ];
  const hit = matchDictionaryValue(dict, "Чёрный");
  check("字典命中 → 带 dictionary_value_id", hit.dictionary_value_id === 501 && hit.value === "Чёрный", JSON.stringify(hit));
  check("忽略大小写与空格", matchDictionaryValue(dict, "  чёрный ").dictionary_value_id === 501, JSON.stringify(matchDictionaryValue(dict, "  чёрный ")));
  const miss = matchDictionaryValue(dict, "Светло-серый");
  check("字典没命中 → 只给文本，不伪造 ID", miss.dictionary_value_id === undefined && miss.value === "Светло-серый", JSON.stringify(miss));

  const defs = [
    { id: 10096, name: "Цвет", is_aspect: true, dictionary: dict },
    { id: 4191, name: "Аннотация" },  // 自由文本属性，不该被字典拦
  ];
  const snapped = snapAttributeValues(defs, { 10096: "чёрный", 4191: "любой текст" });
  check("就近落字典：归一化后命中并带回 ID",
    snapped.values["10096"] === "Чёрный" && snapped.ids["10096"] === 501, JSON.stringify(snapped));
  check("自由文本属性不受影响", snapped.values["4191"] === "любой текст", JSON.stringify(snapped.values));
  const unmatched = snapAttributeValues(defs, { 10096: "Светло-серый" });
  check("落不到字典的值进 unmatched（交给界面提示，不静默丢）",
    unmatched.unmatched.length === 1 && unmatched.unmatched[0].id === 10096, JSON.stringify(unmatched.unmatched));

  // 整条上传：枚举属性必须发 dictionary_value_id
  const dictDraft = {
    ...draft,
    attributeValues: { 10096: "белый" },
    categoryAttributes: defs,
  };
  const item = buildImportItem(dictDraft, { pricing: draft.pricing, categoryAttributes: defs, attributeDefinitions: defs });
  const attr = item.attributes.find((a) => a.id === 10096);
  check("上传 payload 里枚举属性发的是 dictionary_value_id",
    attr?.values?.[0]?.dictionary_value_id === 502, JSON.stringify(attr));
}

console.log("=== v1.9.55 属性对账 reconcileAttributes ===");
{
  const defs = [
    { id: 85, name: "Бренд", is_required: true, dictionary_id: 123, dictionary: [{ value: "XIAOMI", id: 11 }, { value: "SAMSUNG", id: 12 }] },
    { id: 4191, name: "Аннотация" },
    { id: 90, name: "Тип", attribute_complex_id: 55, is_required: true },
    { id: 91, name: "Ёмкость", attribute_complex_id: 55 },
    { id: 4180, name: "Цвет", dictionary: [{ value: "Чёрный", id: 501 }] },
  ];
  const r = reconcileAttributes({
    definitions: defs,
    values: { 999: "废属性", 4180: "чёрный ", 4191: "说明文字", 90: "Li-ion", 85: "GELEX" },
    valueIds: {},
  });
  check("越界属性被剔除且值不外带", r.removed.length === 1 && r.removed[0].id === 999 && r.values["999"] === undefined, JSON.stringify(r.removed));
  check("枚举值唯一就近命中 → 自动修正并绑定字典 ID",
    r.fixed.length === 1 && r.fixed[0].from === "чёрный" && r.values["4180"] === "Чёрный" && r.valueIds["4180"] === 501,
    JSON.stringify({ fixed: r.fixed, valueIds: r.valueIds }));
  check("匹配不上的枚举值进 unmatched（保留原值标红，不瞎改不丢值）", r.unmatched.length === 1 && r.unmatched[0].id === 85 && r.values["85"] === "GELEX", JSON.stringify(r.unmatched));
  check("复合属性组：组 55 填了一项缺另一项 → 提示", r.complex.length === 1 && r.complex[0].complexId === 55 && r.complex[0].missingNames.includes("Ёмкость"), JSON.stringify(r.complex));
  check("ok=false（有 unmatched）", r.ok === false);
  const rMiss = reconcileAttributes({ definitions: defs, values: {} });
  check("必填未填进 missing（只列清单不自动编）",
    rMiss.missing.some((m) => m.id === 85) && rMiss.missing.some((m) => m.id === 90), JSON.stringify(rMiss.missing));
  const r2 = reconcileAttributes({
    definitions: [{ id: 7, name: "Тип упаковки", is_required: true, dictionary: [{ value: "Единственный", id: 9 }] }],
    values: {},
  });
  check("唯一候选值的必填枚举自动补", r2.added.length === 1 && r2.values["7"] === "Единственный" && r2.valueIds["7"] === 9, JSON.stringify(r2));
  check("补完之后 ok=true", r2.ok === true);
}

console.log("=== v1.9.55 属性指纹 buildAttributesFingerprint ===");
{
  const base = [
    { id: 85, name: "Бренд", is_required: true, dictionary_id: 123 },
    { id: 4191, name: "Аннотация" },
  ];
  const same = buildAttributesFingerprint(base.map((a) => ({ ...a })));
  const changed = buildAttributesFingerprint([{ ...base[0], is_required: false }, base[1]]);
  const cosmetic = buildAttributesFingerprint([{ ...base[0], displayName: "品牌" }, { ...base[1], dictionary: [{ value: "x", id: 1 }] }]);
  check("定义相同 → 指纹一致", same === buildAttributesFingerprint(base), `${same} vs ${buildAttributesFingerprint(base)}`);
  check("必填标记变化 → 指纹变化", same !== changed, `${same} vs ${changed}`);
  check("展示字段（displayName/翻译）变化不影响指纹", same === cosmetic, `${same} vs ${cosmetic}`);
}

console.log("=== v1.9.55 Ozon 导入报错解析 classifyOzonImportErrors ===");
{
  const panelSrc = fs.readFileSync(path.join(HERE, "../src/ui/panel.js"), "utf8").replace(/\r\n/g, "\n");
  const workerSrc = fs.readFileSync(path.join(HERE, "../src/background/service-worker.js"), "utf8").replace(/\r\n/g, "\n");
  const constantsSrc = fs.readFileSync(path.join(HERE, "../src/shared/constants.js"), "utf8").replace(/\r\n/g, "\n");
  const htmlSrc = fs.readFileSync(path.join(HERE, "../src/ui/panel.html"), "utf8").replace(/\r\n/g, "\n");
  const packageSrc = fs.readFileSync(path.join(HERE, "../tools/package.py"), "utf8").replace(/\r\n/g, "\n");
  check("打包排除根目录散落的 md（只留 README.md）",
    /!= "readme\.md"/.test(packageSrc) && /os\.sep not in relpath/.test(packageSrc));
  const attrs = [{ id: 12345, name: "Диагональ экрана, см", displayName: "屏幕对角线" }];
  const parsed = classifyOzonImportErrors([
    { code: "E1", message: "Атрибут «Диагональ экрана, см» не поддерживается категорией" },
    { code: "E1", message: "Атрибут «Диагональ экрана, см» не поддерживается категорией" },
    { code: "E2", message: "Поле attributes: выберите значение из справочника (enum) для «Цвет»" },
    { code: "E3", message: "Заполните обязательный атрибут «Бренд»" },
    { code: "", message: "Совершенно новая ошибка" },
  ], attrs);
  check("同文案去重（4 条进 4 条，重复的合并）", parsed.length === 4, `得到 ${parsed.length}`);
  check("не поддерживается → unsupported + 修改建议", parsed[0].kind === "unsupported" && parsed[0].title === "属性不被该类目支持", JSON.stringify(parsed[0]));
  check("属性名从 «» 里抽出并带中文名", parsed[0].attrName === "Диагональ экрана, см" && parsed[0].attrZh === "屏幕对角线", JSON.stringify(parsed[0]));
  check("enum 关键词 → 枚举分类", parsed[1].kind === "enum", parsed[1].kind);
  check("обязательный → 必填缺失", parsed[2].kind === "required", parsed[2].kind);
  check("没收录的报错原文保留并归入 other", parsed[3].kind === "other" && parsed[3].raw === "Совершенно новая ошибка", JSON.stringify(parsed[3]));
  check("panel 轮询使用解析器渲染中文明细", /classifyOzonImportErrors/.test(panelSrc) && /upload-error-detail/.test(panelSrc));
  check("面板载入属性改走元数据通道并支持强制刷新", /ozonAttributeMeta/.test(panelSrc) && /btn-attr-meta-refresh/.test(panelSrc));
  check("载入属性后自动跑对账", /runAttributeCheck\(\{ silent: true \}\)/.test(panelSrc));
  check("报告支持复制与导出 txt", /btn-attr-check-copy/.test(panelSrc) && /btn-attr-check-export/.test(panelSrc));
  check("service-worker 有元数据缓存处理（24h TTL + 指纹比对）",
    /ATTR_META_CACHE_TTL = 24 \* 60 \* 60 \* 1000/.test(workerSrc) && /hit\.fingerprint === fingerprint/.test(workerSrc));
  check("v1.9.58 缓存代际：v1.9.57 塞过中文候选值的旧缓存一律作废",
    /CACHE_GEN = 2/.test(workerSrc) && /hit\.gen === CACHE_GEN/.test(workerSrc));
  check("v1.9.58 离线兜底结果不写缓存（接口恢复就重拉俄文值）",
    /if \(source === "network"\) \{/.test(workerSrc));
  check("元数据回源后全量补枚举候选值", /loadEnumDictionaries\(credentials, \{ categoryId, typeId, language: "ru", ids: enumIds \}\)/.test(workerSrc));
  check("空属性清单按失败处理而不是清空用户属性表", /Ozon 返回了空的属性清单/.test(workerSrc));
  check("constants 注册元数据存储键与消息动作", /attributeMetaCache/.test(constantsSrc) && /ozonAttributeMeta/.test(constantsSrc));
  check("HTML 有校验报告区与来源提示行", /attr-check-wrap/.test(htmlSrc) && /attr-meta-hint/.test(htmlSrc));
}

console.log("=== v1.9.56 品牌全库搜索 + 品牌值不翻译 ===");
{
  const panelSrc = fs.readFileSync(path.join(HERE, "../src/ui/panel.js"), "utf8").replace(/\r\n/g, "\n");
  const workerSrc = fs.readFileSync(path.join(HERE, "../src/background/service-worker.js"), "utf8").replace(/\r\n/g, "\n");
  const apiSrc = fs.readFileSync(path.join(HERE, "../src/background/ozon-api.js"), "utf8").replace(/\r\n/g, "\n");
  const constantsSrc = fs.readFileSync(path.join(HERE, "../src/shared/constants.js"), "utf8").replace(/\r\n/g, "\n");
  check("constants 注册 values/search 消息动作", /ozonAttributeValueSearch/.test(constantsSrc));
  check("ozon-api 有 searchAttributeValues（按词搜全库）",
    /export async function searchAttributeValues/.test(apiSrc) && /values\/search/.test(apiSrc));
  check("search 响应三形态兼容（result/values/数组）",
    /Array\.isArray\(result\?\.result\)/.test(apiSrc) && /Array\.isArray\(result\?\.values\)/.test(apiSrc));
  check("service-worker 路由 search 消息", /ozonAttributeValueSearch/.test(workerSrc) && /searchAttributeValues/.test(workerSrc));
  check("填入式选择本地查不到 → 调官方搜索反查",
    /searchBrandDictionaryValue\(own, typed\)/.test(panelSrc));
  check("整串一致才认（防半个词匹配错品牌）",
    /const hit = hits\.find\(\(item\) => norm\(item\.value\) === target\)/.test(panelSrc));
  check("搜索命中后补进本地字典（对账与上传组装都认）",
    /attr\.dictionary\.push\(\{ value: cleanText\(hit\.value\), id: Number\(hit\.id\)/.test(panelSrc));
  check("校验对账时大字典未命中项先经全库搜索（上限 5 项）",
    /bigDictMisses/.test(panelSrc) && /\.slice\(0, 5\)/.test(panelSrc));
  check("AI 填完属性后自动静默对账", /await runAttributeCheck\(\{ silent: true \}\);\s*\n\s*return filled;/.test(panelSrc));
  check("品牌类属性枚举值不进批量翻译", /BRAND_ATTR_RE\.test\(cleanText\(a\.name\)\)/.test(panelSrc));
  check("品牌值中文提示行同样跳过", /brandAttrIds\.has\(String\(node\.dataset\.zhFor\)\)/.test(panelSrc));
  check("报告区分「全库搜过也没有」与普通枚举不匹配", /官方全库按词搜索都未命中/.test(panelSrc));
}

console.log("=== v1.9.57 官方类目模板离线属性库 ===");
{
  const panelSrc = fs.readFileSync(path.join(HERE, "../src/ui/panel.js"), "utf8").replace(/\r\n/g, "\n");
  const workerSrc = fs.readFileSync(path.join(HERE, "../src/background/service-worker.js"), "utf8").replace(/\r\n/g, "\n");
  const kbDir = path.join(HERE, "../assets/ozon-kb");

  // —— 纯函数：离线库压缩字段 → 插件口径属性定义 ——
  const def = offlineAttributeToDefinition({ id: 10096, n: "Цвет", t: "String", r: 1, rec: 0, c: 1, mc: 3, cx: 0, pa: 0, asp: 1, same: 0, vc: 2, v: [[501, "Чёрный"], [502, "Белый"]], h: "选择商品颜色" });
  check("离线属性转成插件口径（ID/名称/类型/必填/集合/复合）",
    def.id === 10096 && def.name === "Цвет" && def.type === "string" && def.is_required === true
      && def.is_collection === true && def.max_value_count === 3, JSON.stringify(def));
  check("候选值带上官方 dictionary_value_id（上传靠它认枚举值）",
    def.dictionary.length === 2 && def.dictionary[0].id === 501 && def.dictionary[0].value === "Чёрный",
    JSON.stringify(def.dictionary));
  check("有候选值才算枚举（dictionary_id>0 界面才给下拉框）", def.dictionary_id === 10096, String(def.dictionary_id));
  check("is_aspect 从「变体特征」栏位反推（多变体上传全靠它）", def.is_aspect === true);
  check("中文填写说明保留（界面 title 提示）", def.hint === "选择商品颜色");
  const free = offlineAttributeToDefinition({ id: 4191, n: "Аннотация", t: "String", vc: 0, v: [] });
  check("自由文本属性 dictionary_id=0（不给下拉框也不发 ID）", free.dictionary_id === 0 && free.dictionary.length === 0);

  // —— 候选值状态：决定「本地够用 / 回源接口 / 只能搜索」——
  check("候选值全量在本地 → full", offlineDictionaryState(120, 120) === "full");
  check("本地没留但接口拿得全 → api", offlineDictionaryState(800, 0) === "api");
  check("超过接口 2000 上限 → huge（只能 values/search 反查）", offlineDictionaryState(50000, 0) === "huge");
  check("没有候选值 → none", offlineDictionaryState(0, 0) === "none");

  // —— 用离线库给接口定义补货（v1.9.58：默认只补显示层，候选值仍由接口拉俄文）——
  const apiAttrs = [
    { id: 10096, name: "Цвет", dictionary_id: 0, dictionary: [] },
    { id: 85, name: "Бренд", dictionary: [{ value: "OLD", id: 1 }] },
    { id: 4191, name: "Аннотация" },
  ];
  const offlineAttrs = [
    offlineAttributeToDefinition({ id: 10096, n: "Цвет", vc: 2, v: [[501, "黑色"], [502, "白色"]], asp: 1, h: "选颜色" }),
    offlineAttributeToDefinition({ id: 85, n: "Бренд", vc: 30000, v: [] }),
    offlineAttributeToDefinition({ id: 4191, n: "Аннотация", vc: 0, v: [] }),
  ];
  const filled = enrichAttributesFromOffline(apiAttrs, { attributes: offlineAttrs });
  check("默认不用离线库候选值覆盖接口（上传枚举值必须是俄文官方值）",
    apiAttrs[0].dictionary.length === 0 && filled.dictionaries === 0, JSON.stringify(apiAttrs[0]));
  check("fillDictionaries=true（接口挂了的兜底）才用离线库候选值",
    enrichAttributesFromOffline([{ id: 10096, name: "Цвет", dictionary: [] }], { attributes: offlineAttrs }, { fillDictionaries: true })
      .dictionaries === 1);
  check("接口没标枚举但离线库有候选值 → 补上 dictionary_id", apiAttrs[0].dictionary_id === 10096, String(apiAttrs[0].dictionary_id));
  check("接口说不是变体、离线库说是 → 补 is_aspect", apiAttrs[0].is_aspect === true && filled.aspects === 1);
  check("接口已经给了候选值的不覆盖（接口是类型级，更准）",
    apiAttrs[1].dictionary.length === 1 && apiAttrs[1].dictionary[0].value === "OLD", JSON.stringify(apiAttrs[1].dictionary));
  check("超大字典记下真实规模（界面据此改走搜索反查）",
    apiAttrs[1].dictionary_total === 30000 && apiAttrs[1].dictionary_state === "huge",
    JSON.stringify({ t: apiAttrs[1].dictionary_total, s: apiAttrs[1].dictionary_state }));
  check("中文填写说明只补不覆盖", apiAttrs[0].hint === "选颜色" && filled.hints === 1);
  check("离线库为 null 时不炸（没装离线库的老环境）",
    enrichAttributesFromOffline(apiAttrs, null).dictionaries === 0);

  // —— v1.9.58 中文显示层：按官方 ID 对齐模板中文 ——
  const zhAttrs = [
    { id: 10096, name: "Цвет", dictionary: [{ value: "Чёрный", id: 501 }, { value: "Белый", id: 502 }] },
    { id: 9999, name: "Неизвестный атрибут", dictionary: [] },
  ];
  // 离线库的 n 是模板里的中文名（LANGUAGE=ZH-HANS 下载）
  const zhOffline = { attributes: [
    offlineAttributeToDefinition({ id: 10096, n: "商品颜色", vc: 2, v: [[501, "黑色"], [502, "白色"]] }),
    offlineAttributeToDefinition({ id: 4191, n: "商品描述", vc: 0, v: [] }),
  ] };
  const zhFilled = enrichAttributesFromOffline(zhAttrs, zhOffline);
  check("属性名按 ID 命中离线库 → displayName 取模板中文（0 请求，比 AI 翻译权威）",
    zhAttrs[0].displayName === "商品颜色" && zhFilled.zhNames === 1, JSON.stringify(zhAttrs[0].displayName));
  check("俄文候选值按 dictionary_value_id 对齐出官方中文 displayValue",
    zhAttrs[0].dictionary[0].displayValue === "黑色" && zhAttrs[0].dictionary[1].displayValue === "白色" && zhFilled.zhValues === 2,
    JSON.stringify(zhAttrs[0].dictionary));
  check("离线库对不上的属性不动 displayName（留给 AI 翻译兜底，界面标需确认）",
    zhAttrs[1].displayName === undefined, JSON.stringify(zhAttrs[1]));
  check("离线库候选值带 zh 标记（模板值是中文翻译，上传靠 ID 不靠文本）",
    zhOffline.attributes[0].dictionary.every((v) => v.zh === true), "");
  check("attrTypeZh 把接口/模板类型翻成人话",
    attrTypeZh("string") === "文本" && attrTypeZh("Decimal") === "小数" && attrTypeZh("integer") === "整数"
      && attrTypeZh("multiline") === "多行文本" && attrTypeZh("Boolean") === "是/否" && attrTypeZh("ImageURL") === "图片链接"
      && attrTypeZh("") === "文本", "");
  check("校验报错用中文显示名（displayName 有中文时不再露俄文）",
    validateAttributeValues([{ id: 85, name: "Бренд", displayName: "品牌", is_required: true }], {}).errors[0] === "缺少必填属性「品牌」",
    JSON.stringify(validateAttributeValues([{ id: 85, name: "Бренд", displayName: "品牌", is_required: true }], {}).errors));
  check("没有中文显示名的报错标「需确认」而不是硬编",
    validateAttributeValues([{ id: 85, name: "Бренд", is_required: true }], {}).errors[0].includes("Бренд（需确认）"),
    JSON.stringify(validateAttributeValues([{ id: 85, name: "Бренд", is_required: true }], {}).errors));

  // —— 真实数据：库确实装进来了 ——
  const index = JSON.parse(fs.readFileSync(path.join(kbDir, "index.json"), "utf8"));
  const cids = Object.keys(index.categories || {});
  check("离线库索引就位（541 个类目，带类目中文名与分片号）",
    cids.length === 541 && Number(index.cap) > 0 && Number.isFinite(index.categories[cids[0]].s),
    `${cids.length} 类目 / cap=${index.cap}`);
  const shards = fs.readdirSync(kbDir).filter((f) => /^kb-\d+\.json$/.test(f));
  check("分片文件都在（按类目只读那一片，不做 18MB 全量 parse）", shards.length >= 20, String(shards.length));
  const sampleCid = cids.find((cid) => (index.categories[cid].a || 0) > 20 && (index.categories[cid].v || 0) > 50);
  const shard = JSON.parse(fs.readFileSync(path.join(kbDir, `kb-${index.categories[sampleCid].s}.json`), "utf8"));
  const rawAttrs = shard[sampleCid].a;
  const converted = rawAttrs.map(offlineAttributeToDefinition);
  check("真实类目解析出属性定义且每条都有 ID 与名称",
    converted.length > 20 && converted.every((a) => a.id > 0 && a.name), `${sampleCid}: ${converted.length} 条`);
  const withDict = converted.filter((a) => a.dictionary.length);
  check("真实候选值全带官方 dictionary_value_id（不是自由文本）",
    withDict.length > 0 && withDict.every((a) => a.dictionary.every((v) => Number(v.id) > 0 && v.value)),
    `${withDict.length} 个枚举属性`);
  check("真实类目里能解析出必填属性（离线库带官方 IsRequired）",
    converted.some((a) => a.is_required === true), "");

  // —— 后台接线 ——
  check("元数据加载先探离线库", /loadOfflineCategory\(categoryId\)/.test(workerSrc));
  check("接口正常时用离线库补候选值/变体标记", /enrichAttributesFromOffline\(attributes, offline\)/.test(workerSrc));
  check("超大字典不再发无谓的候选值请求（接口 2000 也拿不全）",
    /attr\.dictionary_state !== "huge"/.test(workerSrc));
  check("接口挂了由离线库整份顶上（类目级全量）",
    /offline && offline\.attributes\.length/.test(workerSrc) && /source = "offline"/.test(workerSrc));
  check("没填 Client-Id / Api-Key 也能先把属性表填完", /if \(result\.ok\) return result;/.test(workerSrc));
  check("离线库结果标清来源，不假装是官方接口数据", /meta: \{ source, at, fingerprint, offline: offlineInfo \}/.test(workerSrc));

  // —— 面板接线 ——
  check("来源提示写明「官方离线属性库」并说明是类目级",
    /官方离线属性库/.test(panelSrc) && /类目级全量属性/.test(panelSrc));
  check("来源提示带出官方中文对齐数", /个属性名用官方模板中文/.test(panelSrc) && /个候选值带官方中文/.test(panelSrc));
  check("超大字典给专属输入框（提示输入后到官方库反查）",
    /官方候选值 \$\{Number\(row\.dictionary_total\)\} 条，输入后自动到官方库反查/.test(panelSrc));
  check("对账反查判定放宽到「本地字典 < 官方候选值总数」",
    /Number\(attr\.dictionary_total\) > \(attr\.dictionary \|\| \[\]\)\.length/.test(panelSrc));
  check("属性名挂官方中文填写说明（title 悬停可见）", /title="\$\{escapeHtml\(hint\)\}"/.test(panelSrc));
}

console.log("=== v1.9.59 订阅授权：ECDSA 机器码激活 ===");
{
  const panelSrc = fs.readFileSync(path.join(HERE, "../src/ui/panel.js"), "utf8").replace(/\r\n/g, "\n");
  const htmlSrc = fs.readFileSync(path.join(HERE, "../src/ui/panel.html"), "utf8").replace(/\r\n/g, "\n");
  const cssSrc = fs.readFileSync(path.join(HERE, "../src/ui/panel.css"), "utf8").replace(/\r\n/g, "\n");
  // 签发工具（license-master）与插件公钥必须是同一对曲线参数；这里用固定测试码验证互通
  const MACHINE = "0000000000000000";
  const LIC_OK = "eyJtIjoiMDAwMDAwMDAwMDAwMDAwMCIsImUiOjE4OTM1MTM1OTkwMDAsIm4iOiJzZWxmdGVzdC1vayIsInYiOjF9.I3-f4B16Ma6RzZy3yHMBbf-VPpMYaaEi826kNr5r34-KBmnhYkcRspFAnmJOQ-XntRwhmo2CWztBQ0WHs-mp4A";
  const LIC_EXP = "eyJtIjoiMDAwMDAwMDAwMDAwMDAwMCIsImUiOjE3OTAyNjU1OTkwMDAsIm4iOiJzZWxmdGVzdC1leHBpcmVkIiwidiI6MX0.pxyR_8ZC5_RCSWJYEIqYmXBM__HyXYS-ETpq8ViYC-bYMRIsTB7QKT-r1blb85GQg0Ol5GyxCnN48Mbw9eImcw";
  check("机器码归一（带横线/乱字符都清洗成 16 位大写）",
    normalizeMachineId("a1b2-c3d4-e5f6-a7b8") === "A1B2C3D4E5F6A7B8" && normalizeMachineId("zz") === "", "");
  check("展示格式四四位", formatMachineId("A1B2C3D4E5F6A7B8") === "A1B2-C3D4-E5F6-A7B8", formatMachineId("A1B2C3D4E5F6A7B8"));
  const r1 = await verifyLicense(LIC_OK, MACHINE, Date.parse("2026-01-01"));
  check("有效激活码验签通过（私钥签发 → 插件公钥验证，端到端互通）",
    r1.ok === true && r1.payload.n === "selftest-ok", JSON.stringify(r1));
  const r2 = await verifyLicense(LIC_OK, "1111111111111111", Date.parse("2026-01-01"));
  check("换机器码验不过（一码绑一机）", r2.ok === false && /机器码/.test(r2.reason), JSON.stringify(r2));
  const r3 = await verifyLicense(LIC_OK, MACHINE, Date.parse("2031-01-01"));
  check("到期后拒绝并给出到期日文案（续费话术内置）", r3.ok === false && /到期/.test(r3.reason), JSON.stringify(r3));
  const r4 = await verifyLicense(LIC_EXP, MACHINE, Date.parse("2026-12-01"));
  check("已过期码（明天到期、今天十二月）被拒", r4.ok === false && r4.exp > 0, JSON.stringify(r4));
  const r5 = await verifyLicense("garbage", MACHINE, Date.now());
  check("乱码格式友好报错不崩", r5.ok === false && !!r5.reason, JSON.stringify(r5));
  const dot = LIC_OK.indexOf(".");
  const tampered = LIC_OK.slice(0, dot + 1) + (LIC_OK[dot + 1] === "Q" ? "R" : "Q") + LIC_OK.slice(dot + 2);
  const r6 = await verifyLicense(tampered, MACHINE, Date.now());
  check("签名被篡改一个字符 → 验签失败（改码续期不可行）", r6.ok === false && /签名校验失败/.test(r6.reason), JSON.stringify(r6));
  check("公钥以 JWK 常量内置且私钥不在插件里",
    /PUB_X = "pXZMYt1uDF9O-x-eYR4eQnmeeCsiqKx8tBqug8vHKfY"/.test(fs.readFileSync(path.join(HERE, "../src/shared/license.js"), "utf8"))
      && !fs.existsSync(path.join(ROOT, "private-jwk.json")), "");
  check("防时钟回拨：按见过的最大时间判定",
    /licenseMaxSeen/.test(fs.readFileSync(path.join(HERE, "../src/shared/license.js"), "utf8")), "");
  // 付费闸门覆盖：8 个入口全部过 ensureLicensed
  const gates = [
    ["AI 一键全流程", /ensureLicensed\("AI 一键全流程"\)/],
    ["上传到 Ozon", /ensureLicensed\("上传到 Ozon"\)/],
    ["批量上传", /ensureLicensed\("批量上传 Ozon"\)/],
    ["AI 生图", /ensureLicensed\("AI 生成图片"\)/],
    ["AI 卖点", /ensureLicensed\("AI 生成卖点"\)/],
    ["AI 填属性", /ensureLicensed\("AI 填类目属性"\)/],
    ["图片翻译", /ensureLicensed\("图片翻译"\)/],
  ];
  for (const [label, re] of gates) check(`付费闸门：${label}`, re.test(panelSrc), "");
  check("基础功能不设闸（采集按钮无 ensureLicensed）",
    /btn-capture"\).addEventListener\("click"[\s\S]{0,200}/.test(panelSrc) && !/ensureLicensed\("(采集|检测)/.test(panelSrc), "");
  check("顶栏有授权徽章与激活弹窗", /license-badge/.test(htmlSrc) && /openLicenseModal/.test(panelSrc) && /lic-activate/.test(panelSrc));
  check("徽章三态样式齐全", /\.license-badge\.ok/.test(cssSrc) && /\.license-badge\.trial/.test(cssSrc) && /\.license-badge\.bad/.test(cssSrc), "");
  check("激活码校验不过不进存储",
    /if \(!result\.ok\) return result;[\s\S]{0,120}STORAGE_KEYS\.license\]/.test(fs.readFileSync(path.join(HERE, "../src/shared/license.js"), "utf8")), "");
}

console.log("=== v1.9.50 价格：售价=实付价、old_price=划线价（原来写反了）===");
{
  // 折扣 40%：标价 200 → 活动价（实付）120，划线价应为 200
  const discountDraft = {
    ...draft,
    pricing: { ...result, priceCny: 500, oldPriceCny: 900 },
  };
  const item = buildImportItem(discountDraft, { pricing: discountDraft.pricing });
  check("price 低于 old_price 时两条都发出去（折扣能显示）",
    Number(item.price) > 0 && Number(item.old_price) > Number(item.price), `${item.price}/${item.old_price}`);

  // 折扣为 0：两者相等 → 不带划线价，且提示文案要说清「正常现象」
  const flat = { ...draft, pricing: { ...result, priceCny: 300, oldPriceCny: 300 } };
  const flatItem = buildImportItem(flat, { pricing: flat.pricing });
  check("折扣为 0 时不带划线价（old_price=0）", flatItem.old_price === "0", flatItem.old_price);
  const diag = collectImportDiagnostics(flat, { pricing: flat.pricing });
  check("折扣为 0 的提示写明是正常现象、成交价不受影响",
    diag.warnings.some((text) => /活动折扣为 0/.test(text) && /成交价不受影响/.test(text)),
    JSON.stringify(diag.warnings));
  const lowered = collectImportDiagnostics({ ...draft, pricing: { ...result, priceCny: 300, oldPriceCny: 100 } }, { pricing: { priceCny: 300, oldPriceCny: 100 } });
  check("划线价更低时提示去查折扣设置",
    lowered.warnings.some((text) => /低于成交价/.test(text) && /折扣设置/.test(text)),
    JSON.stringify(lowered.warnings));
}

console.log("=== v1.9.50 图片：上传前拦掉 Ozon 抓不到的地址 ===");
{
  check("后台有图片可达性探针（data:/blob: 直接判死）",
    /async function probeImageUrls/.test(swSrc) && /\^data:/i.test(swSrc) && /\^blob:/i.test(swSrc),
    "");
  check("探针会检查 content-type，防盗链回 HTML 也算坏",
    /text\\\/html|application\\\/json/.test(swSrc) || /text\/html\|application\/json/.test(swSrc), "");
  check("面板有 imageProbe 消息动作", /imageProbe: "image_probe"/.test(constantsSrc), "");
  check("上传前先剔除抓不到的图（全坏则拦住上传）",
    /pruneUnreachableImages/.test(js) && /没有一张图片是 Ozon 能抓到的/.test(js), "");
  check("「加入草稿」只收 Ozon 抓得到的图，并记录 AI 图来源",
    /aiImageUrls/.test(js) && /这些套图 Ozon 服务器打不开/.test(js), "");
  check("只拿到 base64 的套图会明确提示（Ozon 解析不了 data:）",
    /只拿到本地 base64/.test(js), "");
  check("主图是采集原图时警告中文风险（Ozon 禁止主图有汉字/英文）",
    /商品卡片中使用了汉字或英文/.test(ozonApiSrc) && /主图用的是采集原图/.test(ozonApiSrc), "");
}

console.log("=== v1.9.50 生图速度与上架流程 ===");
{
  check("取参考图与拟俄文标题并行（原来串行白等一个来回）",
    /Promise\.allSettled\(\[fetchReferenceImages\(\), fetchSetGenPlan\(shots\)\]\)/.test(js), "");
  check("参考图结果按 URL 缓存（同一张图不重复下载）",
    /const refDataUrlCache = new Map\(\)/.test(js) && /cachedRefDataUrl/.test(js), "");
  check("面板 HTML 有并发出图数开关（1~3）",
    /id="set-gen-concurrency"/.test(html) && /max="3"/.test(html), "");
  check("上传前自检会算出「将上传条目」条数",
    /将上传条目/.test(js) && /一条一个规格/.test(js), "");
  check("属性表「补齐候选值」按钮已接线",
    /id="btn-attr-dict"/.test(html) && /btn-attr-dict"\)\?\.addEventListener/.test(js), "");
  check("载入类目属性后自动拉必填/变体属性的候选值",
    /await loadAttributeDictionaries\(state\.categoryAttributes, \{ onlyImportant: true \}\)/.test(js), "");
  check("下拉选值会把 dictionary_value_id 一起存进草稿",
    /attributeValueIds/.test(js) && /dataset\?\.dictId/.test(js), "");
  check("自检要能看出来「选用的 SKU 没单独定价」",
    /没有单独定价/.test(ozonApiSrc), "");
  check("上传前预检就拦住「多规格映射不到变体属性」（不等到提交才报）",
    (() => {
      const stuck = {
        ...draft,
        skus: [
          { id: "s1", specs: { 颜色: "黑" }, label: "黑", price: 300 },
          { id: "s2", specs: { 颜色: "白" }, label: "白", price: 320 },
        ],
        categoryAttributes: [{ id: 9048, name: "Бренд" }],
      };
      try {
        assertReadyToImport(stuck, { pricing: stuck.pricing, selectedSkus: stuck.skus, categoryAttributes: stuck.categoryAttributes });
        return false;
      } catch (error) {
        return /变体属性/.test(error?.message || "");
      }
    })(), "");
  check("校验 zip 前先确认「不是 http(s) 的图片地址」会被拦（Ozon 抓不了 data:）",
    /不是 http\(s\) 地址/.test(swSrc) && /本地 base64 图/.test(swSrc), "");
  check("imageProbe 回包是 { ok, data } 信封（面板按 ok 判断，不然会静默失败）",
    /imageProbe:[\s\S]{0,80}return \{ ok: true, data: await probeImageUrls/.test(swSrc), "");
  check("更新价格发的是人民币（原先把卢布数值当人民币发，价格改不过来）",
    /v1\.9\.50 必须发人民币/.test(js) && !/price: String\(picked\?\.priceRub/.test(js), "");
  check("更新价格时 old_price 不高于 price 就不带（Ozon 会整条拒）",
    /if \(oldPriceCny > priceCny\) entry\.old_price/.test(js), "");
}

console.log("=== v1.9.51 生图提速 / 张数手填 / 筛选 AI 图 / 载入 AI 主图 / 品牌填入式 ===");
{
  // ① 生图与展示提速
  check("生成完成立刻上屏：不再阻塞在整张图下载上",
    /const src = data\?\.dataUrl \|\| remoteUrl;\s*\n\s*if \(!src\) throw new Error\("生图接口未返回可用图片"\);\s*\n\s*state\.setGen\.push/.test(js), "");
  check("单格增量渲染：完成一张只重画那一格（整板重建会让所有大图重新解码）",
    /function patchSetGenSlot\(shotId\)/.test(js) && /patchSetGenSlot\(shot\.id\);/.test(js), "");
  check("图位卡片带 data-shot（增量替换的锚点）", /dataset: \{ shot: shot\.id \}/.test(js), "");
  check("方案没变就不整板重绘（补充信息打字不再触发重建）",
    /const planKey = setPlanKey\(shots\);/.test(js) && /if \(planKey !== lastSetPlanKey\) renderSetGenGrid\(\);/.test(js), "");
  // ② 张数手填
  check("预设张数按钮容器已从面板移除", !html.includes('id="set-gen-counts"'), "");
  // ③ 筛选 AI 图
  check("图片工具栏有「筛选 AI 图片」开关", /id="btn-img-ai-only"/.test(html), "");
  check("筛选开关按 aiImageUrls 过滤、再点恢复全部",
    /state\.aiImageOnly = !state\.aiImageOnly/.test(js) && /state\.aiImageOnly \? all\.filter\(\(url\) => aiSet\.has\(url\)\) : all/.test(js), "");
  check("筛选后没有 AI 图时给引导提示（去生成并加入草稿）", /还没有 AI 生成的图片/.test(js), "");
  // ④ 载入 AI 主图
  check("每张图有「设为主图」按钮（AI 图带标识）",
    /img-set-main/.test(js) && /设为主图 \(AI\)/.test(js), "");
  check("setDraftMainImage 把选中图挪到首位（Ozon 主图 = 第一张）",
    /async function setDraftMainImage\(/.test(js)
      && /const kept = \[url, \.\.\.images\.filter\(\(item\) => item !== url\)\];/.test(js), "");
  check("设采集原图为主图时提示中文文案风险", /建议优先用 AI 主图/.test(js), "");
  check("换图弹窗修「点图没反应」：事件委托 + 防重复关闭 + Esc",
    /event\.target\.closest\?\.\("\.image-picker-item"\)/.test(js)
      && /if \(settled\) return;/.test(js)
      && /if \(event\.key === "Escape"\) close\(undefined\);/.test(js), "");
  check("换图弹窗里 AI 图带角标并排在前面",
    /picker-ai-badge/.test(js) && /sort\(\(a, b\) => Number\(b\.ai\) - Number\(a\.ai\)\)/.test(js), "");
  // ⑤ 品牌填入式选择
  check("大字典属性（品牌等）渲染成填入式选择：输入筛选 + datalist 建议",
    /ATTR_DICT_COMBO_MIN/.test(js) && /list="attr-dl-\$\{row\.id\}"/.test(js) && /datalist id="attr-dl-/.test(js), "");
  check("填入的值按字典反查 dictionary_value_id（大小写/空格不敏感、整串一致）",
    /String\(item\.value \|\| ""\)\.trim\(\)\.toLowerCase\(\) === lower/.test(js), "");
  check("填入式属性的中文提示行仍在", /data-zh-for="\$\{row\.id\}"/.test(js), "");

  console.log("=== v1.9.52 图片类型每类张数可手填 ===");
  {
    check("类型卡片内嵌张数输入框（data-kind 锚定类型）",
      /class: "setgen-kind-count"/.test(js) && /dataset: \{ kind: kind\.id \}/.test(js), "");
    check("张数上限 = 该类拍法数（超出只会重复同一套拍法）",
      /const max = kind\.shots\.length;/.test(js) && /最多只有 \$\{max\} 种拍法/.test(js), "");
    check("只收整数：输入过程拦非数字字符",
      /input\.value\.replace\(\/\[\^\\d\]\/g, ""\)\.slice\(0, 2\)/.test(js), "");
    check("空/非法回退默认张数，越界按边界纠正并提示",
      /张数没填或不是整数，已回退默认/.test(js)
        && /至少出 1 张，已按 1 张处理/.test(js), "");
    check("每类张数写进 state.setKindLimits 并传给出图方案",
      /state\.setKindLimits\[input\.dataset\.kind\] = value;/.test(js)
        && /limits: state\.setKindLimits,/.test(js), "");
    check("汇总按手填张数算（不再固定用 DEFAULT_KIND_LIMITS）",
      /expandSetShots\(state\.setGenKindIds, state\.setKindLimits\)/.test(js), "");
    check("state 初始为默认构成（未手填的类型行为不变）",
      /setKindLimits: \{ \.\.\.DEFAULT_KIND_LIMITS \}/.test(js), "");
  }

  console.log("=== v1.9.53 类目属性中文术语统一 ===");
  {
    const dictStart = js.indexOf("const ATTRIBUTE_NAME_DICT = {");
    const dictBlock = js.slice(dictStart, js.indexOf("\n};", dictStart));
    const pairs = [...dictBlock.matchAll(/^\s*"([^"]+)": "([^"]*)"/gm)].map((m) => [m[1], m[2]]);
    const val = (k) => (pairs.find((p) => p[0] === k) || [, ""])[1];

    check("词条一个没少也没多（键集合不变，只改展示文案）", pairs.length === 154, String(pairs.length));
    check("品牌字段保持不译且必须与 1688 回填口径同名", val("бренд") === "品牌", val("бренд"));
    check("单位统一用标准符号：kg / cm / W / V / L / g",
      val("вес, кг") === "重量（kg）" && val("высота, см") === "高度（cm）"
        && val("мощность, вт") === "功率（W）" && val("напряжение, в") === "电压（V）"
        && val("объем, л") === "容量（L）" && val("вес с упаковкой, г") === "带包装重量（g）", "");
    check("不再出现中文单位词（厘米/千克/瓦/伏/升/克）",
      !/（厘米）|（千克）|（瓦）|（伏）|（升）|（克）/.test(dictBlock), "");
    check("适用对象系列统一为「适用 + 对象」",
      val("сезон") === "适用季节" && val("возраст") === "适用年龄" && val("пол") === "适用性别", "");
    check("назначение 统一译作适用场景（原来按直译写成用途）",
      val("назначение") === "适用场景" && val("назначение товара") === "商品适用场景"
        && val("назначение подарка") === "礼品适用场景", "");
    check("等级枚举统一「X 级」后缀", ["универсал", "профессиональный", "любительский", "продвинутый", "начальный", "эксперт"]
      .every((k) => val(k).endsWith("级")), "");
    check("品牌型号 / 单位符号 / 代码占位符不翻译",
      val("xs") === "XS" && val("xxxl") === "XXXL"
        && val("тн вэд код").includes("ТН ВЭД")
        && val("нужен код маркировки").includes("Честный ЗНАК"), "");
    check("属性名不再带括号补充说明（括号只允许：单位符号、包装轴序、专有名词）",
      [...dictBlock.matchAll(/^\s*"[^"]+": "([^"]*[（(][^"]*)"/gm)].length === 18, "");
    check("修正旧译：抽屉柜→通风柜、领口→领型、认证证书→证书、型号名称（改型）→改型名称",
      val("вытяжной шкаф") === "通风柜" && val("декольте") === "领型"
        && val("сертификат") === "证书" && val("наименование модификации") === "改型名称", "");
    const sharedPrompts = fs.readFileSync(path.join(HERE, "../src/shared/prompts.js"), "utf8").replace(/\r\n/g, "\n");
    check("AI 兜底翻译也按同一套术语规则（单位符号/等级/不译品牌）",
      /единицы измерения пиши символом в скобках/.test(sharedPrompts)
        && /не переводи названия брендов/.test(sharedPrompts)
        && /суффикс «级»/.test(sharedPrompts), "");
    check("属性表列标题统一叫「属性值」", /label: "属性值（可编辑）"/.test(js), "");
  }

  console.log("=== v1.9.54 SKU AI 主图可还原为原有商品主图 ===");
  {
    check("AI 主图已生成时显示「还原主图」按钮（未生成时不显示）",
      /const restore = row\.aiMainUrl/.test(js) && /class="mini sku-ai-restore"/.test(js), "");
    check("还原 = 主图换回 originalImage + 清掉 aiMainUrl/originalImage（v1.9.81）",
      /delete sku\.aiMainUrl;/.test(js) && /delete sku\.originalImage;/.test(js)
        && /const backTo = original \|\| rest\[0\]/.test(js)
        && /sku\.image = backTo;/.test(js), "");
    check("还原后刷新 SKU 区（否则界面还显示 AI 图）",
      /button\.sku-ai-restore"\)\) \{/.test(js) && /refreshSkuSection\(\);/.test(js), "");
  }
}
}

console.log("=== v1.9.61 品牌合规：把「缺少品牌文件」封锁挡在上传前 ===");
{
  const panelSrc = fs.readFileSync(path.join(HERE, "../src/ui/panel.js"), "utf8").replace(/\r\n/g, "\n");
  const htmlSrc = fs.readFileSync(path.join(HERE, "../src/ui/panel.html"), "utf8").replace(/\r\n/g, "\n");
  const brandAttr = { id: 85, name: "Бренд", is_required: false, dictionary: [{ id: 11, value: "Нет бренда" }] };
  const baseDraft = {
    id: "brand-draft",
    ru: { title: "无线蓝牙耳机 降噪 长续航" },
    ozonCategory: { descriptionCategoryId: 100, typeId: 200 },
    pricing: { priceCny: 50, oldPriceCny: 90 },
    images: ["https://img.example.com/a.jpg"],
    attributes: [],
    attributeValues: {},
  };
  const opts = (values) => ({
    categoryAttributes: [brandAttr],
    attributeValues: values,
    requiredAttributeIds: [],
    weightGrams: 300, depthMm: 10, widthMm: 10, heightMm: 10,
  });

  check("品牌属性识别：Бренд / Brand / 品牌 都认，普通属性不误判",
    isBrandAttribute({ id: 85, name: "Бренд" }) && isBrandAttribute({ id: 1, name: "Brand name" })
      && isBrandAttribute({ id: 2, displayName: "品牌" }) && !isBrandAttribute({ id: 3, name: "Цвет" }), "");

  check("「无品牌」判定覆盖 Нет бренда / No brand，具体品牌不算",
    isNoBrandValue("Нет бренда") && isNoBrandValue("НЕТ   БРЕНДА") && isNoBrandValue("No brand")
      && !isNoBrandValue("Xiaomi"), "");

  check("能从类目字典里挑出无品牌项（供一键填写用）",
    pickNoBrandFromDictionary(brandAttr.dictionary)?.id === 11
      && pickNoBrandFromDictionary([{ id: 10, value: "Apple" }]) === null, "");

  check("品牌词扫描：短词整词匹配（hp 命中 / shp 不命中）+ 标点写法 + 中文品牌",
    scanBrandWords("HP 原装墨盒").includes("hp") && !scanBrandWords("SHP 支架").includes("hp")
      && scanBrandWords("G-Shock 电子表").includes("gshock") && scanBrandWords("小米移动电源").includes("小米")
      && scanBrandWords("无线蓝牙耳机 降噪 长续航 白色").length === 0, "");

  const missBrand = collectImportDiagnostics(baseDraft, opts({}));
  check("品牌属性没填 → 上传前自检给出品牌合规提示",
    [...missBrand.problems, ...missBrand.warnings].some((t) => /【品牌合规】/.test(t) && /Бренд/.test(t)),
    JSON.stringify(missBrand.problems));

  const conflict = collectImportDiagnostics({ ...baseDraft, ru: { title: "Xiaomi 蓝牙耳机" } }, opts({ 85: "Нет бренда" }));
  check("标题带品牌词、品牌属性却填「无品牌」→ 判为必须修（最易被封/被举报的组合）",
    conflict.problems.some((t) => /【品牌合规】/.test(t) && /自相矛盾/.test(t)), JSON.stringify(conflict.problems));

  const consistent = collectImportDiagnostics({ ...baseDraft, ru: { title: "Xiaomi 蓝牙耳机" } }, opts({ 85: "Xiaomi" }));
  check("标题品牌与品牌属性一致 → 只提示「需备授权文件」，不算硬伤",
    !consistent.problems.some((t) => /【品牌合规】/.test(t))
      && consistent.warnings.some((t) => /【品牌合规】/.test(t) && /授权/.test(t)), "");

  const clean = collectImportDiagnostics(baseDraft, opts({ 85: "Нет бренда" }));
  check("品牌填「无品牌」+ 标题无品牌词 → 不再有品牌提示（不误报）",
    ![...clean.problems, ...clean.warnings].some((t) => /【品牌合规】/.test(t)), JSON.stringify(clean.warnings));

  check("必填品牌缺失已被通用「必填属性缺失」报过时不重复刷屏",
    collectBrandRisks({
      title: "无线蓝牙耳机", attributeValues: {},
      categoryAttributes: [{ id: 85, name: "Бренд", is_required: true }],
      skipAttributeIds: ["85"],
    }).items.length === 0, "");

  check("宣称词 / 商标符号 / 图片 logo 各自成条",
    (() => {
      const r = collectBrandRisks({
        title: "原装正品 蓝牙耳机 ®",
        attributeValues: { 85: "Нет бренда" },
        categoryAttributes: [brandAttr],
        images: ["https://x.com/logo-main.jpg"],
      });
      const codes = r.items.map((i) => i.code);
      return codes.includes("brand-claim-word") && codes.includes("brand-mark-symbol") && codes.includes("brand-image-logo");
    })(), "");

  check("面板：一键填「无品牌」按钮 + 品牌合规状态行已接入",
    /id="btn-brand-nobrand"/.test(htmlSrc) && /id="brand-guard-hint"/.test(htmlSrc) && /id="brand-guard-status"/.test(htmlSrc)
      && /async function fillNoBrandAttributes/.test(panelSrc) && /function renderBrandGuard/.test(panelSrc)
      && /renderBrandGuard\(\);\n  await renderVariantAttrHint\(\)/.test(panelSrc), "");

  check("已有具体品牌值时先弹确认再覆盖（不静默改动业务数据）",
    /confirmDialog\(/.test(panelSrc) && /确认改为「Нет бренда」/.test(panelSrc), "");
}

console.log("=== v1.9.62 图片采集：拼多多取原图 / 排除买家秀 / 三平台统一 ===");
{
  const pddSrc = fs.readFileSync(path.join(HERE, "../src/content/adapter-pdd.js"), "utf8").replace(/\r\n/g, "\n");
  const baseSrc = fs.readFileSync(path.join(HERE, "../src/content/adapter-base.js"), "utf8").replace(/\r\n/g, "\n");
  const taobaoSrc = fs.readFileSync(path.join(HERE, "../src/content/adapter-taobao.js"), "utf8").replace(/\r\n/g, "\n");
  const ali1688Src = fs.readFileSync(path.join(HERE, "../src/content/adapter-1688.js"), "utf8").replace(/\r\n/g, "\n");

  // ① 拼多多图床原来不在白名单里（白名单写的是并不存在的 pinduoduoimg.com），
  //    导致 .jpeg.w800.jpeg / .jpeg_400x400.jpeg 这类缩略图后缀从来没被裁过 —— 一直采到小图
  const pdd = "https://img.pddpic.com/mms-material-img/2023-01-01/abc.jpeg";
  check("拼多多图床进白名单：点号变体后缀裁到原图",
    normalizeImageUrl(`${pdd}.w800.jpeg`) === pdd
      && normalizeImageUrl(`${pdd}.h800.jpeg`) === pdd
      && normalizeImageUrl(`${pdd}.q75.jpeg`) === pdd
      && normalizeImageUrl(`${pdd}_400x400.jpeg`) === pdd, "");
  check("拼多多自己的原图标记 .a.jpeg 不被误裁",
    normalizeImageUrl(`${pdd}.a.jpeg`) === `${pdd}.a.jpeg`, "");
  check("拼多多腾讯云数据万象 query 去掉（顺带避免被转成 webp）",
    normalizeImageUrl(`${pdd}?imageMogr2/thumbnail/400x400/strip`) === pdd
      && normalizeImageUrl(`${pdd}?imageView2/2/w/400/h/400`) === pdd, "");
  check("1688/淘宝原有规则没被破坏（下划线尺寸 / _.webp / sum 小图 / x-oss-process）",
    normalizeImageUrl("https://cbu01.alicdn.com/img/ibank/a.jpg_400x400q90.jpg") === "https://cbu01.alicdn.com/img/ibank/a.jpg"
      && normalizeImageUrl("https://cbu01.alicdn.com/img/ibank/a.jpg_.webp") === "https://cbu01.alicdn.com/img/ibank/a.jpg"
      && normalizeImageUrl("https://img.alicdn.com/imgextra/a.jpg.sum.jpg") === "https://img.alicdn.com/imgextra/a.jpg"
      && normalizeImageUrl("https://cbu01.alicdn.com/a.jpg?x-oss-process=image/resize,w_400") === "https://cbu01.alicdn.com/a.jpg", "");
  check("非白名单站点不许乱裁（用户自己的 photo.1920x1080.jpg 必须原样保留）",
    normalizeImageUrl("https://example.com/photo.1920x1080.jpg") === "https://example.com/photo.1920x1080.jpg"
      && normalizeImageUrl("https://example.com/a/abc.jpeg.w800.jpeg") === "https://example.com/a/abc.jpeg.w800.jpeg", "");
  check("放大按钮（highResImageUrl）也认拼多多点号变体",
    highResImageUrl(`${pdd}.w800.jpeg`) === pdd, "");

  // ② 采集器新能力：@ 完整选择器 / extraFirst / extraMeta / 占位图让位 srcset
  check("采集器支持以 @ 开头的完整选择器（不补 ' img'，且不会把 @ 丢给 querySelectorAll）",
    /const isFullSelector = \(selector\) => selector\.charAt\(0\) === "@";/.test(baseSrc)
      && /resolveSelector = \(selector\) => \(isFullSelector\(selector\) \? selector\.slice\(1\) : `\$\{selector\} img`\)/.test(baseSrc)
      && /resolveContainer = \(selector\) => \(isFullSelector\(selector\) \? selector\.slice\(1\) : selector\)/.test(baseSrc), "");
  check("结构化数据的图可以排到 DOM 图前面（extraFirst）",
    /extraFirst = false/.test(baseSrc) && /if \(extraFirst\) addExtra\(\);/.test(baseSrc)
      && /if \(!extraFirst\) addExtra\(\);/.test(baseSrc), "");
  check("结构化数据自带的真实宽高能进 imageMeta（extraMeta）",
    /extraMeta = null/.test(baseSrc) && /natural: sized/.test(baseSrc), "");
  check("占位图文件名认得出，让位给 srcset 的真图",
    /PLACEHOLDER_FILE_RE/.test(baseSrc) && /blank\|loading\|load\|placeholder/.test(baseSrc), "");

  // ③ 拼多多：主图来源与排除区
  check("拼多多用 aria-label 锚点抓轮播主图与详情长图（类名混淆时唯一稳的钩子）",
    /@img\[aria-label="商品大图"\]/.test(pddSrc) && /@img\[aria-label="查看图片"\]/.test(pddSrc), "");
  check("拼多多排除评论晒图 / 推荐位 / 店铺卡片",
    /const IMAGE_EXCLUDE_ZONES = \[/.test(pddSrc)
      && /\[class\*=review\]/.test(pddSrc) && /\[class\*=recommend\]/.test(pddSrc)
      && /\[class\*=shopCard\]/.test(pddSrc), "");
  check("拼多多不再把 [class*=thumb] / [class*=banner-list] 当图集容器（那是买家秀与活动位）",
    !/containers: \["\[class\*=gallery\]", "\[class\*=thumb\]", "\[class\*=carousel\]", "\[class\*=banner-list\]"/.test(pddSrc), "");
  check("拼多多按尺寸挑主图并把主图排到第一位（原来直接用 images[0]）",
    /function pickMainImage\(images = \[\], imageMeta = \{\}\)/.test(pddSrc)
      && /const mainImage = pickMainImage\(ordered, imageMeta\);/.test(pddSrc)
      && /mainImage: picked\.mainImage \|\| images\[0\] \|\| ""/.test(pddSrc), "");
  check("拼多多读内联 JSON 时带上真实宽高（唯一可信的尺寸来源）",
    /function jsonGallery\(model\)/.test(pddSrc) && /extraMeta: json\.meta/.test(pddSrc), "");
  check("拼多多补齐详情长图采集 + 懒加载轻扫",
    /function pickDetailImages\(exclude = \[\]\)/.test(pddSrc) && /async function sweepForLazyImages\(/.test(pddSrc)
      && /detailImages,/.test(pddSrc), "");
  check("拼多多提示主图视频可能占着轮播首图",
    /轮播首图有可能是视频封面/.test(pddSrc), "");

  // ④ 1688 / 淘宝：评价区排除 + extraFirst + 详情图去重 + 张数上限
  check("1688 排除评价区（买家秀缩略图会命中 [class*=thumb] 选择器）",
    /\[class\*=review\]/.test(ali1688Src) && /\[class\*=comment\]/.test(ali1688Src) && /\[class\*=appraise\]/.test(ali1688Src), "");
  check("淘宝/天猫排除评价区",
    /\[class\*=review\]/.test(taobaoSrc) && /\[class\*=rate-\]/.test(taobaoSrc) && /\[class\*=appraise\]/.test(taobaoSrc), "");
  check("1688 / 淘宝的 JSON-LD 图排到前面，并对图集设张数上限",
    /extraFirst: true/.test(ali1688Src) && /GALLERY_IMAGE_LIMIT/.test(ali1688Src)
      && /extraFirst: true/.test(taobaoSrc) && /GALLERY_IMAGE_LIMIT/.test(taobaoSrc), "");
  check("1688 / 淘宝详情长图剔除与图集重复的封面图",
    /function pickDetailImages\(exclude = \[\]\)/.test(ali1688Src) && /pickDetailImages\(images\)/.test(ali1688Src)
      && /function pickDetailImages\(exclude = \[\]\)/.test(taobaoSrc) && /pickDetailImages\(images\)/.test(taobaoSrc), "");

  // ⑤ 两处 normalizeImageUrl 必须行为一致（采集端剥一次、面板/后台再剥一次）
  check("content 与 shared 的图床白名单一致",
    /pddpic\|pinduoduo\|yangkeduo/.test(baseSrc) && /pddpic\|pinduoduo\|yangkeduo/.test(
      fs.readFileSync(path.join(HERE, "../src/shared/utils.js"), "utf8"),
    ), "");
}

/* ------------------------------------------------------------------
 * v1.9.63 「产品没有识别出来」修复
 * 用户截图：图片明明是空气炸锅，AI 却输出「未知商品 / 未指定商品类型 / 信息不足以描述」，
 * 而且「AI 匹配类目」同时失败。根因是三件事叠在一起：
 *   ① 采集把标题退化成了店铺名（甚至 0 个 SKU），AI 手里没有任何可判断的信息；
 *   ② 插件把 AI 的「未知商品」当成「用户已确认的品类」持久化并锁死，之后每次生成都回传给模型；
 *   ③ 插件不校验 AI 输出，把「礼貌放弃」的废话当成成功结果标绿点。
 * ------------------------------------------------------------------ */
console.log("=== v1.9.63 商品识别失败：不再把「未知商品」当成功、不再自锁 ===");
{
  // ① 品类占位值识别：这些值绝不能当成「用户已确认的品类」
  check("占位品类识别：未知商品 / 未指定 / 空 / 俄文 неизвестно 都判为占位",
    isPlaceholderProductType("未知商品") && isPlaceholderProductType("未指定")
      && isPlaceholderProductType("") && isPlaceholderProductType("  ")
      && isPlaceholderProductType("неизвестно") && isPlaceholderProductType("не указано"), "");
  check("正常俄文品类不误判",
    !isPlaceholderProductType("Воздушные фритюрницы") && !isPlaceholderProductType("Футбольные бутсы"), "");
  check("品类里出现中文本身就是错的（提示词要求全俄文）", isPlaceholderProductType("空气炸锅"), "");

  // ② 用户截图里的真实输出必须被拦下
  const shot = {
    productType: "未知商品",
    usage: "已指定",
    title: "未知商品 - 无用途信息",
    shortDescription: "未指定商品类型；未指定用途；信息不足以描述",
    description: "原始数据中只标注了官方名称，没有指明具体商品。由于缺乏信息，无法确定类型，用途和特性。",
    keywords: [], categoryHint: "", bulletPoints: [],
  };
  const bad = inspectListingResult(shot);
  check("截图里的「未知商品」输出被判为无效结果", bad.weak === true, JSON.stringify(bad.reasons));
  check("无效结果的原因能被说清楚（不是笼统「解析失败」）",
    bad.reasons.some((r) => r.includes("中文")) && bad.reasons.some((r) => r.includes("品类")), bad.reasons.join(" | "));

  const good = {
    productType: "Воздушные фритюрницы",
    usage: "для приготовления блюд без масла",
    title: "Воздушная фритюрница 5 л с прозрачным окном",
    shortDescription: "Объём 5 л; Смотровое окно",
    description: "Воздушная фритюрница объёмом 5 литров готовит блюда без масла.",
    keywords: ["фритюрница"], categoryHint: "Бытовая техника", bulletPoints: ["Объём 5 л"],
  };
  check("正常俄文结果不被误杀", inspectListingResult(good).weak === false, JSON.stringify(inspectListingResult(good).reasons));
  check("只错一项（品类写 не указано）不整体判失败",
    inspectListingResult({ ...good, productType: "не указано" }).weak === false, "");
  check("空对象判为无效结果", inspectListingResult(null).weak === true && inspectListingResult({}).weak === true, "");

  // ③ 报错要分得清「AI 不会写」和「采集没拿到数据」
  const noData = weakListingError(bad, { title: "威海丹泰体育用品有限公司", skus: [], attributes: [], description: "" });
  check("采集没数据时提示去重新采集 / 手填品类",
    noData.includes("重新采集") && noData.includes("商品词"), noData.slice(0, 60));
  const badAi = weakListingError(bad, { title: "正常商品标题", skus: [{ id: "1" }], attributes: [{ name: "a" }], description: "有描述" });
  check("有数据但 AI 放弃作答时提示换模型 / 手填品类",
    badAi.includes("模型") && !badAi.includes("重新采集"), badAi.slice(0, 60));

  // ④ 提示词：占位品类不许当「用户指定」传下去，且必须带上采集线索
  const weakMsgs = buildListingMessages(
    { platform: "1688", title: "", images: ["a", "b"], sourceUrl: "https://detail.1688.com/x", diagnostics: { notes: ["未识别到 SKU 规格"] }, skus: [], attributes: [] },
    { productType: "未知商品" },
  );
  const weakPayload = weakMsgs[1].content;
  check("占位品类不会出现在「用户指定类型」里（否则模型永远答不知道）",
    !weakPayload.includes("ТИП ТОВАРА ЗАДАН ПОЛЬЗОВАТЕЛЕМ"), "");
  check("标题缺失时显式告诉模型「没拿到标题」，而不是发一个空行",
    weakPayload.includes("НЕ ПОЛУЧЕНО"), "");
  check("提示词带上来源链接 / 图片数量 / 采集器诊断",
    weakPayload.includes("https://detail.1688.com/x") && weakPayload.includes("2 шт") && weakPayload.includes("未识别到 SKU 规格"), "");
  check("提示词明令禁止「未知商品」这类放弃式回答与中文输出",
    weakPayload.includes("ЗАПРЕЩЕНО") && weakPayload.includes("китайском"), "");
  const strongMsgs = buildListingMessages({ platform: "1688", title: "X", skus: [], attributes: [] }, { productType: "Футбольные бутсы" });
  check("用户真填了品类时仍然作为硬约束传下去",
    strongMsgs[1].content.includes("ТИП ТОВАРА ЗАДАН ПОЛЬЗОВАТЕЛЕМ") && strongMsgs[1].content.includes("Футбольные бутсы"), "");

  // ⑤ 后台两条路径（一次性 / 流式）都必须过闸门
  const swSrc = fs.readFileSync(path.join(HERE, "../src/background/service-worker.js"), "utf8").replace(/\r\n/g, "\n");
  check("后台一次性生成路径接入质量闸门",
    /const quality = inspectListingResult\(parsed\);/.test(swSrc)
      && /quality\.weak\) return \{ ok: false, error: weakListingError/.test(swSrc), "");
  check("后台流式生成路径也接入质量闸门",
    /quality\.weak\) \{\s*\n\s*port\.postMessage\(\{ type: "done", ok: false, error: weakListingError/.test(swSrc), "");

  // ⑥ 面板：占位值不写回、不锁定、不持久化
  const panelSrc = fs.readFileSync(path.join(HERE, "../src/ui/panel.js"), "utf8").replace(/\r\n/g, "\n");
  check("面板导入占位品类判定",
    /import \{ isPlaceholderProductType \} from "\.\.\/shared\/prompts\.js";/.test(panelSrc), "");
  check("载入草稿时占位品类不锁定（否则之后再也改不回来）",
    /const usableType = savedType && !isPlaceholderProductType\(savedType\) \? savedType : "";/.test(panelSrc)
      && /typeInput\.dataset\.dirty = usableType \? "1" : "";/.test(panelSrc), "");
  check("手输品类时占位值不算「用户已确认」",
    /node\.dataset\.dirty = value && !isPlaceholderProductType\(value\) \? "1" : "";/.test(panelSrc), "");
  check("applyRu 不把占位品类写进输入框 / 草稿",
    /const usableType = data\.productType && !isPlaceholderProductType\(data\.productType\)/.test(panelSrc)
      && /productType: usableType \|\| state\.draft\.ru\?\.productType \|\| ""/.test(panelSrc), "");
  check("流式生成失败时把真实原因提示给用户",
    /toast\(message\.error \|\| "生成结束，但结果无法解析为 JSON", "error"\);/.test(panelSrc), "");

  // ⑦ 采集侧：标题退化成一个店铺名时宁可留空 + 写诊断
  const base63 = fs.readFileSync(path.join(HERE, "../src/content/adapter-base.js"), "utf8").replace(/\r\n/g, "\n");
  const ali63 = fs.readFileSync(path.join(HERE, "../src/content/adapter-1688.js"), "utf8").replace(/\r\n/g, "\n");
  const tb63 = fs.readFileSync(path.join(HERE, "../src/content/adapter-taobao.js"), "utf8").replace(/\r\n/g, "\n");
  const pdd63 = fs.readFileSync(path.join(HERE, "../src/content/adapter-pdd.js"), "utf8").replace(/\r\n/g, "\n");
  check("标题清洗新增「结尾店铺噪声」剥离（对称于原有的前缀剥离）",
    /const TITLE_NOISE_SUFFIX = new RegExp/.test(base63) && /out\.replace\(TITLE_NOISE_SUFFIX, ""\)/.test(base63), "");
  check("剥离后变空要退回原值（不能把标题剥没）",
    /const noSuffix = out\.replace\(TITLE_NOISE_SUFFIX, ""\);\s*\n\s*if \(cleanText\(noSuffix\)\) out = noSuffix;/.test(base63), "");
  check("公共工具新增 looksLikeShopName 并导出",
    /function looksLikeShopName\(value\)/.test(base63) && /^    looksLikeShopName,$/m.test(base63), "");
  check("1688 不再兜底返回店铺名，改为留空",
    /if \(good\) return good;/.test(ali63) && !/return good \|\| ordered\[0\] \|\| "";/.test(ali63), "");
  check("1688 / 淘宝 / 拼多多 标题退化时都写一条采集诊断",
    /没能从页面取到商品标题/.test(ali63) && /没能从页面取到商品标题/.test(tb63) && /没能从页面取到商品标题/.test(pdd63), "");
  check("淘宝 / 拼多多 也会跳过店铺名候选",
    /U\.looksLikeShopName\(cleaned\)/.test(tb63) && /U\.looksLikeShopName\(cleaned\)/.test(pdd63), "");
}

/* ------------------------------------------------------------------
 * v1.9.64 「JSON 富内容」搬出属性表 + AI 自动生成；品牌默认「无品牌」；类目属性识别加强
 * ------------------------------------------------------------------ */
console.log("=== v1.9.64 富内容 / 品牌默认 / 属性识别加强 ===");
{
  // ① 富内容图片过滤：Ozon 只认 jpg / jpeg / png 直链
  check("富内容图片只认 jpg/jpeg/png 直链（gif、webp 一律剔除）",
    isRichContentImage("https://x/a.jpg") && isRichContentImage("https://x/a.JPEG")
      && isRichContentImage("https://x/a.png?w=800")
      && !isRichContentImage("https://x/a.gif") && !isRichContentImage("https://x/a.webp")
      && !isRichContentImage("/local/a.jpg") && !isRichContentImage(""), "");

  // ② 挑图：去重 + 过滤 webp/gif + 用采集到的真实宽高（拿不到才 1000 兜底）+ 限量
  const picked64 = pickRichContentImages({
    images: ["https://x/1.jpg", "https://x/1.jpg", "https://x/2.webp", "https://x/3.png", "https://x/4.gif"],
    imageMeta: { "https://x/1.jpg": { width: 800, height: 600 } },
  }, RICH_CONTENT_MAX_BLOCKS);
  check("挑图：去重 + 剔除 webp/gif + 保留 jpg/png",
    picked64.length === 2 && picked64[0].url === "https://x/1.jpg" && picked64[1].url === "https://x/3.png",
    JSON.stringify(picked64.map((i) => i.url)));
  check("挑图：优先用采集到的真实宽高，拿不到才用 1000 兜底",
    picked64[0].width === 800 && picked64[0].height === 600 && picked64[1].width === 1000 && picked64[1].height === 1000,
    JSON.stringify(picked64.map((i) => `${i.width}x${i.height}`)));
  check("挑图：限量生效",
    pickRichContentImages({ images: ["https://x/1.jpg", "https://x/2.jpg", "https://x/3.jpg"] }, 2).length === 2, "");

  // ③ 拼 JSON：Ozon 官方形状 raShowcase / billboard
  const rcJson = buildRichContentJson(
    [{ url: "https://x/1.jpg", width: 800, height: 600 }],
    [{ title: "Компактный корпус", text: "Занимает мало места." }],
  );
  const rcParsed = JSON.parse(rcJson);
  check("富内容 JSON 形状符合官方要求（raShowcase / billboard / blocks[].img 全字段）",
    Array.isArray(rcParsed) && rcParsed[0].widgetName === "raShowcase" && rcParsed[0].type === "billboard"
      && rcParsed[0].blocks[0].img.src === "https://x/1.jpg" && rcParsed[0].blocks[0].img.srcMobile === "https://x/1.jpg"
      && rcParsed[0].blocks[0].img.width === 800 && rcParsed[0].blocks[0].img.height === 600
      && rcParsed[0].blocks[0].img.widthMobile === 800 && rcParsed[0].blocks[0].img.heightMobile === 600
      && rcParsed[0].blocks[0].title === "Компактный корпус"
      && rcParsed[0].blocks[0].text.content[0] === "Занимает мало места.", "");
  check("标题与正文都为空的图块会被丢掉（宁缺毋滥）",
    buildRichContentJson([{ url: "https://x/1.jpg" }, { url: "https://x/2.jpg" }], [{ title: "", text: "" }, { title: "T", text: "" }]).includes("https://x/2.jpg")
      && !buildRichContentJson([{ url: "https://x/1.jpg" }], [{ title: "", text: "" }]).includes("https://x/1.jpg"), "");
  check("没有任何可用图块时返回空串（不是一段平台必然拒绝的 JSON）",
    buildRichContentJson([{ url: "https://x/1.gif" }], [{ title: "T", text: "X" }]) === "", "");

  // ④ 校验：硬错误要能指出原因
  check("校验：合法富内容通过并报出小工具 / 图块数",
    validateRichContentJson(rcJson).ok && validateRichContentJson(rcJson).widgets === 1 && validateRichContentJson(rcJson).blocks === 1, "");
  check("校验：非法 JSON / 缺 widgetName / 缺 blocks / gif 图片都要报错",
    !validateRichContentJson("{oops").ok
      && !validateRichContentJson('[{"blocks":[{"img":{"src":"https://x/a.jpg"}}]}]').ok
      && !validateRichContentJson('[{"widgetName":"raShowcase"}]').ok
      && !validateRichContentJson('[{"widgetName":"raShowcase","blocks":[{"img":{"src":"https://x/a.gif"}}]}]').ok, "");
  check("校验：空值不算错（富内容是可选属性）",
    validateRichContentJson("").ok && validateRichContentJson("").empty, "");
  check("状态行文案：N 个小工具 / M 个图块",
    summarizeRichContent(rcJson).text === "1 个小工具 / 1 个图块", summarizeRichContent(rcJson).text);

  // ⑤ 不调 AI 的兜底排版：详细描述按空行切段逐段配图，首块带标题
  const fb64 = JSON.parse(buildRichContentFallback(
    [{ url: "https://x/1.jpg", width: 800, height: 800 }, { url: "https://x/2.jpg", width: 800, height: 800 }],
    "Первый абзац.\n\nВторой абзац.\n\nТретий абзац.",
    "Аэрогриль 4.5 л",
  ));
  check("兜底排版：按空行切段、逐段配图、首块带标题",
    fb64.length === 2 && fb64[0].blocks[0].title === "Аэрогриль 4.5 л"
      && fb64[0].blocks[0].text.content[0] === "Первый абзац."
      && fb64[1].blocks[0].text.content[0] === "Второй абзац.", JSON.stringify(fb64.map((w) => w.blocks[0].text.content[0])));
  check("兜底排版：没有描述或没有图片时返回空串",
    buildRichContentFallback([{ url: "https://x/1.jpg" }], "") === ""
      && buildRichContentFallback([], "Первый абзац.") === "", "");

  // ⑥ 提示词：模型只写文字，图片地址不经过模型；俄语硬约束
  const rcMsgs64 = buildRichContentMessages(
    { platform: "1688", ru: { title: "Аэрогриль", productType: "Аэрогриль", description: "Компактный" } },
    [{ url: "https://x/1.jpg" }, { url: "https://x/2.jpg" }],
  );
  check("富内容提示词：明令只写俄语、禁止中文",
    /ТОЛЬКО на русском языке/.test(RICH_CONTENT_SYSTEM_PROMPT) && /запрещен\S* китайск/i.test(RICH_CONTENT_SYSTEM_PROMPT), "");
  check("富内容提示词：把图片清单发给模型，并要求「一图一块、顺序一致」",
    rcMsgs64[1].content.includes("https://x/1.jpg") && rcMsgs64[1].content.includes("https://x/2.jpg")
      && rcMsgs64[1].content.includes("ровно 2"), "");

  // ⑦ 解析：混进中文的图块丢掉；全丢光返回 null（面板据此降级）
  const rcPlan64 = parseRichContentPlanResult('{"blocks":[{"title":"Компактный корпус","text":"Занимает мало места."},{"title":"中文标题","text":"bad"}]}');
  check("富内容方案解析：混进中文的图块整条丢掉",
    rcPlan64 && rcPlan64.blocks.length === 1 && rcPlan64.blocks[0].title === "Компактный корпус", JSON.stringify(rcPlan64));
  check("富内容方案解析：全丢光 / 非法 JSON 都返回 null",
    parseRichContentPlanResult('{"blocks":[{"title":"中文","text":"中文"}]}') === null
      && parseRichContentPlanResult("{oops") === null, "");

  // ⑧ 属性填写提示词：喂够俄文线索 + 采集诊断，且不把 11254 交给模型
  const attrPayload64 = buildAttributeMessages(
    {
      platform: "1688",
      title: "空气炸锅",
      ru: { productType: "Аэрогриль", usage: "для кухни", title: "Аэрогриль", description: "Компактный аэрогриль", shortDescription: "быстро" },
      diagnostics: { notes: ["运费未取到"] },
    },
    [{ id: RICH_CONTENT_ATTR_ID, name: "JSON富内容" }, { id: 85, name: "Бренд", is_required: true }],
  )[1].content;
  check("属性提示词：带上已定稿的俄文品类 / 用途 / 标题 / 描述",
    attrPayload64.includes("Аэрогриль") && attrPayload64.includes("для кухни") && attrPayload64.includes("Компактный аэрогриль"), "");
  check("属性提示词：带上采集诊断（告诉模型哪些字段本来就没采到）",
    attrPayload64.includes("运费未取到"), "");
  check("属性提示词：JSON 富内容(11254) 不交给模型（它由富内容区单独生成）",
    !attrPayload64.includes(String(RICH_CONTENT_ATTR_ID)) && attrPayload64.includes("85 | Бренд"), "");
  check("属性提示词：明确要求「能推出来就填满」",
    /МАКСИМАЛЬНО ПОЛНО/.test(attrPayload64), "");
  const catPayload64 = buildCategoryPickMessages(
    { platform: "1688", title: "空气炸锅", ru: { description: "Компактный аэрогриль", usage: "для кухни" } },
    [{ node: { description_category_id: 1, type_id: 2 }, path: ["A", "B"] }],
  )[1].content;
  check("类目匹配提示词：补上俄文描述 / 用途",
    catPayload64.includes("Компактный аэрогриль") && catPayload64.includes("для кухни"), "");

  // ⑨ 面板接线：11254 移出属性表、富内容区在详细描述之后、品牌默认无品牌
  const panelSrc64 = fs.readFileSync(path.join(HERE, "../src/ui/panel.js"), "utf8").replace(/\r\n/g, "\n");
  const htmlSrc64 = fs.readFileSync(path.join(HERE, "../src/ui/panel.html"), "utf8").replace(/\r\n/g, "\n");
  check("面板：属性表渲染时把 11254 富内容过滤掉",
    /\.filter\(\(attr\) => String\(attr\.id\) !== String\(RICH_CONTENT_ATTR_ID\)\)/.test(panelSrc64), "");
  check("面板：富内容区在 HTML 里排在「详细描述」之后",
    htmlSrc64.indexOf('id="ru-desc"') > -1 && htmlSrc64.indexOf('id="rich-content"') > htmlSrc64.indexOf('id="ru-desc"'), "");
  check("面板：AI 生成 / 按描述排版 / 清空 三个入口都接上了",
    /generateRichContent\(\{ useAi: true \}\)/.test(panelSrc64) && /generateRichContent\(\{ useAi: false \}\)/.test(panelSrc64)
      && /saveRichContent\(""\)/.test(panelSrc64), "");
  check("面板：保存文案时一并写回富内容",
    /await saveRichContent\(richText\)/.test(panelSrc64), "");
  check("面板：品牌字段下方有小字说明",
    /BRAND_DEFAULT_NOTE/.test(panelSrc64) && /attr-brand-note/.test(panelSrc64), "");
  check("面板：品牌属性为空时自动填「无品牌」，且只补空值",
    /applyBrandDefault/.test(panelSrc64) && /onlyEmpty: true/.test(panelSrc64)
      && /const empty = brandAttributeState\(\)\.filter\(\(item\) => !item\.value\)/.test(panelSrc64), "");
  check("面板：一键填「无品牌」支持 silent / onlyEmpty（自动调用不弹窗、不覆盖具体品牌）",
    /async function fillNoBrandAttributes\(\{ silent = false, onlyEmpty = false \} = \{\}\)/.test(panelSrc64)
      && /const realTargets = onlyEmpty \? \[\] :/.test(panelSrc64), "");
  check("面板：AI 填属性前先补齐枚举候选值，填完还有必填空缺就补漏一轮",
    /await loadAttributeDictionaries\(state\.categoryAttributes, \{ onlyImportant: true \}\);\s*\n\s*\}\s*\n\s*\/\/ 先用 1688/.test(panelSrc64)
      && /async function aiFillMissingRequired\(/.test(panelSrc64), "");
  check("面板：模型硬塞的 11254 也会被丢掉",
    /delete values\[String\(RICH_CONTENT_ATTR_ID\)\];/.test(panelSrc64), "");

  // ⑩ 常量 / 后台 / 版本
  const constSrc64 = fs.readFileSync(path.join(HERE, "../src/shared/constants.js"), "utf8").replace(/\r\n/g, "\n");
  const swSrc64 = fs.readFileSync(path.join(HERE, "../src/background/service-worker.js"), "utf8").replace(/\r\n/g, "\n");
  const manifest64 = JSON.parse(fs.readFileSync(path.join(HERE, "../manifest.json"), "utf8"));
  check("常量：新增 aiRichContent action", /aiRichContent: "ai_rich_content"/.test(constSrc64), "");
  check("后台：aiRichContent 有独立 handler，且模型只写 blocks",
    /case MESSAGE_ACTIONS\.aiRichContent:/.test(swSrc64)
      && /async function buildRichContent\(message\)/.test(swSrc64)
      && /parseRichContentPlanResult\(content\)/.test(swSrc64), "");
  // 版本号断言放宽为「≥ 1.9.64」，后续小版本升级不用再回来改这一行
  const v64 = String(manifest64.version || "").split(".").map((n) => Number(n) || 0);
  check("版本号已升级到 1.9.64 及以上", v64[0] > 1 || (v64[1] === 9 && v64[2] >= 64), manifest64.version);
}

console.log("=== v1.9.65 类目树加载状态提示 + 完整类目树数据 ===");
{
  const htmlSrc65 = fs.readFileSync(path.join(HERE, "../src/ui/panel.html"), "utf8").replace(/\r\n/g, "\n");
  const panelSrc65 = fs.readFileSync(path.join(HERE, "../src/ui/panel.js"), "utf8").replace(/\r\n/g, "\n");
  const manifest65 = JSON.parse(fs.readFileSync(path.join(HERE, "../manifest.json"), "utf8"));

  // ① 状态承载元素
  check("面板：新增类目树状态条 #cat-tree-status",
    /<p class="hint" id="cat-tree-status">/.test(htmlSrc65), "");
  check("面板：状态条在按钮行之后、候选卡片之前",
    htmlSrc65.indexOf('id="cat-tree-status"') > htmlSrc65.indexOf('id="cat-search"')
    && htmlSrc65.indexOf('id="cat-tree-status"') < htmlSrc65.indexOf('id="cat-candidates"'), "");

  // ② 状态机
  check("面板：有 setCategoryTreeStatus（idle / loading / ready / error 四态）",
    /function setCategoryTreeStatus\(phase, text\)/.test(panelSrc65)
    && /phase === "loading" \? "hint warn-text"/.test(panelSrc65)
    && /phase === "ready" \? "hint ok-text"/.test(panelSrc65)
    && /phase === "error" \? "hint danger-text"/.test(panelSrc65), "");
  check("面板：有「加载中…」文案",
    /加载中…（正在解析完整类目树，请稍候）/.test(panelSrc65), "");
  check("面板：有「加载完成」文案（含规模 · 来源 · 耗时）",
    /加载完成：\$\{categoryTreeSummary\(stats\)\} · 来源：\$\{categoryTreeSourceLabel\(\)\} · 耗时 \$\{Date\.now\(\) - startedAt\}ms/.test(panelSrc65), "");
  check("面板：加载失败给可操作原因（提示点「拉取类目树」重试）",
    /加载失败：没有读到任何类目。请检查网络后点「拉取类目树」重试。/.test(panelSrc65)
    && /加载失败：\$\{error\?\.message \|\| "未知错误"\}。点「拉取类目树」可重试。/.test(panelSrc65), "");

  // ③ 规模统计与来源标注
  check("面板：countCategoryTree 统计顶层域 / 类目 / 末级类型 / 待同步",
    /function countCategoryTree\(tree\)/.test(panelSrc65)
    && /return \{ domains, categories, types, pending, usable: types - pending \};/.test(panelSrc65), "");
  check("面板：categoryTreeSummary 输出「N 个顶层域 / N 个类目 / N 个末级类型」",
    /个顶层域 \/ \$\{stats\.categories\} 个类目 \/ \$\{stats\.types\} 个末级类型/.test(panelSrc65), "");
  check("面板：三种类目树来源都有中文标注（本地完整树 / 缓存 / Ozon API）",
    /local: "本地完整类目树（Ozon 官方 XLS 模板）"/.test(panelSrc65)
    && /cache: "本地缓存（历史 Ozon API 拉取）"/.test(panelSrc65)
    && /api: "Ozon API 实时拉取"/.test(panelSrc65), "");
  check("面板：ensureCategoryTree 逐级记录来源 local → cache → api",
    /state\.categoryTreeSource = "local";/.test(panelSrc65)
    && /state\.categoryTreeSource = "cache";/.test(panelSrc65)
    && /state\.categoryTreeSource = "api";/.test(panelSrc65), "");

  // ④ 接线：三处入口都走带状态的加载
  check("面板：loadCategoryTreeWithStatus 统一封装「加载中 → 加载完成」",
    /async function loadCategoryTreeWithStatus\(\{ force = false, label = "类目树" \} = \{\}\)/.test(panelSrc65)
    && /setCategoryTreeStatus\("loading"/.test(panelSrc65)
    && /setCategoryTreeStatus\("ready"/.test(panelSrc65), "");
  check("面板：「拉取类目树」按钮改走带状态加载（force = true）",
    /const tree = await loadCategoryTreeWithStatus\(\{ force: true, label: "类目树" \}\);/.test(panelSrc65), "");
  check("面板：载入草稿时首次加载类目树也走状态提示",
    /const tree = state\.categoryTree\?\.length\s*\n\s*\? await ensureCategoryTree\(\)\s*\n\s*: await loadCategoryTreeWithStatus\(\{ label: "类目树" \}\);/.test(panelSrc65), "");

  // ⑤ AI 匹配用完整树
  check("面板：AI 匹配前先带状态加载完整类目树",
    /const tree = await loadCategoryTreeWithStatus\(\{ label: "AI 匹配用的类目树" \}\);/.test(panelSrc65), "");
  check("面板：候选池只保留带 type_id 的末级类型（无 ID 的不参与匹配）",
    /const allLeaves = flattenCategoryLeaves\(tree\);/.test(panelSrc65)
    && /const leaves = allLeaves\.filter\(\(item\) => Number\(item\.node\?\.type_id\) > 0\);/.test(panelSrc65), "");
  check("面板：匹配完成后把「从 N 个可上传类型筛出 M 个候选」写回状态条",
    /已从 \$\{leaves\.length\} 个可上传类型里筛出 \$\{candidates\.length\} 个候选/.test(panelSrc65), "");
  check("面板：没匹配上时状态条也切到「加载完成」并提示手动选择",
    /本次 AI 匹配没有找到足够贴近的候选，请手动展开类目树选择/.test(panelSrc65), "");
  check("面板：候选卡片不再因 type_id 为 0 被静默吞掉（pickCategoryCandidate 保留早退保护）",
    /if \(!categoryId \|\| !typeId\) return;/.test(panelSrc65), "");

  // ⑥ 叶子路径带上顶层域（真实三级结构）
  const flatStart = panelSrc65.indexOf("function flattenCategoryLeaves");
  const flatEnd = panelSrc65.indexOf("\nfunction ", flatStart + 10);
  const flatten = new Function(`${panelSrc65.slice(flatStart, flatEnd)}; return flattenCategoryLeaves;`)();
  const sampleTree = [{
    category_name: "家用电器",
    children: [{
      title: "慢炖锅、面包机、空气烤架",
      description_category_id: 17039629,
      children: [{ title: "空气炸锅", type_id: 94726, description_category_id: 17039629 }],
    }],
  }];
  const flatLeaves = flatten(sampleTree);
  check("面板：flattenCategoryLeaves 把顶层域带进路径（与界面 pathText 口径一致）",
    flatLeaves.length === 1
    && flatLeaves[0].path.join(" / ") === "家用电器 / 慢炖锅、面包机、空气烤架 / 空气炸锅",
    JSON.stringify(flatLeaves[0]?.path));

  const domSetSrc = panelSrc65.slice(
    panelSrc65.indexOf("const CATEGORY_TREE_TOP_DOMAINS"),
    panelSrc65.indexOf("const GENERIC_PATH_SEGMENT_RE"),
  );
  const topDomains = new Function(`${domSetSrc}; return CATEGORY_TREE_TOP_DOMAINS;`)();
  check("面板：内置 Ozon 官方 26 个顶层域（供打分降权）",
    topDomains.size === 26 && topDomains.has("家用电器") && topDomains.has("电影、音乐、视频游戏、软件"),
    String(topDomains.size));
  check("面板：scoreCategoryLeaf 对顶层域只给 1 分、且不计入 2-gram 命中",
    /GENERIC_PATH_SEGMENT_RE\.test\(seg\) \|\| CATEGORY_TREE_TOP_DOMAINS\.has\(seg\)/.test(panelSrc65)
    && /const leafPath = path\.filter\(\(seg\) => !CATEGORY_TREE_TOP_DOMAINS\.has\(seg\)\)\.join\(""\)\.toLowerCase\(\);/.test(panelSrc65), "");

  // ⑦ 版本号
  // 版本号断言放宽为「≥ 1.9.65」，后续小版本升级不用再回来改这一行
  check("版本号升到 1.9.65 及以上",
    manifest65.version.split(".").map(Number)[0] > 1
    || (manifest65.version.split(".").map(Number)[1] === 9 && manifest65.version.split(".").map(Number)[2] >= 65),
    manifest65.version);
}

console.log("=== v1.9.66 类目匹配：产品标题 + 产品外观图片 双通道，且只在类目树内选 ===");
{
  const promptsSrc66 = fs.readFileSync(path.join(HERE, "../src/shared/prompts.js"), "utf8").replace(/\r\n/g, "\n");
  const panelSrc66 = fs.readFileSync(path.join(HERE, "../src/ui/panel.js"), "utf8").replace(/\r\n/g, "\n");
  const swSrc66 = fs.readFileSync(path.join(HERE, "../src/background/service-worker.js"), "utf8").replace(/\r\n/g, "\n");
  const constantsSrc66 = fs.readFileSync(path.join(HERE, "../src/shared/constants.js"), "utf8").replace(/\r\n/g, "\n");
  const manifest66 = JSON.parse(fs.readFileSync(path.join(HERE, "../manifest.json"), "utf8"));

  // ① 系统提示词：双通道 + 只能在树内选 + 不许编造
  check("提示词：新增 CATEGORY_TREE_MATCH_SYSTEM_PROMPT",
    /export const CATEGORY_TREE_MATCH_SYSTEM_PROMPT = \[/.test(promptsSrc66), "");
  check("提示词：明令「同时依据标题与外观图片」两路信息",
    /必须【同时】依据两路信息判断商品是什么/.test(promptsSrc66)
    && /产品标题名称与文字描述/.test(promptsSrc66)
    && /产品外观图片里看到的实物/.test(promptsSrc66), "");
  check("提示词：明令「只能在清单范围内选，不许编造 ID」",
    /只能在给出的清单范围内选择/.test(promptsSrc66)
    && /绝对不允许自己编造类目名称、类目 ID 或类型 ID/.test(promptsSrc66), "");
  check("提示词：图片与标题冲突时以图片实物为准",
    /以图片中的实物为准/.test(promptsSrc66), "");
  check("提示词：没有合适项时返回 -1、confidence=0，不许硬选",
    /把行号返回 -1、confidence 返回 0/.test(promptsSrc66), "");

  // ② 行号索引 + 两阶段提示词
  check("提示词：buildCategoryTreeIndex 建 D/C/T 行号索引",
    /export function buildCategoryTreeIndex\(tree\)/.test(promptsSrc66)
    && /byCategoryLine\.set\(category\.key, category\)/.test(promptsSrc66), "");
  check("提示词：阶段 1 只给「域 + 类目」，阶段 2 才给「类型」",
    /export function renderCategoryTreeDomainList\(index\)/.test(promptsSrc66)
    && /export function renderCategoryTypeList\(category\)/.test(promptsSrc66)
    && /export function buildCategoryTreeDomainMessages\(product, tree, \{ imageDataUrls = \[\] \} = \{\}\)/.test(promptsSrc66)
    && /export function buildCategoryTreeTypeMessages\(product, domainPick, \{ imageDataUrls = \[\] \} = \{\}\)/.test(promptsSrc66), "");
  check("提示词：多模态 content 是 [{type:text}, ...image_url]",
    /export function categoryImageParts\(imageDataUrls = \[\]\)/.test(promptsSrc66)
    && /\{ type: "image_url", image_url: \{ url \} \}/.test(promptsSrc66)
    && /content: images\.length \? \[\{ type: "text", text \}, \.\.\.images\] : text/.test(promptsSrc66), "");
  check("提示词：无图时自动降级为纯文字（并在 reason 里注明「无图」）",
    /本次没有取到可用的商品图片，只能依据文字信息判断，请在 reason 里注明「无图」。/.test(promptsSrc66), "");

  // ③ 解析：行号必须回查到真实节点
  check("解析：阶段 1 行号越界 / 非 JSON / -1 全部判失败",
    /export function parseCategoryTreeDomainResult\(text, tree\)/.test(promptsSrc66)
    && /if \(!Number\.isInteger\(d\) \|\| !Number\.isInteger\(c\) \|\| d < 1 \|\| c < 1\) return null;/.test(promptsSrc66)
    && /const domain = index\.byDomainLine\.get\(d\);\s*\n\s*if \(!domain\) return null;/.test(promptsSrc66)
    && /const category = index\.byCategoryLine\.get\(`\$\{d\}\.\$\{c\}`\);\s*\n\s*if \(!category \|\| !category\.categoryId\) return null;/.test(promptsSrc66), "");
  check("解析：阶段 2 类型行号必须落在该类目的类型清单内",
    /export function parseCategoryTreeTypeResult\(text, category\)/.test(promptsSrc66)
    && /if \(!Number\.isInteger\(t\) \|\| t < 1 \|\| t > types\.length\) return null;/.test(promptsSrc66), "");
  check("解析：composeCategoryTreeMatch 从真实节点取 categoryId / typeId",
    /export function composeCategoryTreeMatch\(domainPick, typePick, \{ imageCount = 0 \} = \{\}\)/.test(promptsSrc66)
    && /const categoryId = Number\(domainPick\?\.category\?\.categoryId\) \|\| 0;/.test(promptsSrc66)
    && /const typeId = Number\(typePick\?\.type\?\.typeId\) \|\| 0;/.test(promptsSrc66)
    && /if \(!categoryId \|\| !typeId\) return null;/.test(promptsSrc66), "");

  // ④ 后台：自己加载完整树 + 两阶段调用 + action 接线
  check("后台：类目树走顶层静态 import（v1.9.78 修复：SW 禁用动态 import()）",
    /function loadCategoryTreeBundle\(\)/.test(swSrc66)
    && /import \{ OZON_CATEGORY_TREE_BUNDLE \} from "\.\.\/\.\.\/assets\/ozon-category-tree\.js"/.test(swSrc66)
    && !/import\("\.\.\/\.\.\/assets\/ozon-category-tree/.test(swSrc66), "");
  check("后台：matchCategoryTree 走两阶段（先域+类目，再类型）",
    /async function matchCategoryTree\(message\)/.test(swSrc66)
    && /buildCategoryTreeDomainMessages\(product, tree, \{ imageDataUrls \}\)/.test(swSrc66)
    && /buildCategoryTreeTypeMessages\(product, domainPick, \{ imageDataUrls: imageUsed \? imageDataUrls : \[\] \}\)/.test(swSrc66), "");
  check("后台：该类目只有一个类型时跳过阶段 2",
    /if \(category\.types\.length === 1\) \{/.test(swSrc66)
    && /该类目下只有一个可上传类型/.test(swSrc66), "");
  check("后台：AI 选不出来就返回 ok:false（不静默选错）",
    /AI 没有在类目树范围内选出可用的域与类目/.test(swSrc66)
    && /AI 没有在「\$\{category\.name\}」下选出可用的类型/.test(swSrc66), "");
  check("后台：带图被服务端拒掉时自动退回纯文字重试（纯文本模型也能用）",
    /let imageUsed = imageDataUrls\.length > 0;/.test(swSrc66)
    && /if \(!imageUsed\) throw error;/.test(swSrc66)
    && /imageUsed = false;/.test(swSrc66)
    && /filter\(\(part\) => part\.type === "text"\)\.map\(\(part\) => part\.text\)\.join\("\\n"\)/.test(swSrc66), "");
  check("后台：如实回报 imageUsed（面板据此说明本次依据）",
    /return \{ ok: true, data: \{[\s\S]*\.\.\.data,[\s\S]*imageUsed,[\s\S]*visionModel: credentials\.model/.test(swSrc66)
    && /imageCount: imageUsed \? imageDataUrls\.length : 0/.test(swSrc66), "");
  check("面板：模型不支持图片时明确提示换模型，且不谎报「已结合图片」",
    /aiMatch\?\.imageUsed === false/.test(panelSrc66)
    && /当前 AI 模型不支持图片输入，本次只按产品标题匹配/.test(panelSrc66)
    && /imageGuided: images\.length > 0 && aiMatch\.imageUsed !== false,/.test(panelSrc66), "");
  check("常量：新增 aiMatchCategoryTree action",
    /aiMatchCategoryTree: "ai_match_category_tree"/.test(constantsSrc66)
    && /case MESSAGE_ACTIONS\.aiMatchCategoryTree:\s*\n\s*return matchCategoryTree\(message\);/.test(swSrc66), "");

  // ⑤ 面板：取图 → 压缩 → 多模态调用 → 严格校验 → 候选卡片
  check("面板：collectCategoryMatchImages 取主图+图集、最多 3 张",
    /const CATEGORY_MATCH_IMAGE_LIMIT = 3;/.test(panelSrc66)
    && /async function collectCategoryMatchImages\(draft\)/.test(panelSrc66)
    && /urls\.slice\(0, CATEGORY_MATCH_IMAGE_LIMIT\)/.test(panelSrc66), "");
  check("面板：图片压到 800px JPEG，本来就小的不重编码",
    /function shrinkImageDataUrl\(dataUrl, maxSide = 800, quality = 0\.8\)/.test(panelSrc66)
    && /canvas\.toDataURL\("image\/jpeg", quality\)/.test(panelSrc66)
    && /if \(scale >= 1 && dataUrl\.length < 300000\) return done\(dataUrl\);/.test(panelSrc66), "");
  check("面板：单张取图失败静默跳过（不阻断匹配）",
    /单张失败不影响其它图，也不影响文字匹配/.test(panelSrc66)
    && /取不到时匹配自动降级为「仅按标题文字」/.test(panelSrc66), "");
  check("面板：匹配时把图片与商品一起发给 aiMatchCategoryTree",
    /action: MESSAGE_ACTIONS\.aiMatchCategoryTree/.test(panelSrc66)
    && /imageDataUrls: images,/.test(panelSrc66), "");
  check("面板：AI 结果放候选第一位，标题文字兜底作为备选",
    /aiSelected: true/.test(panelSrc66)
    && /imageGuided: images\.length > 0/.test(panelSrc66)
    && /标题文字兜底（AI 未给出可用结果/.test(panelSrc66)
    && /confidence: Math\.min\(55, normalizeMatchScore/.test(panelSrc66), "");
  check("面板：状态行写明用了哪条通道",
    /AI 在完整类目树内选类目（依据：产品标题/.test(panelSrc66)
    && /张外观图片/.test(panelSrc66)
    && /本次未取到外观图/.test(panelSrc66), "");
  check("面板：候选卡片标注「已结合产品外观图片」",
    /（已结合产品外观图片）/.test(panelSrc66), "");

  // ⑥ 用真实类目树跑一遍行号索引与回查
  const treeMod66 = await import(pathToFileURL(path.join(HERE, "../assets/ozon-category-tree.js")).href);
  const tree66 = (treeMod66.OZON_CATEGORY_TREE_BUNDLE || treeMod66.default).tree;
  const index66 = buildCategoryTreeIndex(tree66);
  const cats66 = index66.domains.reduce((sum, d) => sum + d.categories.length, 0);
  const types66 = index66.domains.reduce((sum, d) => sum + d.categories.reduce((s, c) => s + c.types.length, 0), 0);
  check("真实树：行号索引覆盖 26 域 / 542 类目 / 8600 类型",
    index66.domains.length === 26 && cats66 === 542 && types66 === 8600,
    `${index66.domains.length}/${cats66}/${types66}`);
  check("真实树：阶段 1 清单 = 26 域 + 542 类目 = 568 行，且不含类型行",
    renderCategoryTreeDomainList(index66).split("\n").length === 568
    && !/^\s*T\d/m.test(renderCategoryTreeDomainList(index66)), "");
  const sampleDomain66 = index66.domains.find((d) => d.categories.some((c) => c.types.length >= 5));
  const sampleCat66 = sampleDomain66.categories.find((c) => c.types.length >= 5);
  const parsedDomain66 = parseCategoryTreeDomainResult(
    `{"domain":${sampleDomain66.lineNo},"category":${sampleCat66.lineNo},"confidence":0.7,"reason":"x"}`, tree66);
  check("真实树：阶段 1 行号能回查到真实类目 ID",
    parsedDomain66?.category?.categoryId === sampleCat66.categoryId, String(parsedDomain66?.category?.categoryId));
  check("真实树：树外行号一律拒绝（AI 编不出来）",
    parseCategoryTreeDomainResult('{"domain":9999,"category":1}', tree66) === null
    && parseCategoryTreeDomainResult(`{"domain":${sampleDomain66.lineNo},"category":9999}`, tree66) === null
    && parseCategoryTreeTypeResult('{"type":9999}', sampleCat66) === null, "");
  const typePick66 = parseCategoryTreeTypeResult('{"type":2,"confidence":0.6,"reason":"y"}', sampleCat66);
  const composed66 = composeCategoryTreeMatch(
    { domain: sampleDomain66, category: sampleCat66, confidence: 0.5, reason: "a" },
    typePick66, { imageCount: 3 });
  check("真实树：合成结果的 ID 与路径都来自树内真实节点",
    composed66.categoryId === sampleCat66.categoryId
    && composed66.typeId === sampleCat66.types[1].typeId
    && composed66.path.join(" / ") === `${sampleDomain66.name} / ${sampleCat66.name} / ${sampleCat66.types[1].name}`,
    composed66.path.join(" / "));
  check("真实树：置信度 = 两阶段相乘，且 node 带全部三个 ID 字段",
    Math.abs(composed66.confidence - 0.3) < 1e-9
    && composed66.node.description_category_id === sampleCat66.categoryId
    && composed66.node.category_id === sampleCat66.categoryId
    && composed66.node.type_id === sampleCat66.types[1].typeId, String(composed66.confidence));

  // ⑦ 版本号
  check("版本号升到 1.9.66 及以上",
    manifest66.version.split(".").map(Number)[0] > 1
    || (manifest66.version.split(".").map(Number)[1] === 9 && manifest66.version.split(".").map(Number)[2] >= 66),
    manifest66.version);
}

console.log("=== v1.9.67 产品图采集：图集缩略图被「最长边<120px 当图标」规则误杀 ===");
{
  const baseSrc67 = fs.readFileSync(path.join(HERE, "../src/content/adapter-base.js"), "utf8").replace(/\r\n/g, "\n");
  const ali67 = fs.readFileSync(path.join(HERE, "../src/content/adapter-1688.js"), "utf8").replace(/\r\n/g, "\n");
  const tb67 = fs.readFileSync(path.join(HERE, "../src/content/adapter-taobao.js"), "utf8").replace(/\r\n/g, "\n");
  const pdd67 = fs.readFileSync(path.join(HERE, "../src/content/adapter-pdd.js"), "utf8").replace(/\r\n/g, "\n");
  const manifest67 = JSON.parse(fs.readFileSync(path.join(HERE, "../manifest.json"), "utf8"));

  /* ① 行为复现：新版 1688 图集只有 60×60 缩略图 <img>（主图位是 <video>），
        不带 allowSmall 时会被「最长边 < 120px 当图标丢掉」整批误杀 —— 这就是用户报的 bug。 */
  const thumbUrl = "https://cbu01.alicdn.com/img/ibank/O1CN01abc/xyz.jpg_60x60q90.jpg";
  const makeThumb = () => ({
    tagName: "IMG",
    src: thumbUrl,
    currentSrc: thumbUrl,
    naturalWidth: 60,
    naturalHeight: 60,
    complete: true,
    getAttribute: (name) => (name === "src" ? thumbUrl : null),
    closest: () => null,
    getBoundingClientRect: () => ({ width: 60, height: 60 }),
    querySelectorAll: () => [],
    shadowRoot: null,
  });
  const ctx67 = { console, setTimeout, clearTimeout, setInterval, clearInterval, performance };
  ctx67.window = ctx67;
  ctx67.location = { origin: "https://detail.1688.com" };
  ctx67.document = {
    querySelector: () => null,
    querySelectorAll: (selector) => (String(selector).includes("img") ? [makeThumb()] : []),
    documentElement: { innerHTML: "" },
    body: { innerText: "" },
  };
  vm.createContext(ctx67);
  vm.runInContext(baseSrc67, ctx67);
  const utils67 = ctx67.__OZON_ADAPTERS__.utils;

  const strict67 = utils67.collectImages({ origin: "https:", containers: [".detail-gallery"], noPageFallback: true });
  check("不带 allowSmall：60×60 图集缩略图被尺寸规则误杀（bug 复现）",
    strict67.images.length === 0, JSON.stringify(strict67.images));
  const loose67 = utils67.collectImages({ origin: "https:", containers: [".detail-gallery"], noPageFallback: true, allowSmall: true });
  check("带 allowSmall：同一张缩略图被收进来，且 URL 已升到原图",
    loose67.images.length === 1 && loose67.images[0] === "https://cbu01.alicdn.com/img/ibank/O1CN01abc/xyz.jpg",
    JSON.stringify(loose67.images));
  const byHost67 = utils67.collectImagesByHostPattern({
    pattern: /^https?:\/\/[^/]*(?:alicdn|alibaba|1688)\.com\/img\/ibank\//i,
    stopSelector: "#mod-detail-description",
    origin: "https:",
  });
  check("图床兜底：按 /img/ibank/ 路径也能捞到，且不做尺寸过滤",
    byHost67.images.length === 1, JSON.stringify(byHost67.images));
  const byHostMiss67 = utils67.collectImagesByHostPattern({ pattern: /^https?:\/\/example\.com\//, origin: "https:" });
  check("图床兜底：域名不匹配的一张都不收", byHostMiss67.images.length === 0, JSON.stringify(byHostMiss67.images));
  check("adapter-base：导出 collectImagesByHostPattern",
    /collectImagesByHostPattern,\n    collectImages,/.test(baseSrc67), "");
  check("adapter-base：计算样式兜底按「检查过的节点数」计预算（旧写法等于没预算）",
    /if \(scanned >= MAX_COMPUTED_BG_NODES\) break;\n            scanned \+= 1;/.test(baseSrc67), "");
  check("adapter-base：背景图扫描前先给容器去重",
    /const containerNodes = \[\];/.test(baseSrc67) && /for \(const node of containerNodes\) \{/.test(baseSrc67), "");

  /* ② 三个适配器：图集兜底层都必须开 allowSmall */
  check("1688：图集兜底层开了 allowSmall（核心修复）",
    /containers: GALLERY_FALLBACK_SELECTORS,[\s\S]{0,400}?allowSmall: true,/.test(ali67), "");
  check("淘宝：图集兜底层也开了 allowSmall",
    /containers: GALLERY_FALLBACK_SELECTORS,[\s\S]{0,400}?allowSmall: true,/.test(tb67), "");
  check("拼多多：图集兜底层也开了 allowSmall",
    /containers: GALLERY_FALLBACK_SELECTORS,\n\s*includeBackground: true,\n(?:\s*\/\/[^\n]*\n)*\s*allowSmall: true,/.test(pdd67), "");

  /* ③ 1688：新类名 + 图床兜底 + 分层诊断 + 轻扫顺序 */
  check("1688：图集选择器补上 turn / pic / media 系新类名",
    /\[class\*=galleryTurn\] img/.test(ali67)
    && /\.detail-gallery-turn-item img/.test(ali67)
    && /\[class\*=thumbItem\] img/.test(ali67)
    && /\[class\*=turn-thumb\] img/.test(ali67), "");
  check("1688：新增阿里图床路径常量 /img/ibank/",
    /const ALI_GALLERY_IMAGE_RE = /.test(ali67) && ali67.includes("/img/ibank/"), "");
  check("1688：新增「按图床路径 + 文档顺序」的最后一层兜底",
    /hostPicked = U\.collectImagesByHostPattern\(\{/.test(ali67)
    && /pattern: ALI_GALLERY_IMAGE_RE,/.test(ali67)
    && /stopSelector: DETAIL_IMAGE_SELECTORS\.join\(", "\),/.test(ali67), "");
  check("1688：详情长图也能按图床路径恢复",
    /insideSelector: DETAIL_IMAGE_SELECTORS\.join\(", "\),/.test(ali67), "");
  check("1688：pickImages 返回分层诊断 layers（哪一层失灵一眼可见）",
    /layers: \{\n\s*main: main\.images\.length,\n\s*thumbs: thumbs\.images\.length,/.test(ali67), "");
  check("1688：未识别时写明是哪一层失灵",
    /未识别到产品图（主图位 \$\{l\.main \|\| 0\} \/ 缩略图位 \$\{l\.thumbs \|\| 0\} \/ 图集兜底 \$\{l\.fallback \|\| 0\} \/ 图床兜底 \$\{l\.host \|\| 0\}）/.test(ali67), "");
  check("1688：轻扫改到抓图之前（懒加载图集不再被漏掉）",
    ali67.indexOf('cache.time("懒加载轻扫"') > 0
    && ali67.indexOf('cache.time("懒加载轻扫"') < ali67.indexOf('cache.time("图片"'), "");
  check("1688：轻扫加了总预算，不再被页面自己的 scroll 处理器拖到 5s+",
    /const budget = 3000;/.test(ali67) && /if \(Date\.now\(\) - startedAt > budget\) break;/.test(ali67), "");
  check("1688：等待就绪的选择器补上 turn / pic / swiper",
    /"\[class\*=turn\] img", "\[class\*=pic\] img", "\[class\*=swiper\] img"/.test(ali67), "");

  /* ④ 版本号 */
  check("版本号升到 1.9.67 及以上",
    manifest67.version.split(".").map(Number)[0] > 1
    || (manifest67.version.split(".").map(Number)[1] === 9 && manifest67.version.split(".").map(Number)[2] >= 67),
    manifest67.version);
}

console.log("=== v1.9.68 采集准确性：结果卡陈旧 / 首页误判为商品页 / 跨商品草稿污染 ===");
{
  const sw68 = fs.readFileSync(path.join(HERE, "../src/background/service-worker.js"), "utf8").replace(/\r\n/g, "\n");
  const panel68 = fs.readFileSync(path.join(HERE, "../src/ui/panel.js"), "utf8").replace(/\r\n/g, "\n");
  const html68 = fs.readFileSync(path.join(HERE, "../src/ui/panel.html"), "utf8").replace(/\r\n/g, "\n");
  const drafts68 = fs.readFileSync(path.join(HERE, "../src/ui/drafts.js"), "utf8").replace(/\r\n/g, "\n");
  const ali68 = fs.readFileSync(path.join(HERE, "../src/content/adapter-1688.js"), "utf8").replace(/\r\n/g, "\n");
  const manifest68 = JSON.parse(fs.readFileSync(path.join(HERE, "../manifest.json"), "utf8"));

  /* ① 商品身份键（行为测试）：同一件商品的不同 URL 写法必须归一到同一个键，
        不同商品必须不同 —— 这是「换了商品就新建草稿」的判据 */
  const sameA = productIdentity("https://detail.1688.com/offer/685447891234.html?spm=a26352.b2801");
  const sameB = productIdentity("https://detail.1688.com/offer/685447891234.html?from=detail&tracelog=xx");
  const other = productIdentity("https://detail.1688.com/offer/111111111111.html");
  check("身份键：同一 offer 的不同跟踪参数归一为同一个键", sameA === sameB && Boolean(sameA), `${sameA} / ${sameB}`);
  check("身份键：不同 offer 得到不同的键（换商品必须能识别出来）", sameA !== other, `${sameA} / ${other}`);
  check("身份键：淘宝按 id 归一，丢掉 spm",
    productIdentity("https://item.taobao.com/item.htm?id=123&spm=a1.b2") === "item.taobao.com/item.htm#123",
    productIdentity("https://item.taobao.com/item.htm?id=123&spm=a1.b2"));
  check("身份键：空 URL 返回空串（不会把两件未知商品误判成同一件）", productIdentity("") === "", "");

  /* ② 首页 / 搜索页不能再被当成商品页 */
  check("后台：新增 isProductPageUrl（域名匹配 ≠ 商品详情页）",
    /function isProductPageUrl\(url\) \{/.test(sw68), "");
  check("后台：1688 只认 /offer/<数字>",
    /domain: "1688\.com", test: \(u\) => \/\^\\\/offer\\\/\\d\+\/i\.test\(u\.pathname\)/.test(sw68), "");
  check("后台：淘宝/天猫要求 /item.htm 且带 id 参数",
    (sw68.match(/\/\^\\\/item\\\.htm\$\/i\.test\(u\.pathname\) && u\.searchParams\.has\("id"\)/g) || []).length === 2, "");
  check("后台：拼多多要求 /goods*.html 且带 goods_id",
    (sw68.match(/u\.searchParams\.has\("goods_id"\)/g) || []).length === 2, "");
  check("后台：标签页列表带 productPage 标记",
    /productPage: isProductPageUrl\(tab\.url\),/.test(sw68), "");
  check("后台：列表排序把商品详情页排在前面",
    /Number\(isProductPageUrl\(b\.url\)\) - Number\(isProductPageUrl\(a\.url\)\)/.test(sw68), "");
  check("后台：自动选目标时优先挑商品详情页（不再盲取第一个）",
    /return matched\.find\(\(tab\) => isProductPageUrl\(tab\.url\)\) \|\| matched\[0\] \|\| null;/.test(sw68), "");
  check("后台：自检报告里区分 matchedTabs 与 productTabs",
    /report\.productTabs = report\.allTabs\.filter\(\(tab\) => tab\.productPage\);/.test(sw68)
    && /没有一个是「商品详情页」/.test(sw68), "");

  /* ③ 采集结果必须带来源页，并且失败时卡片必须清空 */
  check("后台：采集结果写入 captureSource（tabId / url / 身份键 / 时间）",
    /product\.captureSource = \{/.test(sw68)
    && /identity: productIdentity\(tab\.url \|\| ""\),/.test(sw68)
    && /at: new Date\(\)\.toISOString\(\),/.test(sw68), "");
  check("面板：卡片新增来源行元素",
    /id="capture-source"/.test(html68), "");
  check("面板：卡片新增「本次没采」提示元素与列表说明元素",
    /id="capture-notice"/.test(html68) && /id="product-tabs-note"/.test(html68), "");
  check("面板：采集一开始就把卡片清成「采集中」（不可能再残留上一件商品）",
    /async function doCapture\(tabId\) \{[\s\S]{0,600}?beginCaptureCard\(targetLabel\);/.test(panel68)
    && /function beginCaptureCard\(targetLabel\) \{/.test(panel68)
    && /\.textContent = "采集中…";/.test(panel68), "");
  check("面板：采集失败时卡片显示失败态（不保留旧数据）",
    /async function doCapture\(tabId\) \{[\s\S]*?catch \(error\) \{[\s\S]{0,400}?renderCaptureFailure\(targetLabel, error\);/.test(panel68)
    && /function renderCaptureFailure\(targetLabel, error\) \{/.test(panel68)
    && /本次采集失败，没有拿到任何商品数据/.test(panel68), "");
  check("面板：来源行写明来源页与采集时间，来源页不在时给警告",
    /来源页：\$\{shortUrl\(src\.url\)\}/.test(panel68)
    && /该来源页已关闭或已跳转/.test(panel68), "");
  check("面板：多个商品页时明确说「本次没有采集任何页面」（不再静默）",
    /本次没有采集任何页面/.test(panel68)
    && /setCaptureNotice\(message\);/.test(panel68), "");
  check("面板：检测不到商品详情页时明确报错，不会去采首页",
    /但没有一个是商品详情页/.test(panel68), "");
  check("面板：非详情页行标出「非商品详情页」并改成「仍要采集」",
    /非商品详情页/.test(panel68) && /仍要采集/.test(panel68), "");

  /* ④ 跨商品草稿污染 */
  check("面板：草稿按商品身份键隔离（换商品必然新建草稿）",
    /async function syncDraftWithCapture\(data\) \{/.test(panel68)
    && /const sameProduct = Boolean\(state\.draft\) && Boolean\(identity\) && identity === draftIdentity;/.test(panel68)
    && /if \(!sameProduct\) \{/.test(panel68), "");
  check("面板：切换商品时明确提示「上一份草稿原样保留」",
    /这是另一件商品，已新建草稿；上一份草稿原样保留/.test(panel68), "");
  check("草稿：写入 sourceIdentity，供下次比对",
    /sourceIdentity: product\.captureSource\?\.identity \|\| "",/.test(drafts68), "");

  /* ⑤ 顺带修的两个「未识别」字段：老版类名 → 新版类名 + 结构兜底 */
  check("1688：pickShop 补驼峰类名并加「进店链接 / 公司名容器」两层结构兜底",
    /\[class\*=shopName\]/.test(ali68)
    && /\[class\*=supplierName\]/.test(ali68)
    && /a\[href\*="winport"\]/.test(ali68)
    && /looksLikeCompanyName\(head\) \|\| U\.looksLikeShopName\(head\)/.test(ali68), "");
  check("1688：pickAttributes 补 attribute / param / property / specification 容器",
    /\[class\*=attribute\]/.test(ali68)
    && /\[class\*=param\]/.test(ali68)
    && /\[class\*=property\]/.test(ali68)
    && /\[class\*=specification\]/.test(ali68), "");
  check("1688：属性文本兜底的区块标题扩到规格/技术/基本参数等",
    /产品参数\|商品参数\|规格参数\|技术参数\|基本参数\|详细参数\|参数信息\|产品属性\|商品属性/.test(ali68), "");
  check("1688：pickSales 补 saleCount / soldCount / tradeCount 等新类名",
    /\[class\*=saleCount\]/.test(ali68) && /\[class\*=tradeCount\]/.test(ali68), "");

  /* ⑥ 版本号 */
  check("版本号升到 1.9.68 及以上",
    manifest68.version.split(".").map(Number)[0] > 1
    || (manifest68.version.split(".").map(Number)[1] === 9 && manifest68.version.split(".").map(Number)[2] >= 68),
    manifest68.version);
}

console.log("=== v1.9.69 商品主体区：全页扫描会把「页面里别的商品」当成当前商品 ===");
{
  const baseSrc69 = fs.readFileSync(path.join(HERE, "../src/content/adapter-base.js"), "utf8").replace(/\r\n/g, "\n");
  const ali69 = fs.readFileSync(path.join(HERE, "../src/content/adapter-1688.js"), "utf8").replace(/\r\n/g, "\n");
  const tb69 = fs.readFileSync(path.join(HERE, "../src/content/adapter-taobao.js"), "utf8").replace(/\r\n/g, "\n");
  const pdd69 = fs.readFileSync(path.join(HERE, "../src/content/adapter-pdd.js"), "utf8").replace(/\r\n/g, "\n");
  const manifest69 = JSON.parse(fs.readFileSync(path.join(HERE, "../manifest.json"), "utf8"));

  /* ---------- 迷你 DOM + CSS 选择器匹配器（够用即可：tag / .class / #id / [attr op v] / 逗号 / 后代） ---------- */
  const parseCompound = (token) => {
    const out = { tag: "", classes: [], id: "", attrs: [] };
    const re = /(^[a-zA-Z][\w-]*)|\.([\w-]+)|#([\w-]+)|\[([\w-]+)(?:([*^$~|]?=)\s*"?([^\]"]*?)"?\s*(i)?)?\]/g;
    let m;
    while ((m = re.exec(token))) {
      if (m[1]) out.tag = m[1].toUpperCase();
      else if (m[2]) out.classes.push(m[2]);
      else if (m[3]) out.id = m[3];
      else if (m[4]) out.attrs.push({ name: m[4], op: m[5] || "", value: m[6] || "", ci: Boolean(m[7]) });
    }
    return out;
  };
  const matchesCompound = (node, c) => {
    if (!node || !node.tagName) return false;
    if (c.tag && node.tagName !== c.tag) return false;
    if (c.id && node.id !== c.id) return false;
    const classes = String(node.className || "").split(/\s+/).filter(Boolean);
    for (const cls of c.classes) if (!classes.includes(cls)) return false;
    for (const a of c.attrs) {
      const raw = node.getAttribute(a.name);
      if (raw == null) return false;
      let v = String(raw);
      let want = a.value;
      if (a.ci) { v = v.toLowerCase(); want = want.toLowerCase(); }
      if (!a.op) continue;
      if (a.op === "*=" && v.indexOf(want) < 0) return false;
      if (a.op === "=" && v !== want) return false;
      if (a.op === "^=" && v.indexOf(want) !== 0) return false;
      if (a.op === "$=" && v.slice(-want.length) !== want) return false;
    }
    return true;
  };
  const matchChain = (node, parts) => {
    let cur = node;
    for (let i = parts.length - 1; i >= 0; i -= 1) {
      if (i === parts.length - 1) {
        if (!matchesCompound(cur, parts[i])) return false;
      } else {
        let p = cur.parentElement;
        let found = null;
        while (p) {
          if (matchesCompound(p, parts[i])) { found = p; break; }
          p = p.parentElement;
        }
        if (!found) return false;
        cur = found;
      }
    }
    return true;
  };
  const descendants = (root) => {
    const out = [];
    const walk = (node) => { for (const child of node.children || []) { out.push(child); walk(child); } };
    walk(root);
    return out;
  };
  const selectAll = (root, selector) => {
    const groups = String(selector).split(",").map((g) => g.trim()).filter(Boolean)
      .map((g) => g.split(/\s+/).filter(Boolean).map(parseCompound));
    const out = [];
    for (const node of descendants(root)) {
      if (groups.some((parts) => matchChain(node, parts))) out.push(node);
    }
    return out;
  };
  const matchesSelector = (node, selector) => {
    const groups = String(selector).split(",").map((g) => g.trim()).filter(Boolean)
      .map((g) => g.split(/\s+/).filter(Boolean).map(parseCompound));
    return groups.some((parts) => matchChain(node, parts));
  };

  const makeNode = (tag, opts = {}) => {
    const node = {
      tagName: String(tag).toUpperCase(),
      className: opts.className || "",
      id: opts.id || "",
      attrs: Object.assign({}, opts.attrs),
      text: opts.text || "",
      children: [],
      parentElement: null,
      get textContent() {
        return [this.text].concat(this.children.map((c) => c.textContent)).filter(Boolean).join(" ");
      },
      get innerText() { return this.textContent; },
      getAttribute(name) {
        // 选择器里的 [class*=x] / #id 都要走 getAttribute，桩里必须把 className/id 也映射进来
        if (name === "class") return this.className || null;
        if (name === "id") return this.id || null;
        return name in this.attrs ? this.attrs[name] : null;
      },
      contains(other) { let p = other; while (p) { if (p === this) return true; p = p.parentElement; } return false; },
      closest(selector) { let p = this; while (p) { if (matchesSelector(p, selector)) return p; p = p.parentElement; } return null; },
      querySelectorAll(selector) { return selectAll(this, selector); },
      querySelector(selector) { return this.querySelectorAll(selector)[0] || null; },
      appendChild(child) { child.parentElement = this; this.children.push(child); return child; },
    };
    return node;
  };
  const add = (parent, tag, opts) => parent.appendChild(makeNode(tag, opts));

  /* ---------- 构造一个「详情页」：推荐位里是别的商品，主体区里才是当前商品 ---------- */
  const buildDom = () => {
    const body = makeNode("body");
    body.parentElement = null;

    // 推荐位 / 猜你喜欢：另一件商品（电动牙刷）
    const rec = add(body, "div", { className: "recommend-module" });
    add(rec, "h1", { text: "家用电动牙刷成人软毛牙刷清洁刷超声波洁牙护牙器厂家批发会员礼品" });
    add(rec, "div", { className: "price", text: "¥9.9" });
    add(rec, "div", { text: "成交 9999 件" });

    // 商品主体区：当前这件商品（空气炸锅）
    const main = add(body, "div", { className: "detail-content" });
    add(main, "h1", { text: "空气炸锅多功能电炸锅智能电烤箱家用大容量面包机早餐机" });
    add(main, "div", { className: "price", text: "¥88.00" });
    add(main, "div", { text: "成交 12 件 库存 500" });

    return { body, rec, main };
  };

  const runBase = (dom) => {
    const ctx = { console, setTimeout, clearTimeout, setInterval, clearInterval, performance };
    ctx.window = ctx;
    ctx.location = { origin: "https://detail.1688.com", href: "https://detail.1688.com/offer/123.html" };
    ctx.document = {
      title: "空气炸锅多功能电炸锅智能电烤箱家用大容量面包机早餐机 - 阿里巴巴",
      body: dom.body,
      documentElement: dom.body,
      querySelector: (s) => dom.body.querySelector(s),
      querySelectorAll: (s) => dom.body.querySelectorAll(s),
    };
    vm.createContext(ctx);
    vm.runInContext(baseSrc69, ctx);
    return ctx.__OZON_ADAPTERS__.utils;
  };

  const dom69 = buildDom();
  const U69 = runBase(dom69);

  /* ① 权威标题：必须来自 og:title / document.title，而不是推荐位里的 h1 */
  const authoritative69 = U69.authoritativeTitle();
  check("权威标题取 document.title（去掉「- 阿里巴巴」站点后缀）",
    authoritative69 === "空气炸锅多功能电炸锅智能电烤箱家用大容量面包机早餐机",
    authoritative69);

  /* ② 商品主体区定位：锚点 = 权威标题节点 + 向上最近的含 ¥ 祖先 */
  const scope69 = U69.resolveProductScope();
  check("主体区定位到商品主信息区（不是 body，也不是推荐位）",
    scope69 === dom69.main, scope69 === dom69.main ? ".detail-content" : String(scope69 && scope69.className));

  /* ③ 主体区文本：不含推荐位里别的商品的任何信息 */
  const scoped69 = U69.scopeTextOf(scope69);
  check("主体区文本含本商品信息（成交 12 件 / 库存 500）",
    scoped69.includes("成交 12 件") && scoped69.includes("库存 500"), scoped69.slice(0, 60));
  check("主体区文本**不含**推荐位里别的商品（电动牙刷 / 成交 9999）",
    !scoped69.includes("电动牙刷") && !scoped69.includes("9999"), scoped69.slice(0, 60));

  /* ④ 价格：bug 复现 + 修复验证 */
  const noScope69 = U69.pickPagePrice({ selectors: [] });
  check("bug 复现：不限定主体区时，价格会取到推荐位里别的商品的 ¥9.9",
    noScope69.min === 9.9, JSON.stringify(noScope69));
  const withScope69 = U69.pickPagePrice({ selectors: [], scope: scope69 });
  check("修复后：价格取本商品的 ¥88.00（推荐位的 ¥9.9 被挡掉）",
    withScope69.min === 88, JSON.stringify(withScope69));
  const cacheScope69 = U69.pickPagePrice({
    selectors: [],
    cache: { jsonLd: () => [], scope: () => scope69 },
  });
  check("修复后：传 cache 时自动用主体区（调用方不用手动传 scope）",
    cacheScope69.min === 88, JSON.stringify(cacheScope69));

  /* ⑤ 图片采集：scopeRoot 之外的图一律不收 */
  const imgMain = "https://cbu01.alicdn.com/img/ibank/O1CN01main/main.jpg";
  const imgRec = "https://cbu01.alicdn.com/img/ibank/O1CN01rec/other.jpg";
  const domImg = buildDom();
  const mainImg = add(domImg.main, "img", { attrs: { src: imgMain }, text: "" });
  const recImg = add(domImg.rec, "img", { attrs: { src: imgRec }, text: "" });
  for (const n of [mainImg, recImg]) {
    n.naturalWidth = 800; n.naturalHeight = 800; n.complete = true;
    Object.defineProperty(n, "src", { get: () => n.getAttribute("src"), configurable: true });
    Object.defineProperty(n, "currentSrc", { get: () => n.getAttribute("src"), configurable: true });
    n.getBoundingClientRect = () => ({ width: 800, height: 800 });
  }
  const U69b = runBase(domImg);
  const scopedImgs = U69b.collectImages({
    origin: "https:", containers: ["[class*=detail-content]"], noPageFallback: true, scopeRoot: domImg.main,
  });
  check("图片：scopeRoot 内的大图被收进来",
    scopedImgs.images.includes(imgMain), JSON.stringify(scopedImgs.images));
  check("图片：scopeRoot 之外（推荐位）的图被挡掉",
    !scopedImgs.images.includes(imgRec), JSON.stringify(scopedImgs.images));

  /* ⑥ 三个适配器的接线：权威标题必须排在 DOM 选择器之前，且全页 innerText 扫描已清零 */
  const authoritativeBeforeSelectors = (src) => {
    const fn = src.indexOf("function pickTitle");
    if (fn < 0) return false;
    const auth = src.indexOf("U.authoritativeTitle()", fn);
    const next = src.indexOf("\n  function ", fn + 10);
    if (auth < 0) return false;
    if (next > 0 && auth > next) return false;
    return true;
  };
  check("1688：pickTitle 把权威标题排在 DOM 选择器之前",
    authoritativeBeforeSelectors(ali69)
    && ali69.indexOf("const authoritative = U.authoritativeTitle();", ali69.indexOf("function pickTitle"))
      < ali69.indexOf("for (const selector of TITLE_SELECTORS)", ali69.indexOf("function pickTitle")), "");
  check("淘宝：pickTitle 把权威标题排在 DOM 选择器之前",
    authoritativeBeforeSelectors(tb69)
    && tb69.indexOf("const authoritative = U.authoritativeTitle();", tb69.indexOf("function pickTitle"))
      < tb69.indexOf("for (const selector of candidates)", tb69.indexOf("function pickTitle")), "");
  check("拼多多：pickTitle 把权威标题排在通用 DOM 选择器之前",
    authoritativeBeforeSelectors(pdd69), "");

  for (const [name, src] of [["1688", ali69], ["淘宝", tb69], ["拼多多", pdd69]]) {
    check(`${name}：不再有「扫全页 innerText」的取值（全部收敛到主体区）`,
      !/cache\.innerText\(\)/.test(src), "");
  }
  check("1688：销量 / 库存 / 属性 / 毛重 / 发货地 / 描述 全部改用主体区文本",
    (ali69.match(/cache\.scopeText\(\)/g) || []).length >= 6,
    String((ali69.match(/cache\.scopeText\(\)/g) || []).length));
  check("1688：图集兜底与图床兜底都限定在主体区内",
    (ali69.match(/scopeRoot: cache\.scope\(\)/g) || []).length === 2, "");
  check("1688：标题不在主体区内时写出备注提醒人工核对",
    /采集到的标题不在商品主体区内/.test(ali69), "");
  check("adapter-base：导出 resolveProductScope / scopeTextOf / authoritativeTitle",
    /resolveProductScope,\n    scopeTextOf,\n    authoritativeTitle,/.test(baseSrc69), "");
  check("adapter-base：推荐区名单覆盖 recommend / similar / mayLike / review 等",
    /\[class\*=recommend\]/.test(baseSrc69) && /\[class\*=mayLike\]/.test(baseSrc69) && /\[class\*=review\]/.test(baseSrc69), "");

  /* ⑦ 面板顶栏显示插件版本：用户据此确认「改动到底生效没有」 */
  const html69 = fs.readFileSync(path.join(HERE, "../src/ui/panel.html"), "utf8").replace(/\r\n/g, "\n");
  const panel69 = fs.readFileSync(path.join(HERE, "../src/ui/panel.js"), "utf8").replace(/\r\n/g, "\n");
  check("面板顶栏有版本号元素（改完代码没生效时一眼可见）",
    /id="ext-version"/.test(html69), "");
  check("面板启动时把当前插件版本写进顶栏",
    /chrome\.runtime\.getManifest\(\)\.version/.test(panel69)
    && /\$\("#ext-version"\)/.test(panel69), "");

  /* ⑧ 版本号 */
  check("版本号升到 1.9.69 及以上",
    manifest69.version.split(".").map(Number)[0] > 1
    || (manifest69.version.split(".").map(Number)[1] === 9 && manifest69.version.split(".").map(Number)[2] >= 69),
    manifest69.version);
}

console.log("=== v1.9.70 类目匹配：视觉模型优先，禁止旧 AI 文案污染，禁止伪造图片匹配置信度 ===");
{
  const sw70 = fs.readFileSync(path.join(HERE, "../src/background/service-worker.js"), "utf8").replace(/\r\n/g, "\n");
  const panel70 = fs.readFileSync(path.join(HERE, "../src/ui/panel.js"), "utf8").replace(/\r\n/g, "\n");
  const prompts70 = fs.readFileSync(path.join(HERE, "../src/shared/prompts.js"), "utf8").replace(/\r\n/g, "\n");
  const manifest70 = JSON.parse(fs.readFileSync(path.join(HERE, "../manifest.json"), "utf8"));

  check("后台：类目匹配使用视觉凭据（aiVisionModel），不再误用纯文本凭据",
    /const credentials = resolveVisionCredentials\(settings\);/.test(sw70)
    && /visionModel: credentials\.model/.test(sw70), "");
  check("后台：图片降级时如实回报 imageUsed=false",
    /imageUsed = false;/.test(sw70)
    && /data: \{ stage: 1, imageCount: imageDataUrls\.length, imageUsed \}/.test(sw70), "");
  check("面板：本地兜底不再混入旧 AI 标题/旧类目提示",
    /v1\.9\.70：类目匹配只能依据/.test(panel70)
    && !/draft\.ru\?\.categoryHint,\n      draft\.ru\?\.title,\n      draft\.ru\?\.description,/.test(panel70), "");
  check("提示词：不再把旧俄文标题/旧类目/旧关键词作为匹配依据",
    /严禁把上一轮 AI 生成的俄文标题/.test(prompts70)
    && /不要相信草稿里此前生成的类目/.test(prompts70), "");
  check("面板：本地兜底最高 55%，不再伪造本地匹配度 100%",
    /confidence: Math\.min\(55, normalizeMatchScore\(item\.score, topScore\)\)/.test(panel70), "");
  check("面板：本地候选明确标成「标题文字兜底」",
    /标题文字兜底 \$\{c\.confidence\}%/.test(panel70)
    && /图片未参与自动确认/.test(panel70), "");
  check("面板：取到图片但 AI 不可用时提示配置视觉模型",
    /图片已取到 \$\{images\.length\} 张，但视觉类目模型未返回可用结果/.test(panel70)
    && /配置支持图片输入的视觉模型/.test(panel70), "");
  check("版本号升到 1.9.70 及以上",
    manifest70.version.split(".").map(Number)[0] > 1
    || (manifest70.version.split(".").map(Number)[1] === 9 && manifest70.version.split(".").map(Number)[2] >= 70),
    manifest70.version);
}

console.log("=== v1.9.73 策划师模式（先卖点排序→8图固定结构方案→按方案出图）===");
{
  const manifest73 = JSON.parse(fs.readFileSync(path.join(HERE, "../manifest.json"), "utf8"));
  const constantsSrc = fs.readFileSync(path.join(HERE, "../src/shared/constants.js"), "utf8").replace(/\r\n/g, "\n");
  const workerSrc = fs.readFileSync(path.join(HERE, "../src/background/service-worker.js"), "utf8").replace(/\r\n/g, "\n");
  const imgSvcSrc = fs.readFileSync(path.join(HERE, "../src/background/image-service.js"), "utf8").replace(/\r\n/g, "\n");
  const panelSrc = fs.readFileSync(path.join(HERE, "../src/ui/panel.js"), "utf8").replace(/\r\n/g, "\n");
  const htmlSrc = fs.readFileSync(path.join(HERE, "../src/ui/panel.html"), "utf8").replace(/\r\n/g, "\n");
  const cssSrc = fs.readFileSync(path.join(HERE, "../src/ui/panel.css"), "utf8").replace(/\r\n/g, "\n");

  // —— 8 图固定结构 ——
  check("8 图结构齐全且顺序固定（主图/核心卖点/卖点②/场景/尺寸/细节/包装/模特）",
    PLAN_8_SHOTS.length === 8
    && PLAN_8_SHOTS.map((s) => s.key).join(",") === "hero,core-benefit,benefit-2,scene,size,detail,package,model",
    PLAN_8_SHOTS.map((s) => s.key).join(","));
  check("每张带中文画面职责说明与英文出图口径（hard/textMode）",
    PLAN_8_SHOTS.every((s) => s.hard && s.task && s.label && typeof s.textMode === "string"), "");
  check("出图统一比例 3:4", PLAN_ASPECT === "3:4", PLAN_ASPECT);

  // —— 提示词人设（第一步卖点 + 第二步 8 图 + 唯一最强卖点 + 只 JSON）——
  const planMsgs = buildPlanMessages({ title: "电暖器", attributes: [{ name: "功率", value: "2 кВт" }], skus: [{ label: "白", price: "39" }] }, { audience: "家庭", points: ["Быстрый нагрев"] });
  const sys = planMsgs[0].content, usr = planMsgs[1].content;
  check("系统提示：OZON 资深视觉策划 + 俄语专家人设", /资深商品视觉策划|俄语卖点文案专家/.test(sys), "");
  check("系统提示：要求按影响力排序 + 唯一最强卖点 bestIndex + 进第2图",
    /影响力/.test(sys) && /bestIndex/.test(sys) && /第 2 张|第二张|2 张图/.test(sys), "");
  check("系统提示：8 张图职责逐条写死（主图/核心卖点/包装清单/模特）",
    /主图/.test(sys) && /核心卖点图/.test(sys) && /包装清单图/.test(sys) && /模特图/.test(sys), "");
  check("系统提示：俄文短句≤6词、每行3~5词、图内只俄文、地道不机翻",
    /≤6|不超过6|6 个词|6个词/.test(sys) && /地道|不机翻|机翻/.test(sys) && /只.{0,4}俄文|只用俄文|图内.*俄文/.test(sys), "");
  check("系统提示：只输出合法 JSON", /严格.{0,4}JSON|只输出.*JSON|不要.*markdown/i.test(sys), "");
  check("用户消息带上商品资料/目标人群/已有卖点", /电暖器|家庭取暖|家庭/.test(usr) && /Быстрый нагрев/.test(usr), "");

  // —— 解析 + 校验 ——
  const good = {
    sellingPoints: [
      { zh: "3秒速热", ru: "Нагрев за 3 секунды", evidence: "通电发热特写" },
      { zh: "静音", ru: "Тихая работа", evidence: "分贝对比" },
    ],
    bestIndex: 0,
    shots: PLAN_8_SHOTS.map((tpl, i) => ({
      slot: tpl.slot, type: tpl.label, sceneZh: "画面" + (i + 1),
      ruText: tpl.textMode === "none" ? "" : (tpl.key === "core-benefit" ? "Нагрев за 3 секунды" : "Текст" + tpl.slot),
      promptEn: "english scene " + tpl.slot,
    })),
  };
  const rg = parsePlanResult(JSON.stringify(good));
  check("完整方案解析通过、无瑕疵", rg.ok === true && rg.problems.length === 0, JSON.stringify(rg.problems));
  check("最强卖点按 bestIndex 定位", rg.data.bestPoint && rg.data.bestPoint.zh === "3秒速热", JSON.stringify(rg.data.bestPoint));
  check("8 张按模板顺序补齐（含 slot/key/textMode）",
    rg.data.shots.length === 8 && rg.data.shots[0].key === "hero" && rg.data.shots[0].textMode === "hero", JSON.stringify(rg.data.shots[0]));
  check("core-benefit 承载最强卖点 → coreCarriesBest=true", rg.data.coreCarriesBest === true, "");

  // 俄文短句混中文：该卖点 ru 应被清空（图上不出现汉字）
  const badRu = { sellingPoints: [{ zh: "x", ru: "你好 мир" }], bestIndex: 0, shots: good.shots };
  const rbr = parsePlanResult(JSON.stringify(badRu));
  check("图上俄文里混入中文会被发现（报告问题，出图剔除）",
    rbr.problems.some((p) => /混入了中文/.test(p)), JSON.stringify(rbr.problems));
  // ruText 里混中文 → 直接清空
  const ruTextMixed = { sellingPoints: [{ zh: "a", ru: "Хорошо" }], bestIndex: 0,
    shots: [{ slot: 1, promptEn: "p", ruText: "主图 3 сек" }] };
  const rtm = parsePlanResult(JSON.stringify(ruTextMixed));
  check("ruText 含中文一律剔除为空（图上绝不出现汉字）", rtm.data.shots[0].ruText === "", JSON.stringify(rtm.data.shots[0].ruText));
  // 只给 1 张：靠兜底不致命，但报告列出缺哪几张
  const sparse = parsePlanResult(JSON.stringify({ sellingPoints: [{ zh: "a", ru: "Aa" }], shots: [{ slot: 1, promptEn: "x" }] }));
  check("AI 漏给画面：不整批失败（有卖点就出方案），缺的张靠兜底并逐张提示",
    sparse.ok === true && sparse.problems.some((p) => /第 8 张/.test(p) && /兜底/.test(p)), JSON.stringify(sparse.problems));
  check("连卖点都没有才判失败（无从谈起）", parsePlanResult(JSON.stringify({ shots: [] })).ok === false, "");
  check("返回不是 JSON 时安全失败不抛异常", parsePlanResult("这不是 JSON").ok === false, "");

  // —— 编译出图 prompt ——
  const heroPrompt = buildPlannedPrompt(rg.data.shots[0], { bestPoint: rg.data.bestPoint, context: "电暖器", styleHint: "teal palette" });
  check("主图 prompt：炫酷拼接背景 + 明确非纯白底（Ozon 无白底强制规范，非违规）",
    /collage/i.test(heroPrompt) && /NOT a plain pure-white/i.test(heroPrompt), "");
  check("每张 prompt 结尾都带 3:4 比例与统一风格指令",
    /Aspect ratio 3:4/i.test(heroPrompt) && /same color palette/i.test(heroPrompt), "");
  check("每张 prompt 带俄文硬约束（俄罗斯面孔/禁中文/产品本体不变）",
    /ТОЛЬКО русский/i.test(heroPrompt) && /китайские иероглифы/i.test(heroPrompt) && /ТОВАР НЕИЗМЕНЕН/i.test(heroPrompt), "");
  const corePrompt = buildPlannedPrompt(rg.data.shots[1], { bestPoint: rg.data.bestPoint, context: "电暖器" });
  check("核心卖点图 prompt 把最强卖点俄文原样写成待渲染大标题",
    /Нагрев за 3 секунды/.test(corePrompt) && /Russian headline/i.test(corePrompt), "");
  const noTextPrompt = buildPlannedPrompt(rg.data.shots[3], { context: "电暖器" });
  check("无字图 prompt 明确不加任何文字水印", /No text on this image/i.test(noTextPrompt), "");

  // —— 导出 ——
  const md = renderPlanMarkdown(rg.data, { title: "电暖器", category: "家居", at: "2026-10-01" });
  check("导出含卖点表 + 唯一最强卖点标记 + 8 张分节",
    md.includes("| 中文卖点 | 俄文短句 | 视觉证据 |") && md.includes("⭐最强") && (md.match(/### /g) || []).length === 8, "");

  // —— 接线 ——
  check("后台有 aiImageStrategy 动作与 handler",
    /aiImageStrategy:\s*"ai_image_strategy"/.test(constantsSrc)
    && /case MESSAGE_ACTIONS\.aiImageStrategy:/.test(workerSrc)
    && /async function generateImageStrategy/.test(workerSrc), "");
  check("handler 走 buildPlanMessages→chatComplete→parsePlanResult，失败带 problems 话术",
    /buildPlanMessages\(/.test(workerSrc) && /parsePlanResult\(/.test(workerSrc)
    && /策划方案解析失败/.test(workerSrc), "");
  check("redrawImage 支持 plannedPrompt 直连（策划模式出图），缺省走旧链路",
    /plannedPrompt\s*\?\s*plannedPrompt/.test(imgSvcSrc) && /plannedPrompt = ""/.test(imgSvcSrc), "");
  check("service-worker 把 plannedPrompt 透传给 redrawImage",
    /plannedPrompt: message\.plannedPrompt/.test(workerSrc), "");
  check("面板有策划区四个按钮处理器与独立图位渲染",
    /function bindPlan\(/.test(panelSrc) && /generatePlanStrategy/.test(panelSrc)
    && /generatePlanImages/.test(panelSrc) && /exportPlan/.test(panelSrc) && /renderPlanGrid/.test(panelSrc), "");
  check("面板出图用 buildPlannedPrompt 且传 plannedPrompt",
    /buildPlannedPrompt\(shot/.test(panelSrc) && /plannedPrompt: prompt/.test(panelSrc), "");
  check("面板：换草稿作废策划方案（防 A 商品图串到 B）",
    /state\.planDraftId !== \(draft\?\.id \|\| ""\)/.test(panelSrc) && /state\.plan = null/.test(panelSrc), "");
  check("面板：编辑单张画面/俄文/prompt 后重出",
    /function editAndRegeneratePlanShot/.test(panelSrc) && /英文出图指令/.test(panelSrc), "");
  check("面板：俄文卖点可一键并入旧套图卖点区", /function applyPlanPointsToSet/.test(panelSrc), "");
  check("HTML 有策划卡且落在 workspace 视图末尾（不塞进 mediaCard 折叠区，保住旧布局断言）",
    /id="plan-card"/.test(htmlSrc) && /id="btn-plan-strategy"/.test(htmlSrc) && /id="plan-grid"/.test(htmlSrc), "");
  check("CSS 有方案网格样式", /\.plan-grid \{/.test(cssSrc) && /\.plan-cell \{/.test(cssSrc), "");
  check("版本号升到 1.9.73 及以上",
    manifest73.version.split(".").map(Number)[0] > 1
    || (manifest73.version.split(".").map(Number)[1] === 9 && manifest73.version.split(".").map(Number)[2] >= 73),
    manifest73.version);
}

console.log("=== v1.9.74 SKU 采集准确性（规格污染 / 整段切分 / 去重误删 / 商品编码）===");
{
  const manifest74 = JSON.parse(fs.readFileSync(path.join(HERE, "../manifest.json"), "utf8"));
  const code74 = fs.readFileSync(path.join(HERE, "../src/content/adapter-1688.js"), "utf8").replace(/\r\n/g, "\n");
  const base74 = fs.readFileSync(path.join(HERE, "../src/content/adapter-base.js"), "utf8").replace(/\r\n/g, "\n");
  const model74 = fs.readFileSync(path.join(HERE, "../src/shared/product-model.js"), "utf8").replace(/\r\n/g, "\n");
  const drafts74 = fs.readFileSync(path.join(HERE, "../src/ui/drafts.js"), "utf8").replace(/\r\n/g, "\n");
  const panel74 = fs.readFileSync(path.join(HERE, "../src/ui/panel.js"), "utf8").replace(/\r\n/g, "\n");

  // 独立上下文跑纯函数（不复用前面的 ctx2，避免块级作用域踩空）
  const ctx74 = { console, setTimeout, clearTimeout, setInterval, clearInterval, performance };
  ctx74.window = ctx74;
  ctx74.location = { origin: "https://detail.1688.com", href: "https://detail.1688.com/offer/123456789.html" };
  ctx74.document = { querySelector: () => null, querySelectorAll: () => [], documentElement: { innerHTML: "" }, body: { innerText: "" } };
  vm.createContext(ctx74);
  vm.runInContext(base74, ctx74);
  vm.runInContext(code74, ctx74);
  const sku74 = ctx74.__OZON_ADAPTERS__.sku1688;

  // —— ① 规格字段不再被整页营销文案污染（超哥截图里的根因）——
  const polluted = sku74.parseSkuRow([
    "售100% 200+人已加购 领券满100减10 包邮 标准款-卡其色 ¥129 库存4333件",
  ]);
  check("规格名不再混入「已加购/领券/包邮」这类页面文案",
    polluted && !/人已加购|领券|包邮|满100减10/.test(polluted.label), JSON.stringify(polluted));
  check("清洗后规格名保留真实规格「标准款-卡其色」",
    polluted && polluted.label.includes("标准款-卡其色") && polluted.price === 129 && polluted.stock === 4333,
    JSON.stringify(polluted));
  check("cleanSpecLabel 清空纯营销文本",
    sku74.cleanSpecLabel("售100% 200+人已加购 领券 满100减10 包邮") === "",
    JSON.stringify(sku74.cleanSpecLabel("售100% 200+人已加购 领券 满100减10 包邮")));
  check("cleanSpecLabel 不动真实规格名",
    sku74.cleanSpecLabel("标准款双向推-卡其色(EVA/八轮)") === "标准款双向推-卡其色(EVA/八轮)",
    JSON.stringify(sku74.cleanSpecLabel("标准款双向推-卡其色(EVA/八轮)")));

  // —— ② 装了很多行的外层容器不再被当成「一条 SKU」——
  // v1.9.75：判据从「文本超长」改成「本质特征 —— 剥掉价格后仍剩多个库存锚点」。
  // 容器即使剥掉价格/库存，行内文本里仍有好几份「库存」字样；正常一行只有一个。
  const containerBlob = "标准款-卡其色 ¥129 库存4333件 标准款-亚麻灰 ¥129 库存4523件 豪华款-卡其色 ¥139 库存2662件";
  check("多库存锚点的外层容器被拒绝，不产出单条伪 SKU",
    sku74.parseSkuRow([containerBlob]) === null, JSON.stringify(sku74.parseSkuRow([containerBlob])));
  check("正常单行（只有一个库存锚点）照旧通过",
    (() => { const r = sku74.parseSkuRow(["标准款-卡其色 ¥129 库存4333件"]); return r && r.price === 129 && r.stock === 4333; })(),
    JSON.stringify(sku74.parseSkuRow(["标准款-卡其色 ¥129 库存4333件"])));

  // —— ③ 无换行的整段文本按库存锚点切回多条 ——
  const blob74 = [
    "标准款-卡其色 ¥129 库存4333件",
    "标准款-亚麻灰 ¥129 库存4523件",
    "豪华款-卡其色 ¥139 库存2662件",
  ].join(" ");
  check("countStockAnchors 数出整段里的 3 个库存锚点", sku74.countStockAnchors(blob74) === 3, String(sku74.countStockAnchors(blob74)));
  const pieces74 = sku74.splitSkuBlob(blob74);
  check("splitSkuBlob 把一整段无换行文本切成 3 条", pieces74.length === 3, JSON.stringify(pieces74));
  check("splitSkuBlob 切出的每片规格/价格/库存都对",
    pieces74[0].includes("标准款-卡其色") && pieces74[2].includes("¥139") && pieces74[2].includes("库存2662件"),
    JSON.stringify(pieces74));
  check("splitSkuBlob 对单条正常行不误切（返回空数组 = 交给原逻辑）",
    sku74.splitSkuBlob("标准款-卡其色 ¥129 库存4333件").length === 0, "");

  // —— ④ 文本行兜底：整段 → 多条 + 规格维度接进去 ——
  const blobCache74 = { innerText: () => blob74, scopeText: () => blob74 };
  const textSkus74 = sku74.pickSkuRowsFromText(blobCache74, [
    { name: "颜色", values: ["卡其色", "亚麻灰"] },
  ]);
  check("文本行兜底：整段无换行也能还原成 3 条 SKU",
    textSkus74.length === 3, JSON.stringify(textSkus74.map((s) => s.label)));
  check("文本行兜底：价格库存逐条独立，不再全 0",
    textSkus74[0].price === 129 && textSkus74[2].price === 139 && textSkus74[1].stock === 4523,
    JSON.stringify(textSkus74.map((s) => [s.price, s.stock])));
  check("文本行兜底：接入了规格维度（颜色）而不是全堆在「规格」键下",
    textSkus74.some((s) => s.specs && s.specs["颜色"]),
    JSON.stringify(textSkus74.map((s) => s.specs)));

  // —— ⑤ 去重不再把 30 个变体压成 1 条（签名被污染时必须退回 id）——
  check("skuSignature 对被污染的规格退回 id 去重（长签名不再当身份）",
    /const polluted = parts\.some/.test(base74) && /SKU_SIG_MAX_PART/.test(base74), "");
  check("dedupeSkus 保留规格相同但 id 不同的条目（id 兜底生效）", (() => {
    const list = [
      { id: "a", specs: { 规格: "X".repeat(200) }, price: 10, stock: 1 },
      { id: "b", specs: { 规格: "X".repeat(200) }, price: 20, stock: 2 },
      { id: "c", specs: { 规格: "X".repeat(200) }, price: 30, stock: 3 },
    ];
    const out = ctx74.__OZON_ADAPTERS__.utils.dedupeSkus(list);
    return out.length === 3;
  })(), "");

  // —— ⑥ 条数护栏：1 条 vs 30 条时选多的那边 ——
  check("择优时加了「条数」护栏（1 条不敌 3+ 条的真实变体）",
    /若最优源只有 1 条|skus\.length <= 1 && richer/.test(code74) && /const richer = \[tableSkus, dataSkus, textSkus\]/.test(code74), "");

  // —— ⑦ 商品编码 ——
  check("1688 有 pickProductCode（属性区货号优先）",
    /function pickProductCode\(cache, attributes = \[\]\)/.test(code74) && /CODE_NAMES/.test(code74), "");
  check("pickProductCode：属性区「货号」命中即返回", (() => {
    const fake = { scopeText: () => "", scripts: () => "" };
    return sku74.pickProductCode(fake, [{ name: "货号", value: "DT-2026-XL" }]) === "DT-2026-XL";
  })(), "");
  check("pickProductCode：没货号时用 URL 里的 offerId 兜底", (() => {
    const fake = { scopeText: () => "", scripts: () => "" };
    return sku74.pickProductCode(fake, []) === "123456789";
  })(), JSON.stringify(sku74.pickProductCode({ scopeText: () => "", scripts: () => "" }, [])));
  check("pickProductCode：都拿不到返回空串（不编造）", (() => {
    const fake = { scopeText: () => "材质 塑料", scripts: () => "" };
    const saved = ctx74.location.href;
    ctx74.location.href = "https://detail.1688.com/offer/1.html";   // offerId 只有 1 位，不满足 6 位下限
    const out = sku74.pickProductCode(fake, []);
    ctx74.location.href = saved;
    return out === "";
  })(), "");
  check("商品编码写进采集返回值", /title,\n        productCode,/.test(code74), "");
  // 采集失败要留诊断，不能静默
  check("采不到商品编码时写诊断备注", /没采到商品编码/.test(code74), "");
  check("product-model 有空 productCode 字段并在 normalize 时清洗",
    /productCode: "",/.test(model74) && /product\.productCode = cleanText\(raw\.productCode\)/.test(model74), "");
  check("草稿保存 productCode", /productCode: product\.productCode \|\| ""/.test(drafts74), "");
  check("面板采集摘要显示编码", /product\.productCode \? `编码 \$\{product\.productCode\}`/.test(panel74), "");

  // —— ⑧ 表格行也接上整段切分 ——
  check("pickSkuTableRows 在整行超长时按库存锚点切分（不再静默丢整块）",
    /const pieces = splitSkuBlob\(flat\)/.test(code74) && /countStockAnchors\(flat\) < 2/.test(code74), "");

  check("版本号升到 1.9.74 及以上",
    manifest74.version.split(".").map(Number)[0] > 1
    || (manifest74.version.split(".").map(Number)[1] === 9 && manifest74.version.split(".").map(Number)[2] >= 74),
    manifest74.version);
}

console.log("=== v1.9.75 SKU 采集扩容 + SKU 结构诊断（超哥：只采到部分规格）===");
{
  const manifest75 = JSON.parse(fs.readFileSync(path.join(HERE, "../manifest.json"), "utf8"));
  const code75 = fs.readFileSync(path.join(HERE, "../src/content/adapter-1688.js"), "utf8").replace(/\r\n/g, "\n");
  const injector75 = fs.readFileSync(path.join(HERE, "../src/content/injector.js"), "utf8").replace(/\r\n/g, "\n");
  const worker75 = fs.readFileSync(path.join(HERE, "../src/background/service-worker.js"), "utf8").replace(/\r\n/g, "\n");
  const constants75 = fs.readFileSync(path.join(HERE, "../src/shared/constants.js"), "utf8").replace(/\r\n/g, "\n");
  const panel75 = fs.readFileSync(path.join(HERE, "../src/ui/panel.js"), "utf8").replace(/\r\n/g, "\n");
  const html75 = fs.readFileSync(path.join(HERE, "../src/ui/panel.html"), "utf8").replace(/\r\n/g, "\n");

  const ctx75 = { console, setTimeout, clearTimeout, setInterval, clearInterval, performance };
  ctx75.window = ctx75;
  ctx75.location = { origin: "https://detail.1688.com", href: "https://detail.1688.com/offer/123456789.html" };
  ctx75.document = { querySelector: () => null, querySelectorAll: () => [], documentElement: { innerHTML: "" }, body: { innerText: "" } };
  vm.createContext(ctx75);
  vm.runInContext(fs.readFileSync(path.join(HERE, "../src/content/adapter-base.js"), "utf8"), ctx75);
  vm.runInContext(code75, ctx75);
  const sku75 = ctx75.__OZON_ADAPTERS__.sku1688;

  // —— ① 笛卡尔积不再砍掉多规格 ——
  // 原来写死「前 2 维度 × 各前 12 值、上限 60」：颜色 8 × 尺码 6 × 款式 3 = 144 个真变体被砍到 24。
  // 用例规模控制在 300 以内，这样考察的是「维度数 / 单维度值上限」，而不是总量截断。
  const manyOptions = [
    { name: "颜色", values: Array.from({ length: 15 }, (_, i) => `色${i + 1}`) },  // 15 > 旧上限 12
    { name: "尺码", values: Array.from({ length: 6 }, (_, i) => `码${i + 1}`) },
    { name: "款式", values: ["A", "B", "C"] },                                      // 第 3 个维度，旧实现整个丢
  ];
  const combos75 = sku75.buildSkusFromOptions(manyOptions, {}, {});
  check("笛卡尔积支持 3 个维度（不再只取前 2 个）",
    combos75.length > 0 && combos75.some((skuItem) => skuItem.specs["款式"]),
    `组合数=${combos75.length}`);
  check("笛卡尔积单维度值上限从 12 放宽（15 个颜色不再被砍到 12）",
    combos75.some((skuItem) => skuItem.specs["颜色"] === "色15"),
    JSON.stringify(combos75.slice(-1).map((s) => s.specs)));
  check("15×6×3=270 个组合全部展开（旧实现只给 24 条）",
    combos75.length === 270, String(combos75.length));
  // 总量上限仍然存在，防止页面异常时卡死
  const hugeOptions = [
    { name: "颜色", values: Array.from({ length: 120 }, (_, i) => `色${i + 1}`) },
    { name: "尺码", values: Array.from({ length: 10 }, (_, i) => `码${i + 1}`) },
  ];
  check("组合总量仍有上限（120×10 会被截到 300 以内，不会卡死）",
    sku75.buildSkusFromOptions(hugeOptions, {}, {}).length <= 300,
    String(sku75.buildSkusFromOptions(hugeOptions, {}, {}).length));

  // —— ② 容器判据改成「多库存锚点」这一本质特征 ——
  const containerBlob75 = "标准款-卡其色 ¥129 库存4333件 标准款-亚麻灰 ¥129 库存4523件 豪华款-卡其色 ¥139 库存2662件";
  check("容器判据用库存锚点数（不再只看文本长度）",
    /countStockAnchors\(rawText\) > 1/.test(code75), "");
  check("短文本的多行容器同样被拒绝（长度判据会漏掉它）",
    sku75.parseSkuRow([containerBlob75]) === null, JSON.stringify(sku75.parseSkuRow([containerBlob75])));
  // 多维长规格的正常一行不能被误杀（旧长度上限 80 会杀）
  const longButValid = "豪华款双向推-卡其色(EVA/八轮)+收纳袋+手拉环+加大版 ¥139 库存2662件";
  check("正常的长规格单行不被误杀（长度上限放宽到 200）",
    (() => { const r = sku75.parseSkuRow([longButValid]); return r && r.price === 139 && r.stock === 2662; })(),
    JSON.stringify(sku75.parseSkuRow([longButValid])));

  // —— ③ 规格值上限放宽 ——
  check("mergeOptions 单维度上限从 40 放宽", /MAX_VALUES_PER_OPTION = 120/.test(code75), "");
  check("启发式规格识别不再因选项多而整块跳过", /MAX_HEURISTIC_OPTIONS = 150/.test(code75), "");
  check("变体图锚点上限放开（30+ 变体页面够用）", /MAX_SKU_ROW_ANCHORS = 400/.test(code75), "");
  check("单行文本上限从 200 放宽到 400", /MAX_SKU_ROW_TEXT = 400/.test(code75), "");

  // —— ④ SKU 结构诊断链路 ——
  check("1688 有 diagnoseSkuStructure", /function diagnoseSkuStructure\(\)/.test(code75), "");
  check("诊断会输出选择器命中数 / 节点样本 / 库存行 / 祖先链",
    /out\.selectors\.push/.test(code75) && /out\.sampleRows\.push/.test(code75)
    && /out\.stockLines\.push/.test(code75) && /out\.anchors\.push/.test(code75), "");
  check("诊断函数已导出到 registry.sku1688", /diagnoseSkuStructure,/.test(code75), "");
  check("content script 响应 ozon_diagnose_sku（且在 capture_product 拦截之前）",
    /ozon_diagnose_sku/.test(injector75)
    && injector75.indexOf("ozon_diagnose_sku") < injector75.indexOf('message?.action !== "capture_product"'), "");
  check("constants 有 diagnoseSku 动作", /diagnoseSku: "diagnose_sku"/.test(constants75), "");
  check("后台有 diagnoseSku handler（含补注入重试）",
    /case MESSAGE_ACTIONS\.diagnoseSku:/.test(worker75)
    && /async function diagnoseSku\(\)/.test(worker75)
    && /ozon_diagnose_sku/.test(worker75), "");
  check("面板有诊断 SKU 按钮与复制按钮", /btn-diagnose-sku/.test(html75) && /btn-copy-diagnose-sku/.test(html75), "");
  check("面板绑定两个按钮的事件",
    /"#btn-diagnose-sku"\)\?\.addEventListener/.test(panel75)
    && /"#btn-copy-diagnose-sku"\)\?\.addEventListener/.test(panel75), "");
  check("诊断输出区 id 正确", /id="diagnose-sku-output"/.test(html75), "");

  check("版本号升到 1.9.75 及以上",
    manifest75.version.split(".").map(Number)[0] > 1
    || (manifest75.version.split(".").map(Number)[1] === 9 && manifest75.version.split(".").map(Number)[2] >= 75),
    manifest75.version);
}

console.log("=== v1.9.76 白底认知修正（Ozon 无主图白底强制规范）===");
{
  const manifest76 = JSON.parse(fs.readFileSync(path.join(HERE, "../manifest.json"), "utf8"));
  const plan76 = fs.readFileSync(path.join(HERE, "../src/shared/image-plan.js"), "utf8").replace(/\r\n/g, "\n");
  const prompts76 = fs.readFileSync(path.join(HERE, "../src/shared/image-prompts.js"), "utf8").replace(/\r\n/g, "\n");
  const html76 = fs.readFileSync(path.join(HERE, "../src/ui/panel.html"), "utf8").replace(/\r\n/g, "\n");
  const readme76 = fs.readFileSync(path.join(HERE, "../README.md"), "utf8").replace(/\r\n/g, "\n");

  // 1. 错误说法必须全部清干净（这 4 个串一个都不能留）
  check("全仓库不再出现「Ozon 主图规范」这个伪规范说法",
    !/Ozon 主图规范/.test(plan76 + prompts76 + html76 + readme76), "");
  check("不再出现「官方白底规范」「忽略…白底规范」的说法",
    !/官方白底规范/.test(plan76 + prompts76 + html76 + readme76), "");
  // 注：不再断言「自测文件自身不含旧串」——检测代码必须包含被检测的字面量，这条同义反复且必然失败。
  // 真正要保证的是「被检测的源码/文档」里清干净，见上面两条。

  // 2. 新注释必须落地：讲清「白底是亚马逊规则被抄串」+「Ozon 官方工具本就加信息图」
  check("image-plan 注明 Ozon 无白底强制规范（并点明源自亚马逊被抄串）",
    /Ozon 并无「主图必须纯白底」的官方规范/.test(plan76) && /亚马逊/.test(plan76), "");
  check("image-plan 注明 Ozon 官方 Design Tool 本就是给主图加俄文标签的",
    /Design Tool/.test(plan76) && /Card Enhancement/.test(plan76), "");
  check("image-prompts 文件头注明依据（白底说法源自亚马逊，不可信）",
    /Ozon 无「主图必须纯白底」规范/.test(prompts76) && /亚马逊规范/.test(prompts76), "");
  check("image-prompts 背景规则处注明白底开关是偏好不是合规",
    /保留白底开关是因为部分类目\/部分买家吃白底那套，不是因为有强制规范要绕/.test(prompts76), "");

  // 3. 面板文案：不能再把「Ozon 主图规范」当事实陈述给用户看
  check("面板白底开关文案已改为「Ozon 并无主图白底强制规范」",
    /Ozon 并无主图白底强制规范/.test(html76) && !/（Ozon 主图规范；不勾/.test(html76), "");
  check("面板仍保留白底开关本体与 id（只是措辞变了，功能不动）",
    /id="set-gen-bg-white"/.test(html76), "");

  // 4. README：不能再说「忽略 Ozon 官方白底规范」
  check("README 已改为「Ozon 并无主图白底强制规范」",
    /Ozon 并无主图白底强制规范/.test(readme76) && !/忽略 Ozon 官方白底规范/.test(readme76), "");
  check("README 白底开关条目标注为「风格偏好开关，不是合规开关」",
    /风格偏好开关，不是合规开关/.test(readme76), "");

  // 5. 关键：出图 prompt 的实际行为一行都不能变（这次只改注释/文案，不改逻辑）
  check("主图 prompt 仍然明确要求非纯白底（行为不变，唯标签更准）",
    /NOT a plain pure-white studio background/.test(plan76), "");
  check("非白底背景规则仍在（其余方向的非纯白约束未被误删）",
    /Фон — не чисто-белый/.test(prompts76), "");
  check("白底开关逻辑仍受 allowWhiteBg + studio 双重约束（未被误改）",
    /direction\?\.id === "studio" && allowWhiteBg/.test(prompts76), "");
  check("IMAGE_HARD_RULES 仍未被改动（禁中文/俄文硬约束原样）",
    /ВСЕ НАДПИСИ НА ИЗОБРАЖЕНИИ — ТОЛЬКО НА РУССКОМ ЯЗЫКЕ/.test(prompts76)
    && /ТОВАР НЕИЗМЕНЕН/.test(prompts76), "");

  check("版本号升到 1.9.76 及以上",
    manifest76.version.split(".").map(Number)[0] > 1
    || (manifest76.version.split(".").map(Number)[1] === 9 && manifest76.version.split(".").map(Number)[2] >= 76),
    manifest76.version);
}

console.log("=== v1.9.77 类目匹配修复（空气炸锅被推荐成钢琴：超哥截图实证）===");
{
  const manifest77 = JSON.parse(fs.readFileSync(path.join(HERE, "../manifest.json"), "utf8"));
  const kw77 = fs.readFileSync(path.join(HERE, "../src/shared/category-keywords.js"), "utf8").replace(/\r\n/g, "\n");
  const panel77 = fs.readFileSync(path.join(HERE, "../src/ui/panel.js"), "utf8").replace(/\r\n/g, "\n");

  // —— 行为验证 1：domainsOfPath 单字符收紧（键盘乐器不再被「盘」误判进厨房用品）——
  check("词典：domainsOfPath 走收紧版（路径判定用 countDomainHitsInPath）",
    /countDomainHitsInPath\(joined, domain\.keywords\)/.test(kw77)
    && /minLen = \/\[\\\\u4e00-\\\\u9fa5\]\/\.test\(w\) \? 2 : 3/.test(kw77.replace(/\\/g, "\\\\")), "");
  check("词典：新增「家用电器」领域且含空气炸锅/аэрогриль",
    /domain: "家用电器"/.test(kw77) && /"空气炸锅"/.test(kw77) && /аэрогриль/.test(kw77), "");

  // 真跑：import 模块验证钢琴路径不再命中厨房用品
  const kwMod = await import(pathToFileURL(path.join(HERE, "../src/shared/category-keywords.js")).href);
  check("行为：钢琴路径不再被误判进任何领域（旧版因单字「盘」判进厨房用品）",
    JSON.stringify(kwMod.domainsOfPath(["乐器", "键盘乐器", "原声三角钢琴"])) === "[]",
    JSON.stringify(kwMod.domainsOfPath(["乐器", "键盘乐器", "原声三角钢琴"])));
  check("行为：真厨房路径仍正常命中厨房用品（收紧不误伤）",
    kwMod.domainsOfPath(["住宅与花园", "烹饪配件", "厨房剪刀"]).includes("厨房用品"), "");
  check("行为：空气炸锅路径命中新「家用电器」领域",
    kwMod.domainsOfPath(["家用电器", "慢炖锅、面包机、空气烤架", "空气炸锅"]).includes("家用电器"), "");
  check("行为：空气炸锅商品文本 top 领域 = 家用电器",
    kwMod.detectProductDomains({ title: "厂家多功能空气炸锅家用大容量无油电炸锅烤箱一体" })[0]?.domain === "家用电器",
    JSON.stringify(kwMod.detectProductDomains({ title: "厂家多功能空气炸锅家用大容量无油电炸锅烤箱一体" }).slice(0, 2)));

  // —— 验证 2：scoreCategoryLeaf 标题锚定闸（源码静态断言；行为已在独立复现脚本验证：
  //    污染文本下钢琴叶子归 0、空气炸锅叶子照常高分，见 2026-10-02 日志）——
  check("面板：scoreCategoryLeaf 有标题锚定闸（末级类型名须与 product.title 有交集，否则 return 0）",
    /const rawTitle = String\(product\?\.title \|\| ""\)\.trim\(\);/.test(panel77)
    && /const leafName = String\(path\[path\.length - 1\] \|\| ""\)\.trim\(\);/.test(panel77)
    && /if \(!anchored\) return 0;/.test(panel77), "");
  check("面板：锚定闸对 product.title 缺失时跳过（rawTitle && leafName 双条件，兼容旧调用）",
    /if \(rawTitle && leafName\) \{/.test(panel77), "");

  // —— 行为验证 3：AI 失败原因可见化 ——
  check("面板：兜底通道状态行带上 AI 具体失败原因",
    /标题文字兜底（AI 未给出可用结果\$\{aiError \? `：\$\{aiError\}` : ""\}/.test(panel77), "");

  check("版本号升到 1.9.77 及以上",
    manifest77.version.split(".").map(Number)[0] > 1
    || (manifest77.version.split(".").map(Number)[1] === 9 && manifest77.version.split(".").map(Number)[2] >= 77),
    manifest77.version);
}

console.log("=== v1.9.78 SW 动态 import 根因修复 + 加载属性按钮反馈 ===");
{
  const manifest78 = JSON.parse(fs.readFileSync(path.join(HERE, "../manifest.json"), "utf8"));
  const sw78 = fs.readFileSync(path.join(HERE, "../src/background/service-worker.js"), "utf8").replace(/\r\n/g, "\n");
  const panel78 = fs.readFileSync(path.join(HERE, "../src/ui/panel.js"), "utf8").replace(/\r\n/g, "\n");

  // —— 根因：MV3 service worker 禁用动态 import()，旧版 AI 类目匹配每次死在加载类目树 ——
  check("后台：类目树改顶层静态 import（OZON_CATEGORY_TREE_BUNDLE）",
    /^import \{ OZON_CATEGORY_TREE_BUNDLE \} from "\.\.\/\.\.\/assets\/ozon-category-tree\.js";/m.test(sw78), "");
  check("后台：loadCategoryTreeBundle 内不再有动态 import()（超哥截图 import is disallowed 根因）",
    !/import\("\.\.\/\.\.\/assets\/ozon-category-tree/.test(sw78), "");
  check("后台：整个 service-worker 无任何动态 import(",
    !/[^a-zA-Z]import\(/.test(sw78), "");
  check("后台：loadCategoryTreeBundle 仍返回 Promise（调用方零改动）",
    /function loadCategoryTreeBundle\(\)/.test(sw78) && /return _categoryTreeBundlePromise;/.test(sw78), "");

  // —— 加载类目属性按钮的运行态反馈（超哥：点了没反应，其实在跑）——
  check("面板：loadCategoryAttributes 点击即置灰改字「加载中…」",
    /async function loadCategoryAttributes/.test(panel78)
    && /btn\.disabled = true; btn\.textContent = "加载中…"/.test(panel78), "");
  check("面板：加载全程状态条按阶段推进（拉定义→翻译→校验→完成）",
    /正在拉取官方属性定义/.test(panel78) && /正在翻译中文名/.test(panel78)
    && /正在校验属性值/.test(panel78) && /已加载 \$\{list2\.length\} 项属性/.test(panel78), "");
  check("面板：loadCategoryAttributes 有 finally 恢复按钮（成功/失败都能解锁）",
    /finally \{\s*if \(btn\) \{ btn\.disabled = false; btn\.textContent = prevText/.test(panel78), "");

  check("版本号升到 1.9.78 及以上",
    manifest78.version.split(".").map(Number)[0] > 1
    || (manifest78.version.split(".").map(Number)[1] === 9 && manifest78.version.split(".").map(Number)[2] >= 78),
    manifest78.version);
}

console.log("=== v1.9.79 品牌化：LOGO + 名称改为 OWA ===");
{
  const manifest79 = JSON.parse(fs.readFileSync(path.join(HERE, "../manifest.json"), "utf8"));
  const html79 = fs.readFileSync(path.join(HERE, "../src/ui/panel.html"), "utf8").replace(/\r\n/g, "\n");
  const css79 = fs.readFileSync(path.join(HERE, "../src/ui/panel.css"), "utf8").replace(/\r\n/g, "\n");

  check("manifest：name 与 short_name 都是 OWA",
    manifest79.name === "OWA" && manifest79.short_name === "OWA", `${manifest79.name}/${manifest79.short_name}`);
  check("manifest：action.default_title 是 OWA",
    manifest79.action?.default_title === "OWA", String(manifest79.action?.default_title));
  check("面板：标题 <title> 是 OWA", /<title>OWA<\/title>/.test(html79), "");
  check("面板：顶栏有 .brand 容器（logo + h1 并排）",
    /class="brand"/.test(html79) && /class="brand-logo"/.test(html79) && /<h1[^>]*>OWA<\/h1>/.test(html79), "");
  check("面板：logo 引用扩展图标 assets/icon48.png",
    /brand-logo" src="\.\.\/\.\.\/assets\/icon48\.png"/.test(html79), "");
  check("CSS：.brand 与 .brand-logo 规则已加（inline-flex + 圆角）",
    /\.brand \{/.test(css79) && /\.brand-logo \{/.test(css79) && /border-radius: 5px/.test(css79), "");
  check("CSS：旧布局断言锚点 .topbar h1 规则仍在（h1 未被移出 topbar）",
    css79.includes(".topbar h1 {\n  margin: 0;\n  font-size: 14px;"), "");

  // 三尺寸图标是真 PNG 且尺寸正确（16/48/128 方图，RGBA）
  const pngSig = Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]);
  for (const size of [16, 48, 128]) {
    const buf = fs.readFileSync(path.join(HERE, "../assets", `icon${size}.png`));
    const isPng = buf.subarray(0, 8).equals(pngSig);
    // PNG IHDR：宽高在大端偏移 16 / 20 处
    const w = isPng ? buf.readUInt32BE(16) : 0;
    const h = isPng ? buf.readUInt32BE(20) : 0;
    check(`图标 icon${size}.png 是真 PNG 且 ${size}×${size}`, isPng && w === size && h === size, `${w}x${h}`);
  }
  // 图标已换成 OWA（不再是旧的占位小图标）：体积应显著大于旧的 <1KB 占位
  const big = fs.statSync(path.join(HERE, "../assets/icon128.png")).size;
  check("图标已替换为 OWA（icon128 体积明显增大，非旧占位）", big > 2000, `${big}B`);

  check("版本号升到 1.9.79 及以上",
    manifest79.version.split(".").map(Number)[0] > 1
    || (manifest79.version.split(".").map(Number)[1] === 9 && manifest79.version.split(".").map(Number)[2] >= 79),
    manifest79.version);
}

console.log("=== v1.9.80 点版本号检查更新（超哥：方便别人更新）===");
{
  const manifest80 = JSON.parse(fs.readFileSync(path.join(HERE, "../manifest.json"), "utf8"));
  const panel80 = fs.readFileSync(path.join(HERE, "../src/ui/panel.js"), "utf8").replace(/\r\n/g, "\n");
  const settings80 = fs.readFileSync(path.join(HERE, "../src/shared/settings.js"), "utf8").replace(/\r\n/g, "\n");
  const html80 = fs.readFileSync(path.join(HERE, "../src/ui/panel.html"), "utf8").replace(/\r\n/g, "\n");
  const css80 = fs.readFileSync(path.join(HERE, "../src/ui/panel.css"), "utf8").replace(/\r\n/g, "\n");
  const man80 = JSON.stringify(manifest80);

  // 行为验证：compareVersions 纯函数（从源码抽取真跑）
  const cvStart = panel80.indexOf("function compareVersions");
  const cvEnd = panel80.indexOf("/**", cvStart + 10);
  const cvSrc = panel80.slice(cvStart, cvEnd);
  const compareVersions = new Function(`${cvSrc}; return compareVersions;`)();
  check("compareVersions：1.9.81 > 1.9.80", compareVersions("1.9.81", "1.9.80") === 1, "");
  check("compareVersions：1.10.0 > 1.9.9（按段比数字，不是字符串）", compareVersions("1.10.0", "1.9.9") === 1, "");
  check("compareVersions：相等返回 0；旧于当前返回 -1",
    compareVersions("1.9.80", "1.9.80") === 0 && compareVersions("1.9.79", "1.9.80") === -1, "");
  check("compareVersions：脏输入不抛异常（空/非数字按 0）",
    compareVersions("", "1.0.0") === -1 && compareVersions("v1.9.80".replace("v", ""), "1.9.80") === 0, "");

  check("设置：DEFAULT_SETTINGS 有 updateUrl 字段（老客户手填值兼容位，v1.9.86 起界面不再暴露）", /updateUrl: ""/.test(settings80), "");
  check("面板：保存不再写 updateUrl（v1.9.86 起更新源内置）",
    !/updateUrl: cleanText\(\$\("#set-update-url"\)/.test(panel80), "");
  check("面板：回填不再碰 set-update-url（v1.9.86 输入框已移除）",
    !/\$\("#set-update-url"\)\.value = s\.updateUrl/.test(panel80), "");
  check("面板：版本号绑定 click → checkForUpdate（含 title 提示）",
    /versionNode\.addEventListener\("click", \(\) => checkForUpdate\(versionNode\)\)/.test(panel80)
    && /versionNode\.title = "点击检查新版本"/.test(panel80), "");
  check("面板：checkForUpdate 优先设置手填值、回落内置地址（v1.9.86 零配置）",
    /async function checkForUpdate/.test(panel80)
    && /cleanText\(state\.settings\?\.updateUrl\) \|\| cleanText\(BUILT_IN_UPDATE_URL\)/.test(panel80), "");
  check("面板：检查更新走 fetch JSON + 缓存击穿参数 t=", /cache=no-store|cache: "no-store"/.test(panel80) && /t=\$\{Date\.now\(\)\}/.test(panel80), "");
  check("面板：有新版弹确认框并 chrome.downloads.download 下载 zip",
    /chrome\.downloads\.download\(\{ url: zipUrl, filename, saveAs: true \}\)/.test(panel80), "");
  check("面板：已是最新/失败/完成三态都会恢复版本号显示（finally）",
    /finally \{[\s\S]{0,200}versionNode\.textContent = `v\$\{current\}`/.test(panel80), "");
  check("manifest：downloads 权限在位（检查更新依赖）", /"downloads"/.test(man80), "");
  check("CSS：版本号可点样式（cursor:pointer + hover 高亮 + checking 态）",
    /#ext-version \{[\s\S]*cursor: pointer/.test(css80) && /#ext-version:hover/.test(css80) && /#ext-version\.checking/.test(css80), "");

  check("版本号升到 1.9.80 及以上",
    manifest80.version.split(".").map(Number)[0] > 1
    || (manifest80.version.split(".").map(Number)[1] === 9 && manifest80.version.split(".").map(Number)[2] >= 80),
    manifest80.version);
}

console.log("=== v1.9.81 七项优化（超哥 15:23-15:34 排队需求）===");
{
  const manifest81 = JSON.parse(fs.readFileSync(path.join(HERE, "../manifest.json"), "utf8"));
  const panel81 = fs.readFileSync(path.join(HERE, "../src/ui/panel.js"), "utf8").replace(/\r\n/g, "\n");
  const prompts81 = fs.readFileSync(path.join(HERE, "../src/shared/prompts.js"), "utf8").replace(/\r\n/g, "\n");

  // —— 行为验证：buildImportItems 真跑（需求 1/3/6 同一条链路）——
  const v81draft = {
    title: "空气炸锅", ru: { title: "Аэрогриль 5.5л", keywords: ["аэрогриль", "5.5 л", "без масла"] },
    skus: [
      { id: "s1", label: "白色", specs: { 颜色: "白色" }, image: "https://e.com/w.jpg" },
      { id: "s2", label: "黑色", specs: { 颜色: "黑色" }, image: "https://e.com/b.jpg" },
    ],
    images: ["https://e.com/w.jpg"],
    pricing: { priceCny: 200, oldPriceCny: 260, perSku: {} },
    attributeValues: { "10096": "红色" },
  };
  const v81attrs = [
    { id: 10096, name: "Цвет", is_aspect: true },
    { id: 9048, name: "Название модели" },
    { id: 23171, name: "#Тематический тег" },
    { id: 4191, name: "Аннотация" },
  ];
  const v81items = buildImportItems(v81draft, {
    pricing: v81draft.pricing, selectedSkus: v81draft.skus,
    categoryAttributes: v81attrs, attributeValues: v81draft.attributeValues,
  });
  const colorOf = (it) => it.attributes.find((a) => a.id === 10096)?.values[0]?.value;
  check("需求3：变体属性优先占位——各 SKU 用自己的颜色，产品级「红色」不再把全部变体挤成同色（真 bug 修复）",
    v81items.length === 2 && colorOf(v81items[0]) === "白色" && colorOf(v81items[1]) === "黑色",
    `${colorOf(v81items[0])}/${colorOf(v81items[1])}`);
  check("需求1：型号名称属性 9048 没填时自动补 model_name（合并卡片依据）",
    v81items.every((it) => {
      const a = it.attributes.find((x) => x.id === 9048);
      return a && a.values[0].value === it.model_name;
    }), JSON.stringify(v81items[0].attributes.find((x) => x.id === 9048)));
  check("需求6：主题标签 23171 没填时自动把搜索关键词拼成 #词（去空格去#）",
    v81items[0].attributes.find((a) => a.id === 23171)?.values[0]?.value === "#аэрогриль #5.5л #безмасла",
    String(v81items[0].attributes.find((a) => a.id === 23171)?.values[0]?.value));
  const v81manual = buildImportItems({ ...v81draft, attributeValues: { "9048": "Моя модель" } }, {
    pricing: v81draft.pricing, selectedSkus: v81draft.skus,
    categoryAttributes: v81attrs, attributeValues: { "9048": "Моя модель" },
  });
  const m9048 = v81manual[0].attributes.filter((a) => a.id === 9048);
  check("自动补齐不覆盖手填、不重复写（9048 手填「Моя модель」原样保留且只有一条）",
    m9048.length === 1 && m9048[0].values[0].value === "Моя модель", JSON.stringify(m9048));
  const v81noKw = buildImportItems({ ...v81draft, ru: { title: "Аэрогриль" } }, {
    pricing: v81draft.pricing, selectedSkus: [v81draft.skus[0]],
    categoryAttributes: v81attrs, attributeValues: {},
  });
  check("没有关键词时不硬造主题标签（宁缺毋滥）",
    !v81noKw[0].attributes.some((a) => a.id === 23171), "");

  // —— 行为验证：富内容挑图（需求 5 根因）——
  const rcPicked = pickRichContentImages({
    images: [
      "https://cbu01.alicdn.com/img/xxx.jpg_460x460q100.jpg_.webp",
      "https://img.alicdn.com/bao/zzz.jpg_.webp",
      "https://x/plain.png",
      "https://x/g.gif",
    ],
  }, 6);
  check("需求5：1688 转码后缀图（.jpg_460x460…_.webp）先还原成真实原图再进富内容（旧版整批剔光报「没有可用图片」）",
    rcPicked.length === 3 && rcPicked.every((p) => /\.(jpe?g|png)$/i.test(p.url)) && rcPicked.some((p) => /zzz\.jpg$/.test(p.url)),
    JSON.stringify(rcPicked.map((p) => p.url)));

  // —— 静态断言：需求 2（prompt 去重约束）——
  check("需求2：属性填写提示词加了「不要把描述整段复制进属性值」的去重约束",
    /НЕ переноси целиком текст аннотации\/описания в атрибут/.test(prompts81), "");

  // —— 静态断言：需求 4（套图提示讲人话）——
  check("需求4：「套图不可用」提示改为可操作说明（服务器打不开 + 拦下原因 + 解法）",
    /这些套图 Ozon 服务器打不开/.test(panel81) && /加进草稿上传后会被判「没有照片」并封锁/.test(panel81)
    && /已拦下 \$\{bad\.length\} 张/.test(panel81), "");

  // —— 静态断言：需求 7（SKU 主图自动替换 + 防 AI 生 AI + 还原）——
  check("需求7：AI 主图生成后自动替换该变体主图（sku.image=AI图，原图存 originalImage）",
    /sku\.image = uploadable;/.test(panel81) && /sku\.originalImage = original/.test(panel81), "");
  check("需求7：参考图优先 originalImage（再生成不会拿 AI 图当参考，防 AI 生 AI）",
    /const sourceUrl = sku\.originalImage \|\| sku\.image/.test(panel81), "");
  check("需求7：对比弹窗的「原图」取 originalImage（替换后不会 AI 图对 AI 图）",
    /original: sku\.originalImage \|\| sku\.image/.test(panel81), "");
  check("需求7：还原 = 主图换回 originalImage + 两个字段一起清",
    /const backTo = original \|\| rest\[0\]/.test(panel81) && /delete sku\.originalImage;/.test(panel81), "");
  check("需求7：纯 base64（无直链）不替换主图，只进预览位",
    /if \(uploadable\) \{[\s\S]{0,200}\} else \{[\s\S]{0,200}只返回了本地预览图/.test(panel81), "");

  check("版本号升到 1.9.81 及以上",
    manifest81.version.split(".").map(Number)[0] > 1
    || (manifest81.version.split(".").map(Number)[1] === 9 && manifest81.version.split(".").map(Number)[2] >= 81),
    manifest81.version);
}

console.log("=== v1.9.83 SKU 表默认只显示选用的（超哥：没选中的不需要显示）===");
{
  const manifest83 = JSON.parse(fs.readFileSync(path.join(HERE, "../manifest.json"), "utf8"));
  const panel83 = fs.readFileSync(path.join(HERE, "../src/ui/panel.js"), "utf8").replace(/\r\n/g, "\n");
  const html83 = fs.readFileSync(path.join(HERE, "../src/ui/panel.html"), "utf8").replace(/\r\n/g, "\n");

  check("面板：renderSkuSection 按选用过滤（selectedList / visibleSkus）",
    /const selectedList = skus\.filter\(\(sku\) => state\.selectedSkus\.has\(sku\.id\)\);/.test(panel83)
    && /const visibleSkus = showUnselected \|\| !selectedList\.length \? skus : selectedList;/.test(panel83), "");
  check("面板：SKU 表数据源是 visibleSkus（不再是全量 skus）",
    /\], visibleSkus, \{/.test(panel83), "");
  check("面板：防死锁兜底——一个都没选用时强制显示全部（否则取消勾选后找不回行）",
    /showUnselected \|\| !selectedList\.length/.test(panel83), "");
  check("面板：隐藏计数提示「已隐藏 N 个未选用 SKU」",
    /已隐藏 \$\{hiddenCount\} 个未选用 SKU/.test(panel83), "");
  check("面板：「显示未选用」开关 change 时重渲染",
    /\$\("#sku-show-unselected"\)\?\.addEventListener\("change"/.test(panel83)
    && /renderSkuSection\(state\.draft\.skus \|\| \[\], state\.draft\.specOptions \|\| \[\]\)/.test(panel83), "");
  check("HTML：开关与计数节点存在",
    /id="sku-show-unselected"/.test(html83) && /id="sku-hidden-count"/.test(html83), "");
  check("面板：取消勾选该行立即从表消失（重渲染），勾选方向不重渲染",
    /state\.selectedSkus\.delete\(id\);[\s\S]{0,200}renderSkuSection\(state\.draft\?\.skus \|\| \[\], state\.draft\?\.specOptions \|\| \[\]\)/.test(panel83), "");
  check("面板：手动添加的行自动选用（否则一加上就被过滤「消失」）",
    /state\.selectedSkus\.add\(created\.id\);/.test(panel83)
    && /skus: \[\.\.\.skus, created\], selectedSkus: \[\.\.\.state\.selectedSkus\]/.test(panel83), "");

  check("版本号升到 1.9.83 及以上",
    manifest83.version.split(".").map(Number)[0] > 1
    || (manifest83.version.split(".").map(Number)[1] === 9 && manifest83.version.split(".").map(Number)[2] >= 83),
    manifest83.version);
}

console.log("=== v1.9.84 图片探测 HEAD 403 误杀修复（超哥：已拦下 8 张 Ozon 抓不到）===");
{
  const manifest84 = JSON.parse(fs.readFileSync(path.join(HERE, "../manifest.json"), "utf8"));
  const sw84 = fs.readFileSync(path.join(HERE, "../src/background/service-worker.js"), "utf8").replace(/\r\n/g, "\n");

  check("探测：HEAD 回落 GET 的状态码列表含 401/403（万相 OSS 签名链 HEAD 必 403，旧列表漏了）",
    /\[400, 401, 403, 404, 405, 501\]\.includes\(response\.status\)/.test(sw84), "");
  check("探测：GET 复核只取头部即取消（不整图下载）",
    /response = await fetch\(url, \{ method: "GET", signal: controller\.signal, credentials: "omit" \}\);\s*\n\s*\/\/ GET 只取头部[\s\S]{0,120}response\.body\?\.cancel/.test(sw84), "");
  check("探测：GET 仍失败才判坏（HTTP 状态进 reason）",
    /if \(!response\.ok\) return \{ url, ok: false, reason: `HTTP \$\{response\.status\}` \};/.test(sw84), "");
  check("探测：data:/blob: 依旧直接拦（真拦不误伤）",
    /本地 base64 图（data:）/.test(sw84) && /本地 blob 地址/.test(sw84), "");

  check("版本号升到 1.9.84 及以上",
    manifest84.version.split(".").map(Number)[0] > 1
    || (manifest84.version.split(".").map(Number)[1] === 9 && manifest84.version.split(".").map(Number)[2] >= 84),
    manifest84.version);
}

console.log("=== v1.9.85 SKU 区新增「添加库存」按钮（超哥需求）===");
{
  const manifest85 = JSON.parse(fs.readFileSync(path.join(HERE, "../manifest.json"), "utf8"));
  const panel85 = fs.readFileSync(path.join(HERE, "../src/ui/panel.js"), "utf8").replace(/\r\n/g, "\n");
  const html85 = fs.readFileSync(path.join(HERE, "../src/ui/panel.html"), "utf8").replace(/\r\n/g, "\n");

  check("HTML：按钮在「手动添加一行」旁边，带 title 说明",
    /id="btn-sku-add-stock" title="[^"]*库存[^"]*"/.test(html85), "");
  check("面板：无草稿/无选用 SKU 都有明确提示（不静默）",
    /\$\("#btn-sku-add-stock"\)\?\.addEventListener/.test(panel85)
    && /请先采集或载入草稿/.test(panel85.split("btn-sku-add-stock")[1].slice(0, 600))
    && /没有已选用的 SKU/.test(panel85.split("btn-sku-add-stock")[1].slice(0, 600)), "");
  check("面板：弹窗复用 openModal（自带提交禁用+处理中+失败保弹窗重试）",
    /title: "添加库存",[\s\S]{0,1200}onSubmit: async \(values\) => \{/.test(panel85), "");
  check("面板：只列已选用 SKU（未选用不参与上传，改它们没意义）",
    /const candidates = getSelectedSkus\(\);/.test(panel85), "");
  check("面板：库存校验（0 以上整数，非法值抛错给 toast）",
    /if \(!Number\.isFinite\(next\) \|\| next < 0\) throw new Error\("库存必须是 0 以上的整数"\)/.test(panel85), "");
  check("面板：成功后写回草稿 + 重渲染 SKU 区 + ok 提示",
    /sku\.stock = next;[\s\S]{0,200}saveDraft\(\{ id: state\.draft\.id, skus: state\.draft\.skus \}\)[\s\S]{0,120}refreshSkuSection\(\)[\s\S]{0,120}库存已更新为 \$\{next\}/.test(panel85), "");

  check("版本号升到 1.9.85 及以上",
    manifest85.version.split(".").map(Number)[0] > 1
    || (manifest85.version.split(".").map(Number)[1] === 9 && manifest85.version.split(".").map(Number)[2] >= 85),
    manifest85.version);
}

console.log("=== v1.9.86 更新源内置化：点版本号零配置检查更新（超哥：这个不需要显示，点击即可更新）===");
{
  const manifest86 = JSON.parse(fs.readFileSync(path.join(HERE, "../manifest.json"), "utf8"));
  const panel86 = fs.readFileSync(path.join(HERE, "../src/ui/panel.js"), "utf8").replace(/\r\n/g, "\n");
  const html86 = fs.readFileSync(path.join(HERE, "../src/ui/panel.html"), "utf8").replace(/\r\n/g, "\n");
  const const86 = fs.readFileSync(path.join(HERE, "../src/shared/constants.js"), "utf8").replace(/\r\n/g, "\n");

  check("constants：BUILT_IN_UPDATE_URL 已导出（发布者填一处，所有客户共用）",
    /export const BUILT_IN_UPDATE_URL = /.test(const86), "");
  check("面板：checkForUpdate 用「设置手填值 || 内置地址」（老客户灰度值优先，新客户零配置）",
    /const url = cleanText\(state\.settings\?\.updateUrl\) \|\| cleanText\(BUILT_IN_UPDATE_URL\);/.test(panel86), "");
  check("设置页：更新源输入框已移除（不再暴露给客户）",
    !/set-update-url/.test(html86) && !/更新源地址/.test(html86), "");
  check("设置页：留了一句「更新源已内置，无需配置」说明",
    /更新源已内置/.test(html86), "");
  check("面板：未配置时提示改为「联系发布者」（不再引导客户去设置页填地址）",
    !/请先到「插件设置 → 通用 → 更新源地址」/.test(panel86) && /这个构建没有内置更新源地址/.test(panel86), "");
  check("面板：保存不再写 updateUrl（老客户已存的值原样保留）",
    !/updateUrl: cleanText/.test(panel86), "");

  check("版本号升到 1.9.86 及以上",
    manifest86.version.split(".").map(Number)[0] > 1
    || (manifest86.version.split(".").map(Number)[1] === 9 && manifest86.version.split(".").map(Number)[2] >= 86),
    manifest86.version);
}

console.log("=== v1.9.87 自动检查更新 + 一键发布工具（超哥：客户点击即升级，我发新版不逐个发）===");
{
  const manifest87 = JSON.parse(fs.readFileSync(path.join(HERE, "../manifest.json"), "utf8"));
  const panel87 = fs.readFileSync(path.join(HERE, "../src/ui/panel.js"), "utf8").replace(/\r\n/g, "\n");
  const css87 = fs.readFileSync(path.join(HERE, "../src/ui/panel.css"), "utf8").replace(/\r\n/g, "\n");
  const const87 = fs.readFileSync(path.join(HERE, "../src/shared/constants.js"), "utf8").replace(/\r\n/g, "\n");
  const readme87 = fs.readFileSync(path.join(HERE, "../README.md"), "utf8").replace(/\r\n/g, "\n");
  const releasePy = fs.readFileSync(path.join(HERE, "../tools/release.py"), "utf8").replace(/\r\n/g, "\n");

  check("constants：updateCheck 节流缓存键已加", /updateCheck: "owa_update_check"/.test(const87), "");
  check("面板：fetchUpdateInfo 带 6 小时节流（force 跳过缓存）",
    /async function fetchUpdateInfo\(\{ force = false \}/.test(panel87)
    && /6 \* 3600 \* 1000/.test(panel87), "");
  check("面板：自动检查静默——失败/无新版不出声，有新版只亮徽章+toast 不弹模态",
    /async function autoCheckUpdate/.test(panel87)
    && /if \(info\.error \|\| !info\.latest\) return;/.test(panel87)
    && /点左上角版本号即可升级/.test(panel87), "");
  check("面板：init 挂自动检查（3 秒后跑，不打断首屏渲染）",
    /setTimeout\(\(\) => autoCheckUpdate\(versionNode\), 3000\)/.test(panel87), "");
  check("面板：发现新版徽章红脉冲样式 + title 改「点击升级」",
    /classList\.add\("has-update"\)/.test(panel87) && /点击升级/.test(panel87)
    && /#ext-version\.has-update/.test(css87) && /owa-update-pulse/.test(css87), "");
  check("面板：升级弹窗承诺「不需要重新激活」并自动开 chrome://extensions",
    /不需要重新激活/.test(panel87) && /chrome\.tabs\.create\(\{ url: "chrome:\/\/extensions" \}\)/.test(panel87), "");
  check("面板：手动检查与自动检查共用 fetchUpdateInfo（口径一致）",
    /const info = await fetchUpdateInfo\(\{ force: true \}\);/.test(panel87), "");

  check("release.py：一键发布存在（版本号+1 / 更新JSON / 写内置源 / 打包）",
    /--zip-url/.test(releasePy) && /--update-url/.test(releasePy) && /BUILT_IN_UPDATE_URL/.test(releasePy)
    && /owa-update-/.test(releasePy) && /package\.py/.test(releasePy), "");
  check("release.py：固定源地址只写一次，已有不一致时拒绝覆盖（客户包里的地址必须恒定）",
    /保持原值不改/.test(releasePy), "");
  check("README：客户快速上手 4 步 + 升级零操作说明在",
    /客户快速上手/.test(readme87) && /升级不丢、不用重新激活/.test(readme87) && /tools\/release\.py/.test(readme87), "");

  check("版本号升到 1.9.87 及以上",
    manifest87.version.split(".").map(Number)[0] > 1
    || (manifest87.version.split(".").map(Number)[1] === 9 && manifest87.version.split(".").map(Number)[2] >= 87),
    manifest87.version);
}

console.log("=== v1.9.89 更新双源回落（GitHub raw 主 + jsDelivr 镜像备，超哥：不挂代理的也要能更）===");
{
  const manifest89 = JSON.parse(fs.readFileSync(path.join(HERE, "../manifest.json"), "utf8"));
  const panel89 = fs.readFileSync(path.join(HERE, "../src/ui/panel.js"), "utf8").replace(/\r\n/g, "\n");
  const const89 = fs.readFileSync(path.join(HERE, "../src/shared/constants.js"), "utf8").replace(/\r\n/g, "\n");
  const release89 = fs.readFileSync(path.join(HERE, "../tools/release.py"), "utf8").replace(/\r\n/g, "\n");
  const man89 = JSON.parse(fs.readFileSync(path.join(HERE, "../manifest.json"), "utf8"));

  check("constants：主源 GitHub raw + 备源 jsDelivr 镜像都在",
    /BUILT_IN_UPDATE_URL = "https:\/\/raw\.githubusercontent\.com\/XaaCaa\/owa-release\/main\/owa-update\.json"/.test(const89)
    && /BUILT_IN_UPDATE_MIRROR = "https:\/\/cdn\.jsdelivr\.net\/gh\/XaaCaa\/owa-release@main\/owa-update\.json"/.test(const89), "");
  check("面板：fetchUpdateInfo 三源数组去重后逐个回落（手填>主>备）",
    /const sources = \[\s*cleanText\(state\.settings\?\.updateUrl\),\s*cleanText\(BUILT_IN_UPDATE_URL\),\s*cleanText\(BUILT_IN_UPDATE_MIRROR\),/.test(panel89)
    && /for \(let i = 0; i < sources\.length; i \+= 1\)/.test(panel89), "");
  check("面板：viaMirror 标记（走备源查到的，下载也优先备链）",
    /viaMirror: i > 0 && !state\.settings\?\.updateUrl/.test(panel89), "");
  check("面板：promptUpdate 备源命中时下载用 url2 镜像链",
    /const downloadUrl = \(viaMirror && zipUrl2\) \? zipUrl2 : zipUrl;/.test(panel89), "");
  check("release.py：to_jsdelivr_mirror 转换函数存在",
    /def to_jsdelivr_mirror\(url\):/.test(release89)
    && /cdn\.jsdelivr\.net\/gh\/\{user\}\/\{repo\}@\{branch\}\/\{path\}/.test(release89), "");
  check("release.py：JSON 自动生成 url2 备链",
    /payload\["url2"\] = mirror/.test(release89), "");
  check("release.py：备源域名也进 host_permissions",
    /for src in \(builtin, mirror_src\):/.test(release89), "");
  check("manifest：jsdelivr 域名已在 host_permissions",
    (man89.host_permissions || []).includes("https://cdn.jsdelivr.net/*"), JSON.stringify((man89.host_permissions||[]).slice(-3)));

  check("版本号升到 1.9.89 及以上",
    manifest89.version.split(".").map(Number)[0] > 1
    || (manifest89.version.split(".").map(Number)[1] === 9 && manifest89.version.split(".").map(Number)[2] >= 89),
    manifest89.version);
}

console.log(failed ? `\n${failed} 项失败` : "\n逻辑测试全部通过");
process.exit(failed ? 1 : 0);
