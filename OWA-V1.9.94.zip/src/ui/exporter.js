// 导出：CSV（UTF-8 BOM，Excel 可直接打开）与最小 XLSX（手写 zip+xml，无第三方依赖）。
import { cleanText } from "../shared/utils.js";
import { buildStableModel } from "../shared/product-model.js";
import { downloadBlob } from "./dom.js";

function csvCell(value) {
  const text = cleanText(value);
  return /[",\n]/.test(text) ? `"${text.replace(/"/g, '""')}"` : text;
}

export function draftToRows(draft) {
  const rows = [];
  const base = [
    cleanText(draft.ru?.title || draft.title),
    cleanText(draft.ru?.shortDescription),
    cleanText(draft.ru?.description),
    (draft.ru?.keywords || []).join(", "),
    cleanText(draft.ru?.categoryHint),
    draft.costCny || "",
    draft.pricing?.priceRub || "",
    draft.pricing?.oldPriceRub || "",
    draft.pricing?.profitRub || "",
    draft.pricing?.actualMarginRate || "",
    (draft.images || []).join(" | "),
    cleanText(draft.sourceUrl),
  ];
  if (draft.skus?.length) {
    for (const sku of draft.skus) {
      rows.push([...base, cleanText(sku.label), sku.price || "", sku.stock || "", cleanText((sku.images || [sku.image]).filter(Boolean).join(" | ")),
        cleanText(sku.skuGroup || draft.skuGroup), cleanText(sku.skuClassification?.status || "unclassified")]);
    }
  } else {
    rows.push([...base, "", "", "", "", cleanText(draft.skuGroup), cleanText(draft.skuClassification?.status || "unclassified")]);
  }
  return rows;
}

export const EXPORT_HEADERS = [
  "俄语标题", "卖点", "描述", "关键词", "建议类目",
  "成本CNY", "售价RUB", "划线价RUB", "利润RUB", "利润率%",
  "图片", "来源链接", "SKU", "SKU价格", "SKU库存", "SKU图片", "SKU商品组", "SKU分类状态",
];

export function exportCsv(drafts, filename = "ozon-drafts.csv") {
  const lines = [EXPORT_HEADERS.map(csvCell).join(",")];
  for (const draft of [].concat(drafts)) {
    for (const row of draftToRows(draft)) lines.push(row.map(csvCell).join(","));
  }
  const blob = new Blob(["\uFEFF" + lines.join("\r\n")], { type: "text/csv;charset=utf-8" });
  downloadBlob(filename, blob);
}

/* ---------------- OZON 上架表（对齐「上架表」口径） ---------------- */

// 列序与用户自用的上架表逐列一致：A 序号 → AE 密度
export const LISTING_HEADERS = [
  "序号", "货号", "采集平台", "采集商品名称", "采集商品链接", "采集规格",
  "采集价格(CNY)", "运费（¥）", "渠道", "拿货成本\n（¥）", "平台售价\n（￥）", "平台售价\n（₽）",
  "活动折扣", "活动售价\n（¥）", "活动售价\n（₽）", "广告出价", "广告费用", "平台佣金", "佣金",
  "重量（g）", "国际物流\n（¥）", "OZON结算", "提现金额", "店铺利润",
  "利润率", "利润百分比", "物流利润率", "长", "宽", "高", "密度",
];

const LISTING_COL = {
  seq: "A", sku: "B", platform: "C", title: "D", url: "E", spec: "F",
  price: "G", freight: "H", channel: "I", cost: "J", priceCny: "K", priceRub: "L",
  discount: "M", promoCny: "N", promoRub: "O", adRate: "P", adFee: "Q",
  commissionRate: "R", commission: "S", weight: "T", logistics: "U",
  settlement: "V", withdrawal: "W", profit: "X", purchaseRate: "Y",
  salesRate: "Z", logisticsRate: "AA", length: "AB", width: "AC", height: "AD", density: "AE",
};

/**
 * 把草稿按上架表口径展开成行（含 Excel 公式，导出后可直接改售价看利润变化）。
 * @param {object} draft 草稿（含 skus / parcel / logistics）
 * @param {object} template OZON 核价模板（见 pricing.normalizeListingTemplate）
 * @param {number} startRow 起始 Excel 行号（第 1 行是表头）
 */
export function draftToListingRows(draft, template = {}, startRow = 2) {
  const t = template || {};
  const rate = Number(t.exchangeRate) || 10.5;
  const withdrawal = Number(t.withdrawalRate) || 0.993;
  const divisor = Number(t.volumetricDivisor) || 12000;
  const freight = Number(draft?.logistics?.freightCny) || 0;
  const parcel = draft?.parcel || {};
  const weightG = Math.round((Number(parcel.weightKg) || 0) * 1000) || Number(draft?.weightG) || 0;
  const lengthCm = Number(parcel.lengthCm) || 0;
  const widthCm = Number(parcel.widthCm) || 0;
  const heightCm = Number(parcel.heightCm) || 0;
  const skus = (draft?.skus || []).length ? draft.skus : [{ id: "", label: "", price: draft?.costCny || 0, stock: 0 }];

  return skus.map((sku, index) => {
    const r = startRow + index;
    const basePrice = Number(sku.basePrice) || Number(sku.price) || 0;
    const cost = Number(sku.price) || basePrice;
    const calc = sku.calc || null;
    const priceCny = Number(calc?.priceCny) || Number(t.priceCny) || 0;
    const discount = Number(calc?.discountRate ?? t.discountRate) || 0;
    const adRate = Number(calc?.adRate ?? (Number(t.adRate) || 0) / 100) || 0;
    const commissionRate = Number(calc?.commissionRate ?? (Number(t.commissionRate) || 0) / 100) || 0;
    const a = Number(calc?.logisticsA) || 0;
    const b = Number(calc?.logisticsB) || 0;
    const C = LISTING_COL;
    return [
      index + 1,                                                     // A 序号
      buildStableModel(draft, sku, draft?.skuPrefix),                   // B 货号/型号
      cleanText(draft?.platform),                                     // C 采集平台
      cleanText(draft?.title),                                        // D 采集商品名称
      cleanText(draft?.sourceUrl),                                    // E 采集商品链接
      cleanText(sku.label),                                           // F 采集规格
      basePrice,                                                      // G 采集价格
      freight || "",                                                  // H 运费
      cleanText(calc?.channelLabel || t.channelLabel || ""),          // I 渠道
      { f: `${C.price}${r}+${C.freight}${r}` },                       // J 拿货成本
      priceCny,                                                       // K 平台售价¥
      { f: `${C.priceCny}${r}*${rate}` },                             // L 平台售价₽
      discount,                                                       // M 活动折扣
      { f: `${C.priceCny}${r}-${C.priceCny}${r}*${C.discount}${r}` }, // N 活动售价¥
      { f: `${C.priceRub}${r}-${C.priceRub}${r}*${C.discount}${r}` }, // O 活动售价₽
      adRate,                                                         // P 广告出价
      { f: `${C.promoCny}${r}*${C.adRate}${r}` },                     // Q 广告费用
      commissionRate,                                                 // R 平台佣金
      { f: `${C.promoCny}${r}*${C.commissionRate}${r}` },             // S 佣金
      weightG,                                                        // T 重量 g
      a || b ? { f: `(${a}*${C.weight}${r}+${b})` } : "",             // U 国际物流
      { f: `${C.promoCny}${r}-${C.adFee}${r}-${C.commission}${r}-${C.logistics}${r}` }, // V OZON结算
      { f: `${C.settlement}${r}*${withdrawal}` },                     // W 提现金额
      { f: `${C.withdrawal}${r}-${C.cost}${r}` },                     // X 店铺利润
      { f: `${C.profit}${r}/${C.cost}${r}` },                         // Y 利润率（采购）
      { f: `${C.profit}${r}/${C.promoCny}${r}` },                     // Z 利润百分比（销售）
      { f: `${C.profit}${r}/(${C.cost}${r}+${C.logistics}${r})` },    // AA 物流利润率
      lengthCm,                                                       // AB 长
      widthCm,                                                        // AC 宽
      heightCm,                                                       // AD 高
      { f: `${C.height}${r}*${C.width}${r}*${C.length}${r}/${divisor}` }, // AE 密度
    ];
  });
}

export function exportListingXlsx(drafts, template = {}, filename = "ozon-上架表.xlsx") {
  const rows = [LISTING_HEADERS];
  let cursor = 2;
  for (const draft of [].concat(drafts)) {
    const list = draftToListingRows(draft, template, cursor);
    for (const row of list) rows.push(row);
    cursor += list.length;
  }
  downloadBlob(filename, buildXlsxBlob(rows, { sheetName: "上架表" }));
}

/* ---------------- 最小 XLSX ---------------- */

const CRC_TABLE = (() => {
  const table = new Uint32Array(256);
  for (let i = 0; i < 256; i++) {
    let c = i;
    for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    table[i] = c >>> 0;
  }
  return table;
})();

function crc32(bytes) {
  let crc = 0xffffffff;
  for (let i = 0; i < bytes.length; i++) crc = CRC_TABLE[(crc ^ bytes[i]) & 0xff] ^ (crc >>> 8);
  return (crc ^ 0xffffffff) >>> 0;
}

// 仅实现 stored（不压缩）方式的 zip，XLSX 规范允许。
function zipStore(entries, mime = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet") {
  const encoder = new TextEncoder();
  const chunks = [];
  const central = [];
  let offset = 0;

  for (const entry of entries) {
    const nameBytes = encoder.encode(entry.name);
    const data = entry.data;
    const crc = crc32(data);
    const local = new Uint8Array(30 + nameBytes.length);
    const view = new DataView(local.buffer);
    view.setUint32(0, 0x04034b50, true);
    view.setUint16(4, 20, true);
    view.setUint16(6, 0, true);
    view.setUint16(8, 0, true);
    view.setUint16(10, 0, true);
    view.setUint16(12, 0x2821, true);
    view.setUint32(14, crc, true);
    view.setUint32(18, data.length, true);
    view.setUint32(22, data.length, true);
    view.setUint16(26, nameBytes.length, true);
    view.setUint16(28, 0, true);
    local.set(nameBytes, 30);
    chunks.push(local, data);

    // 中央目录结构：0 签名 / 4 版本 / 6 版本 / 8 标志 / 10 压缩方式 / 12 时间 / 14 日期
    // 16 CRC / 20 压缩后 / 24 压缩前 / 28 文件名长 / 30 扩展长 / 32 注释长
    // 34 磁盘号 / 36 内部属性 / 38 外部属性 / 42 本地头偏移 / 46 文件名
    const dir = new Uint8Array(46 + nameBytes.length);
    const dv = new DataView(dir.buffer);
    dv.setUint32(0, 0x02014b50, true);
    dv.setUint16(4, 20, true);
    dv.setUint16(6, 20, true);
    dv.setUint16(8, 0, true);
    dv.setUint16(10, 0, true);
    dv.setUint16(12, 0, true);
    dv.setUint16(14, 0x2821, true);
    dv.setUint32(16, crc, true);
    dv.setUint32(20, data.length, true);
    dv.setUint32(24, data.length, true);
    dv.setUint16(28, nameBytes.length, true);
    dv.setUint16(30, 0, true);
    dv.setUint16(32, 0, true);
    dv.setUint16(34, 0, true);
    dv.setUint16(36, 0, true);
    dv.setUint32(38, 0, true);
    dv.setUint32(42, offset, true);
    dir.set(nameBytes, 46);
    central.push(dir);

    offset += local.length + data.length;
  }

  const centralSize = central.reduce((sum, item) => sum + item.length, 0);
  const end = new Uint8Array(22);
  const ev = new DataView(end.buffer);
  ev.setUint32(0, 0x06054b50, true);
  ev.setUint16(8, central.length, true);
  ev.setUint16(10, central.length, true);
  ev.setUint32(12, centralSize, true);
  ev.setUint32(16, offset, true);

  return new Blob([...chunks, ...central, end], { type: mime });
}


function escapeXml(value) {
  return String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function columnName(index) {
  let name = "";
  let n = index + 1;
  while (n > 0) {
    const rem = (n - 1) % 26;
    name = String.fromCharCode(65 + rem) + name;
    n = Math.floor((n - 1) / 26);
  }
  return name;
}

function buildSheetXml(rows) {
  const body = rows
    .map((row, r) => {
      const cells = row
        .map((cell, c) => {
          const ref = `${columnName(c)}${r + 1}`;
          // 公式单元格：{ f: "K3*10.5" } —— 导出后 Excel / WPS 会自己重算
          if (cell && typeof cell === "object" && typeof cell.f === "string") {
            return `<c r="${ref}"><f>${escapeXml(cell.f)}</f></c>`;
          }
          const isNumber = typeof cell === "number" && Number.isFinite(cell);
          return isNumber
            ? `<c r="${ref}"><v>${cell}</v></c>`
            : `<c r="${ref}" t="inlineStr"><is><t xml:space="preserve">${escapeXml(cell)}</t></is></c>`;
        })
        .join("");
      return `<row r="${r + 1}">${cells}</row>`;
    })
    .join("");
  return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>${body}</sheetData></worksheet>`;
}

/** 生成 XLSX Blob（纯逻辑，便于单独测试） */
export function buildXlsxBlob(rows, { sheetName = "草稿" } = {}) {
  const encoder = new TextEncoder();
  const toBytes = (text) => encoder.encode(text);
  const safeName = String(sheetName || "草稿").replace(/[\\\/\?\*\[\]:]/g, "_").slice(0, 31) || "草稿";

  const entries = [
    {
      name: "[Content_Types].xml",
      data: toBytes(`<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>`),
    },
    {
      name: "_rels/.rels",
      data: toBytes(`<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>`),
    },
    {
      name: "xl/workbook.xml",
      data: toBytes(`<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="${safeName}" sheetId="1" r:id="rId1"/></sheets></workbook>`),
    },
    {
      name: "xl/_rels/workbook.xml.rels",
      data: toBytes(`<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/></Relationships>`),
    },
    { name: "xl/worksheets/sheet1.xml", data: toBytes(buildSheetXml(rows)) },
  ];

  return zipStore(entries);
}

export function exportXlsx(drafts, filename = "ozon-drafts.xlsx") {
  const rows = [EXPORT_HEADERS];
  for (const draft of [].concat(drafts)) {
    for (const row of draftToRows(draft)) rows.push(row);
  }
  downloadBlob(filename, buildXlsxBlob(rows));
}
