// 面板 DOM 小工具

export function $(selector, root = document) {
  return root.querySelector(selector);
}

export function $$(selector, root = document) {
  return Array.from(root.querySelectorAll(selector));
}

export function el(tag, props = {}, children = []) {
  const node = document.createElement(tag);
  for (const [key, value] of Object.entries(props)) {
    if (value === null || value === undefined || value === false) continue;
    if (key === "class") node.className = value;
    else if (key === "text") node.textContent = value;
    else if (key === "html") node.innerHTML = value;
    else if (key.startsWith("on") && typeof value === "function") node.addEventListener(key.slice(2), value);
    else if (key === "dataset") Object.assign(node.dataset, value);
    else node.setAttribute(key, value === true ? "" : value);
  }
  for (const child of [].concat(children)) {
    if (child === null || child === undefined || child === false) continue;
    node.appendChild(typeof child === "string" ? document.createTextNode(child) : child);
  }
  return node;
}

let toastTimer = null;
export function toast(message, tone = "info") {
  const node = $("#toast");
  if (!node) return;
  node.textContent = message;
  node.hidden = false;
  node.style.background = tone === "error" ? "#a32d2d" : tone === "ok" ? "#0f6e56" : "#1f2328";
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => { node.hidden = true; }, 3000);
}

export function setBadge(selector, text, tone = "") {
  const node = $(selector);
  if (!node) return;
  node.textContent = text;
  node.className = `badge${tone ? ` ${tone}` : ""}`;
}

/**
 * columns: [{ key, label, render?(row), html? }]
 * 指定 html: true 时，render 的返回值按 HTML 插入（用于可编辑单元格）。
 * options.detail：可选，返回一段 HTML 字符串时，会在该行后面插一条整行合并的详情行（默认隐藏，
 *   用于「每个 SKU 下面挂自己的核价面板」这类布局）。返回空值则该行不插详情行。
 */
export function renderTable(selector, columns, rows, options = {}) {
  const table = $(selector);
  if (!table) return;
  table.innerHTML = "";
  const thead = el("thead", {}, [
    el("tr", {}, columns.map((col) => el("th", { text: col.label }))),
  ]);
  const body = [];
  for (const row of rows || []) {
    body.push(
      el(
        "tr",
        {},
        columns.map((col) => {
          const value = col.render ? col.render(row) : row[col.key];
          return col.html
            ? el("td", { html: String(value ?? "") })
            : el("td", { text: String(value ?? "") });
        }),
      ),
    );
    if (typeof options.detail === "function") {
      const detail = options.detail(row);
      if (detail) {
        body.push(el("tr", { class: "row-detail", hidden: true }, [
          el("td", { colspan: String(columns.length), html: String(detail) }),
        ]));
      }
    }
  }
  table.append(thead, el("tbody", {}, body));
}

export function kv(selector, pairs) {
  const node = $(selector);
  if (!node) return;
  node.innerHTML = "";
  for (const [key, value] of pairs) {
    node.append(el("div", { class: "k", text: key }), el("div", { text: String(value ?? "") }));
  }
}

export function switchTab(name) {
  for (const tab of $$(".tab")) tab.classList.toggle("is-active", tab.dataset.tab === name);
  for (const view of $$(".view")) view.classList.toggle("is-active", view.dataset.view === name);
}

/**
 * 自定义模态表单。
 * Chrome 在扩展页面里不弹原生 prompt/confirm（调用即返回空），所以一律用这个替代。
 * fields: [{ key, label, type: text|password|number|checkbox, value, placeholder, hint, options }]
 * 返回填写结果对象，取消时返回 null。
 */
export function openModal({ title, fields = [], submitText = "保存", onSubmit }) {
  return new Promise((resolve) => {
    const overlay = el("div", { class: "modal-overlay" });
    const inputs = {};

    const form = el("form", { class: "modal" }, [
      el("h3", { text: title }),
      ...fields.map((field) => {
        let input;
        if (field.type === "select") {
          input = el("select", {}, (field.options || []).map((opt) =>
            el("option", { value: opt.value, text: opt.label, selected: opt.value === field.value })));
        } else if (field.type === "textarea") {
          // v1.9.49 长文本字段（如「重出此图」时写上一版的问题与调整方向）
          input = el("textarea", { rows: String(field.rows || 3), placeholder: field.placeholder || "" });
          input.value = field.value ?? "";
        } else if (field.type === "checkbox") {
          input = el("input", { type: "checkbox", ...(field.value ? { checked: true } : {}) });
        } else {
          input = el("input", {
            type: field.type || "text",
            value: field.value ?? "",
            placeholder: field.placeholder || "",
            ...(field.step ? { step: field.step } : {}),
          });
        }
        inputs[field.key] = input;
        return el("label", { class: field.type === "checkbox" ? "inline" : "" }, [
          field.type === "checkbox" ? input : null,
          field.type === "checkbox" ? ` ${field.label}` : field.label,
          field.type === "checkbox" ? null : input,
          field.hint ? el("div", { class: "sub", text: field.hint }) : null,
        ]);
      }),
      el("div", { class: "row modal-actions" }, [
        el("button", { type: "submit", class: "primary", text: submitText }),
        el("button", { type: "button", text: "取消", onclick: () => close(null) }),
      ]),
    ]);

    const close = (value) => {
      overlay.remove();
      document.removeEventListener("keydown", onKey);
      resolve(value);
    };
    const onKey = (event) => {
      if (event.key === "Escape") close(null);
    };

    form.addEventListener("submit", async (event) => {
      event.preventDefault();
      const values = {};
      for (const field of fields) {
        const input = inputs[field.key];
        values[field.key] = field.type === "checkbox"
          ? input.checked
          : field.type === "number"
            ? input.value === "" ? "" : Number(input.value)
            : input.value;
      }
      const submit = form.querySelector('button[type="submit"]');
      try {
        if (onSubmit) {
          submit.disabled = true;
          submit.textContent = "处理中…";
          await onSubmit(values);
        }
        close(values);
      } catch (error) {
        submit.disabled = false;
        submit.textContent = submitText;
        toast(error?.message || String(error), "error");
      }
    });

    overlay.addEventListener("click", (event) => {
      if (event.target === overlay) close(null);
    });
    overlay.appendChild(form);
    document.body.appendChild(overlay);
    document.addEventListener("keydown", onKey);

    const first = form.querySelector("input, select");
    if (first) first.focus();
  });
}

/** 自定义确认框，替代原生 confirm */
export function confirmDialog(message, { confirmText = "确定", danger = false } = {}) {
  return new Promise((resolve) => {
    const overlay = el("div", { class: "modal-overlay" });
    const close = (value) => {
      overlay.remove();
      document.removeEventListener("keydown", onKey);
      resolve(value);
    };
    const onKey = (event) => {
      if (event.key === "Escape") close(false);
    };
    overlay.appendChild(
      el("div", { class: "modal" }, [
        el("h3", { text: "请确认" }),
        el("p", { class: "hint", text: message }),
        el("div", { class: "row modal-actions" }, [
          el("button", { class: danger ? "danger" : "primary", text: confirmText, onclick: () => close(true) }),
          el("button", { text: "取消", onclick: () => close(false) }),
        ]),
      ]),
    );
    overlay.addEventListener("click", (event) => {
      if (event.target === overlay) close(false);
    });
    document.body.appendChild(overlay);
    document.addEventListener("keydown", onKey);
  });
}

export function downloadBlob(filename, blob) {
  const url = URL.createObjectURL(blob);
  const anchor = el("a", { href: url, download: filename });
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  setTimeout(() => URL.revokeObjectURL(url), 5000);
}

/** 等待图片解码完成 */
export function loadImage(src) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error("图片解码失败"));
    img.src = src;
  });
}
