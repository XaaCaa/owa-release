// 草稿存储：本地 chrome.storage.local，不上传任何服务器。
import { STORAGE_KEYS } from "../shared/constants.js";
import { createId } from "../shared/utils.js";
import { classifySku, buildStableModel } from "../shared/product-model.js";

async function read(key, fallback) {
  const result = await chrome.storage.local.get(key);
  return result?.[key] ?? fallback;
}

async function write(key, value) {
  await chrome.storage.local.set({ [key]: value });
  return value;
}

export async function listDrafts() {
  const drafts = await read(STORAGE_KEYS.drafts, []);
  return Array.isArray(drafts) ? drafts : [];
}

export async function saveDraft(draft) {
  const drafts = await listDrafts();
  const now = new Date().toISOString();
  if (draft.id && drafts.some((item) => item.id === draft.id)) {
    const next = drafts.map((item) => (item.id === draft.id ? { ...item, ...draft, updatedAt: now } : item));
    return (await write(STORAGE_KEYS.drafts, next)).find((item) => item.id === draft.id);
  }
  const created = { ...draft, id: draft.id || createId("draft"), createdAt: now, updatedAt: now };
  await write(STORAGE_KEYS.drafts, [created, ...drafts]);
  return created;
}

export async function getDraft(id) {
  const drafts = await listDrafts();
  return drafts.find((item) => item.id === id) || null;
}

export async function deleteDraft(id) {
  const drafts = await listDrafts();
  await write(STORAGE_KEYS.drafts, drafts.filter((item) => item.id !== id));
}

export async function clearDrafts() {
  await write(STORAGE_KEYS.drafts, []);
}

/** 把采集结果转成草稿 */
export function draftFromProduct(product) {
  const skuGroup = product.skuGroup || classifySku({}, product).skuGroup;
  return {
    id: createId("draft"),
    platform: product.platform,
    sourceUrl: product.sourceUrl,
    // v1.9.68：商品身份键。面板用它判断「这次采的还是不是同一件商品」——
    // 换了商品就新建草稿，绝不把两件商品的图片并进同一份草稿。
    sourceIdentity: product.captureSource?.identity || "",
    title: product.title,
    // v1.9.74 商品编码：采集源的货号/offerId，导出售价表与上架表时用作货号依据
    productCode: product.productCode || "",
    mainImage: product.mainImage,
    images: product.images || [],
    detailImages: product.detailImages || [],
    imageMeta: product.imageMeta || {},
    videos: product.videos || [],
    skuGroup,
    skuClassification: product.skuClassification || { status: "classified", reason: "" },
    skus: (product.skus || []).map((sku) => ({
      ...sku,
      model: sku.model || buildStableModel(product, sku),
      idSource: sku.idSource || "采集",
      images: Array.isArray(sku.images) && sku.images.length
        ? [...new Set(sku.images.filter(Boolean))].slice(0, 9)
        : (sku.image ? [sku.image] : []),
      skuGroup: sku.skuGroup || skuGroup,
    })),
    specOptions: product.specOptions || [],
    specImages: product.specImages || {},
    attributes: product.attributes || [],
    parcel: product.parcel || { weightKg: 0, lengthCm: 0, widthCm: 0, heightCm: 0, raw: "", dimsRaw: "" },
    logistics: product.logistics || { from: "", freightText: "", freightCny: 0, express: "" },
    shopName: product.shopName,
    costCny: product.price?.min || 0,
    // 采集到的价格区间（区间价商品用 max-min 标记），供定价时人工确认用哪一档成本
    priceMinCny: product.price?.min || 0,
    priceMaxCny: product.price?.max || 0,
    diagnostics: product.diagnostics,
    ru: { title: "", shortDescription: "", description: "", keywords: [], bulletPoints: [], categoryHint: "" },
    pricing: null,
    ozonCategory: null,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };
}
