/**
 * Ozon 官方类目模板「离线属性库」（v1.9.57）。
 *
 * 数据从哪来：超哥从 Ozon 卖家后台下载的类目 XLSX 模板（544 个文件 / 541 个类目）。
 * 每个模板的第二个 sheet 里塞了一份 XLS_TEMPLATE_INFO_BASE64 —— 解码出来就是官方
 * 属性定义全量 JSON：属性 ID / 名称 / 类型 / IsRequired / IsRecommended / IsCollection /
 * MaxValueCount / IsComplex / ComplexID / **LookupData.Values 全量候选值（带 dictionary_value_id）** /
 * Label 中文填写说明。这份数据比 API 还给得多：
 *
 *   1. /v1/description-category/attribute 只给定义，**不给候选值**；
 *   2. /v1/description-category/attribute/values 给候选值，但**每个属性一次请求**，
 *      而且单属性截断 2000 条 —— 品牌、汽车配件这种几十万条的字典根本拿不全；
 *   3. 模板里的候选值是全量，没有 2000 上限，而且**离线**，不发一个请求。
 *
 * 所以现在的策略是「接口管定义，离线库管候选值」：
 *   - 属性定义仍然以接口为准（接口是按 description_category_id + type_id 给的，更精确）；
 *   - 候选值优先吃离线库（0 请求、不截断），离线库没有/被裁掉的才回源；
 *   - 接口彻底不可用时（断网、密钥过期、WAF），整份属性表直接由离线库顶上。
 *
 * 注意一个语义：模板里的 DESCRIPTION_CATEGORY_ID 是**类目 ID**（实测 120 个模板里
 * 117 个命中类目 ID、0 个命中 type_id），不是类型 ID。也就是说离线库是「类目级」的，
 * 接口是「类型级」的。类目级是超集，只在「接口挂了、只能靠离线库」时才会多出
 * 一些该类型其实没有的属性 —— 这时界面会明确标注来源是离线库，不会假装是官方接口数据。
 *
 * 分片：541 个类目拆成 39 个分片（每个几百 KB），用哪个类目读哪个分片，
 * 不做「一次 parse 18MB JSON」这种蠢事。
 */

const KB_DIR = "assets/ozon-kb";
const KB_INDEX = "index.json";
// 离线库把候选值裁掉的分界线：超过这个数的字典一条不留（走接口或搜索反查）
export const OFFLINE_KB_VALUE_CAP = 300;
// 接口 /attribute/values 的单属性上限（超过它接口也拿不全，只能靠 values/search）
export const OZON_API_VALUE_CAP = 2000;

let indexPromise = null;
const shardPromises = new Map();

async function readKbJson(file) {
  const url = chrome.runtime.getURL(`${KB_DIR}/${file}`);
  const response = await fetch(url);
  if (!response.ok) throw new Error(`离线属性库读取失败：${file}（HTTP ${response.status}）`);
  return response.json();
}

/** 类目索引（很小，几十 KB，常驻内存）。读不到返回 null —— 没装离线库不能让插件崩。 */
export async function loadOfflineKbIndex() {
  if (!indexPromise) {
    indexPromise = readKbJson(KB_INDEX).catch(() => {
      indexPromise = null; // 这次失败了，下次还能重试
      return null;
    });
  }
  return indexPromise;
}

/** 该类目在离线库里有没有。顺带把类目中文名带出来，接口挂了也能给用户看。 */
export async function getOfflineCategoryInfo(categoryId) {
  const id = String(categoryId || "");
  if (!id || id === "0") return null;
  const index = await loadOfflineKbIndex();
  const entry = index?.categories?.[id];
  return entry ? { id, ...entry } : null;
}

/**
 * 读某个类目的离线属性定义，返回 { name, folder, attributes }（attributes 已是插件口径）。
 * 类目不在库里返回 null。
 */
export async function loadOfflineCategory(categoryId) {
  const info = await getOfflineCategoryInfo(categoryId);
  if (!info) return null;
  const shard = Number(info.s) || 0;
  if (!shardPromises.has(shard)) {
    shardPromises.set(shard, readKbJson(`kb-${shard}.json`));
  }
  const data = await shardPromises.get(shard);
  const raw = data?.[String(categoryId)];
  if (!raw || !Array.isArray(raw.a)) return null;
  return {
    name: raw.n || info.n || "",
    folder: raw.f || info.f || "",
    attributes: raw.a.map(offlineAttributeToDefinition),
  };
}

/**
 * 离线库里一条属性 → 插件口径的属性定义。
 * 字段故意压成一个字母（离线库 18MB，字段名省一点是一点）。
 *
 * dictionary_id：官方模板 JSON 里**没有**这个字段，只有 LookupData.Values。
 * 上传时 Ozon 认的是 dictionary_value_id，dictionary_id 在插件里只当「是不是枚举」的开关，
 * 所以用属性 ID 当标记值——只要 > 0 界面就会给下拉框、上传就会发 ID。
 */
export function offlineAttributeToDefinition(a = {}) {
  const id = Number(a.id) || 0;
  const total = Number(a.vc) || 0;
  const pairs = Array.isArray(a.v) ? a.v : [];
  const dictionary = pairs
    .map((pair) => ({
      id: Number(Array.isArray(pair) ? pair[0] : pair?.id) || null,
      value: String(Array.isArray(pair) ? pair[1] : pair?.value ?? "").trim(),
      picture: "",
      // v1.9.58：离线库的候选值是中文（模板 LANGUAGE=ZH-HANS）。zh 标记很重要：
      // 上传 payload 里的枚举值必须是俄文官方值，中文值只在「接口拉不到」时
      // 靠 dictionary_value_id 顶上（Ozon 认 ID），界面照常显示中文。
      zh: true,
    }))
    .filter((item) => item.value);
  return {
    id,
    name: String(a.n || ""),
    type: String(a.t || "string").toLowerCase(),
    is_required: Boolean(a.r),
    is_recommended: Boolean(a.rec),
    is_collection: Boolean(a.c),
    max_value_count: Number(a.mc) || 0,
    attribute_complex_id: Number(a.cx) || 0,
    parent_id: Number(a.pa) || 0,
    // is_aspect（变体属性）官方模板 JSON 里也没有，是从模板 sheet1 的「变体特征」
    // 栏位区块反推出来的 —— 多变体上传（v1.9.50）全靠它
    is_aspect: Boolean(a.asp),
    is_shared: Boolean(a.same),
    dictionary_id: total > 0 ? id : 0,
    dictionary,
    // 官方候选值总数（可能被裁）：用来判断「字典不全」到底该回源还是只能搜索
    dictionary_total: total,
    dictionary_state: offlineDictionaryState(total, dictionary.length),
    hint: String(a.h || ""),
  };
}

/**
 * 候选值在离线库里的状态：
 *  - full   ≤300：全量在本地，不用发请求；
 *  - api    300<总数≤2000：本地没留，走 /attribute/values 能拿全；
 *  - huge   >2000：接口也拿不全，只能靠 /values/search 按词反查；
 *  - none   该属性没有候选值（自由文本）。
 */
export function offlineDictionaryState(total = 0, stored = 0) {
  if (!total) return "none";
  if (stored && stored >= total) return "full";
  if (total <= OZON_API_VALUE_CAP) return "api";
  return "huge";
}

/** 含中文（属性名/候选值判定用，和面板 isZh 口径一致） */
export function isChineseText(s) {
  return /[\u4e00-\u9fa5]/.test(String(s || ""));
}

/**
 * 属性类型 → 中文（v1.9.58）。离线库与接口的 Type 就这七种（官方模板全量统计），
 * 界面「类型」列和校验报告不再露 string/decimal 这种英文。
 */
const ATTR_TYPE_ZH = {
  string: "文本",
  decimal: "小数",
  double: "小数",
  numeric: "小数",
  integer: "整数",
  multiline: "多行文本",
  boolean: "是/否",
  url: "链接",
  imageurl: "图片链接",
  image_list: "图片链接",
  images: "图片链接",
  guid: "编号",
  cncf_guid: "编号",
  date: "日期",
};
export function attrTypeZh(type) {
  const key = String(type || "").trim().toLowerCase();
  return ATTR_TYPE_ZH[key] || key || "文本";
}

/**
 * 用离线库给接口返回的属性定义「补货」：中文显示名、变体标记、必填/推荐、中文填写说明、字典真实规模。
 *
 * ⚠️ v1.9.58 重要调整：候选值（attr.dictionary）**默认不用离线库填**，仍由接口拉俄文官方值。
 * 原因：上传 payload 里枚举属性的 value 必须是俄文官方值（模板是 ZH-HANS 出的，候选值是中文翻译，
 * 只有 dictionary_value_id 是全局官方 ID）。接口 values 端点对 ≤2000 条的字典本来就是全量，
 * 离线库在「值」上没有信息增量；它的独特价值是**中文显示层**和接口挂掉时的兜底
 * （那时才传 fillDictionaries: true，中文值 + 官方 ID 一起发，Ozon 认 ID）。
 *
 * v1.9.58 中文显示层（超哥：类目属性内容全部中文，严格以官方模板为准）：
 * 属性名（「商品颜色」而非 Цвет）、候选值（「蔚蓝色」而非 Голубой）、填写说明在模板里全是中文，
 * 且属性 ID / 字典值 ID 与接口数据能按 ID 精确对上。所以：
 *  - 属性名：按 ID 命中离线库 → displayName 直接取模板中文（比 AI 翻译权威，0 请求）；
 *  - 候选值：接口拉的俄文值按 dictionary_value_id 命中离线库 → displayValue 取模板中文；
 *  - 对不上的（离线库没有这个属性/这个字典值）一律不动，留给 AI 翻译兜底，
 *    翻译也没有的由界面标「（需确认）」——绝不硬编一个中文塞进去。
 * 返回补了多少条，给界面显示「N 个属性名、M 个候选值对齐官方中文」。
 */
export function enrichAttributesFromOffline(attributes = [], offline = null, options = {}) {
  const fillDictionaries = Boolean(options.fillDictionaries);
  const offlineAttrs = offline?.attributes || [];
  if (!attributes.length || !offlineAttrs.length) return { dictionaries: 0, aspects: 0, hints: 0, zhNames: 0, zhValues: 0 };
  const map = new Map(offlineAttrs.map((attr) => [String(attr.id), attr]));
  let dictionaries = 0;
  let aspects = 0;
  let hints = 0;
  let zhNames = 0;
  let zhValues = 0;
  for (const attr of attributes) {
    const off = map.get(String(attr.id));
    if (!off) continue;
    // —— 中文显示层：按官方 ID 对齐，模板中文直接当 displayName/displayValue ——
    if (!isChineseText(attr.displayName) && isChineseText(off.name)) {
      attr.displayName = String(off.name).trim();
      zhNames += 1;
    }
    const apiDict = Array.isArray(attr.dictionary) ? attr.dictionary : [];
    if (apiDict.length && off.dictionary.length) {
      const zhById = new Map();
      for (const v of off.dictionary) {
        const vid = Number(v.id) || 0;
        if (vid && isChineseText(v.value)) zhById.set(vid, String(v.value).trim());
      }
      for (const item of apiDict) {
        const zh = zhById.get(Number(item.id) || 0);
        if (zh && !isChineseText(item.displayValue)) {
          item.displayValue = zh;
          zhValues += 1;
        }
      }
    }
    if (fillDictionaries && !(apiDict.length > 0) && off.dictionary.length) {
      attr.dictionary = off.dictionary;
      dictionaries += 1;
    }
    // 字典规模信息一律以离线库为准：它才是「这个属性到底有多少候选值」的真话
    if (!attr.dictionary_total) attr.dictionary_total = off.dictionary_total;
    if (!attr.dictionary_state || attr.dictionary_state === "none") attr.dictionary_state = off.dictionary_state;
    if (!attr.is_aspect && off.is_aspect) {
      attr.is_aspect = true;
      aspects += 1;
    }
    if (!attr.is_recommended && off.is_recommended) attr.is_recommended = true;
    if (!attr.hint && off.hint) {
      attr.hint = off.hint;
      hints += 1;
    }
    // 接口说不是枚举、离线库说有候选值：信离线库，否则界面给文本框、上传被判「请从列表中选择」
    if (!(Number(attr.dictionary_id) > 0) && off.dictionary_id > 0) attr.dictionary_id = off.dictionary_id;
  }
  return { dictionaries, aspects, hints, zhNames, zhValues };
}
