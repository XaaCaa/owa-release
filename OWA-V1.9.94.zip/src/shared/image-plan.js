/**
 * 「策划师模式」核心模块（v1.9.73 重构生图提示词体系）。
 *
 * 超哥给的方法论：为产品先提炼卖点（按对下单决策的影响力排序、标出唯一「最强卖点」），
 * 再产出 8 张结构固定的商品图方案（主图 / 核心卖点 / 卖点② / 使用场景 / 尺寸规格 / 细节特写 /
 * 包装清单 / 模特）。每张含三段：中文画面描述、图内俄文文案、英文出图 prompt。
 *
 * 设计边界（务必守住）：
 *  1. 图内**渲染的文字永远是俄文**——生图模型只画俄文字，超哥文档里「图内俄文文案」即此意；
 *     「英文出图 prompt」是给图像模型的**画面指令**（构图/光影/材质），不是画上去的字。
 *  2. 复用既有硬约束（俄罗斯面孔、禁中文/中式元素、产品本体零改动、非纯白底）——见 image-prompts.js IMAGE_HARD_RULES。
 *     关于「非纯白底」：Ozon 没有主图白底强制规定，官方信息图工具本就鼓励加俄文标签；详见本文件 buildPlannedPrompt 的注释。
 *  3. 与旧的「逐张轮换版式」出图并存：面板用开关切换，旧链路一行不动，老自测全保。
 *  4. 本模块是纯逻辑（无 chrome / 无网络 / 无 DOM），Node 可直接 import 测试。
 */

import { IMAGE_HARD_RULES } from "./image-prompts.js";

/* ------------------------------------------------------------------ *
 * 8 张图的固定结构（超哥文档第二步那张表，一一对应）
 * ------------------------------------------------------------------ */

export const PLAN_8_SHOTS = Object.freeze([
  {
    slot: 1, key: "hero", label: "主图",
    task: "让买家一秒认出产品",
    hard: "炫酷拼接背景实物图，产品居中占画面 70% 以上，精简最强卖点展示（背景非纯白）",
    // 主图带「精简最强卖点」小面积展示，但主体仍是产品本身
    textMode: "hero",
  },
  {
    slot: 2, key: "core-benefit", label: "核心卖点图",
    task: "打最强卖点",
    hard: "大号俄文标题 + 产品特写，优势标注明确；这张承载第①步标出的「唯一最强卖点」",
    textMode: "headline",
  },
  {
    slot: 3, key: "benefit-2", label: "卖点图②",
    task: "打第二卖点",
    hard: "功能拆解 / 结构说明，可用箭头标注",
    textMode: "breakdown",
  },
  {
    slot: 4, key: "scene", label: "使用场景图",
    task: "让人代入自己",
    hard: "真实生活场景（俄式家居或户外），有手部或模特互动，体现解决了什么麻烦",
    textMode: "none",
  },
  {
    slot: 5, key: "size", label: "尺寸规格图",
    task: "消除尺寸顾虑",
    hard: "尺寸标注 + 关键参数表，用俄制单位 см / кг / мл",
    textMode: "spec",
  },
  {
    slot: 6, key: "detail", label: "细节特写图",
    task: "证明做工",
    hard: "材质纹理、接缝、接口等微距特写",
    textMode: "none",
  },
  {
    slot: 7, key: "package", label: "包装清单图",
    task: "消除漏发顾虑",
    hard: "包装盒 + 全部配件平铺，逐项标数量",
    textMode: "package",
  },
  {
    slot: 8, key: "model", label: "模特图",
    task: "临门一脚",
    hard: "俄罗斯人使用该产品的图片",
    textMode: "none",
  },
]);

/** 出图统一比例（超哥要求 3:4） */
export const PLAN_ASPECT = "3:4";

/** 全套统一的收尾指令：比例 + 风格一致 + 俄文地道 + 不夸大。每段 prompt 末尾都拼。 */
export const PLAN_UNIFIED_SUFFIX = Object.freeze([
  "Aspect ratio 3:4, portrait orientation, high resolution, sharp focus.",
  "All images in this set share one consistent art direction: same color palette, same typography style, same lighting setup — as if shot by one photographer for the same brand.",
  "Any on-image text must be natural, idiomatic Russian as used by Ozon buyers; never machine-translation phrasing.",
  "Never exaggerate claims or show anything inconsistent with the real product (Ozon review + returns risk).",
]);

/* ------------------------------------------------------------------ *
 * 第一步：给 LLM 的「策划 + 出方案」总提示词（卖点表 + 8 图一次产出）
 * ------------------------------------------------------------------ */

/** 把商品信息压成一段给模型看的中文+俄文混合摘要（方案模块自用，不依赖 prompts.js 私有函数） */
export function compactBrief(product = {}) {
  const attrs = (product.attributes || [])
    .slice(0, 20)
    .map((a) => `${(a.name || "").trim()}: ${(a.value ?? "").toString().trim()}`)
    .filter((line) => line.replace(/^[^:]*:\s*/, "").length)
    .join("\n");
  const skus = (product.skus || [])
    .slice(0, 20)
    .map((s) => `${s.label || Object.values(s.specs || {}).join("/")} — ${s.price ?? ""}`.trim())
    .filter(Boolean)
    .join("\n");
  const desc = String(product.description || "").slice(0, 1200);
  return [
    `产品名称 / 已识别俄文标题：${(product.ru && (product.ru.title || product.ru.productType)) || ""}`,
    `原始标题（中文/采集）：${product.title || ""}`,
    product.ozonCategory && product.ozonCategory.path
      ? `Ozon 类目：${[].concat(product.ozonCategory.path).join(" > ")}` : "",
    attrs ? `核心参数/属性：\n${attrs}` : "",
    skus ? `规格 SKU：\n${skus}` : "",
    desc ? `商品描述：\n${desc}` : "",
    product.targetAudience ? `目标人群：${product.targetAudience}` : "",
    product.pricePosition ? `价格带/竞品：${product.pricePosition}` : "",
  ].filter(Boolean).join("\n\n");
}

export const PLAN_SYSTEM_PROMPT = [
  "你是俄罗斯头部电商平台 OZON 的资深商品视觉策划，同时也是俄语卖点文案专家。",
  "你的任务分两步，一次性完成：第一步先给这个产品提炼卖点并按对下单决策的影响力排序；第二步按固定 8 张图结构产出可直接上架的商品图方案。",
  "硬性要求：",
  "- 第一步：5~8 个卖点，按影响力从高到低排序；每个卖点含「中文卖点(买家得到什么好处，不罗列参数)」「俄文短句(≤6 个词、OZON 买家一眼能懂、地道不机翻)」「视觉证据(这张图拍什么才能让人相信)」。",
  "- 必须从这些卖点里挑出【唯一】的「最强卖点」(bestIndex，指向卖点数组下标)；它必须出现在第 2 张图(核心卖点图)。",
  "- 第二步：严格输出 8 张图，顺序与职责固定，不得增删：",
  "  1 主图：让买家一秒认出产品——炫酷拼接背景实物图，产品居中占画面70%以上，精简展示最强卖点。",
  "  2 核心卖点图：打最强卖点——大号俄文标题+产品特写，优势标注明确。",
  "  3 卖点图②：打第二卖点——功能拆解/结构说明，可用箭头标注。",
  "  4 使用场景图：让人代入自己——真实生活场景(俄式家居或户外)，有手部或模特互动，体现解决了什么麻烦。",
  "  5 尺寸规格图：消除尺寸顾虑——尺寸标注+关键参数表，用俄制单位 см/кг/мл。",
  "  6 细节特写图：证明做工——材质纹理、接缝、接口等微距特写。",
  "  7 包装清单图：消除漏发顾虑——包装盒+全部配件平铺，逐项标数量。",
  "  8 模特图：临门一脚——俄罗斯人使用该产品。",
  "- 每张图给三段：sceneZh(中文画面描述，写给摄影/美术看) / ruText(图上要渲染的俄文文案；无字图填空字符串) / promptEn(英文出图指令，写给图像生成模型：构图、主体占比、背景、光位、镜头、材质)。",
  "- promptEn 只描述画面，绝不把要渲染的俄文当成 prompt 的一部分塞进去(那是 ruText 的活)；但要在 promptEn 里说明「图上留出版面放俄文标题/标注」的位置意图。",
  "- 图内所有文字只用俄文，禁止出现中文、英文标签；文字要少而大(每行3~5个词)。",
  "- 全套风格统一：同一配色、同一字体、同一光位，像同一位摄影师为同一品牌所拍。",
  "- 不得夸大、不得与实物不符；产品参数只能来自给你的资料，资料没有的不要编造(需要推断的在中文卖点里标注「推测」)。",
  "- 不得出现真实第三方品牌 logo、名人肖像。模特/使用者一律为俄罗斯(斯拉夫/欧洲)面孔。",
  "只输出严格合法的 JSON，不要任何解释文字或 markdown 包裹。JSON 结构：",
  '{"sellingPoints":[{"zh":"中文卖点","ru":"≤6词俄文短句","evidence":"视觉证据"}],"bestIndex":0,"shots":[{"slot":1,"type":"主图","sceneZh":"中文画面描述","ruText":"图上俄文(无字则空串)","promptEn":"English image prompt"}]}',
].join("\n");

/**
 * 生成「策划师模式」请求消息。
 * @param {object} product  草稿/商品对象
 * @param {object} options  { extraInfo, audience, pricePosition, points(已有卖点,可选) }
 */
export function buildPlanMessages(product = {}, options = {}) {
  const extra = String(options.extraInfo || "").trim();
  const givenPoints = Array.isArray(options.points) ? options.points.filter(Boolean) : [];
  const userPayload = [
    "【产品资料】",
    compactBrief(product),
    extra ? `\n【补充信息(图上看不到但属实，可用于文案)】\n${extra}` : "",
    options.audience ? `\n【目标人群】\n${options.audience}` : "",
    options.pricePosition ? `\n【价格带/竞品】\n${options.pricePosition}` : "",
    givenPoints.length ? `\n【已有的候选卖点(可采纳、可重排、可补充)】\n${givenPoints.join("\n")}` : "",
    "\n现在按两步产出：先卖点表(带排序与唯一最强卖点)，再 8 张图方案。只返回 JSON。",
  ].filter(Boolean).join("\n");

  return [
    { role: "system", content: PLAN_SYSTEM_PROMPT },
    { role: "user", content: userPayload },
  ];
}

/* ------------------------------------------------------------------ *
 * 解析 + 校验 LLM 返回的方案
 * ------------------------------------------------------------------ */

const hasChinese = (s) => /[\u4e00-\u9fa5]/.test(String(s || ""));
const RU_WORD_LIMIT = 8; // ≤6 词是要求，>8 词才判失败（留点宽容，连字符/数字算词有歧义）

function ruWordCount(text) {
  return String(text || "").trim().split(/\s+/).filter(Boolean).length;
}

/**
 * 解析方案 JSON，返回 { ok, data?, problems[] }。
 * 宽容处理：能补的补（缺字段填空串），原则性错误记进 problems 让界面提示，
 * 但整体仍返回可用结构——不因个别小瑕疵丢掉整份方案。
 * 唯一「致命」：8 张不全 / 卖点表空 → ok=false（出图无从下手）。
 */
export function parsePlanResult(text) {
  const raw = String(text || "").trim();
  const body = (raw.match(/\{[\s\S]*\}/) || [raw])[0];
  let parsed = null;
  try { parsed = JSON.parse(body); } catch { return { ok: false, problems: ["AI 返回的不是合法 JSON，无法解析"] }; }
  if (!parsed || typeof parsed !== "object") return { ok: false, problems: ["AI 返回结构为空"] };

  const problems = [];

  // 卖点表
  const spRaw = Array.isArray(parsed.sellingPoints) ? parsed.sellingPoints : [];
  const sellingPoints = spRaw.map((item) => ({
    zh: String((item && item.zh) || "").trim(),
    ru: String((item && item.ru) || "").trim(),
    evidence: String((item && item.evidence) || "").trim(),
  })).filter((item) => item.zh || item.ru);
  if (!sellingPoints.length) problems.push("没有解析到卖点(第一步)");
  sellingPoints.forEach((item, i) => {
    if (hasChinese(item.ru)) problems.push(`卖点${i + 1}俄文短句里混入了中文，图上会出现汉字`);
    else if (item.ru && ruWordCount(item.ru) > RU_WORD_LIMIT) problems.push(`卖点${i + 1}俄文短句过长(${ruWordCount(item.ru)}词，建议≤6词)`);
  });

  // 最强卖点索引
  let bestIndex = Number(parsed.bestIndex);
  if (!Number.isInteger(bestIndex) || bestIndex < 0 || bestIndex >= sellingPoints.length) bestIndex = 0;
  if (sellingPoints.length && !Number.isInteger(Number(parsed.bestIndex))) problems.push("AI 未明确指定最强卖点，默认按第一个");

  // 8 张图
  const shotsRaw = Array.isArray(parsed.shots) ? parsed.shots : [];
  const bySlot = new Map();
  shotsRaw.forEach((item) => {
    const slot = Number(item && item.slot);
    if (Number.isInteger(slot) && slot >= 1 && slot <= 8 && !bySlot.has(slot)) bySlot.set(slot, item);
  });
  const shots = PLAN_8_SHOTS.map((tpl) => {
    const got = bySlot.get(tpl.slot) || {};
    return {
      slot: tpl.slot,
      key: tpl.key,
      label: tpl.label,
      task: tpl.task,
      hard: tpl.hard,
      textMode: tpl.textMode,
      type: String(got.type || tpl.label).trim(),
      sceneZh: String(got.sceneZh || "").trim(),
      // 图上渲染文字：中文一律剔除（模型只画俄文），俄文保留
      ruText: hasChinese(got.ruText) ? "" : String(got.ruText || "").trim(),
      promptEn: String(got.promptEn || "").trim(),
    };
  });

  // 缺哪张（AI 少给且 sceneZh/promptEn 都空才算缺；有模板兜底不会真缺）
  PLAN_8_SHOTS.forEach((tpl) => {
    const got = bySlot.get(tpl.slot);
    if (!got || (!String(got.promptEn || "").trim() && !String(got.sceneZh || "").trim())) {
      problems.push(`第 ${tpl.slot} 张「${tpl.label}」AI 没给画面，将用结构说明兜底出图`);
    }
  });
  // 俄文文案里不该出现的英文单词单独提示（ruText 混英文标签）
  shots.forEach((shot) => {
    if (shot.ruText && /[A-Za-z]/.test(shot.ruText) && !/[а-яА-Я]/.test(shot.ruText)) {
      problems.push(`第 ${shot.slot} 张图上文案是纯英文(${shot.ruText})，应为俄文`);
    }
  });

  // 只要卖点表非空就出方案：个别张 AI 没给画面时靠 fallbackScene 兜底 + 报告提示（不整批失败），
  // 用户可在该张卡里手动补 promptEn 重出。唯一致命是连卖点都没有——那 8 张无从谈起。
  const fatal = !sellingPoints.length;

  return {
    ok: !fatal,
    problems,
    data: {
      sellingPoints,
      bestIndex,
      bestPoint: sellingPoints[bestIndex] || null,
      shots,
      // 结构化「最强卖点→第2图」校验：第2图若没承载 best 卖点俄文，提示（不致命）
      coreCarriesBest: (() => {
        const core = shots.find((s) => s.key === "core-benefit");
        const best = sellingPoints[bestIndex];
        if (!core || !best) return false;
        const needle = (best.ru || "").toLowerCase();
        return !!needle && (core.ruText || "").toLowerCase().includes(needle.slice(0, Math.min(12, needle.length)));
      })(),
    },
  };
}

/* ------------------------------------------------------------------ *
 * 把一张方案图编译成「喂给图像模型的最终 prompt」
 * ------------------------------------------------------------------ */

/** 图内文字指令（俄文渲染），不同 textMode 排版口径不同 */
function textInstruction(shot, bestPoint) {
  const ru = shot.ruText;
  switch (shot.textMode) {
    case "hero":
      return joinRu([
        ru ? `Small clean Russian badge on the side (not covering the product): "${ru}".` : "",
        "Minimal on-image text: product is the hero.",
      ]);
    case "headline": {
      const strongest = bestPoint && bestPoint.ru ? bestPoint.ru : "";
      return joinRu([
        "Large bold Russian headline, the most prominent element, placed clear of the product.",
        ru ? `Headline text (render exactly, Russian only): "${ru || strongest}".` : (strongest ? `Headline text (render exactly): "${strongest}".` : ""),
        "Short supporting line under it if space allows, few words, Russian.",
      ]);
    }
    case "breakdown":
      return joinRu([
        "Callout labels with thin arrow lines pointing to the relevant part of the product.",
        ru ? `Label texts (Russian only): "${ru}".` : "",
        "Text not overlapping the product; every part stays fully visible and undistorted.",
      ]);
    case "spec":
      return joinRu([
        "Dimension lines with measurement callouts using Russian units (см / кг / мл / мм).",
        ru ? `Parameter labels to render (Russian, no digits garbled): "${ru}".` : "",
        "Thin leader lines, small tidy font, numbers accurate, no fake text.",
      ]);
    case "package":
      return joinRu([
        "Each included item laid out flat with a small Russian count/label (e.g. " + '"' + "×2" + '"' + ").",
        ru ? `Contents labels (Russian): "${ru}".` : "",
        "Nothing overlaps the products; neat knolling arrangement.",
      ]);
    default:
      return joinRu(["No text on this image, no watermark, no logos."]);
  }
}

function joinRu(parts) { return parts.filter(Boolean).join(" "); }

/** 结构兜底画面描述（AI 漏给时用，保证仍出得了这张图） */
function fallbackScene(shot) {
  return {
    hero: "front view, product centered and filling over 70% of the frame, vibrant layered/gradient studio backdrop (NOT pure white), clean product-only shot",
    "core-benefit": "close-up of the product with the single strongest benefit emphasized, generous clear space for a large headline",
    "benefit-2": "product shown disassembled/highlighting structure and mechanism, space for arrow callouts",
    scene: "product in a realistic Russian home or outdoor setting, hands or a person interacting, solving a everyday inconvenience",
    size: "product on neutral backdrop with dimension arrows and a compact spec panel around it",
    detail: "macro close-up of material texture, seams and connection points, shallow depth of field",
    package: "the box plus every accessory spread neatly (knolling) on a light surface",
    model: "a person of Slavic/European appearance using the product naturally, waist-up, product clearly visible and unobstructed",
  }[shot.key] || "product-centered commercial photo, clean composition";
}

/**
 * 生成最终英文出图 prompt：英文画面指令 + 俄文渲染文字 + 硬约束 + 统一后缀。
 * @param {object} shot  parsePlanResult 产出的 shots[i]
 * @param {object} opts  { bestPoint, context(商品是什么), styleHint(品类风格), allowWhiteBg }
 */
export function buildPlannedPrompt(shot, opts = {}) {
  const bestPoint = opts.bestPoint || null;
  const context = String(opts.context || "").trim();
  const styleHint = String(opts.styleHint || "").trim();

  // 画面主体：AI 的 promptEn 优先，缺则英文兜底场景；再把中文 sceneZh 剔掉（模型读英文）
  const sceneEn = shot.promptEn && shot.promptEn.trim()
    ? shot.promptEn.trim()
    : `${fallbackScene(shot)}. (Planner intent: ${shot.task})`;

  // 主图（slot1）按超哥拍板：炫酷拼接背景 + 精简最强卖点、非纯白底。
  // 注意：Ozon 并无「主图必须纯白底」的官方规范（那是亚马逊的规则，被国内服务商软文抄串了）。
  // Ozon 官方 Seller Center 自带 Design Tool / Card Enhancement（模板 #34 之类）就是给主图加俄文标签和色块的，
  // 俄区货架上卖得好的主图基本都是信息图，不是白底图。所以「非纯白底」不是违规绕过，而是适配 Ozon 的实际打法。
  // 其余图的背景交给各自 promptEn 描述（模型自己会按画面类型选景），这里不额外加背景指令。
  const bgNote = shot.key === "hero"
    ? "Background: dynamic composed/gradient collage backdrop, NOT a plain pure-white studio background."
    : "";

  const parts = [
    `Ozon marketplace product card photo.`,
    context ? `Product: ${context}.` : "",
    sceneEn,
    bgNote,
    styleHint ? `Art style: ${styleHint}.` : "",
    // 本体不变（俄文硬约束里也有，这里英文再强调一次给只读英文的模型）
    "Keep the product itself exactly as-is — shape, color, material, proportions, logo and packaging unchanged; do not add or remove parts.",
    "Photorealistic, commercial studio quality, high resolution, no distortion or artifacts.",
    textInstruction(shot, bestPoint),
    ...IMAGE_HARD_RULES.map((line) => `(${line})`),
    ...PLAN_UNIFIED_SUFFIX,
  ];
  return parts.filter(Boolean).join("\n");
}

/* ------------------------------------------------------------------ *
 * 方案导出（超哥：要能导出文件）—— Markdown，可读可粘给任何人
 * ------------------------------------------------------------------ */

export function renderPlanMarkdown(plan, meta = {}) {
  const { sellingPoints = [], bestIndex = 0, shots = [] } = plan || {};
  const lines = [];
  lines.push(`# ${meta.title || "OZON 商品图方案"}（策划师模式）`);
  if (meta.category) lines.push(`\n> 类目：${meta.category}`);
  lines.push(`\n生成时间：${meta.at || ""}\n`);

  lines.push("## 第一步 · 卖点清单（按对下单决策影响力排序）");
  lines.push("");
  lines.push("| # | 中文卖点 | 俄文短句 | 视觉证据 |");
  lines.push("| --- | --- | --- | --- |");
  sellingPoints.forEach((p, i) => {
    const star = i === bestIndex ? " ⭐最强" : "";
    lines.push(`| ${i + 1}${star} | ${p.zh || ""} | ${p.ru || ""} | ${p.evidence || ""} |`);
  });
  lines.push("");
  lines.push(`> 唯一最强卖点（第 ${bestIndex + 1} 条）已安排在第 2 张「核心卖点图」。`);

  lines.push("");
  lines.push("## 第二步 · 8 张图方案");
  shots.forEach((s) => {
    lines.push("");
    lines.push(`### ${s.slot}. ${s.label}（${s.task}）`);
    if (s.hard) lines.push(`- **硬性要求**：${s.hard}`);
    if (s.sceneZh) lines.push(`- **画面描述**：${s.sceneZh}`);
    if (s.ruText) lines.push(`- **图内俄文**：${s.ruText}`);
    if (s.promptEn) { lines.push(`- **英文出图 prompt**：`); lines.push(""); lines.push("  ```"); lines.push(`  ${s.promptEn}`); lines.push("  ```"); }
  });
  lines.push("");
  lines.push("---");
  lines.push("出图统一规范：比例 3:4；全套同配色/同字体/同光位；图内只俄文、少而大；不夸大、不与实物不符。");
  return lines.join("\n");
}
