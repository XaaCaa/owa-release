// 通用工具：数值解析、文本清理、URL 规范化、ID 生成。

export function cleanText(value) {
  return String(value ?? "")
    .replace(/\s+/g, " ")
    .trim();
}

// 从任意字符串里抽出第一个数字，支持千分位、逗号小数点、中文金额符号。
export function parseNumber(value) {
  if (typeof value === "number") return Number.isFinite(value) ? value : 0;
  const raw = String(value ?? "").replace(/[^\d.,\-]/g, "");
  if (!raw) return 0;
  // 同时存在 , 和 . 时，靠后者的是小数点
  let normalized = raw;
  const lastComma = raw.lastIndexOf(",");
  const lastDot = raw.lastIndexOf(".");
  if (lastComma > -1 && lastDot > -1) {
    normalized = lastComma > lastDot
      ? raw.replace(/\./g, "").replace(",", ".")
      : raw.replace(/,/g, "");
  } else if (lastComma > -1) {
    const decimals = raw.length - lastComma - 1;
    normalized = decimals === 3 ? raw.replace(/,/g, "") : raw.replace(",", ".");
  }
  const parsed = Number.parseFloat(normalized);
  return Number.isFinite(parsed) ? parsed : 0;
}

export function roundTo(value, decimals = 2) {
  const factor = 10 ** decimals;
  return Math.round((Number(value) || 0) * factor) / factor;
}

export function clampNumber(value, min, max) {
  const n = Number(value) || 0;
  return Math.min(max, Math.max(min, n));
}

// 图片 URL 规范化：补全协议、去掉防盗链/尺寸裁剪参数里明显降质的一段。
// 必须与 src/content/adapter-base.js 的 normalizeImageUrl 行为一致 —— 采集端剥一次、
// 面板/后台再剥一次，两边规则不同就会出现「采集拿原图、上传前又被改回小图」。
export function normalizeImageUrl(url, pageOrigin = "") {
  let value = cleanText(url);
  if (!value) return "";
  if (value.startsWith("//")) value = `https:${value}`;
  else if (value.startsWith("/") && pageOrigin) value = `${pageOrigin}${value}`;
  if (!/^https?:\/\//i.test(value)) return "";
  // 阿里 OSS 的 query 缩放参数只会降画质，去掉；其它 query（签名/版本号）保留，避免把地址改坏。
  value = value.replace(/([?&])x-oss-process=[^&]*/gi, "$1")
    .replace(/([?&])&+/g, "$1")
    .replace(/[?&]+$/, "");
  // v1.9.62 拼多多的 query 缩放走腾讯云数据万象（?imageMogr2/thumbnail/400x400、
  //   ?imageView2/2/w/400/h/400），同样只降画质还常顺带转成 webp，去掉即回原图。
  if (PDD_IMAGE_HOST_RE.test(value)) {
    value = value.replace(/([?&])(?:imageMogr2|imageView2)\/[^&]*/gi, "$1")
      .replace(/([?&])&+/g, "$1")
      .replace(/[?&]+$/, "");
  }
  // 去掉 .60x60 / _400x400 之类的缩略图后缀，尽量取原图
  value = value.replace(/\._\d+x\d+(?:q\d+)?\.(jpg|jpeg|png|webp)$/i, ".$1");
  // 点号尺寸后缀只对已知图床动手（与 content/adapter-base.js 同步）：
  // 别的站点可能真把文件命名成 photo.1920x1080.jpg，裁了就 404
  if (SIZE_SUFFIX_HOST_RE.test(value)) {
    value = value.replace(/\.(\d+)x(\d+)\.(jpg|jpeg|png|webp)$/i, ".$3");
    // 阿里系的「小图」标记：abc.jpg.sum.jpg（sum = summary，图集列表用的小图）
    value = value.replace(/\.(jpe?g|png|webp)\.sum\.(jpe?g|png|webp)$/i, ".$1");
    // 阿里系的「单下划线」尺寸后缀：abc.jpg_400x400q90.jpg / abc.jpg_.webp
    value = value.replace(
      /\.(jpe?g|png|webp|gif)_[qQ]?\d+x\d+(?:[qQ]\d+)?[a-z]{0,2}\.(jpe?g|png|webp|gif)$/i,
      ".$1",
    );
    value = value.replace(/\.(jpe?g|png|webp|gif)_\.(jpe?g|png|webp|gif)$/i, ".$1");
  }
  // 拼多多的「点号变体」后缀：<base>.jpeg.w800.jpeg / .h800 / .q75 → <base>.jpeg。
  // 拼多多自己的「原图」标记 <base>.jpeg.a.jpeg 不受影响（a 不是数字）。
  if (PDD_IMAGE_HOST_RE.test(value)) {
    value = value.replace(/\.(jpe?g|png|webp|gif)\.[whq]\d+\.(jpe?g|png|webp|gif)$/i, ".$1");
  }
  return value;
}

// 会带「尺寸后缀」的图片主机白名单：只有这些主机才敢按尺寸规则裁后缀，
// 否则会把用户自己命名成 photo_1920x1080.jpg 的原图改成 photo.jpg（打开就 404）。
// v1.9.62 补 pddpic / pinduoduo —— 拼多多真实图床是 img.pddpic.com，原来漏了。
const SIZE_SUFFIX_HOST_RE = /(?:alicdn|taobaocdn|tbcdn|mmstat|alibaba|1688|aliyuncs|pddpic|pinduoduo|yangkeduo|tb\.ele)/i;
// 拼多多系图床：变体后缀是「点号」形式，和阿里系的下划线形式不同
const PDD_IMAGE_HOST_RE = /(?:pddpic|pinduoduo|yangkeduo)/i;
const IMAGE_EXT = "(?:jpe?g|png|webp|gif)";

/**
 * 尽量把图片地址升到最高清的一版（点「放大」时用）。
 * 1688 / 阿里图床的「原图」就是去掉尺寸后缀的那一版：
 *   abc.jpg_400x400.jpg   abc.jpg_400x400q90.jpg   abc.jpg_50x50c.jpg
 *   abc.jpg_400x400.webp  abc.jpg_.webp            abc.jpg.sum.jpg
 * 阿里 OSS 走 query 缩放：?x-oss-process=image/resize,w_400
 * dataUrl / blob / AI 出图结果原样返回，不做任何改写。
 */
export function highResImageUrl(url) {
  let value = cleanText(url);
  if (!value || /^(data|blob):/i.test(value)) return value;

  // ① 只做缩放/压缩的 query 参数（保留其它参数，避免把地址改坏）
  value = value.replace(/([?&])x-oss-process=[^&]*/gi, "$1")
    .replace(/([?&])&+/g, "$1")
    .replace(/[?&]+$/, "");

  // ② abc.jpg_400x400.jpg / abc.jpg_400x400q90.jpg / abc.jpg_50x50c.jpg / abc.jpg_400x400.webp
  value = value.replace(new RegExp(`(\\.${IMAGE_EXT})_[qQ]?\\d+x\\d+(?:[qQ]\\d+)?[a-z]{0,2}\\.${IMAGE_EXT}$`, "i"), "$1");
  // ③ abc.jpg_Q75.jpg
  value = value.replace(new RegExp(`(\\.${IMAGE_EXT})_[qQ]\\d+\\.${IMAGE_EXT}$`, "i"), "$1");
  // ④ abc.jpg_.webp（末尾那个扩展名是转码加的，去掉它才露出真实原名）
  value = value.replace(new RegExp(`(\\.${IMAGE_EXT})_\\.${IMAGE_EXT}$`, "i"), "$1");
  // ⑤ abc.jpg.sum.jpg / abc.jpg_.sum.jpg
  value = value.replace(new RegExp(`(\\.${IMAGE_EXT})[._]sum\\.${IMAGE_EXT}$`, "i"), "$1");

  // ⑥⑦ 只有后缀、没有双扩展名的写法，风险高一点，只对已知图床动手
  if (SIZE_SUFFIX_HOST_RE.test(value)) {
    value = value.replace(new RegExp(`_[qQ]?\\d+x\\d+(?:[qQ]\\d+)?[a-z]{0,2}\\.(${IMAGE_EXT})$`, "i"), ".$1");
    value = value.replace(new RegExp(`\\.\\d+x\\d+\\.(${IMAGE_EXT})$`, "i"), ".$1");
  }
  // ⑧ 拼多多的「点号变体」后缀：<base>.jpeg.w800.jpeg / .h800 / .q75 → <base>.jpeg
  //（<base>.jpeg.a.jpeg 是拼多多自己的原图标记，a 不是数字，不会被这条命中）
  if (PDD_IMAGE_HOST_RE.test(value)) {
    value = value.replace(new RegExp(`\\.(${IMAGE_EXT})\\.[whq]\\d+\\.(${IMAGE_EXT})$`, "i"), ".$1");
  }
  return value;
}

export function dedupeStrings(list) {
  const seen = new Set();
  const out = [];
  for (const item of Array.isArray(list) ? list : []) {
    const value = cleanText(item);
    if (!value || seen.has(value)) continue;
    seen.add(value);
    out.push(value);
  }
  return out;
}

const API_CONFIG_URL_KEYS = ["url", "base_url", "baseurl", "baseUrl", "endpoint", "host", "api_base", "apibase", "server"];
const API_CONFIG_KEY_KEYS = ["key", "api_key", "apikey", "apiKey", "token", "api_token", "apitoken", "secret", "sk", "access_key"];

function pickConfigField(object, names) {
  for (const [rawKey, rawValue] of Object.entries(object)) {
    if (typeof rawValue !== "string") continue;
    const key = rawKey.toLowerCase();
    if (names.some((name) => name.toLowerCase() === key)) return rawValue.trim();
  }
  return "";
}

function readApiConfigObject(object, depth = 0) {
  if (!object || typeof object !== "object" || Array.isArray(object) || depth > 3) return { url: "", key: "" };
  const url = pickConfigField(object, API_CONFIG_URL_KEYS);
  const key = pickConfigField(object, API_CONFIG_KEY_KEYS);
  if (url || key) return { url, key };
  // 有些配置是嵌套的：{ data: { url, key } } / { config: {...} } / { channel: {...} }
  for (const name of ["data", "config", "conn", "connection", "channel", "provider", "settings", "api"]) {
    for (const [rawKey, rawValue] of Object.entries(object)) {
      if (rawKey.toLowerCase() !== name) continue;
      const nested = readApiConfigObject(rawValue, depth + 1);
      if (nested.url || nested.key) return nested;
    }
  }
  return { url: "", key: "" };
}

/**
 * 从「整段渠道配置」里拆出 URL 与 Key。
 * 新版的 OpenAI 兼容中转（new-api 系）在后台复制出来的是这种一段 JSON：
 *   {"_type":"newapi_channel_conn","key":"sk-xxx","url":"https://api.siliconflow.cn"}
 * 用户很容易把它整段粘进 Base URL 输入框 —— 这里负责把它拆对。
 * 不是配置 JSON（普通 URL）时返回空串，调用方照常处理。
 */
export function extractApiConfig(value) {
  const text = String(value ?? "").trim();
  if (!text || !/[{}]/.test(text)) return { url: "", key: "" };

  try {
    const parsed = JSON.parse(text);
    const found = readApiConfigObject(parsed);
    if (found.url || found.key) return found;
    // 可能是 JSON 数组
    if (Array.isArray(parsed)) {
      for (const item of parsed) {
        const nested = readApiConfigObject(item);
        if (nested.url || nested.key) return nested;
      }
    }
  } catch {
    /* 不是严格 JSON，用正则兜底 */
  }

  // 兜底：单引号、缺引号、被截断的片段
  const urlMatch = text.match(/["']?(?:base_?url|api_?base|endpoint|host|url)["']?\s*[:=]\s*["']([^"'\s,}]+)["']/i);
  const keyMatch = text.match(/["']?(?:api_?key|access_?key|key|token|secret|sk)["']?\s*[:=]\s*["']([^"'\s,}]+)["']/i);
  return { url: urlMatch ? urlMatch[1].trim() : "", key: keyMatch ? keyMatch[1].trim() : "" };
}

/**
 * 规范化用户填写的 API Base URL（AI 文案 / 生图 / 自定义中转共用）。
 * 专门处理三类「肉眼看不出来」的常见问题：
 *   1. 从网页复制或中文输入法带进来的零宽字符、BOM、全角标点（：／）——看着和半角一模一样；
 *   2. 漏写协议（`api.siliconflow.cn/v1`）；
 *   3. 结尾多余的斜杠。
 * 另外：如果用户把整段渠道配置 JSON 粘了进来，会先从中拆出 url 字段。
 * 返回 "" 表示空值；返回不是 http(s) 开头的原样文本，交给调用方给出中文提示。
 */
export function normalizeApiBase(value) {
  const raw = String(value ?? "");
  // 整段 JSON 配置粘进来时，先取出里面的 url（见 extractApiConfig）
  if (/[{}]/.test(raw)) {
    const picked = extractApiConfig(raw).url;
    if (picked) return normalizeApiBase(picked);
  }

  let text = raw;
  // 零宽字符 / BOM / 控制字符：复制粘贴时极常见，界面上完全看不见
  text = text.replace(/[\u200B-\u200D\u2060\uFEFF\u0000-\u001F\u007F]/g, "");
  // 全角 → 半角（中文输入法下很容易打出全角的冒号或斜杠）
  text = text.replace(/：/g, ":").replace(/／/g, "/");
  // URL 里不该有空格（含全角空格）
  text = text.replace(/[\s\u3000]+/g, "");
  if (!text) return "";
  if (!/^https?:\/\//i.test(text) && /^[a-z0-9.-]+\.[a-z]{2,}(?:[/:?#].*)?$/i.test(text)) {
    text = `https://${text}`; // 只填了域名，自动补协议
  }
  return text.replace(/\/+$/, "");
}

/**
 * 图片生成端点。补全规则与 OpenAI 兼容服务的惯例一致：
 *   https://api.siliconflow.cn/            → https://api.siliconflow.cn/v1/images/generations
 *   https://x.cn/v1                → https://x.cn/v1/images/generations
 *   https://x.cn/v1/images/generations → 原样返回
 * 少了「裸域名自动补 /v1」这一步，用户填 https://api.siliconflow.cn/ 会打到
 * /images/generations 上直接 404 —— 这正是「URL 看着没错却一直失败」的常见原因。
 */
export function imagesEndpoint(baseUrl) {
  const base = normalizeApiBase(baseUrl);
  if (!base) return "";
  if (/\/images\/(?:generations|edits)$/i.test(base)) return base;
  if (/\/v\d+$/i.test(base)) return `${base}/images/generations`;
  if (/^https?:\/\/[^/?#]+$/i.test(base)) return `${base}/v1/images/generations`;
  return `${base}/images/generations`;
}

/** 从同一份 Base URL 推出 /models 探测端点，保证「检测的域名」就是「实际请求的域名」 */
export function modelsEndpoint(baseUrl) {
  const endpoint = imagesEndpoint(baseUrl);
  if (!endpoint) return "";
  return endpoint.replace(/\/images\/(?:generations|edits)$/i, "/models");
}

export function createId(prefix = "id") {
  const rand = Math.random().toString(36).slice(2, 10);
  return `${prefix}_${Date.now().toString(36)}_${rand}`;
}

export function deepClone(value) {
  if (value === null || typeof value !== "object") return value;
  if (Array.isArray(value)) return value.map(deepClone);
  const out = {};
  for (const [key, item] of Object.entries(value)) out[key] = deepClone(item);
  return out;
}

// 把 "红色;XL" / "红色 XL" / "颜色:红色" 拆成规格对
export function parseSpecPairs(text) {
  const out = {};
  for (const chunk of String(text || "").split(/[;；|]/)) {
    const pair = chunk.split(/[:：]/);
    if (pair.length >= 2) {
      out[cleanText(pair[0])] = cleanText(pair.slice(1).join(":"));
    }
  }
  return out;
}

export function formatBytes(bytes) {
  const n = Number(bytes) || 0;
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`;
  return `${(n / 1024 / 1024).toFixed(1)} MB`;
}

export function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

// 把 JSON-LD、页面内嵌 JSON 等常见结构安全取出
export function safeJsonParse(text, fallback = null) {
  try {
    return JSON.parse(text);
  } catch {
    return fallback;
  }
}
