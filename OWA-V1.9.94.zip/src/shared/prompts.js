import { cleanText } from "./utils.js";
import { RICH_CONTENT_ATTR_ID } from "./rich-content.js";

// AI 俄语文案提示词与结果解析。输出强制为 JSON，便于直接写入商品草稿。

export const SYSTEM_PROMPT = [
  "Ты — опытный копирайтер маркетплейса Ozon (Россия).",
  "Пишешь продающие карточки товаров на русском языке.",
  "СНАЧАЛА точно определи, ЧТО это за товар: тип, назначение, для кого он.",
  "Опирайся ТОЛЬКО на исходные данные (название, характеристики, варианты, описание).",
  "Главное правило — НЕ ИСКАЖАЙ ТИП ТОВАРА:",
  "— если это узкоспециальный товар (футбольные бутсы, баскетбольные кроссовки, балетки, коньки,",
  "ботинки для сноуборда, шиповки, боксёрские перчатки и т. п.) — сохрани именно это назначение;",
  "— ЗАПРЕЩЕНО подменять узкое назначение общим («для бега», «для фитнеса», «для повседневной носки»,",
  "«универсальный»), если этого нет в исходных данных;",
  "— если назначение в исходных данных не указано — не выдумывай его, пиши нейтрально;",
  "— не придумывай бренды, материалы, сертификаты, размеры и цифры, которых нет в исходных данных.",
  "Прочее: никакого китайского и английского текста, без медицинских обещаний и превосходной степени,",
  "без запрещённых законодательством заявлений. В заголовке обязательно назови тип товара.",
  "Отвечай строго валидным JSON без markdown-обёрток.",
].join(" ");

export const JSON_SCHEMA_HINT = JSON.stringify(
  {
    productType: "Точный тип товара на русском, 2-5 слов (например «Футбольные бутсы»)",
    usage: "Назначение строго из исходных данных, одна короткая фраза",
    title: "Заголовок до 120 символов, обязательно с типом товара",
    shortDescription: "Краткие преимущества, 2-4 пункта через '; '",
    description: "Полное описание 3-6 предложений",
    keywords: "Поисковые запросы через запятую, 8-15 шт.",
    categoryHint: "Предполагаемая категория Ozon на русском",
    bulletPoints: ["Пункт 1", "Пункт 2", "Пункт 3"],
  },
  null,
  2,
);

/* ------------------------------------------------------------------
 * v1.9.63 AI 输出质量闸门
 *
 * 采集数据不全时，模型会「礼貌地放弃」——回一屏「未知商品 / 未指定 / 信息不足」。
 * 这类输出被当成正常结果写进草稿，会连锁出两个后果：
 *   ① 用户看到的是一屏废话，但流水线是绿点，根本看不出是采集失败；
 *   ② 「未知商品」被当成「用户已确认的品类」锁死，之后每次生成都把它回传给模型，
 *      模型于是永远答「未知」——一旦踩进去就再也出不来。
 * 所以这里统一识别「放弃作答」，由上层决定：不写回草稿 + 明确报错。
 * ------------------------------------------------------------------ */

// 品类占位值：整串就是「不知道」的意思
const PLACEHOLDER_TYPE_RE =
  /^(?:[-—–?？\s]*|未知(?:商品|品类|类型)?|未指定(?:商品)?(?:类型)?|不确定|无法确定|无法判断|暂无|没有|无|n\/?a|unknown|неизвест\S*|не\s*определ\S*|не\s+указан\S*|нет\s+данных|отсутству\S*)$/i;

// 整段文本里的「放弃作答」口吻（模型不写「未知商品」四个字，而是写一整段解释）
const GIVEUP_RE =
  /(?:信息不足|信息量不足|信息不足以|资料不足|缺乏(?:信息|足够信息|数据)|没有(?:指明|提供|给出|足够)|未指定|未能确定|无法确定|无法判断|不能确定|未知商品|无用途信息|需要(?:添加|补充)(?:一个)?名称|原始数据中(?:只|仅)|недостаточн\S*|неизвестн\S*|невозможно\s+определ\S*|нет\s+(?:данных|достаточн\S*)|не\s+указан\S*)/i;

// 俄语字段里混进中文 = 模型没按指令走（系统提示词明令禁止中文）
const CJK_RE = /[\u4e00-\u9fa5]/;

/** 品类是不是「不知道」的占位值（空串也算）。品类必须是俄语，出现中文本身就是错的。 */
export function isPlaceholderProductType(value) {
  const text = String(value == null ? "" : value).trim();
  if (!text) return true;
  if (CJK_RE.test(text)) return true;
  return PLACEHOLDER_TYPE_RE.test(text);
}

/**
 * 判断一次文案生成是不是「无效结果」。
 * 返回 { weak, reasons[] }：weak=true 时调用方必须拒绝写回草稿并报错，不能标绿点。
 * 只有「标题 / 品类 / 描述」三条同时不可用才算整体失败，避免误杀只错一项的正常结果。
 */
export function inspectListingResult(data) {
  const reasons = [];
  if (!data || typeof data !== "object") return { weak: true, reasons: ["模型没有返回任何可用内容"] };
  const title = String(data.title || "").trim();
  const desc = String(data.description || "").trim();
  const short = String(data.shortDescription || "").trim();
  const type = String(data.productType || "").trim();
  const usage = String(data.usage || "").trim();

  const titleBad = !title || CJK_RE.test(title) || GIVEUP_RE.test(title);
  const typeBad = isPlaceholderProductType(type);
  const descBad = !desc || CJK_RE.test(desc) || GIVEUP_RE.test(desc);

  if (!title) reasons.push("标题为空");
  else if (CJK_RE.test(title)) reasons.push("标题里混进了中文");
  else if (GIVEUP_RE.test(title)) reasons.push(`标题是「放弃作答」的占位内容（${title.slice(0, 24)}）`);
  if (typeBad) reasons.push(`没识别出商品品类（${type || "空"}）`);
  if (usage && (CJK_RE.test(usage) || GIVEUP_RE.test(usage))) reasons.push("用途字段不是有效内容");
  if (!desc) reasons.push("详细描述为空");
  else if (CJK_RE.test(desc) || GIVEUP_RE.test(desc)) reasons.push("详细描述是「放弃作答」的内容");
  if (short && (CJK_RE.test(short) || GIVEUP_RE.test(short))) reasons.push("卖点里混进了中文或占位内容");

  return { weak: titleBad && typeBad && descBad, reasons };
}

/**
 * 把「无效结果」翻译成用户能照着做的提示。
 * 关键是把「AI 不会写」和「采集没拿到数据」区分开——后者用户回去补标题才有用。
 */
export function weakListingError(quality, product = {}) {
  const reasons = (quality?.reasons || []).slice(0, 3).join("；");
  const noTitle = !cleanText(product.title);
  const noSku = !(Array.isArray(product.skus) && product.skus.length);
  const noAttr = !(Array.isArray(product.attributes) && product.attributes.length);
  const noDesc = !cleanText(product.description);
  const hint = noTitle || (noSku && noAttr && noDesc)
    ? "这次采集几乎没拿到商品信息（标题 / 规格 / 属性 / 描述都为空），AI 无从判断这是什么商品。请回到商品详情页重新采集，或直接在「商品词 / 品类」里手动填写品类后再点生成。"
    : "AI 这次没给出可用文案（返回了「未知 / 未指定」这类占位内容，或混进了中文）。换一个更听话的模型，或手动填写「商品词 / 品类」后重试。";
  return `AI 文案生成未通过质量校验：${reasons || "结果为空"}。${hint}`;
}

function compactAttributes(product) {
  return (product.attributes || [])
    .slice(0, 20)
    .map((attr) => `${attr.name}: ${attr.value}`)
    .join("\n");
}

function compactSkus(product) {
  return (product.skus || [])
    .slice(0, 20)
    .map((sku) => `${sku.label || Object.values(sku.specs || {}).join("/")} — ${sku.price}`)
    .join("\n");
}

/**
 * 构造俄语文案生成请求消息。
 */
export function buildListingMessages(product, options = {}) {
  const keywords = (options.extraKeywords || "").trim();
  const tone = options.tone || "нейтральный, информативный";
  // 用户手填/纠正的品类：作为硬约束，优先级高于模型自己的判断
  // v1.9.63：占位值（未知商品 / 未指定…）不能当作用户指定的品类传给模型，
  // 否则提示词里会出现「ТИП ТОВАРА ЗАДАН ПОЛЬЗОВАТЕЛЕМ: «未知商品»」，模型就永远答「不知道」。
  const lockedType = isPlaceholderProductType(options.productType) ? "" : cleanText(options.productType);
  const title = cleanText(product.title);
  const attrs = compactAttributes(product);
  const skus = compactSkus(product);
  const categoryPath = product.ozonCategory?.path;

  // v1.9.63：把「采集侧的线索」尽量都带上。原来只发标题/属性/SKU，
  // 标题一空模型就彻底没抓手，只能回一句「信息不足」——而这句废话用户完全看不懂问题出在采集。
  const notes = (product.diagnostics?.notes || [])
    .map((item) => cleanText(item)).filter(Boolean).slice(0, 6);
  const imageCount = Array.isArray(product.images) ? product.images.length : 0;

  const userPayload = [
    `Товар с китайского маркетплейса (${product.platform || "unknown"}):`,
    title
      ? `Название: ${title}`
      : "Название: (НЕ ПОЛУЧЕНО при сборе — в источнике нет читаемого названия товара)",
    attrs ? `Характеристики:\n${attrs}` : "",
    skus ? `Варианты (SKU):\n${skus}` : "",
    product.description ? `Описание источника:\n${product.description.slice(0, 1500)}` : "",
    product.price?.min ? `Цена закупки: ${product.price.min} ${product.price.currency}` : "",
    imageCount ? `Фото товара в источнике: ${imageCount} шт. (сами изображения тебе недоступны — не выдумывай, что на них)` : "",
    product.sourceUrl ? `Ссылка на источник: ${product.sourceUrl}` : "",
    notes.length ? `Замечания сборщика:\n${notes.map((n) => `- ${n}`).join("\n")}` : "",
    categoryPath ? `Категория Ozon (уже выбрана): ${[].concat(categoryPath).join(" > ")}` : "",
    lockedType ? `ТИП ТОВАРА ЗАДАН ПОЛЬЗОВАТЕЛЕМ: «${lockedType}». Пиши строго в рамках этого типа, не меняй назначение.` : "",
    keywords ? `Дополнительные ключевые слова от пользователя: ${keywords}` : "",
    `Тон: ${tone}.`,
    "Определи тип товара и назначение строго по исходным данным, затем напиши карточку.",
    "Если название неполное или отсутствует — определи наиболее вероятный тип товара по характеристикам, вариантам (SKU), описанию и категории источника.",
    "КАТЕГОРИЧЕСКИ ЗАПРЕЩЕНО отвечать «неизвестный товар», «не указано», «недостаточно данных» и подобным,",
    "и запрещено писать что-либо на китайском или английском — весь текст только на русском.",
    `Верни JSON в формате:\n${JSON_SCHEMA_HINT}`,
  ]
    .filter(Boolean)
    .join("\n\n");

  return [
    { role: "system", content: SYSTEM_PROMPT },
    { role: "user", content: userPayload },
  ];
}

/* ------------------------------------------------------------------
 * 批量翻译：Ozon 类目树只提供 RU / EN 名称，界面要显示中文就得自己翻。
 * 输出严格 JSON 数组，顺序与输入一致。
 * ------------------------------------------------------------------ */

export function buildTranslateMessages(texts = [], { from = "auto", to = "zh" } = {}) {
  const list = (texts || []).slice(0, 80).map((item, index) => `${index + 1}. ${String(item || "").trim()}`).join("\n");
  const userPayload = [
    `Переведи каждый пункт списка на ${to === "zh" ? "китайский язык (упрощённый)" : to}.`,
    "Правила: только перевод, без пояснений и нумерации смысла; сохраняй порядок;",
    "для названий категорий маркетплейса дай краткий общепринятый перевод (1-6 слов);",
    // v1.9.53 属性名称/枚举值的术语口径：本地字典没命中时，AI 兜底翻译也必须跟着这套叫法走
    "для атрибутов товара используй терминологию китайских маркетплейсов: 颜色、尺码、材质、成分、适用场景、适用季节、适用性别、适用年龄、风格、图案、形状、款式、闭合方式、面料/里料材质;",
    "единицы измерения пиши символом в скобках: 重量（kg）、长度/宽度/高度/深度（cm）、功率（W）、电压（V）、容量（L）、带包装重量（g）;",
    "не переводи названия брендов, модели, артикулы, коды и символы (S/M/L/XL, ТН ВЭД, Честный ЗНАК);",
    "для уровней используй суффикс «级» (入门级/进阶级/通用级/专业级/专家级), для видов — «款» (新款/经典款);",
    "без пояснений в скобках, без лишних слов и разговорных выражений;",
    'Отвечай строго валидным JSON-массивом строк вида ["перевод 1", "перевод 2"] без markdown-обёрток.',
    "",
    list,
  ].join("\n");
  return [
    { role: "system", content: `Ты — переводчик каталога маркетплейса Ozon. Исходный язык: ${from}. Отвечай только JSON-массивом строк.` },
    { role: "user", content: userPayload },
  ];
}

/** 解析批量翻译结果；条数对不上时按位置能对齐多少算多少，不整体作废 */
export function parseTranslateResult(text, expectedCount = 0) {
  const raw = String(text || "").trim();
  const body = (raw.match(/\[[\s\S]*\]/) || [raw])[0];
  let parsed = null;
  try {
    parsed = JSON.parse(body);
  } catch {
    return null;
  }
  if (!Array.isArray(parsed)) return null;
  const out = parsed.map((item) => (typeof item === "string" ? item.trim() : String(item?.value ?? item ?? "").trim()));
  if (expectedCount && out.length !== expectedCount) return null; // 顺序错位的翻译比没有更危险
  return out;
}

/* ------------------------------------------------------------------
 * 类目二次精选：本地打分先圈出 Top-N 候选，再让 AI 从候选里挑最贴切的一个。
 * 直接让 AI 凭空编类目 ID 必然出错，所以「候选必须由真实类目树给出，AI 只做选择」。
 * ------------------------------------------------------------------ */

export const CATEGORY_PICK_SYSTEM_PROMPT = [
  "Ты — эксперт по каталогу маркетплейса Ozon.",
  "Тебе дают товар и нумерованный список реальных конечных типов Ozon. Выбирать можно только один пункт из списка.",
  "Сначала определи физический тип товара, основную функцию и сценарий использования; затем сопоставь их с полным путём категории.",
  "Не считай слова «детский», «для дома», «универсальный» и бренд достаточным основанием: проверь предмет, функцию, конструкцию и назначение.",
  "Товар для хранения/организации (полка, стеллаж, шкаф, корзина) нельзя относить к игрушкам, игровым комплексам или детским площадкам только из-за слова «детский».",
  "Если в подсказке указана наиболее вероятная область товара — отдавай приоритет кандидатам этой области и строго отклоняй кандидатов из других областей при прочих равных.",
  "Если тип товара, функция или сценарий не совпадают с кандидатом, отклони его. Если подходящего кандидата нет, верни index=-1 и низкую confidence.",
  'Отвечай строго валидным JSON вида {"index": <номер>, "category_id": <id>, "type_id": <id>, "path": "<полный путь>", "confidence": <0-1>, "reason": "<коротко почему>"} без markdown-обёрток.',
].join(" ");

export function buildCategoryPickMessages(product, candidates = [], domains = []) {
  const attrs = compactAttributes(product);
  const skus = compactSkus(product);
  const list = (candidates || [])
    .slice(0, 12)
    .map((item, index) => {
      const node = item.node || {};
      const categoryId = Number(node.description_category_id ?? node.category_id) || 0;
      const typeId = Number(node.type_id) || 0;
      return `${index + 1}. category_id=${categoryId}; type_id=${typeId}; path=${(item.path || []).join(" / ")}`;
    })
    .join("\n");
  const domainHint = Array.isArray(domains) && domains.length
    ? `По ключевым словам товар, скорее всего, относится к области: ${domains.join(", ")}. Отдавай приоритет кандидатам из этой области и строго отклоняй кандидатов из других областей (например, товар для хранения нельзя относить к игрушкам только из-за слова «детский»).`
    : "";
  const imageContext = [
    ...(Array.isArray(product.images) ? product.images : []),
    ...((product.imageMeta && typeof product.imageMeta === "object") ? Object.values(product.imageMeta) : []),
  ].map((value) => (value && typeof value === "object" ? JSON.stringify(value) : String(value || "").trim()))
    .filter(Boolean).slice(0, 12).join("\n");
  const userPayload = [
    `Товар (${product.platform || "unknown"}): ${product.title || ""}`,
    product.brand ? `Бренд: ${product.brand}` : "",
    attrs ? `Характеристики: ${attrs}` : "",
    skus ? `Варианты: ${skus}` : "",
    product.description ? `Описание и назначение:\n${String(product.description).slice(0, 1800)}` : "",
    product.ru?.title ? `Русское название: ${product.ru.title}` : "",
    product.ru?.categoryHint ? `Предполагаемая категория: ${product.ru.categoryHint}` : "",
    product.ru?.productType ? `Тип товара (черновой): ${product.ru.productType}` : "",
    product.ru?.usage ? `Назначение: ${product.ru.usage}` : "",
    product.ru?.shortDescription ? `Ключевые преимущества: ${product.ru.shortDescription}` : "",
    product.ru?.description ? `Русское описание:\n${String(product.ru.description).slice(0, 1600)}` : "",
    Array.isArray(product.ru?.keywords) && product.ru.keywords.length ? `Ключевые слова: ${product.ru.keywords.slice(0, 15).join(", ")}` : "",
    domainHint,
    imageContext ? `Контекст изображений (URL/已有元数据，仅作辅助，不要仅凭文件名猜测):\n${imageContext}` : "",
    "",
    "Кандидаты категорий Ozon:",
    list,
    "",
    "category_id 和 type_id 必须与所选候选完全一致，path 必须复制候选路径；confidence 表示你对商品类型匹配的把握。",
  ].filter(Boolean).join("\n");
  return [
    { role: "system", content: CATEGORY_PICK_SYSTEM_PROMPT },
    { role: "user", content: userPayload },
  ];
}

/** 解析 AI 的候选选择；返回 0 基下标，选不出来返回 -1 */
export function parseCategoryPickResult(text, count = 0) {
  const parsed = parseCategoryPickDetails(text, count);
  return parsed ? parsed.index : -1;
}

export function parseCategoryPickDetails(text, count = 0) {
  const raw = String(text || "").trim();
  const body = (raw.match(/\{[\s\S]*\}/) || [raw])[0];
  let parsed;
  try {
    parsed = JSON.parse(body);
  } catch {
    return null;
  }
  if (!parsed || typeof parsed !== "object") return null;
  const index = Number(parsed.index);
  if (!Number.isInteger(index) || index < 1 || index > count) return null;
  const confidence = Number(parsed.confidence);
  return {
    index: index - 1,
    confidence: Number.isFinite(confidence) ? Math.max(0, Math.min(1, confidence)) : 0,
    categoryId: Number(parsed.category_id) || 0,
    typeId: Number(parsed.type_id) || 0,
    path: String(parsed.path || "").trim(),
    reason: String(parsed.reason || "").trim().slice(0, 240),
  };
}

/* ------------------------------------------------------------------
 * v1.9.66：类目树全量约束匹配（产品标题 + 产品外观图片 双通道）
 *
 * 与上面「本地打分圈 Top-N → AI 只选下标」不同：这里把 Ozon 官方完整类目树
 * （assets/ozon-category-tree.js：26 域 / 542 类目 / 8600 类型，全部带数字 ID）
 * 直接序列化进提示词，让 AI 在整棵树范围内选，且只能选树里真实存在的节点。
 *
 * 为什么要分两阶段：8600 个类型一次性塞进提示词要十几万 token，所以
 * 阶段 1 只给「域 + 类目」（约 570 行），AI 选域与类目；
 * 阶段 2 只给命中类目下的类型（几行到几十行），AI 选类型。
 * 两阶段返回的都是「清单里的行号」，行号必须能在树里原样查到，查不到就整体判失败——
 * 延续「候选必须由真实类目树给出，AI 只做选择」的原则，杜绝编造 ID。
 * ------------------------------------------------------------------ */

export const CATEGORY_TREE_MATCH_SYSTEM_PROMPT = [
  "你是 Ozon（俄罗斯电商平台）官方类目树的选类目专家。",
  "用户会给你一个商品（标题、描述、规格、属性，可能是中文）以及该商品的真实外观图片，同时给你一份 Ozon 官方类目树清单。",
  "你必须【同时】依据两路信息判断商品是什么：① 产品标题名称与文字描述；② 产品外观图片里看到的实物（形状、材质、结构、数量、使用场景）。两路要互相印证。",
  "硬性规则：",
  "1) 只能在给出的清单范围内选择，答案必须用清单里的行号表示；绝对不允许自己编造类目名称、类目 ID 或类型 ID。",
  "2) 先判断商品的物理形态、核心功能和真实使用场景，再看图片确认外观，不要只凭标题里的某个词下结论。",
  "3) 当标题与图片冲突时，以图片中的实物为准；图片看不清时以标题与描述为准，并在 reason 里说明依据。",
  "4) 「儿童」「家用」「通用」「多功能」「加厚」这类泛词不构成选类目的依据；例如收纳架 / 置物架 / 货架，不能因为带「儿童」二字就选到玩具或游乐设施。",
  "5) 区分「整机」与「配件」：卖的是主体就选主体，卖的是配件就选配件，按图片里的实物判断。",
  "6) 只依据本次消息中的标题、原始描述、规格、属性和附带图片；不要相信草稿里此前生成的类目、俄文标题、关键词或历史推荐。",
  "7) 图片必须与标题指向同一个实物。若图片明显不是标题所说的商品，返回 confidence=0，并在 reason 说明「标题与图片不一致」，不要从清单里硬选。", 
  "6) 如果清单里确实没有合适的类目，把行号返回 -1、confidence 返回 0，不要硬选一个凑数。",
  "只输出严格合法的 JSON，不要 markdown 代码块，不要多余解释。",
].join(" ");

/** 节点显示名：域只有 category_name，类目/类型有 title（类目的 category_name 是域名，不能当类目名） */
function categoryNodeLabel(node) {
  return String(node?.title || node?.category_name || node?.type_name || "").trim();
}

/**
 * 把完整类目树编成「行号索引」：
 *   D1. 域名                       → domains[0]
 *   C1.2. 类目名 | category_id=…   → byCategoryLine.get("1.2")
 *   T1.2.3. 类型名 | type_id=…     → category.types[2]
 * 域用扁平编号，类目 / 类型用相对父节点的编号——这样 AI 只需回几个小整数，
 * 且每个编号都能唯一还原到一个真实节点，杜绝「编一个不存在的类目」。
 */
export function buildCategoryTreeIndex(tree) {
  const domains = [];
  const byDomainLine = new Map();
  const byCategoryLine = new Map();
  let d = 0;
  for (const domainNode of tree || []) {
    const name = categoryNodeLabel(domainNode);
    if (!name) continue;
    d += 1;
    const domain = { lineNo: d, name, node: domainNode, categories: [] };
    domains.push(domain);
    byDomainLine.set(d, domain);
    let c = 0;
    for (const categoryNode of domainNode?.children || []) {
      const categoryName = categoryNodeLabel(categoryNode);
      if (!categoryName) continue;
      c += 1;
      const categoryId = Number(categoryNode?.description_category_id ?? categoryNode?.category_id) || 0;
      const category = { lineNo: c, key: `${d}.${c}`, name: categoryName, categoryId, node: categoryNode, domain, types: [] };
      domain.categories.push(category);
      byCategoryLine.set(category.key, category);
      let t = 0;
      for (const typeNode of categoryNode?.children || []) {
        const typeName = categoryNodeLabel(typeNode);
        const typeId = Number(typeNode?.type_id) || 0;
        if (!typeName || !typeId) continue; // 没有数字 ID 的类型传不上去，不进清单
        t += 1;
        category.types.push({ lineNo: t, key: `${d}.${c}.${t}`, name: typeName, typeId, node: typeNode, category });
      }
    }
  }
  return { domains, byDomainLine, byCategoryLine };
}

/** 渲染「域 + 类目」清单（阶段 1 用，约 570 行） */
export function renderCategoryTreeDomainList(index) {
  const lines = [];
  for (const domain of index.domains) {
    lines.push(`D${domain.lineNo}. ${domain.name}`);
    for (const category of domain.categories) {
      lines.push(`  C${category.key}. ${category.name}${category.categoryId ? ` | category_id=${category.categoryId}` : ""}`);
    }
  }
  return lines.join("\n");
}

/** 渲染某个类目下的「类型」清单（阶段 2 用） */
export function renderCategoryTypeList(category) {
  return (category?.types || []).map((type) => `T${type.key}. ${type.name} | type_id=${type.typeId}`).join("\n");
}

/** 把商品图片 data URL 拼成 OpenAI 兼容的多模态 content 片段 */
export function categoryImageParts(imageDataUrls = []) {
  return (imageDataUrls || [])
    .map((url) => String(url || "").trim())
    .filter((url) => /^data:image\//i.test(url) || /^https?:\/\//i.test(url))
    .slice(0, 4)
    .map((url) => ({ type: "image_url", image_url: { url } }));
}

/** 两阶段共用的商品摘要 */
function buildCategoryMatchProductBrief(product = {}, { maxDescription = 1400 } = {}) {
  const attrs = compactAttributes(product);
  const skus = compactSkus(product);
  return [
    `商品标题：${product.title || ""}`,
    product.platform ? `来源平台：${product.platform}` : "",
    product.brand ? `品牌：${product.brand}` : "",
    attrs ? `商品属性：\n${attrs}` : "",
    skus ? `规格 / 变体：\n${skus}` : "",
    product.description ? `商品描述与用途：\n${String(product.description).slice(0, maxDescription)}` : "",
    // v1.9.70：严禁把上一轮 AI 生成的俄文标题 / 旧类目 / 旧关键词带入本次匹配。
    // 这些内容可能本来就是错误结果，会形成「错误结果反向污染下一轮」的闭环。
    "注意：以上仅包含本次采集的原始商品信息；不要参考草稿中此前生成的类目、俄文文案或关键词。", 
  ].filter(Boolean).join("\n");
}

/**
 * 阶段 1：把【完整类目树】的「域 + 类目」清单 + 商品文字 + 商品外观图片交给 AI，
 * 让它选一个域和一个类目。返回 OpenAI 兼容 messages（多模态时 content 是数组）。
 */
export function buildCategoryTreeDomainMessages(product, tree, { imageDataUrls = [] } = {}) {
  const index = buildCategoryTreeIndex(tree);
  const images = categoryImageParts(imageDataUrls);
  const imageNote = images.length
    ? `本条消息附带 ${images.length} 张该商品的外观实拍图（见下方图片），请务必看图确认实物形态后再判断。`
    : "本次没有取到可用的商品图片，只能依据文字信息判断，请在 reason 里注明「无图」。";
  const text = [
    buildCategoryMatchProductBrief(product),
    "",
    imageNote,
    "",
    `Ozon 官方类目树（域 / 类目，完整清单，共 ${index.domains.length} 个域，只能从下面这些行里选）：`,
    renderCategoryTreeDomainList(index),
    "",
    "请判断该商品属于哪个【域】和哪个【类目】。",
    '只输出 JSON：{"domain": <D 后面的数字>, "category": <C 后面第 2 段的数字>, "confidence": <0-1>, "reason": "<一句中文理由，说明依据了标题的什么信息、图片里的什么特征>"}',
    '例如选 D3 下面的 C3.5，就返回 {"domain":3,"category":5,"confidence":0.9,"reason":"..."}。',
    '如果清单里确实没有合适的类目，返回 {"domain":-1,"category":-1,"confidence":0,"reason":"..."}，不要硬选。',
  ].join("\n");
  return [
    { role: "system", content: CATEGORY_TREE_MATCH_SYSTEM_PROMPT },
    { role: "user", content: images.length ? [{ type: "text", text }, ...images] : text },
  ];
}

/**
 * 阶段 2：类目已定，只把该【类目】下的全部【类型】列给 AI，让它选一个类型。
 * 该类目没有可上传类型时返回 null（调用方据此回退）。
 */
export function buildCategoryTreeTypeMessages(product, domainPick, { imageDataUrls = [] } = {}) {
  const category = domainPick?.category;
  if (!category || !(category.types || []).length) return null;
  const images = categoryImageParts(imageDataUrls);
  const imageNote = images.length
    ? `本条消息附带 ${images.length} 张该商品的外观实拍图，请结合图片里的实物确认后再选类型。`
    : "本次没有取到可用的商品图片，只能依据文字信息判断。";
  const text = [
    buildCategoryMatchProductBrief(product, { maxDescription: 800 }),
    "",
    `已确定的类目：${domainPick.domain?.name || ""} / ${category.name}（category_id=${category.categoryId}）`,
    "",
    imageNote,
    "",
    `该【类目】下的全部【类型】（完整清单，只能从下面这些行里选）：`,
    renderCategoryTypeList(category),
    "",
    "请在该类目下选出最贴切的一个【类型】。",
    '只输出 JSON：{"type": <T 后面第 3 段的数字>, "confidence": <0-1>, "reason": "<一句中文理由>"}',
    `例如选 T${category.key}.4，就返回 {"type":4,"confidence":0.9,"reason":"..."}。`,
    '如果都不合适，返回 {"type":-1,"confidence":0,"reason":"..."}。',
  ].join("\n");
  return [
    { role: "system", content: CATEGORY_TREE_MATCH_SYSTEM_PROMPT },
    { role: "user", content: images.length ? [{ type: "text", text }, ...images] : text },
  ];
}

function parseCategoryMatchJson(text) {
  const raw = String(text || "").trim();
  const body = (raw.match(/\{[\s\S]*\}/) || [raw])[0];
  try {
    const parsed = JSON.parse(body);
    return parsed && typeof parsed === "object" ? parsed : null;
  } catch {
    return null;
  }
}

function clamp01(value) {
  const num = Number(value);
  return Number.isFinite(num) ? Math.max(0, Math.min(1, num)) : 0;
}

/**
 * 解析阶段 1 的结果。返回的行号必须在给定树里原样存在，否则整体判 null（拒绝）。
 */
export function parseCategoryTreeDomainResult(text, tree) {
  const parsed = parseCategoryMatchJson(text);
  if (!parsed) return null;
  const d = Number(parsed.domain);
  const c = Number(parsed.category);
  if (!Number.isInteger(d) || !Number.isInteger(c) || d < 1 || c < 1) return null;
  const index = buildCategoryTreeIndex(tree);
  const domain = index.byDomainLine.get(d);
  if (!domain) return null;
  const category = index.byCategoryLine.get(`${d}.${c}`);
  if (!category || !category.categoryId) return null;
  return {
    domain,
    category,
    confidence: clamp01(parsed.confidence),
    reason: String(parsed.reason || "").trim().slice(0, 240),
  };
}

/** 解析阶段 2 的结果；类型行号必须落在该类目的类型清单内，否则判 null */
export function parseCategoryTreeTypeResult(text, category) {
  const parsed = parseCategoryMatchJson(text);
  if (!parsed) return null;
  const t = Number(parsed.type);
  const types = Array.isArray(category?.types) ? category.types : [];
  if (!Number.isInteger(t) || t < 1 || t > types.length) return null;
  const type = types[t - 1];
  if (!type || !type.typeId) return null;
  return {
    type,
    confidence: clamp01(parsed.confidence),
    reason: String(parsed.reason || "").trim().slice(0, 240),
  };
}

/** 把两阶段的行号还原成真实节点，拼出最终结果（categoryId / typeId / path / node） */
export function composeCategoryTreeMatch(domainPick, typePick, { imageCount = 0 } = {}) {
  const categoryId = Number(domainPick?.category?.categoryId) || 0;
  const typeId = Number(typePick?.type?.typeId) || 0;
  if (!categoryId || !typeId) return null;
  const path = [domainPick.domain?.name, domainPick.category?.name, typePick.type?.name].filter(Boolean);
  const confidence = clamp01((Number(domainPick?.confidence) || 0) * (Number(typePick?.confidence) || 0));
  const reason = [typePick?.reason, domainPick?.reason].map((item) => String(item || "").trim()).filter(Boolean).join("；").slice(0, 240);
  return {
    domain: domainPick.domain?.name || "",
    category: domainPick.category?.name || "",
    type: typePick.type?.name || "",
    categoryId,
    typeId,
    path,
    confidence,
    reason,
    imageCount: Number(imageCount) || 0,
    node: {
      ...(typePick.type?.node || {}),
      title: typePick.type?.name || "",
      type_name: typePick.type?.name || "",
      type_id: typeId,
      category_id: categoryId,
      description_category_id: categoryId,
    },
  };
}

/* ------------------------------------------------------------------
 * 类目属性自动填写：给 AI 一份「属性 ID | 名称 | 可选值」清单，让它按商品信息填值。
 * 输出 values + 每个值的 0~1 confidence，未知放入 unknown，避免编造。
 * ------------------------------------------------------------------ */

export const ATTR_SYSTEM_PROMPT = [
  "Ты — специалист по заполнению карточек товаров на маркетплейсе Ozon (Россия).",
  "По данным товара заполни значения характеристик (атрибутов) его категории.",
  "Правила: значения только на русском языке; не выдумывай бренды, сертификаты и медицинские обещания;",
  "названия атрибутов могут идти с китайским переводом — это подсказка для чтения, значение всё равно возвращай по-русски;",
  "если атрибут со списком вариантов — выбери ровно один вариант из списка дословно (учитывай регистр);",
  "обязательные атрибуты заполняй по любым данным товара, не оставляй пустыми;",
  "заполняй как можно больше атрибутов: если значение выводится из типа товара, назначения, русских текстов или характеристик — заполни его;",
  "для размеров и веса переводи единицы в требуемые атрибутом (см→мм, кг→г) и указывай только значение;",
  "если значение точно определить нельзя — добавь id атрибута в массив unknown, не оставляй пустую строку;",
  "Отвечай строго валидным JSON вида {\"values\": {\"<id атрибута>\": \"<значение>\"}, \"confidence\": {\"<id атрибута>\": 0.0}, \"unknown\": [\"<id>\"]} без markdown-обёрток.",
].join(" ");

function compactAttrList(attributes) {
  return (attributes || [])
    .slice(0, 60)
    .map((attr) => {
      const id = Number(attr.id) || 0;
      // v1.9.58 全中文：属性名优先给中文（官方模板/AI 翻译的 displayName）——采集源数据本来就是中文，
      // 模型看中文名匹配更准；俄文原名一并带上，值必须回俄文（上传时按候选值原文落字典）
      const raw = String(attr.name || "").trim();
      const zh = String(attr.displayName || "").trim();
      const hasZh = zh && zh !== raw && /[\u4e00-\u9fa5]/.test(zh);
      const name = hasZh ? `${zh} (${raw})` : raw;
      const required = attr.is_required ? " [必填]" : "";
      const dict = Array.isArray(attr.dictionary) && attr.dictionary.length
        ? ` (候选值，必须原样选用: ${attr.dictionary.slice(0, 30).map((v) => String(v.value ?? v).trim()).join(" | ")})`
        : "";
      return `${id} | ${name}${required}${dict}`;
    })
    .join("\n");
}

export function buildAttributeMessages(product, attributes = [], options = {}) {
  const attrs = compactAttributes(product);
  const skus = compactSkus(product);
  const ru = product.ru || {};
  const diagnostics = Array.isArray(product.diagnostics?.notes) ? product.diagnostics.notes.filter(Boolean) : [];
  // v1.9.64 「JSON 富内容」(id 11254) 不交给模型填：它由「详细描述」下方的富内容区
  // 单独生成（图片直链 + 宽高必须用采集到的真实数据），模型乱写一段 JSON 只会覆盖掉它。
  const pool = (attributes || []).filter((attr) => String(attr?.id) !== String(RICH_CONTENT_ATTR_ID));
  const target = (options.onlyRequired ? pool.filter((a) => a.is_required) : pool).slice(0, 60);
  // v1.9.64 属性填得准不准，关键在「喂够线索」。过去只发中文标题 + 采集属性，
  // 模型看不懂中文标题时经常整片留空（截图里那种「信息不足」）。现在把已经定稿的
  // 俄语文案（品类 / 用途 / 标题 / 卖点 / 详细描述）与采集诊断一起发过去 ——
  // 这些正是判断材质、用途、适用人群的依据；诊断则告诉模型「哪些字段本来就没采到」，
  // 免得它把「采集失败」当成「商品没有这个属性」。
  const userPayload = [
    `Товар с китайского маркетплейса (${product.platform || "unknown"}):`,
    product.title ? `Название (CN): ${product.title}` : "",
    ru.productType ? `Тип товара (уже определён): ${ru.productType}` : "",
    ru.usage ? `Назначение: ${ru.usage}` : "",
    ru.title ? `Русское название: ${ru.title}` : "",
    ru.shortDescription ? `Ключевые преимущества: ${ru.shortDescription}` : "",
    ru.description ? `Русское описание товара:\n${String(ru.description).slice(0, 1600)}` : "",
    attrs ? `Характеристики (CN):\n${attrs}` : "",
    skus ? `Варианты (SKU):\n${skus}` : "",
    product.description ? `Описание источника (CN):\n${String(product.description).slice(0, 1200)}` : "",
    diagnostics.length ? `Заметки сбора данных (что не удалось прочитать на странице):\n${diagnostics.slice(0, 6).join("\n")}` : "",
    "",
    "Заполни атрибуты категории Ozon. Список атрибутов (id | название | варианты):",
    compactAttrList(target.length ? target : pool),
    "",
    "Заполняй МАКСИМАЛЬНО ПОЛНО: если значение выводится из типа товара, назначения, русских текстов или характеристик — заполни его, не оставляй пустым.",
    // v1.9.81 去重：属性值必须是简短的结构化值（材质=Металл、功率=1400 Вт），
    // 不要把「简介/详细描述」的整段文字复制进某个属性值——那会和描述字段重复、且被判低质。
    "Значение атрибута — короткая структурированная величина (материал=Металл, мощность=1400 Вт), НЕ переноси целиком текст аннотации/описания в атрибут: это дублирует описание и режет качество карточки.",
    "Числовые атрибуты (вес / длина / ширина / высота / объём) ищи в характеристиках источника и переводи единицы в требуемые атрибутом.",
    "Атрибут со списком вариантов — выбери ровно одно значение из списка дословно. Не выдумывай бренды, сертификаты и медицинские обещания.",
    'Верни JSON: {"values": {"<id>": "<значение>"}, "confidence": {"<id>": <0-1>}}. Ключи — только id из списка; если данных действительно нет, не угадывай и добавь id в unknown.',
  ].filter(Boolean).join("\n");

  return [
    { role: "system", content: ATTR_SYSTEM_PROMPT },
    { role: "user", content: userPayload },
  ];
}

/** 解析属性填写结果：容忍围栏/多余文字，只保留 id→值 的字符串映射 */
export function parseAttributeResult(text) {
  const raw = String(text || "").trim();
  const body = (raw.match(/\{[\s\S]*\}/) || [raw])[0];
  let parsed = null;
  try {
    parsed = JSON.parse(body);
  } catch {
    return null;
  }
  const values = parsed && typeof parsed === "object" ? (parsed.values || parsed) : null;
  if (!values || typeof values !== "object") return null;
  const out = {};
  const unknown = [];
  for (const [key, value] of Object.entries(values)) {
    const id = String(key).trim();
    if (!/^\d+$/.test(id)) continue;
    const text = String(value ?? "").trim();
    if (!text) continue;
    if (/^(unknown|не знаю|неизвестно|n\/a|нет данных)$/i.test(text)) {
      unknown.push(id);
      continue;
    }
    out[id] = text;
  }
  // 模型可能在 JSON 里显式给出 unknown 数组
  if (Array.isArray(parsed.unknown)) {
    for (const id of parsed.unknown) {
      const sid = String(id).trim();
      if (/^\d+$/.test(sid) && !unknown.includes(sid)) unknown.push(sid);
    }
  }
  const confidence = {};
  const rawConfidence = parsed && typeof parsed.confidence === "object" ? parsed.confidence : {};
  for (const id of Object.keys(out)) {
    const value = Number(rawConfidence[id]);
    if (Number.isFinite(value)) confidence[id] = Math.max(0, Math.min(1, value));
  }
  return { values: out, unknown, confidence, __raw: raw };
}

// 从模型输出中稳健地抠出 JSON（模型常带 ```json 围栏或前后吐槽文字）
export function parseListingResult(text) {
  const raw = String(text || "").trim();
  const candidates = [];
  const fenced = raw.match(/```(?:json)?\s*([\s\S]*?)```/i);
  if (fenced) candidates.push(fenced[1]);
  const braceStart = raw.indexOf("{");
  const braceEnd = raw.lastIndexOf("}");
  if (braceStart > -1 && braceEnd > braceStart) candidates.push(raw.slice(braceStart, braceEnd + 1));
  candidates.push(raw);

  for (const candidate of candidates) {
    try {
      const parsed = JSON.parse(candidate.trim());
      if (parsed && typeof parsed === "object") return normalizeListingResult(parsed);
    } catch {
      continue;
    }
  }
  return null;
}

function normalizeListingResult(data) {
  const bulletPoints = Array.isArray(data.bulletPoints)
    ? data.bulletPoints.map((item) => String(item).trim()).filter(Boolean)
    : [];
  const keywords = Array.isArray(data.keywords)
    ? data.keywords
    : String(data.keywords || "")
        .split(/[,，;；\n]/)
        .map((item) => item.trim())
        .filter(Boolean);

  return {
    productType: String(data.productType || data.product_type || "").trim().slice(0, 80),
    usage: String(data.usage || data.purpose || "").trim().slice(0, 160),
    title: String(data.title || "").trim().slice(0, 200),
    shortDescription: String(data.shortDescription || "").trim(),
    description: String(data.description || "").trim(),
    keywords: keywords.map((item) => String(item).trim()).filter(Boolean).slice(0, 30),
    categoryHint: String(data.categoryHint || "").trim(),
    bulletPoints: bulletPoints.slice(0, 10),
  };
}

// 把 AI 结果合并进草稿
export function applyListingResult(draft, result) {
  if (!draft || !result) return draft;
  return {
    ...draft,
    ru: {
      ...(draft.ru || {}),
      title: result.title || draft.ru?.title || "",
      productType: result.productType || draft.ru?.productType || "",
      usage: result.usage || draft.ru?.usage || "",
      shortDescription: result.shortDescription || draft.ru?.shortDescription || "",
      description: result.description || draft.ru?.description || "",
      keywords: result.keywords?.length ? result.keywords : draft.ru?.keywords || [],
      bulletPoints: result.bulletPoints?.length ? result.bulletPoints : draft.ru?.bulletPoints || [],
      categoryHint: result.categoryHint || draft.ru?.categoryHint || "",
    },
    updatedAt: new Date().toISOString(),
  };
}

/* ------------------------------------------------------------------
 * 规格维度 AI 自动识别：当 1688 新版页面未展开规格区时，
 * 让 AI 根据标题、描述、SKU 表格文本推断规格维度名称与可选值。
 * ------------------------------------------------------------------ */

export const SPEC_DETECT_SYSTEM_PROMPT = [
  "Ты — специалист по анализу карточек товаров с китайских маркетплейсов.",
  "По названию, описанию и вариантам товара определи характерные вариационные размерности (цвет, размер, материал, комплектация и т.д.).",
  "Отвечай строго валидным JSON без markdown-обёрток.",
].join(" ");

export function buildSpecDetectMessages(product = {}) {
  const skus = (product.skus || [])
    .slice(0, 30)
    .map((sku) => sku.label || Object.values(sku.specs || {}).join(" / "))
    .filter(Boolean)
    .join("\n");
  const attributes = compactAttributes(product);
  const userPayload = [
    `Товар: ${product.title || product.ru?.title || ""}`,
    attributes ? `Характеристики:\n${attributes}` : "",
    skus ? `Варианты на странице:\n${skus}` : "",
    product.description ? `Описание:\n${product.description.slice(0, 800)}` : "",
    "",
    'Определи 1-2 размерности (спецификации) и их возможные значения.',
    'Если товар единичный (без вариаций) — верни пустой массив options.',
    'Формат: {"options": [{"name": "Цвет", "values": ["красный", "синий"]}]}',
  ].filter(Boolean).join("\n");
  return [
    { role: "system", content: SPEC_DETECT_SYSTEM_PROMPT },
    { role: "user", content: userPayload },
  ];
}

/** 解析 AI 返回的规格维度 JSON */
export function parseSpecDetectResult(text) {
  const raw = String(text || "").trim();
  const body = (raw.match(/\{[\s\S]*\}/) || [raw])[0];
  let parsed = null;
  try {
    parsed = JSON.parse(body);
  } catch {
    return null;
  }
  const options = Array.isArray(parsed?.options) ? parsed.options : Array.isArray(parsed) ? parsed : [];
  const out = [];
  for (const item of options) {
    const name = cleanText(item?.name || item?.dimension);
    const values = Array.isArray(item?.values)
      ? item.values
      : String(item?.values || "").split(/[,，、;/]/).map((v) => cleanText(v)).filter(Boolean);
    if (name && values.length) out.push({ name, values: values.slice(0, 20) });
  }
  return out.length ? out : null;
}

/* ------------------------------------------------------------------
 * 电商套图：俄文卖点 + 每张图的俄文标题方案
 * 这两步对应出图工具里的「确认卖点」和「视觉方案规划」——
 * 图上要出现什么字，必须先定死，否则模型会自己乱编俄文（甚至编出乱码）。
 * ------------------------------------------------------------------ */

export const SELLING_POINTS_SYSTEM_PROMPT = [
  "Ты — маркетолог карточки товара на Ozon (Россия).",
  "Твоя задача — короткие, конкретные преимущества товара на русском языке.",
  "Правила: только русский текст; не меняй назначение товара (футбольные бутсы — не «для бега»);",
  "без брендов, без медицинских и юридических обещаний,",
  "без превосходной степени («самый лучший»), без выдуманных цифр — используй только те данные, что даны.",
  "Каждый пункт 40-90 символов, без точки в конце, с большой буквы.",
  "Отвечай строго валидным JSON без markdown-обёрток.",
].join(" ");

/** 商品信息压缩成一段给模型看的文字（卖点/方案两处共用） */
function compactProductBrief(product = {}) {
  const attrs = compactAttributes(product);
  const skus = compactSkus(product);
  return [
    `Название: ${product.title || product.ru?.title || ""}`,
    product.ru?.productType ? `Уже определённый тип товара: ${product.ru.productType}` : "",
    product.ru?.title ? `Заголовок для Ozon: ${product.ru.title}` : "",
    product.ozonCategory?.path ? `Категория Ozon: ${[].concat(product.ozonCategory.path).join(" > ")}` : "",
    attrs ? `Характеристики:\n${attrs}` : "",
    skus ? `Варианты (SKU):\n${skus}` : "",
    product.description ? `Описание источника:\n${String(product.description).slice(0, 1200)}` : "",
  ].filter(Boolean).join("\n\n");
}

export function buildSellingPointsMessages(product = {}, options = {}) {
  const extra = cleanText(options.extraInfo);
  const count = Math.max(3, Math.min(Number(options.count) || 5, 8));
  const userPayload = [
    compactProductBrief(product),
    extra ? `Дополнительные сведения (верны, но не видны на фото): ${extra}` : "",
    "",
    `Сформулируй ${count} главных преимуществ товара для карточки Ozon.`,
    "Каждое преимущество — конкретная польза для покупателя, а не общее слово.",
    'Формат: {"points": ["пункт 1", "пункт 2"]}',
  ].filter(Boolean).join("\n");
  return [
    { role: "system", content: SELLING_POINTS_SYSTEM_PROMPT },
    { role: "user", content: userPayload },
  ];
}

/** 解析卖点：接受 {"points":[...]} 或裸数组；去重、限量、过滤中文 */
export function parseSellingPointsResult(text, limit = 8) {
  const raw = String(text || "").trim();
  const body = (raw.match(/\{[\s\S]*\}/) || raw.match(/\[[\s\S]*\]/) || [raw])[0];
  let parsed = null;
  try {
    parsed = JSON.parse(body);
  } catch {
    return null;
  }
  const list = Array.isArray(parsed?.points)
    ? parsed.points
    : Array.isArray(parsed)
      ? parsed
      : Array.isArray(parsed?.data)
        ? parsed.data
        : [];
  const out = [];
  for (const item of list) {
    const value = cleanText(typeof item === "string" ? item : item?.text || item?.value || item?.point);
    // 图上要出现的是俄文，混进中文一定有地方错了，直接丢掉
    if (!value || /[\u4e00-\u9fa5]/.test(value)) continue;
    if (!out.includes(value)) out.push(value);
  }
  return out.length ? out.slice(0, limit) : null;
}

export const IMAGE_PLAN_SYSTEM_PROMPT = [
  "Ты — арт-директор карточек товаров Ozon (Россия).",
  "Ты пишешь текст, который будет НАРИСОВАН на инфографике товара.",
  "Правила: только русский язык, заголовок 2-5 слов ЗАГЛАВНЫМИ буквами, подзаголовок до 60 символов,",
  "назначение товара не менять и не обобщать, никаких брендов, цен, скидок и обещаний;",
  "текст должен быть коротким — его ещё нужно уместить на картинке.",
  "Отвечай строго валидным JSON без markdown-обёрток.",
].join(" ");

/**
 * 出图标题方案：给每个「带文字的拍摄方案」配一句俄文大标题 + 副标题。
 * 只做标题，不重新规划拍法——拍法由代码里的拍摄方案表定死，模型自由发挥容易跑偏。
 */
export function buildImagePlanMessages(product = {}, shots = [], options = {}) {
  const points = (Array.isArray(options.points) ? options.points : String(options.points || "").split(/[\n,，、;；]/))
    .map((item) => cleanText(item))
    .filter(Boolean)
    .slice(0, 8);
  const extra = cleanText(options.extraInfo);
  const targets = (Array.isArray(shots) ? shots : [])
    .filter((shot) => shot?.id)
    .map((shot) => `  {"id": "${shot.id}", "type": "${shot.label || shot.id}"}`)
    .join(",\n");
  const userPayload = [
    compactProductBrief(product),
    extra ? `Дополнительные сведения: ${extra}` : "",
    points.length ? `Подтверждённые преимущества:\n${points.map((item) => `- ${item}`).join("\n")}` : "",
    "",
    "Для каждого кадра ниже придумай текст, который будет нарисован на изображении.",
    "Заголовок — короткий, продающий, ЗАГЛАВНЫМИ буквами. Подзаголовок — одна короткая поясняющая фраза (или пустая строка).",
    "Соседние кадры не должны повторять один и тот же смысл — раскрывай разные преимущества.",
    "Для кадров с типом «规格标注» или «参数表» дополнительно дай массив labels —",
    "3-6 коротких строк вида «Параметр значение» на русском (например «Объём 2,5 л», «Мощность 2400 Вт»).",
    "Для остальных кадров labels оставь пустым массивом.",
    "",
    `Кадры:\n[\n${targets}\n]`,
    "",
    'Формат ответа: {"plan": [{"id": "main-spec", "title": "ЗАГОЛОВОК", "subtitle": "пояснение", "labels": ["Объём 2,5 л"]}]}',
  ].filter(Boolean).join("\n");
  return [
    { role: "system", content: IMAGE_PLAN_SYSTEM_PROMPT },
    { role: "user", content: userPayload },
  ];
}

/** 解析出图标题方案 → { "<shotId>": { title, subtitle } }；标题里带中文的一律丢掉 */
export function parseImagePlanResult(text) {
  const raw = String(text || "").trim();
  const body = (raw.match(/\{[\s\S]*\}/) || [raw])[0];
  let parsed = null;
  try {
    parsed = JSON.parse(body);
  } catch {
    return null;
  }
  const list = Array.isArray(parsed?.plan)
    ? parsed.plan
    : Array.isArray(parsed?.images)
      ? parsed.images
      : Array.isArray(parsed)
        ? parsed
        : [];
  const out = {};
  for (const item of list) {
    const id = cleanText(item?.id || item?.shot || item?.key);
    const title = cleanText(item?.title || item?.heading);
    const subtitle = cleanText(item?.subtitle || item?.sub);
    if (!id || !title) continue;
    if (/[\u4e00-\u9fa5]/.test(title) || /[\u4e00-\u9fa5]/.test(subtitle)) continue;
    // 规格标签也要俄文——图上的字混进中文，说明模型没听指令，宁可不给
    const labels = (Array.isArray(item?.labels) ? item.labels : [])
      .map((line) => cleanText(line))
      .filter((line) => line && !/[\u4e00-\u9fa5]/.test(line))
      .slice(0, 8);
    out[id] = { title, subtitle, labels };
  }
  return Object.keys(out).length ? out : null;
}

/* ------------------------------------------------------------------
 * v1.9.49 出图前视觉分析：把采集到的参考图真正「看」一遍，
 * 对比它们在构图、风格、色调、光影、材质、主体表现上的差异，
 * 然后为每张待生成的图单独定制一份「导演方案」+ 信息图版式选择。
 * 目的：出图不再反复套同一个固定模板——每张图有独立的处理思路。
 * 需要视觉模型（qwen-vl / qwen3.5-plus 等支持 image_url 的对话模型）；
 * 模型不支持图片输入时调用会失败，面板会降级为「版式逐张轮换」继续出图。
 * ------------------------------------------------------------------ */

export const ART_DIRECTION_SYSTEM_PROMPT = [
  "Ты — арт-директор коммерческой съёмки для карточек Ozon (Россия).",
  "Тебе дают РЕАЛЬНЫЕ фото товара и список кадров, которые нужно по ним собрать.",
  "Сначала СРАВНИ фото между собой и отметь, чем они различаются: композиция, стиль, цветовой тон, свет, материал, подача товара.",
  "Затем для КАЖДОГО кадра придумай СОБСТВЕННОЕ решение, вытекающее из свойств этого товара:",
  "— ракурс и композиция, свет и цветовой тон, фон и материалы окружения, как подать главную деталь товара;",
  "— кадры ОБЯЗАТЕЛЬНО должны отличаться друг от друга: не повторяй одну схему, не делай «шаблон на все случаи»;",
  "— layout: номер макета инфографики от 0 до 4 для кадров с текстом (0 — вертикальный инфо-блок слева; 1 — баннер сверху + чипы снизу; 2 — список преимуществ справа; 3 — технический чертёж с выносками; 4 — журнальный минимализм с воздухом); для кадров без текста верни 0;",
  "— artDirection: 1-2 фразы на русском с конкретной режиссурой ИМЕННО этого кадра (что в кадре, откуда свет, какой фон, на какой детали акцент).",
  "Учитывай назначение каждого кадра (type) и режим текста (text).",
  "Отвечай строго валидным JSON без markdown-обёрток.",
].join(" ");

/**
 * 组视觉分析请求。referenceImages 为 data URL / URL 数组（最多 3 张，与生图参考一致）。
 * shots: [{ id, label, text }]
 */
export function buildArtDirectionMessages(product = {}, shots = [], options = {}) {
  const refs = (Array.isArray(options.referenceImages) ? options.referenceImages : [])
    .map((item) => String(item || "").trim())
    .filter(Boolean)
    .slice(0, 3);
  const brief = [
    `Товар: ${product.title || product.ru?.title || ""}`,
    product.ru?.productType ? `Тип товара: ${product.ru.productType}` : "",
    product.ru?.usage ? `Назначение: ${product.ru.usage}` : "",
    options.extraInfo ? `Дополнительно: ${options.extraInfo}` : "",
    "Перечисленные выше фото — реальные фото этого товара с разных ракурсов; сравни их между собой перед тем, как планировать кадры.",
    "",
    "Кадры для планирования:",
    JSON.stringify((shots || []).filter((shot) => shot?.id)
      .map((shot) => ({ id: shot.id, type: shot.label || shot.id, text: shot.text || "none" }))),
    "",
    'Формат ответа: {"comparison":"1-2 фразы: чем фото различаются по композиции/свету/цвету/материалу","shots":[{"id":"main","layout":2,"artDirection":"...","why":"почему так"}]}',
  ].filter(Boolean).join("\n");
  return [
    { role: "system", content: ART_DIRECTION_SYSTEM_PROMPT },
    {
      role: "user",
      content: [
        ...refs.map((url) => ({ type: "image_url", image_url: { url } })),
        { type: "text", text: brief },
      ],
    },
  ];
}

/**
 * 解析视觉分析结果 → { comparison, shots: { "<id>": { layout, artDirection, why } } }。
 * layout 夹到 0-4；artDirection 混进中文视为无效（要直接进俄文生图提示词）。
 */
export function parseArtDirectionResult(text) {
  const raw = String(text || "").trim();
  const body = (raw.match(/\{[\s\S]*\}/) || [raw])[0];
  let parsed = null;
  try {
    parsed = JSON.parse(body);
  } catch {
    return null;
  }
  if (!parsed || typeof parsed !== "object") return null;
  const list = Array.isArray(parsed?.shots) ? parsed.shots : [];
  const out = {};
  for (const item of list) {
    const id = cleanText(item?.id || item?.shot || item?.key);
    const artDirection = cleanText(item?.artDirection || item?.direction || item?.note);
    if (!id || !artDirection) continue;
    if (/[\u4e00-\u9fa5]/.test(artDirection)) continue; // 中文方案进不了俄文提示词，宁缺毋滥
    const layoutRaw = Number(item?.layout);
    const layout = Number.isFinite(layoutRaw) ? Math.max(0, Math.min(4, Math.trunc(layoutRaw))) : 0;
    out[id] = { layout, artDirection, why: cleanText(item?.why).slice(0, 200) };
  }
  if (!Object.keys(out).length) return null;
  return { comparison: cleanText(parsed.comparison).slice(0, 400), shots: out };
}

/* ------------------------------------------------------------------
 * v1.9.64 JSON 富内容（Ozon 属性 id 11254）
 *
 * 富内容是「图片 + 标题 + 正文」组成的商品详情长图区，有它的时候会**替代**详细描述
 * 显示在卡片里。官方格式是一段 JSON（顶层 widget 数组，widget 里放 block），
 * 官方可视化编辑器：https://rich-content.ozon.ru/visual-editor
 *
 * 分工原则：模型只写「文字」（每个图块的标题与正文），图片直链与宽高必须由插件用
 * 采集到的真实数据拼 —— 模型编出来的图片地址一定 404，宽高对不上会让排版错乱。
 * 拼接与校验在 shared/rich-content.js。
 * ------------------------------------------------------------------ */

export const RICH_CONTENT_SYSTEM_PROMPT = [
  "Ты — контент-редактор карточек товаров на маркетплейсе Ozon (Россия).",
  "Тебе дают товар и нумерованный список его изображений. Для каждого изображения напиши заголовок и короткий текст для блока «Rich content» (расширенное описание карточки).",
  "Пиши ТОЛЬКО на русском языке. Категорически запрещены китайские и английские слова, латиница допустима только в единицах измерения (мм, см, кг, Вт, В).",
  "Заголовок: 2–6 слов, по существу, без КАПСА и без превосходной степени.",
  "Текст: 1–3 предложения (до 300 символов) о конкретной выгоде или свойстве товара, логически связанные с тем, что изображено на этом фото (общий вид, деталь, комплект, применение).",
  "Не повторяй один и тот же смысл в разных блоках: каждый блок раскрывает свою сторону товара.",
  "Опирайся ТОЛЬКО на исходные данные о товаре. Не выдумывай бренды, материалы, размеры, сертификаты и цифры.",
  "Если данных о товаре мало — пиши нейтрально и обще, но не выдумывай факты и не пиши, что данных нет.",
  'Отвечай строго валидным JSON вида {"blocks":[{"title":"...","text":"..."}]} без markdown-обёрток. Количество элементов равно количеству изображений и порядок сохраняется.',
].join(" ");

/** 构造富内容文字方案请求：只让模型产出 blocks（标题 + 正文），图片地址不经过模型 */
export function buildRichContentMessages(product = {}, images = [], options = {}) {
  const ru = product.ru || {};
  const attrs = compactAttributes(product);
  const skus = compactSkus(product);
  const description = cleanText(options.description || ru.description || product.description || "");
  const list = (images || [])
    .map((image, index) => `${index + 1}. ${cleanText(image?.url)}`)
    .join("\n");
  const userPayload = [
    `Товар (${product.platform || "unknown"}):`,
    ru.title ? `Русское название: ${ru.title}` : (product.title ? `Название: ${product.title}` : ""),
    ru.productType ? `Тип товара: ${ru.productType}` : "",
    ru.usage ? `Назначение: ${ru.usage}` : "",
    ru.shortDescription ? `Ключевые преимущества: ${ru.shortDescription}` : "",
    description ? `Описание товара:\n${String(description).slice(0, 2000)}` : "",
    attrs ? `Характеристики:\n${attrs}` : "",
    skus ? `Варианты:\n${skus}` : "",
    "",
    `Изображения (${(images || []).length} шт., порядок сохраняется):`,
    list,
    "",
    `Верни JSON: {"blocks":[{"title":"<заголовок>","text":"<текст>"}]} — ровно ${(images || []).length} элемент(ов), по одному на каждое изображение, в том же порядке.`,
  ].filter(Boolean).join("\n");
  return [
    { role: "system", content: RICH_CONTENT_SYSTEM_PROMPT },
    { role: "user", content: userPayload },
  ];
}

/**
 * 解析富内容文字方案 → { blocks: [{ title, text }] }。
 * 混进中文的条目直接丢掉：俄语卡片里出现中文会被平台判为低质量，宁缺毋滥
 * （全丢光时返回 null，调用方改走不调 AI 的兜底排版）。
 */
export function parseRichContentPlanResult(text) {
  const raw = String(text || "").trim();
  const body = (raw.match(/\{[\s\S]*\}/) || [raw])[0];
  let parsed = null;
  try {
    parsed = JSON.parse(body);
  } catch {
    return null;
  }
  const list = Array.isArray(parsed?.blocks)
    ? parsed.blocks
    : (Array.isArray(parsed) ? parsed : []);
  const blocks = [];
  for (const item of list) {
    const title = cleanText(item?.title);
    const bodyText = cleanText(item?.text || item?.content);
    if (!title && !bodyText) continue;
    if (CJK_RE.test(title) || CJK_RE.test(bodyText)) continue;
    blocks.push({ title: title.slice(0, 120), text: bodyText.slice(0, 400) });
  }
  return blocks.length ? { blocks } : null;
}
