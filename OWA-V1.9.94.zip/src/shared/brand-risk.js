/**
 * 品牌合规预检（v1.9.61）
 *
 * 背景：Ozon 会给卖家发通知「商品将于 X 月 X 日被封锁 —— 缺少品牌文件」。
 * 成因几乎都是同一个：商品卡片里的「Бренд」属性填了某个品牌，而 Ozon 认定该品牌
 * 受保护，要求卖家提交品牌授权书 / 供货合同 / 进货发票；交不出来就封锁商品，
 * 严重的还会被品牌方直接投诉侵权。
 *
 * 必须说清楚的能力边界：**插件拿不到、也不该伪造授权文件**——那是商务问题。
 * 但品牌封锁有很强的规律性，几乎都能在上传前拦住。所以这里只做三件事：
 *   1. 类目有「Бренд」属性却没填 → 直接点出来（Ozon 后续一定会要品牌文件）；
 *   2. 商品其实没品牌 → 一键填官方字典值「Нет бренда」，这是无品牌商品的正解；
 *   3. 标题/采集属性里出现了受保护品牌词，品牌属性却没填（或填了「无品牌」）→
 *      这是「缺少品牌文件」封锁 + 被品牌方举报的最高发组合，必须拦下来。
 *
 * 品牌词表是**启发式清单**，只覆盖高频受保护品牌，命中不等于侵权、不构成法律意见；
 * 没命中也不代表安全。它的价值在于把「事后被封」变成「事前自查」。
 */
import { cleanText } from "./utils.js";

/** 品牌类属性：Ozon 的「Бренд」是上架必填率最高、也是封锁率最高的一个属性 */
export const BRAND_ATTR_RE = /бренд|brand|brand\s*name|торгов\w*\s*марк/i;

/** Ozon 官方字典里的「无品牌」取值（把历史上出现过的几种写法都收进来，避免拼写差异漏判） */
export const NO_BRAND_RE = /^(?:нет\s*бренда|без\s*бренда|бренд\s*отсутствует|no\s*brand|noname|no\s*name|none)$/i;

export function isBrandAttribute(attr = {}) {
  const name = cleanText(attr.name || attr.attribute_name || attr.title);
  const zh = cleanText(attr.displayName || attr.display_name);
  return BRAND_ATTR_RE.test(name) || /品牌/.test(zh);
}

export function isNoBrandValue(value) {
  return NO_BRAND_RE.test(cleanText(value));
}

/** 把「Нет бренда」这类值的各种写法归一到紧凑形式，用于字典里挑无品牌项 */
const NO_BRAND_COMPACT_RE = /^(?:нетбренда|безбренда|брендотсутствует|nobrand|noname|noname|none)$/;

function compact(value) {
  return cleanText(value).toLowerCase().replace(/[^a-z0-9\u0400-\u04ff]/g, "");
}

/** 从类目字典里挑出「无品牌」那一项（本地字典通常已含此项，绝大多数类目无需联网） */
export function pickNoBrandFromDictionary(dictionary = []) {
  for (const item of Array.isArray(dictionary) ? dictionary : []) {
    const value = cleanText(item?.value ?? item);
    if (!value) continue;
    if (isNoBrandValue(value) || NO_BRAND_COMPACT_RE.test(compact(value))) {
      return { value, id: Number(item?.id) || 0 };
    }
  }
  return null;
}

/**
 * 高频受保护品牌清单（分 中/英 两组）。
 * 入选标准：在 Ozon 上属于「必需要品牌授权文件才能卖」的强品牌，且在国内货源标题里出现率不低。
 * 刻意不做穷举——清单越长误报越多，用户会直接无视提示。
 */
const PROTECTED_LATIN = [
  // 消费电子 / 手机
  "apple", "iphone", "ipad", "macbook", "airpods", "samsung", "galaxy", "xiaomi", "redmi", "poco",
  "huawei", "honor", "oppo", "vivo", "realme", "oneplus", "meizu", "zte", "nokia", "motorola",
  "sony", "playstation", "xbox", "nintendo", "switch", "gopro", "dji", "insta360",
  // 电脑 / 外设 / 网络
  "intel", "amd", "nvidia", "geforce", "radeon", "asus", "acer", "lenovo", "dell", "hp", "msi",
  "gigabyte", "tp-link", "netgear", "logitech", "razer", "corsair", "hyperx", "keychron",
  // 音频
  "jbl", "bose", "beats", "sennheiser", "marshall", "harman", "anker", "soundcore", "edifier",
  // 家电 / 电动工具
  "dyson", "bosch", "makita", "dewalt", "milwaukee", "stanley", "siemens", "electrolux",
  "whirlpool", "tefal", "moulinex", "braun", "rowenta", "delonghi", "kenwood", "philips",
  "panasonic", "toshiba", "sharp", "lg", "haier", "midea", "hisense",
  // 影像
  "canon", "nikon", "fujifilm", "olympus", "sigma", "tamron",
  // 运动 / 服饰 / 箱包
  "nike", "adidas", "puma", "reebok", "asics", "newbalance", "underarmour", "converse", "vans",
  "the north face", "columbia", "uniqlo", "zara", "h&m", "decathlon",
  // 玩具 / 母婴 / 文具
  "lego", "disney", "marvel", "sanrio", "hello kitty", "bandai", "hasbro", "fisher price",
  "pampers", "huggies", "merries", "moony",
  // 个护 / 美妆 / 食品饮料
  "loreal", "nivea", "garnier", "maybelline", "dove", "colgate", "oral-b", "gillette",
  "head&shoulders", "pantene", "safeguard", "coca-cola", "pepsi", "nestle", "ferrero",
  // 轻奢 / 腕表
  "chanel", "dior", "gucci", "prada", "rolex", "casio", "g-shock", "fossil", "swatch",
  // 汽车 / 摩托
  "toyota", "honda", "bmw", "audi", "volkswagen", "mercedes", "tesla", "yamaha", "kawasaki",
];

const PROTECTED_CJK = [
  "苹果", "三星", "小米", "红米", "华为", "荣耀", "欧珀", "维沃", "真我", "一加", "魅族", "中兴", "诺基亚",
  "索尼", "任天堂", "佳能", "尼康", "富士", "松下", "东芝", "夏普", "飞利浦", "戴森", "博世", "西门子",
  "海尔", "美的", "格力", "海信", "苏泊尔", "九阳", "小熊", "老板电器", "方太",
  "联想", "戴尔", "惠普", "华硕", "宏碁", "微星", "技嘉", "普联", "雷蛇", "罗技", "雷柏", "大疆",
  "耐克", "阿迪达斯", "彪马", "锐步", "亚瑟士", "新百伦", "安德玛", "匡威", "万斯", "迪卡侬",
  "优衣库", "无印良品", "名创优品",
  "乐高", "迪士尼", "漫威", "三丽鸥", "凯蒂猫", "万代", "孩之宝",
  "帮宝适", "好奇", "花王", "尤妮佳", "贝亲",
  "欧莱雅", "妮维雅", "卡尼尔", "美宝莲", "多芬", "海飞丝", "潘婷", "舒肤佳", "飘柔",
  "高露洁", "佳洁士", "吉列", "可口可乐", "百事", "雀巢", "费列罗",
  "香奈儿", "迪奥", "古驰", "普拉达", "劳力士", "卡西欧", "斯沃琪",
  "丰田", "本田", "宝马", "奥迪", "大众", "奔驰", "特斯拉", "雅马哈", "川崎",
];

/** 长品牌走「紧凑包含」匹配（顺带解决 L'Oreal / G-Shock / New Balance 这类标点与空格写法） */
const LATIN_LONG = PROTECTED_LATIN.map(compact).filter((w) => w.length >= 5);
/** 短品牌走「整词」匹配，避免 hp / lg / amd 在别的词里被误命中 */
const LATIN_SHORT = PROTECTED_LATIN.map(compact).filter((w) => w.length > 0 && w.length < 5);

/** 在文本里扫出疑似受保护品牌词（返回命中的原词，用于提示；去重） */
export function scanBrandWords(text) {
  const raw = cleanText(text);
  if (!raw) return [];
  const hits = new Set();
  const hay = raw.toLowerCase();
  const hayCompact = hay.replace(/[^a-z0-9\u0400-\u04ff]/g, "");
  const hayBounded = ` ${hay.replace(/[^a-z0-9]+/g, " ")} `;
  for (const word of LATIN_LONG) {
    if (word && hayCompact.includes(word)) hits.add(word);
  }
  for (const word of LATIN_SHORT) {
    if (word && hayBounded.includes(` ${word} `)) hits.add(word);
  }
  for (const word of PROTECTED_CJK) {
    if (raw.includes(word)) hits.add(word);
  }
  return [...hits];
}

/** 「官方 / 授权 / 正品」这类宣称词：即使品牌属性没填，光靠这几个字也容易被投诉 */
const CLAIM_RE = /официальн|original|authentic|genuine|лицензи|official|旗舰店|官方|授权|正品|原装|专柜/i;
/** 商标符号：标题里出现 ® ™ © 等于主动声明「这是注册商标商品」 */
const MARK_RE = /[®™©]/;
/** 图片地址里带这些片段的，大概率是品牌 logo / 授权书 / 水印图 */
const IMAGE_RISK_RE = /logo|brand|watermark|shuiyin|trademark|授权|商标/i;

/**
 * 汇总品牌合规风险。
 * @returns {{ level: "high"|"medium"|"ok", items: Array<{level:"problem"|"warning", code, title, detail, advice}> }}
 */
export function collectBrandRisks({
  title = "",
  description = "",
  attributes = [],
  attributeValues = {},
  categoryAttributes = [],
  images = [],
  skipAttributeIds = [],
} = {}) {
  const items = [];
  const push = (level, code, title_, detail, advice) => items.push({ level, code, title: title_, detail, advice });

  const attrs = Array.isArray(categoryAttributes) ? categoryAttributes : [];
  const brands = attrs.filter(isBrandAttribute);
  const skip = new Set((skipAttributeIds || []).map((id) => String(id)));
  const declared = brands.map((attr) => ({ attr, value: cleanText(attributeValues[String(attr.id)]) }));
  const declaredReal = declared.filter((d) => d.value && !isNoBrandValue(d.value));
  const declaredNoBrand = declared.filter((d) => d.value && isNoBrandValue(d.value));

  // ① 类目有品牌属性但没填（必填项已由通用「必填属性缺失」提示覆盖，这里不重复刷屏）
  const emptyBrands = declared.filter((d) => !d.value);
  for (const { attr } of emptyBrands) {
    const id = String(attr.id);
    if (attr.is_required && skip.has(id)) continue;
    push(
      attr.is_required ? "problem" : "warning",
      "brand-attr-missing",
      `品牌属性没填（ID ${id}）`,
      "Ozon 的「Бренд」是封锁率最高的属性：留空时平台会在审核后要求补品牌文件，补不上就封锁商品。",
      "商品本身没品牌 → 点「一键填无品牌」写入官方值「Нет бренда」；有品牌 → 先备好品牌授权书/供货合同/进货发票再上架。",
    );
  }

  // ② 品牌属性填了具体品牌：不是错，但必须有文件兜底
  for (const { attr, value } of declaredReal) {
    push(
      "warning",
      "brand-needs-doc",
      `品牌填的是具体品牌「${value}」`,
      `Ozon 认定受保护品牌（如 ${scanBrandWords(value).join("、") || "知名品牌"}）时会要求提交品牌授权文件，交不出即封锁商品，并可能被品牌方投诉侵权。`,
      "确认你手上有该品牌的授权书/供货合同/进货发票；拿不到就把品牌属性改成「Нет бренда」，并在标题里去干净品牌词。",
    );
    break; // 同一批商品提示一次就够，避免每个变体刷一行
  }

  // ③ 标题/采集属性里出现受保护品牌词 —— 与品牌属性是否填了「无品牌」互相矛盾时最危险
  const titleHits = scanBrandWords(title);
  const sourceBrand = (Array.isArray(attributes) ? attributes : [])
    .map((a) => ({ name: cleanText(a?.name), value: cleanText(Array.isArray(a?.values) ? a.values[0] : (a?.value ?? a?.val)) }))
    .find((a) => a.value && (/品牌|brand/i.test(a.name) || scanBrandWords(a.value).length));
  if (titleHits.length) {
    const conflict = !declaredReal.length;
    push(
      conflict ? "problem" : "warning",
      conflict ? "brand-conflict" : "brand-title-hit",
      `标题里出现了品牌词「${titleHits.slice(0, 4).join("、")}」`,
      conflict
        ? "标题写着品牌、品牌属性却是空的或「Нет бренда」——自相矛盾，这是被平台判「缺少品牌文件」封锁、被品牌方举报的最高发组合。"
        : "标题与品牌属性都指向同一个品牌，属于一致写法，但前提是你确实有该品牌的销售授权。",
      conflict
        ? "二选一：① 真有授权 → 把品牌属性如实填上并备好授权文件；② 没有授权 → 把标题里的品牌词删掉，只留品类 + 通用属性（如「无线蓝牙耳机 降噪 长续航」）。"
        : "没有该品牌授权的话，把标题里的品牌词换成通用描述词，避免被品牌方扫到投诉。",
    );
  }
  if (sourceBrand && !titleHits.length && !declaredReal.length) {
    push(
      "warning",
      "brand-source-attr",
      `采集源标注的品牌是「${sourceBrand.value}」`,
      "1688/淘宝的商品属性里带品牌名，说明货源方把它当品牌商品卖；这个品牌名很可能同时出现在图片上。",
      "要么按品牌商品走（填品牌属性 + 备授权文件），要么把标题、属性、图片里的品牌信息全部去掉再上架。",
    );
  }

  // ④ 官方/授权/正品等宣称词
  const claimText = `${title} ${description}`;
  if (CLAIM_RE.test(claimText)) {
    push(
      "warning",
      "brand-claim-word",
      "标题/描述里有「官方/授权/正品/原装」这类宣称词",
      "这类词在没有品牌授权的前提下属于虚假宣传，Ozon 审核和品牌方投诉都会优先命中它。",
      "删掉这些词，用中性描述替代（如「原装」→ 直接不写；「官方」→ 不写）。",
    );
  }

  // ⑤ 商标符号
  if (MARK_RE.test(claimText)) {
    push(
      "warning",
      "brand-mark-symbol",
      "标题/描述里带 ® ™ © 商标符号",
      "商标符号等于主动声明该商品是注册商标商品，会直接把审核指向「请提供品牌文件」。",
      "删掉 ® ™ © 符号；品牌信息只保留在品牌属性里。",
    );
  }

  // ⑥ 图片地址命中 logo/水印特征
  const riskyImages = (Array.isArray(images) ? images : []).map(cleanText).filter((u) => u && IMAGE_RISK_RE.test(u));
  if (riskyImages.length) {
    push(
      "warning",
      "brand-image-logo",
      `有 ${riskyImages.length} 张图片的地址带 logo/品牌/水印特征`,
      "主图带品牌 logo 或授权水印，既可能被判「主图不合规」，也是品牌方投诉时最直接的证据。",
      "到「④ 图片」把这几张换成 AI 重绘的无品牌主图（AI 套图生成的主图不带原图 logo）。",
    );
  }

  const level = items.some((i) => i.level === "problem") ? "high" : (items.length ? "medium" : "ok");
  return { level, items };
}

/** 把品牌风险条目拍平成一行中文，供上传前自检表格 / toast 复用 */
export function formatBrandRisk(item) {
  return `【品牌合规】${item.title}：${item.detail} ${item.advice}`;
}
