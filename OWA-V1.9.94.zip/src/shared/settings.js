// 设置与店铺的读写封装。所有凭据只存在 chrome.storage.local，不落盘、不上传。
import { STORAGE_KEYS, AI_PRESETS } from "./constants.js";
import { normalizePricingTemplate, normalizeListingTemplate } from "./pricing.js";
import { cleanText, extractApiConfig } from "./utils.js";

export const DEFAULT_SETTINGS = Object.freeze({
  aiPresetId: "deepseek",
  aiBaseUrl: AI_PRESETS[0].baseUrl,
  aiModel: AI_PRESETS[0].defaultModel,
  aiApiKey: "",
  // v1.9.49 视觉分析模型：出图前「看参考图 → 逐图定制方案」用，必须支持图片输入
  // （如 qwen-vl-max / qwen3.5-plus / glm-4v 等）。留空则回落上面的主模型。
  aiVisionModel: "",
  // 图片翻译走象寄开放平台（xiangjifanyi.com），需要 ImgTransKey；按张计费。
  // 象寄的每个翻译引擎有各自的「图片翻译标识码」，所以这里存成一组：
  // [{ id, vendor: "DeepL", key: "..." }]，同引擎可以配多个 Key 轮换/并行。
  xiangjiKeys: [],
  xiangjiVendor: "DeepL",
  // 兼容旧版本：单 Key 字段，读取时会自动迁移进 xiangjiKeys
  xiangjiApiKey: "",
  // AI 生图（OpenAI 兼容 /images/generations）。留空时对应功能不可用，界面会明确提示。
  imagePresetId: "",
  imageBaseUrl: "",
  imageModel: "",
  imageApiKey: "",
  imageSize: "1024x1024",      // 出图尺寸，各服务支持范围不同（如达瓦中转默认 1008x1344）
  imageAspectRatio: "",        // 仅个别中转需要（如 api.siliconflow.cn 认 aspect_ratio）
  ozonClientId: "",
  ozonApiKey: "",
  stores: [],
  pricing: normalizePricingTemplate(),
  // OZON 核价表口径（对齐用户自用的「上架表」）
  listing: normalizeListingTemplate(),
  skuPrefix: "",
  reviewBeforeUpload: true,
  bulkDelayMs: 1500,
  descriptionAttributeId: 4191, // Ozon 描述属性「Аннотация」的通用 id，个别类目可在界面调整
  variantAttributeId: 0, // 变体属性 id（如颜色/尺码），填写后多个选用 SKU 会合并为同一卡片的多规格商品
  // v1.9.80 更新源：填一个返回 JSON 的地址（GitHub raw / 对象存储直链 / 开了 CORS 的服务器均可），
  // 内容形如 {"version":"1.9.81","url":"https://…/OWA-V1.9.81.zip","notes":"这次更新了什么"}。
  // 点顶栏版本号即可检查更新。留空则提示先去设置里配置。
  updateUrl: "",
});

/**
 * 归一化象寄密钥列表：兼容旧版的单个 xiangjiApiKey，并按引擎去重（同引擎同 Key 只留一条）。
 * 返回值里带 key 的条目才可用。
 */
export function normalizeXiangjiKeys(settings = {}) {
  const raw = Array.isArray(settings.xiangjiKeys) ? settings.xiangjiKeys : [];
  const list = raw
    .map((item, index) => ({
      id: cleanText(item?.id) || `xj_${index}`,
      vendor: cleanText(item?.vendor) || cleanText(settings.xiangjiVendor) || "DeepL",
      key: cleanText(item?.key),
    }))
    .filter((item) => item.key);

  if (!list.length && cleanText(settings.xiangjiApiKey)) {
    list.push({
      id: "xj_legacy",
      vendor: cleanText(settings.xiangjiVendor) || "DeepL",
      key: cleanText(settings.xiangjiApiKey),
    });
  }

  const seen = new Set();
  return list.filter((item) => {
    const dedupeKey = `${item.vendor}|${item.key}`;
    if (seen.has(dedupeKey)) return false;
    seen.add(dedupeKey);
    return true;
  });
}

function storage() {
  return globalThis.chrome?.storage?.local;
}

export async function loadSettings() {
  const store = storage();
  if (!store) return { ...DEFAULT_SETTINGS };
  const result = await store.get(STORAGE_KEYS.settings);
  const stored = result?.[STORAGE_KEYS.settings] || {};
  return {
    ...DEFAULT_SETTINGS,
    ...stored,
    pricing: normalizePricingTemplate(stored.pricing),
    listing: normalizeListingTemplate(stored.listing),
    stores: Array.isArray(stored.stores) ? stored.stores : [],
    xiangjiKeys: normalizeXiangjiKeys(stored),
  };
}

export async function saveSettings(patch = {}) {
  const store = storage();
  const current = await loadSettings();
  const next = { ...current, ...patch };
  if (patch.pricing) next.pricing = normalizePricingTemplate(patch.pricing);
  if (patch.listing) next.listing = normalizeListingTemplate(patch.listing);
  if (patch.xiangjiKeys) {
    next.xiangjiKeys = normalizeXiangjiKeys(next);
    // 新结构生效后清掉旧字段，否则「把密钥全删掉」会被旧值复活
    next.xiangjiApiKey = "";
  }
  if (store) await store.set({ [STORAGE_KEYS.settings]: next });
  return next;
}

// AI 凭据：允许按店铺/临时覆盖
export function resolveAiCredentials(settings = {}) {
  const rawBase = cleanText(settings.aiBaseUrl);
  // 用户可能把「渠道配置 JSON」整段粘进了地址框，这里把 url/key 拆出来兜底
  const picked = extractApiConfig(rawBase);
  return {
    baseUrl: picked.url || rawBase,
    apiKey: cleanText(settings.aiApiKey) || picked.key,
    model: cleanText(settings.aiModel),
  };
}

/**
 * v1.9.49 视觉分析凭据：与主 AI 同地址同 Key，只有模型名可能不同
 * （视觉分析必须用支持图片输入的模型；留空回落主模型）。
 */
export function resolveVisionCredentials(settings = {}) {
  const base = resolveAiCredentials(settings);
  return { ...base, model: cleanText(settings.aiVisionModel) || base.model };
}

/**
 * 象寄翻译凭据。象寄每个翻译引擎有各自的「图片翻译标识码」，所以按引擎取 Key：
 * 只返回所选引擎的 Key（同引擎可配多个，后台会切块并行提交）。
 * 严格匹配不回落 —— 用 A 引擎的 Key 却声明 B 引擎会失败或计费异常，
 * 不如让上层直接给出「该引擎没有可用密钥」的明确提示。
 */
export function resolveXiangjiCredentials(settings = {}, vendor = "") {
  const all = normalizeXiangjiKeys(settings);
  const wanted = cleanText(vendor) || cleanText(settings.xiangjiVendor);
  const keys = wanted ? all.filter((item) => item.vendor === wanted) : all;
  return { vendor: wanted, keys, all };
}

/** 已配置密钥的引擎 id 列表，用于只列出真正可用的引擎 */
export function xiangjiConfiguredVendors(settings = {}) {
  return Array.from(new Set(normalizeXiangjiKeys(settings).map((item) => item.vendor)));
}

/** 生图模型凭据。未单独配置时回落到通用 AI 配置。 */
export function resolveImageCredentials(settings = {}) {
  const rawBase = cleanText(settings.imageBaseUrl) || cleanText(settings.aiBaseUrl);
  // 和 AI 文案一样，允许把整段渠道配置 JSON 粘进地址框
  const picked = extractApiConfig(rawBase);
  return {
    baseUrl: picked.url || rawBase,
    apiKey: cleanText(settings.imageApiKey) || cleanText(settings.aiApiKey) || picked.key,
    model: cleanText(settings.imageModel),
    size: cleanText(settings.imageSize) || "1024x1024",
    aspectRatio: cleanText(settings.imageAspectRatio),
  };
}

export function resolveOzonCredentials(settings = {}, storeId = "") {
  const store = (settings.stores || []).find((item) => item.id === storeId);
  if (store) {
    return { clientId: cleanText(store.clientId), apiKey: cleanText(store.apiKey), name: store.name || "" };
  }
  return {
    clientId: cleanText(settings.ozonClientId),
    apiKey: cleanText(settings.ozonApiKey),
    name: "默认店铺",
  };
}
