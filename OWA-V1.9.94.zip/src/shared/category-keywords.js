// 商品领域关键词词典：借鉴「达瓦」类目推荐器的两阶段思路 ——
// 先用关键词命中判断商品落在哪个领域（收纳/家具/服装/3C/箱包…），
// 再做领域内消歧，避免同根多义词（货架 vs 儿童游戏架、婴儿床 vs 儿童床）被误判。
//
// 关键词同时给 中文 / 俄文 / 英文，覆盖超哥主要经营的品类。
// 想加自己品类的识别词，往对应 domain 的 keywords 里补即可，无需改匹配逻辑。

/** 每个领域一组词（中/俄/英小写）；匹配时按词命中计数 */
export const CATEGORY_DOMAINS = [
  {
    domain: "家居收纳",
    keywords: [
      "货架", "置物架", "收纳", "储物", "书架", "展示架", "陈列架", "层架", "鞋架", "厨房架",
      "储物盒", "收纳盒", "收纳箱", "整理箱", "分隔盒", "抽屉", "衣架", "挂钩", "置物",
      "стеллаж", "полк", "шкаф", "хранен", "контейнер", "органайз", "корзин", "вешалк",
      "shelf", "rack", "storage", "organizer", "container", "drawer", "hanger",
    ],
  },
  {
    domain: "家具",
    keywords: [
      "家具", "沙发", "床", "床垫", "桌椅", "桌子", "椅子", "茶几", "衣柜", "书桌", "电脑桌",
      "餐桌", "餐椅", "凳子", "榻榻米", "斗柜", "床头柜", "鞋柜", "电视柜", "书柜",
      "мебел", "диван", "кроват", "стол", "стул", "кресло", "шкаф", "комод", "тумб",
      "furniture", "sofa", "bed", "table", "chair", "desk", "wardrobe", "dresser",
    ],
  },
  {
    domain: "儿童家具/围栏",
    keywords: [
      "婴儿床", "儿童床", "宝宝床", "围栏", "游戏围栏", "婴儿围栏", "爬行垫", "儿童桌椅", "学习桌",
      "детск", "детская кроват", "манеж", "огражден", "пеленальн", "детский стол",
      "baby bed", "crib", "playpen", "kids furniture", "toddler",
    ],
  },
  {
    domain: "儿童玩具/游乐",
    keywords: [
      "玩具", "积木", "公仔", "玩偶", "拼图", "滑梯", "秋千", "蹦床", "摇马", "早教", "绘本",
      "игрушк", "конструктор", "пазл", "горк", "качел", "батут", "мягк", "кук",
      "toy", "puzzle", "blocks", "plush", "doll", "slide", "swing",
    ],
  },
  {
    domain: "服装",
    keywords: [
      "连衣裙", "裙子", "t恤", "短袖", "上衣", "衬衫", "裤子", "牛仔裤", "外套", "卫衣", "毛衣",
      "针织", "套装", "内衣", "童装", "男装", "女装", "羽绒服", "风衣", "大衣",
      "платье", "юбк", "рубашк", "футболк", "брюк", "куртк", "свитер", "худи", "комбинезон", "одежд",
      "dress", "skirt", "shirt", "tshirt", "pants", "jacket", "sweater", "hoodie", "clothing", "outfit",
    ],
  },
  {
    domain: "鞋靴",
    keywords: [
      "鞋", "运动鞋", "拖鞋", "凉鞋", "靴子", "皮鞋", "帆布鞋", "棉鞋", "童鞋", "高跟鞋", "休闲鞋",
      "обув", "кроссов", "sneaker", "sandal", "boot", "slipper", "shoes",
    ],
  },
  {
    domain: "箱包",
    keywords: [
      "包", "背包", "双肩包", "手提包", "斜挎包", "钱包", "行李箱", "旅行箱", "妈咪包", "书包", "化妆包",
      "рюкзак", "сумк", "чемодан", "косметичк", "портмон",
      "backpack", "bag", "handbag", "suitcase", "wallet", "luggage", "purse",
    ],
  },
  {
    domain: "3C数码配件",
    keywords: [
      "手机壳", "保护壳", "保护套", "数据线", "充电线", "快充线", "type-c", "充电器", "电源适配器",
      "充电头", "耳机", "蓝牙耳机", "有线耳机", "保护膜", "贴膜", "钢化膜", "支架", "手机支架",
      "充电宝", "数据线", "转接头", "壳", "чехол", "кабель", "заряд", "наушник", "пленк", "сто",
      "case", "cable", "charger", "adapter", "headphone", "earphone", "screen protector", "stand", "power bank",
    ],
  },
  {
    domain: "厨房用品",
    keywords: [
      "厨房", "厨具", "餐具", "碗", "盘", "锅", "刀具", "菜板", "铲", "勺", "保鲜", "油壶", "调料瓶",
      "水杯", "杯子", "保温杯", "玻璃杯", "马克杯", "饭盒", "砧板",
      "кухон", "нож", "тарелк", "чашк", "стакан", "кастрюл", "сковород", "термос", "контейнер",
      "kitchen", "knife", "plate", "bowl", "cup", "mug", "pot", "pan", "tableware",
    ],
  },
  {
    // v1.9.77：超哥主营之一（空气炸锅等小家电）。此前词典没有这个领域，
    // 「家用电器」叶子路径只能靠「锅」这类单字蹭厨房用品加权——单字收紧后（防「键盘乐器」
    // 被「盘」误判进厨房）这些叶子反而丢了领域分。补正经领域词，路径与商品两头都能命中。
    domain: "家用电器",
    keywords: [
      "空气炸锅", "电炸锅", "炸锅", "烤箱", "电饭煲", "电压力锅", "破壁机", "榨汁机", "原汁机",
      "豆浆机", "电磁炉", "电陶炉", "慢炖锅", "面包机", "空气烤架", "电蒸锅", "酸奶机", "煮蛋器",
      "电水壶", "养生壶", "微波炉", "消毒柜", "油烟机", "燃气灶", "低温慢煮", "冰淇淋机", "发酵罐",
      "油炸锅", "电烤", "多功能锅", "料理机", "绞肉机", "真空封口机", "三明治机", "华夫饼机",
      "аэрогриль", "фритюрниц", "аэрофритюрниц", "мультиварк", "пароварк", "духов", "микроволн",
      "чайник", "блендер", "мясорубк", "air fryer", "oven", "rice cooker", "steamer", "blender",
    ],
  },
  {
    domain: "清洁/洗护",
    keywords: [
      "洗洁精", "洗碗液", "洗涤灵", "清洁剂", "洗衣液", "洗衣凝珠", "拖把", "扫把", "垃圾袋", "抹布",
      "мою", "чист", "стирк", "мыло", "швабр",
      "cleaner", "detergent", "laundry", "mop", "soap", "cleaning",
    ],
  },
  {
    domain: "宠物",
    keywords: [
      "宠物", "猫", "狗", "猫粮", "狗粮", "猫砂", "宠物窝", "牵引绳", "项圈", "宠物玩具", "饮水机",
      "кошк", "собак", "корм", "лак", "питом", "ошейник", "клетк",
      "pet", "cat", "dog", "cat food", "dog food", "litter", "pet bed",
    ],
  },
  {
    domain: "美妆个护",
    keywords: [
      "化妆品", "口红", "面膜", "精华", "面霜", "洗发水", "沐浴露", "牙膏", "牙刷", "美容", "护肤",
      "космет", "помад", "крем", "шампун", "зубн", "уход", "макияж",
      "makeup", "lipstick", "cream", "shampoo", "skincare", "cosmetic", "toothpaste",
    ],
  },
];

/** 把商品可文本化字段拼成一段小写待匹配文本 */
export function collectProductText(product = {}) {
  const specText = (product.skus || [])
    .slice(0, 30)
    .map((sku) => `${sku.label || ""} ${(sku.specs || {}) ? Object.values(sku.specs).join(" ") : ""}`)
    .join(" ");
  const attrText = (product.attributes || [])
    .map((a) => `${a.name || ""}${a.value || ""}`)
    .join(" ");
  return [
    product.title, product.description, product.ru?.title, product.ru?.description,
    product.ru?.categoryHint, (product.ru?.keywords || []).join(" "),
    specText, attrText,
  ].filter(Boolean).join(" ").toLowerCase();
}

/** 统计文本命中某领域关键词的数量（同一词多次命中只算一次，避免堆砌词刷分） */
function countDomainHits(text, keywords) {
  let hits = 0;
  for (const word of keywords) {
    const w = String(word || "").trim().toLowerCase();
    if (w.length >= 1 && text.includes(w)) hits += 1;
  }
  return hits;
}

/**
 * v1.9.77：判定「类目路径」落在哪个领域时，要求词本身够长（中文 ≥2 字 / 非中文 ≥3 字母）。
 * 原因：词典里有单字词（如厨房用品的「盘」），走子串匹配会把「键【盘】乐【器】」判进厨房领域；
 * 商品恰好是厨房类（空气炸锅）时，钢琴叶子反而吃到领域加权冲到候选前列（实测复现）。
 * 对商品文本的判定（countDomainHits）保持原样——商品标题里的短词命中是有信息量的，
 * 但类目路径是封闭集，短词命中几乎全是同形字噪声，必须收紧。
 */
function countDomainHitsInPath(pathText, keywords) {
  let hits = 0;
  for (const word of keywords) {
    const w = String(word || "").trim().toLowerCase();
    const minLen = /[\u4e00-\u9fa5]/.test(w) ? 2 : 3;
    if (w.length >= minLen && pathText.includes(w)) hits += 1;
  }
  return hits;
}

/**
 * 推断商品所属领域。返回按命中数降序的数组：[{ domain, score }]。
 * score 为命中关键词条数；0 分的领域不返回。
 */
export function detectProductDomains(product = {}) {
  const text = collectProductText(product);
  if (!text) return [];
  const scored = CATEGORY_DOMAINS
    .map((domain) => ({ domain: domain.domain, score: countDomainHits(text, domain.keywords) }))
    .filter((item) => item.score > 0)
    .sort((a, b) => b.score - a.score);
  return scored;
}

/**
 * 判断一个类目路径属于哪个领域（用于领域内加权 / 跨领域消歧）。
 * 返回命中的领域名数组（可能多个，例如「儿童家具」同时命中 儿童家具/围栏 与 家具）。
 */
export function domainsOfPath(path = []) {
  const joined = (path || []).join(" ").toLowerCase();
  const out = [];
  for (const domain of CATEGORY_DOMAINS) {
    if (countDomainHitsInPath(joined, domain.keywords) > 0) out.push(domain.domain);
  }
  return out;
}
