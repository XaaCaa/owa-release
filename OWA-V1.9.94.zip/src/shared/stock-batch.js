/**
 * 一键上库存：校验 / 分批 / 结果聚合（纯函数，不碰网络与 DOM）。
 *
 * 背景：Ozon `/v2/products/stocks` 返回的是**逐条** result[]（每条带 errors 数组），
 * 天然支持部分成功。本模块把「提交前的校验」与「提交后的结果归并」抽成纯函数，
 * 便于自测回归，也便于未来别的入口（批量上传后自动上库存）复用。
 *
 * 约定：
 * - 库存是**最终值**（覆盖式），不是增量。批量里同一个 offer_id 只保留最后一个值。
 * - stock 必须是 0 以上的整数；负数一律拒绝（Ozon 会直接 400，浪费一整批）。
 * - 0 是合法业务值（清零 / 售罄），但默认要求用户显式勾选「包含 0」才提交。
 */

/** Ozon 单批 stock 条目上限。保守取值：超限会被整批拒绝，得不偿失。 */
export const STOCK_BATCH_LIMIT = 100;

/**
 * 校验并归一化待提交条目。
 * @param {Array<{offer_id:string, stock:number, label?:string, id?:string}>} items
 * @param {{ includeZero?: boolean }} [options]
 * @returns {{
 *   valid: Array<{offer_id:string, stock:number, label:string, id:string}>,
 *   skipped: Array<{offer_id:string, stock:any, label:string, id:string, reason:string}>,
 * }}
 */
export function normalizeStockItems(items = [], { includeZero = false } = {}) {
  const valid = [];
  const skipped = [];
  const seen = new Map();

  for (const raw of Array.isArray(items) ? items : []) {
    const offerId = String(raw?.offer_id ?? "").trim();
    const label = String(raw?.label ?? "").trim();
    const id = String(raw?.id ?? "").trim();
    const num = Number(raw?.stock);

    if (!offerId) {
      skipped.push({ offer_id: offerId, stock: raw?.stock, label, id, reason: "缺少上架货号（offer_id）" });
      continue;
    }
    if (!Number.isFinite(num)) {
      skipped.push({ offer_id: offerId, stock: raw?.stock, label, id, reason: `库存「${raw?.stock}」不是数字` });
      continue;
    }
    if (!Number.isInteger(num)) {
      skipped.push({ offer_id: offerId, stock: num, label, id, reason: `库存 ${num} 是小数，Ozon 只接受整数` });
      continue;
    }
    if (num < 0) {
      // Ozon 会整批 400。提前拦下并说人话。
      skipped.push({ offer_id: offerId, stock: num, label, id, reason: `库存 ${num} 为负数，Ozon 不接受（清零请填 0）` });
      continue;
    }
    if (num === 0 && !includeZero) {
      skipped.push({ offer_id: offerId, stock: 0, label, id, reason: "库存为 0，未勾选「包含 0」已跳过" });
      continue;
    }
    // 库存是最终值：同一 offer_id 重复出现时后者覆盖前者，并保留最后一条的标签
    valid.push({ offer_id: offerId, stock: num, label, id });
    seen.set(offerId, valid.length - 1);
  }

  // 覆盖式去重：同一 offer_id 只保留最后一次赋值（与「逐条提交」语义一致）
  const deduped = [];
  const lastIndex = new Map();
  for (let i = 0; i < valid.length; i += 1) {
    const item = valid[i];
    const at = lastIndex.get(item.offer_id);
    if (at === undefined) {
      lastIndex.set(item.offer_id, deduped.length);
      deduped.push(item);
    } else {
      deduped[at] = item;
    }
  }

  return { valid: deduped, skipped };
}

/** 把条目切成不超过 limit 的批次（顺序保持）。 */
export function chunkStockItems(items = [], limit = STOCK_BATCH_LIMIT) {
  const list = Array.isArray(items) ? items : [];
  const size = Math.max(1, Math.floor(Number(limit) || STOCK_BATCH_LIMIT));
  const chunks = [];
  for (let i = 0; i < list.length; i += size) chunks.push(list.slice(i, i + size));
  return chunks;
}

/**
 * 归并 Ozon 逐条返回 + 本地已发批次，产出成功/失败明细。
 * Ozon 每条 result 形如 { offer_id, product_id, errors: [...] }；errors 非空即该条失败。
 * 没在返回里出现的 offer_id 视为「Ozon 未确认」，单列出来（不冒充成功）。
 */
export function aggregateStockResults({ sent = [], results = [] } = {}) {
  const byOffer = new Map();
  for (const item of sent) {
    if (item?.offer_id) byOffer.set(String(item.offer_id), item);
  }
  const succeeded = [];
  const failed = [];
  const unconfirmed = [];
  const seen = new Set();

  for (const row of Array.isArray(results) ? results : []) {
    const offerId = String(row?.offer_id ?? "").trim();
    if (!offerId || seen.has(offerId)) continue;
    seen.add(offerId);
    const errors = Array.isArray(row?.errors) ? row.errors.filter(Boolean) : [];
    const label = byOffer.get(offerId)?.label || "";
    if (errors.length) {
      failed.push({
        offer_id: offerId,
        label,
        reason: errors.map((e) => (typeof e === "string" ? e : (e?.message || e?.code || JSON.stringify(e)))).join("；"),
      });
    } else {
      succeeded.push({ offer_id: offerId, label, product_id: row?.product_id ?? "" });
    }
  }

  for (const item of sent) {
    const offerId = String(item?.offer_id ?? "").trim();
    if (offerId && !seen.has(offerId)) {
      unconfirmed.push({ offer_id: offerId, label: item?.label || "", reason: "Ozon 未返回该条结果，状态未知" });
    }
  }

  return { succeeded, failed, unconfirmed };
}

/**
 * 提交指纹：同一批 (仓库 + 货号 + 库存) 已成功提交过就跳过，防重复提交。
 * 只在内存里存最近一次（面板会话级），够挡住误连点。
 */
export function stockSubmitFingerprint(items = [], warehouseId = 0) {
  const rows = (Array.isArray(items) ? items : [])
    .map((item) => `${String(item?.offer_id ?? "").trim()}=${Number(item?.stock) || 0}`)
    .sort();
  return `w${Number(warehouseId) || 0}|${rows.join(",")}`;
}