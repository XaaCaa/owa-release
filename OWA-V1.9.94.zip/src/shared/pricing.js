// 定价模型：以目标利润率倒推售价，覆盖采购、国内运费、头程物流、佣金、广告与杂费。
// 所有金额对外统一以卢布(RUB)结算，输入成本以人民币(CNY)计。
import { roundTo, clampNumber } from "./utils.js";

export const DEFAULT_PRICING_TEMPLATE = Object.freeze({
  name: "默认模板",
  exchangeRate: 12.5,        // 1 CNY = ? RUB
  targetMarginRate: 25,      // 目标净利率 %
  commissionRate: 15,        // 平台佣金 %
  adRate: 8,                 // 广告费比例 %
  otherFeeRate: 2,           // 提现/货损等杂费 %
  domesticShippingCny: 8,    // 国内运费 + 代贴单（元/件）
  logisticsMode: "ozon_air", // 见 LOGISTICS_MODES
  logisticsRateCnyPerKg: 45, // 头程物流单价（元/kg）
  weightKg: 0.5,
  lengthCm: 20,
  widthCm: 15,
  heightCm: 10,
  volumetricDivisor: 6000,   // 体积重除数
  useVolumetricWeight: true,
  roundingStep: 10,          // 售价取整步长（卢布）
  strikeDiscount: 30,        // 划线价在售价上加价 %
  promoDoublePrice: false,   // 促销期间双倍价格上架
  minPriceRub: 0,
});

/**
 * Ozon 物流渠道（头程）。defaultRate 是该渠道常见的头程单价（¥/kg），
 * 选中渠道后会自动带出，仍然可以手工改。
 */
export const LOGISTICS_MODES = Object.freeze([
  { id: "ozon_sea", label: "Ozon 海运", defaultRate: 12, etaDays: "35-50 天" },
  { id: "ozon_rail", label: "Ozon 铁运/卡航", defaultRate: 22, etaDays: "18-30 天" },
  { id: "ozon_air", label: "Ozon 空运", defaultRate: 45, etaDays: "7-15 天" },
  { id: "ozon_express", label: "Ozon 特快专线", defaultRate: 58, etaDays: "5-10 天" },
]);

// 老版本渠道 id（air / ground / sea）→ 新 Ozon 渠道 id，读旧配置时自动迁移
export const LEGACY_LOGISTICS_MODE_MAP = Object.freeze({
  air: "ozon_air",
  ground: "ozon_rail",
  sea: "ozon_sea",
});

/* ------------------------------------------------------------------
 * OZON 核价表口径（对齐用户自用的「上架表」）
 * 表里的利润链路（原样照搬，行号 {r}）：
 *   J 拿货成本 = G 采集价 + H 运费
 *   L 平台售价₽ = K 平台售价¥ × 汇率(10.5)
 *   N 活动售价¥ = K - K*M      （M = 活动折扣）
 *   O 活动售价₽ = L - L*M
 *   Q 广告费用  = N*P          （P = 广告出价）
 *   S 佣金      = N*R          （R = 平台佣金）
 *   U 国际物流  = a×T + b      （T = 重量 g；a/b 由渠道决定）
 *   V OZON结算  = N - Q - S - U
 *   W 提现金额  = V × 0.993
 *   X 店铺利润  = W - J
 *   Y 采购利润率 = X/J    Z 销售利润率 = X/N    AA 物流利润率 = X/(J+U)
 *   AE 密度(体积重) = 长×宽×高 / 12000
 * ------------------------------------------------------------------ */

export const OZON_CHANNELS = Object.freeze([
  {
    id: "super_light", label: "超级轻小件",
    bounds: "500g 以内，<135RMB，单边<60cm，三边 90cm",
    minWeightG: 0, maxWeightG: 500, maxPriceCny: 135, maxSideCm: 60, maxGirthCm: 90,
    logistics: { a: 0.0281, b: 3.37 }, adRate: 0, commissionRate: 12, discount: 0,
  },
  {
    id: "low_standard", label: "低客单标准",
    bounds: "500g-25kg，<135RMB，单边<60cm，三边 150cm",
    minWeightG: 500, maxWeightG: 25000, maxPriceCny: 135, maxSideCm: 60, maxGirthCm: 150,
    logistics: { a: 0.0191, b: 25.83 }, adRate: 3, commissionRate: 0, discount: 0,
  },
  {
    id: "small_low", label: "小件低客单",
    bounds: "2kg 以内，135-635RMB，单边<60cm，三边 150cm",
    minWeightG: 0, maxWeightG: 2000, minPriceCny: 135, maxPriceCny: 635, maxSideCm: 60, maxGirthCm: 150,
    logistics: { a: 0.0281, b: 17.79 }, adRate: 0, commissionRate: 10, discount: 0,
  },
  {
    id: "big_low", label: "大件低客单",
    bounds: "2kg-25kg，135-635RMB，三边 250cm",
    minWeightG: 2000, maxWeightG: 25000, minPriceCny: 135, maxPriceCny: 635, maxGirthCm: 250,
    logistics: { a: 0.0191, b: 40.44 }, adRate: 5, commissionRate: 13, discount: 0,
  },
  {
    id: "small_high", label: "小件高客单",
    bounds: "5kg 以内，>635RMB，三边 250cm",
    minWeightG: 0, maxWeightG: 5000, minPriceCny: 635, maxGirthCm: 250,
    logistics: { a: 0.0281, b: 24.71 }, adRate: 3, commissionRate: 14.5, discount: 0,
  },
  {
    id: "big_high", label: "大件高客单",
    bounds: "5-25kg，>635RMB，三边 310cm",
    minWeightG: 5000, maxWeightG: 25000, minPriceCny: 635, maxGirthCm: 310,
    logistics: { a: 0.0258, b: 69.64 }, adRate: 22, commissionRate: 17, discount: 0,
  },
]);


export function findOzonChannel(id) {
  return OZON_CHANNELS.find((channel) => channel.id === id) || null;
}

/**
 * 按（重量 / 售价 / 尺寸）自动判定 Ozon 渠道。
 * 重量与售价都未知时给不出结论，返回最常用的「大件低客单」作为兜底。
 */
export function pickOzonChannel({ priceCny = 0, weightG = 0, lengthCm = 0, widthCm = 0, heightCm = 0 } = {}) {
  const price = Number(priceCny) || 0;
  const weight = Number(weightG) || 0;
  for (const channel of OZON_CHANNELS) {
    if (weight && channel.minWeightG && weight < channel.minWeightG) continue;
    if (weight && channel.maxWeightG && weight > channel.maxWeightG) continue;
    if (price && channel.minPriceCny && price < channel.minPriceCny) continue;
    if (price && channel.maxPriceCny && price > channel.maxPriceCny) continue;
    return channel;
  }
  return findOzonChannel("big_low") || OZON_CHANNELS[0];
}

/** 国际物流费（¥）：a × 重量(g) + b，a/b 来自渠道（可覆盖） */
export function ozonLogisticsCny(weightG, { a = 0, b = 0 } = {}) {
  const weight = Math.max(0, Number(weightG) || 0);
  const slope = Number(a) || 0;
  const intercept = Number(b) || 0;
  return roundTo(slope * weight + intercept, 2);
}

export const DEFAULT_LISTING_TEMPLATE = Object.freeze({
  exchangeRate: 10.5,      // 1 CNY = ? RUB（表里的 10.5）
  withdrawalRate: 0.993,   // OZON 结算 → 提现（表里的 0.993）
  volumetricDivisor: 12000,// 体积重 = 长×宽×高 / 12000
  discountRate: 0.4,       // 活动折扣 M（0.4 = 活动售价是原价的 6 折）
  adRate: 5,               // 广告出价 P（%）
  commissionRate: 17,      // 平台佣金 R（%）
  targetProfitRate: 30,    // 目标「采购利润率」X/J（%）
  channelId: "",           // 空 = 按重量/售价自动判定
  logisticsA: 0,           // 空/0 = 跟随渠道系数
  logisticsB: 0,
  roundingStep: 1,         // 售价取整步长（¥）
  priceCny: 0,             // 平台售价 ¥（0 = 按目标采购利润率反推）
  purchaseCost: 0,         // 采购成本 ¥（0 = 按 SKU 各自的采集价）
  domesticFreight: 0,      // 国内运费 ¥（0 = 用采集到的 1688 运费）
});

export function normalizeListingTemplate(template = {}) {
  const merged = { ...DEFAULT_LISTING_TEMPLATE, ...(template || {}) };
  merged.exchangeRate = Math.max(0.0001, Number(merged.exchangeRate) || 0);
  merged.withdrawalRate = Number(merged.withdrawalRate) || 0;
  merged.volumetricDivisor = Number(merged.volumetricDivisor) || 12000;
  merged.discountRate = clampNumber(merged.discountRate, 0, 0.95);
  merged.adRate = clampNumber(merged.adRate, 0, 90);
  merged.commissionRate = clampNumber(merged.commissionRate, 0, 90);
  merged.targetProfitRate = clampNumber(merged.targetProfitRate, -50, 500);
  merged.logisticsA = Math.max(0, Number(merged.logisticsA) || 0);
  merged.logisticsB = Math.max(0, Number(merged.logisticsB) || 0);
  merged.roundingStep = Math.max(0, Number(merged.roundingStep) || 0);
  merged.priceCny = Math.max(0, Number(merged.priceCny) || 0);
  merged.purchaseCost = Math.max(0, Number(merged.purchaseCost) || 0);
  merged.domesticFreight = Math.max(0, Number(merged.domesticFreight) || 0);
  merged.channelId = String(merged.channelId || "");
  return merged;
}

/**
 * 拿货成本拆成「采购成本 + 国内运费」两段（上架表 G 采集价 / H 运费 / J 拿货成本 那套口径）。
 * 取值优先级：
 *  - 国内运费：表单手填 domesticFreight > 草稿采集的 logistics.freightCny
 *  - 采购成本：表单手填 purchaseCost > SKU 的 basePrice（采集原价，未含运费）
 *    > sku.price 扣掉运费（老数据 price 已含运费，不扣会重复计算）> 草稿 costCny
 */
export function splitCostCny({ sku = {}, draft = {}, template = {} } = {}) {
  const t = normalizeListingTemplate(template);
  const freight = t.domesticFreight > 0
    ? t.domesticFreight
    : Math.max(0, Number(draft?.logistics?.freightCny) || 0);
  let purchase = t.purchaseCost > 0 ? t.purchaseCost : 0;
  if (!purchase) {
    const base = Number(sku?.basePrice) || 0;
    if (base > 0) {
      purchase = base;
    } else {
      const price = Number(sku?.price) || Number(draft?.costCny) || 0;
      purchase = freight > 0 && price > freight ? roundTo(price - freight, 2) : price;
    }
  }
  purchase = Math.max(0, purchase);
  return { purchase, freight, cost: roundTo(purchase + freight, 2) };
}

/**
 * 已知售价算利润（表里的正向链路）。
 * @returns 与上架表列一一对应的结果对象
 */
export function evaluateListing(input = {}) {
  const t = normalizeListingTemplate(input.template);
  const costCny = Math.max(0, Number(input.costCny) || 0);          // J 拿货成本
  const priceCny = Math.max(0, Number(input.priceCny) || 0);        // K 平台售价¥
  const discount = clampNumber(Number(input.discountRate ?? t.discountRate), 0, 0.95); // M
  const adRate = (Number(input.adRate ?? t.adRate) || 0) / 100;     // P
  const commissionRate = (Number(input.commissionRate ?? t.commissionRate) || 0) / 100; // R
  const logisticsCny = Math.max(0, Number(input.logisticsCny) || 0); // U
  const withdrawal = Number(input.withdrawalRate ?? t.withdrawalRate) || 0;
  const rate = t.exchangeRate;

  const priceRub = roundTo(priceCny * rate, 2);                     // L
  const promoCny = roundTo(priceCny - priceCny * discount, 2);      // N
  const promoRub = roundTo(priceRub - priceRub * discount, 2);      // O
  const adCny = roundTo(promoCny * adRate, 2);                      // Q
  const commissionCny = roundTo(promoCny * commissionRate, 2);      // S
  const settlementCny = roundTo(promoCny - adCny - commissionCny - logisticsCny, 2); // V
  const withdrawalCny = roundTo(settlementCny * withdrawal, 2);     // W
  const profitCny = roundTo(withdrawalCny - costCny, 2);            // X
  const safe = (value) => (Number.isFinite(value) ? value : 0);
  const purchaseMarginRate = costCny > 0 ? safe(roundTo(profitCny / costCny, 4)) : 0;   // Y
  const salesMarginRate = promoCny > 0 ? safe(roundTo(profitCny / promoCny, 4)) : 0;    // Z
  const logisticsMarginRate = (costCny + logisticsCny) > 0
    ? safe(roundTo(profitCny / (costCny + logisticsCny), 4)) : 0;                       // AA

  return {
    costCny,                 // J
    priceCny,                // K
    priceRub,                // L
    discountRate: discount,  // M
    promoCny,                // N
    promoRub,                // O
    adRate,                  // P
    adCny,                   // Q
    commissionRate,          // R
    commissionCny,           // S
    logisticsCny,            // U
    settlementCny,           // V
    withdrawalCny,           // W
    profitCny,               // X
    purchaseMarginRate,      // Y（采购利润率）
    salesMarginRate,         // Z（销售利润率）
    logisticsMarginRate,     // AA（物流利润率）
  };
}

/**
 * 反推售价：给定期望的「采购利润率」Y = 利润 / 拿货成本，倒解平台售价 K。
 * 由 X = W - J = V×0.993 - J 且 X = y×J 得：
 *   N = [J(1+y)/0.993 + U] / (1 - P - R)，K = N / (1 - M)
 */
export function suggestPriceCny(input = {}) {
  const t = normalizeListingTemplate(input.template);
  const costCny = Math.max(0, Number(input.costCny) || 0);
  const logisticsCny = Math.max(0, Number(input.logisticsCny) || 0);
  const target = (Number(input.targetProfitRate ?? t.targetProfitRate) || 0) / 100;
  const discount = clampNumber(Number(input.discountRate ?? t.discountRate), 0, 0.95);
  const adRate = (Number(input.adRate ?? t.adRate) || 0) / 100;
  const commissionRate = (Number(input.commissionRate ?? t.commissionRate) || 0) / 100;
  const withdrawal = Number(input.withdrawalRate ?? t.withdrawalRate) || 1;

  // 广告+佣金吃掉太多时给个下限，避免售价算出无穷大
  const denominator = Math.max(0.1, 1 - adRate - commissionRate);
  const promoCny = (costCny * (1 + target)) / withdrawal / denominator + logisticsCny / denominator;
  let priceCny = promoCny / Math.max(0.05, 1 - discount);
  if (t.roundingStep > 0) priceCny = Math.ceil(priceCny / t.roundingStep) * t.roundingStep;
  return roundTo(priceCny, 2);
}

/**
 * 把一件商品（单个 SKU）按 OZON 表格口径整套算出来，含渠道/物流/体积重。
 * priceCny 不传时按目标采购利润率反推。
 */
export function computeListing({ costCny = 0, priceCny = 0, weightG = 0, lengthCm = 0, widthCm = 0, heightCm = 0, template = {} } = {}) {
  const t = normalizeListingTemplate(template);
  const cost = Math.max(0, Number(costCny) || 0);
  const weight = Math.max(0, Number(weightG) || 0);
  const firstPrice = Math.max(0, Number(priceCny) || 0);
  // 渠道判定要用「售价 + 重量」，但售价本身又依赖渠道的物流系数，所以迭代两轮：
  // 轮 1 用已知售价（或 0）粗判 → 反推售价 → 轮 2 用算出的售价再判一次并定稿。
  const guessChannel = (price) => pickOzonChannel({ priceCny: price, weightG: weight, lengthCm, widthCm, heightCm });
  let channel = t.channelId ? findOzonChannel(t.channelId) : guessChannel(firstPrice);
  if (!channel) channel = pickOzonChannel({ priceCny: firstPrice, weightG: weight });

  let a = t.logisticsA || channel.logistics.a;
  let b = t.logisticsB || channel.logistics.b;
  let logisticsCny = ozonLogisticsCny(weight, { a, b });
  let price = firstPrice || suggestPriceCny({
    costCny: cost, logisticsCny,
    targetProfitRate: t.targetProfitRate, discountRate: t.discountRate,
    adRate: t.adRate, commissionRate: t.commissionRate,
    withdrawalRate: t.withdrawalRate, template: t,
  });

  if (!t.channelId) {
    for (let pass = 0; pass < 2; pass += 1) {
      const next = guessChannel(price);
      if (!next || next.id === channel.id) break;
      channel = next;
      a = t.logisticsA || channel.logistics.a;
      b = t.logisticsB || channel.logistics.b;
      logisticsCny = ozonLogisticsCny(weight, { a, b });
      price = firstPrice || suggestPriceCny({
        costCny: cost, logisticsCny,
        targetProfitRate: t.targetProfitRate, discountRate: t.discountRate,
        adRate: t.adRate, commissionRate: t.commissionRate,
        withdrawalRate: t.withdrawalRate, template: t,
      });
    }
  }

  const dims = [Number(lengthCm) || 0, Number(widthCm) || 0, Number(heightCm) || 0];
  const volumetricKg = dims.every((value) => value > 0)
    ? roundTo((dims[0] * dims[1] * dims[2]) / (t.volumetricDivisor || 12000), 3)
    : 0;

  const result = evaluateListing({
    costCny: cost, priceCny: price, logisticsCny, template: t,
  });
  return {
    ...result,
    channelId: channel.id,
    channelLabel: channel.label,
    channelBounds: channel.bounds,
    logisticsA: a,
    logisticsB: b,
    weightG: weight,
    lengthCm: dims[0],
    widthCm: dims[1],
    heightCm: dims[2],
    volumetricKg,
    exchangeRate: t.exchangeRate,
    withdrawalRate: t.withdrawalRate,
    volumetricDivisor: t.volumetricDivisor,
  };
}

export function normalizePricingTemplate(template = {}) {
  const merged = { ...DEFAULT_PRICING_TEMPLATE, ...(template || {}) };
  const numericFields = [
    "exchangeRate", "targetMarginRate", "commissionRate", "adRate", "otherFeeRate",
    "domesticShippingCny", "logisticsRateCnyPerKg", "weightKg", "lengthCm", "widthCm",
    "heightCm", "volumetricDivisor", "roundingStep", "strikeDiscount", "minPriceRub",
  ];
  for (const field of numericFields) {
    merged[field] = Math.max(0, Number(merged[field]) || 0);
  }
  merged.exchangeRate = Math.max(0.0001, merged.exchangeRate);
  merged.volumetricDivisor = merged.volumetricDivisor || 6000;
  merged.roundingStep = merged.roundingStep || 1;
  merged.promoDoublePrice = Boolean(merged.promoDoublePrice);
  merged.useVolumetricWeight = Boolean(merged.useVolumetricWeight);
  merged.targetMarginRate = clampNumber(merged.targetMarginRate, 0, 95);
  merged.commissionRate = clampNumber(merged.commissionRate, 0, 90);
  merged.adRate = clampNumber(merged.adRate, 0, 90);
  merged.otherFeeRate = clampNumber(merged.otherFeeRate, 0, 90);
  merged.logisticsMode = LEGACY_LOGISTICS_MODE_MAP[merged.logisticsMode] || merged.logisticsMode;
  if (!LOGISTICS_MODES.some((mode) => mode.id === merged.logisticsMode)) {
    merged.logisticsMode = DEFAULT_PRICING_TEMPLATE.logisticsMode;
  }
  merged.name = String(merged.name || DEFAULT_PRICING_TEMPLATE.name);
  return merged;
}

function volumetricWeightKg(template) {
  const { lengthCm, widthCm, heightCm, volumetricDivisor } = template;
  if (!lengthCm || !widthCm || !heightCm) return 0;
  return (lengthCm * widthCm * heightCm) / (volumetricDivisor || 6000);
}

export function billableWeightKg(template) {
  const actual = Math.max(0, Number(template.weightKg) || 0);
  if (!template.useVolumetricWeight) return actual;
  return Math.max(actual, volumetricWeightKg(template));
}

/**
 * 按模板对单个成本价定价。
 * @param {number} purchaseCny 单件采购成本（人民币）
 * @returns 明细对象，含售价、划线价、利润、实际利润率
 */
export function priceForCost(purchaseCny, templateInput = {}) {
  const t = normalizePricingTemplate(templateInput);
  const purchase = Math.max(0, Number(purchaseCny) || 0);

  const weight = billableWeightKg(t);
  const purchaseRub = purchase * t.exchangeRate;
  const domesticRub = t.domesticShippingCny * t.exchangeRate;
  const logisticsRub = weight * t.logisticsRateCnyPerKg * t.exchangeRate;
  const landedCostRub = purchaseRub + domesticRub + logisticsRub;

  const rateSum = (t.commissionRate + t.adRate + t.otherFeeRate + t.targetMarginRate) / 100;
  const denominator = 1 - rateSum;
  const safeDenominator = denominator > 0.05 ? denominator : 0.05; // 防止费率之和 >= 100% 导致售价无穷大

  let priceRub = landedCostRub / safeDenominator;
  if (t.roundingStep > 1) {
    priceRub = Math.ceil(priceRub / t.roundingStep) * t.roundingStep;
  }
  if (t.promoDoublePrice) priceRub *= 2;
  priceRub = Math.max(t.minPriceRub, roundTo(priceRub, 0));

  const commissionRub = roundTo((priceRub * t.commissionRate) / 100, 2);
  const adRub = roundTo((priceRub * t.adRate) / 100, 2);
  const otherRub = roundTo((priceRub * t.otherFeeRate) / 100, 2);
  const profitRub = roundTo(priceRub - landedCostRub - commissionRub - adRub - otherRub, 2);
  const actualMarginRate = priceRub > 0 ? roundTo((profitRub / priceRub) * 100, 2) : 0;

  return {
    purchaseCny: roundTo(purchase, 2),
    weightKg: roundTo(weight, 3),
    purchaseRub: roundTo(purchaseRub, 2),
    domesticRub: roundTo(domesticRub, 2),
    logisticsRub: roundTo(logisticsRub, 2),
    landedCostRub: roundTo(landedCostRub, 2),
    priceRub,
    oldPriceRub: roundTo(priceRub * (1 + t.strikeDiscount / 100), 0),
    commissionRub,
    adRub,
    otherRub,
    profitRub,
    actualMarginRate,
    denominatorBlocked: denominator <= 0.05,
  };
}

// 对整个商品（含多 SKU）批量定价：无 SKU 时按商品价，有 SKU 时逐个按 SKU 价。
export function priceProduct(product, templateInput = {}) {
  const t = normalizePricingTemplate(templateInput);
  if (!product?.skus?.length) {
    return { base: priceForCost(product?.price?.min || 0, t), skus: [] };
  }
  return {
    base: priceForCost(product.price?.min || 0, t),
    skus: product.skus.map((sku) => ({
      id: sku.id,
      label: sku.label,
      cost: sku.price,
      result: priceForCost(sku.price || product.price?.min || 0, t),
    })),
  };
}
