// 统一商品数据模型：三平台适配器都输出该结构，便于后台与 UI 无差别处理。
import { cleanText, parseNumber, normalizeImageUrl, dedupeStrings } from "./utils.js";

export const EMPTY_PRODUCT = Object.freeze({
  platform: "",
  sourceUrl: "",
  capturedAt: "",
  title: "",
  // 采集源的「商品编码」（1688 货号 / offerId）。v1.9.74 新增：
  // 用户点名要这个字段，也用来给上架表的货号列提供稳定、可追溯的默认值。
  productCode: "",
  shopName: "",
  shopUrl: "",
  price: Object.freeze({ min: 0, max: 0, currency: "CNY", raw: "" }),
  salesText: "",
  sales: 0,
  stock: 0,
  mainImage: "",
  images: Object.freeze([]),
  // 商品详情长图（采集源详情描述区）。默认不并进 images，由用户在面板里确认后再合，
  // 避免 1688 的营销长图把 Ozon 有限的图片位占满。
  detailImages: Object.freeze([]),
  // 规格色卡图（也就是「产品分类图」）：{ "颜色分类:5.0L【金属内腔】可悦款": "https://..." }
  // 采集时按规格值一并收下来，用来给每个 SKU 挂它自己的分类图。
  specImages: Object.freeze({}),
  // 采集时量到的图片真实尺寸：{ [url]: { width, height } }，用于面板二次筛选
  imageMeta: Object.freeze({}),
  videos: Object.freeze([]),
  specOptions: Object.freeze([]),
  skus: Object.freeze([]),
  attributes: Object.freeze([]),
  logistics: Object.freeze({ from: "", freightText: "", freightCny: 0, express: "" }),
  parcel: Object.freeze({ weightKg: 0, lengthCm: 0, widthCm: 0, heightCm: 0, raw: "", dimsRaw: "" }),
  description: "",
  diagnostics: Object.freeze({ recognized: [], missing: [], notes: [] }),
  skuGroup: "",
  skuClassification: Object.freeze({ status: "unclassified", reason: "" }),
});

function stableHash(text) {
  let hash = 2166136261;
  for (const char of String(text || "")) {
    hash ^= char.charCodeAt(0);
    hash = Math.imul(hash, 16777619);
  }
  return (hash >>> 0).toString(36);
}

/**
 * offer_id 合法化：Ozon 货号只接受字母、数字与 - _ . 这几类字符，
 * 中文、空格、全角符号一律替换成 - 再清掉首尾多余符号，最后按 Ozon 上限截到 50 字符。
 * 全部被替换掉（比如纯中文店名）时返回 fallback。
 */
export function sanitizeOfferId(value, fallback = "") {
  const safe = cleanText(value)
    .replace(/[^\w.-]+/g, "-")
    .replace(/-{2,}/g, "-")
    .replace(/^[-._]+|[-._]+$/g, "")
    .slice(0, 50);
  return safe || fallback;
}

/**
 * 生成可追溯且稳定的 Ozon 货号/型号，不能依赖上传次数或随机数。
 * v1.9.47 起两级优先：
 *  1. 面板里手工填的「上架 SKU」（sku.offerId）——填什么就上什么，不再叠加店铺前缀；
 *  2. 面板首次渲染时算好并写回草稿的自动货号（sku.offerIdAuto = 店铺名 + 年月日 + 时间 [+ 序号]）。
 *     存进草稿是为了让导出上架表、上传、库存/价格更新拿到同一个值（每次现算会导致重传重复铺货）。
 */
export function buildStableModel(draft = {}, sku = null, prefix = "") {
  const manual = sanitizeOfferId(sku?.offerId);
  if (manual) return manual;
  const auto = sanitizeOfferId(sku?.offerIdAuto);
  if (auto) return auto;
  const skuId = cleanText(sku?.id);
  const savedModel = cleanText(sku?.model);
  const draftId = cleanText(draft?.id);
  const raw = savedModel || skuId || (draft?.skus?.length === 1 ? draft.skus[0]?.id : "") || draftId;
  const fallback = stableHash([
    cleanText(draft?.sourceUrl),
    cleanText(draft?.title),
    cleanText(sku?.label || Object.values(sku?.specs || {}).join(" ")),
  ].join("|"));
  const value = raw || `product-${fallback}`;
  const safe = value.replace(/[^\w.-]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 80) || `product-${fallback}`;
  return `${cleanText(prefix)}${safe}`;
}

/**
 * 生成商品级别的 model_name（Ozon 用于把多个 SKU 合并到同一张卡片）。
 * 所有 SKU 共享同一个 model_name；若为空则 Ozon 报「型号名称必填」。
 */
export function buildProductModelName(draft = {}) {
  const fromTitle = cleanText(draft.ru?.title || draft.title)
    .replace(/[^\w\sа-яА-ЯёЁ0-9-]+/g, " ")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, 50);
  if (fromTitle) return fromTitle;
  const hash = stableHash(cleanText(draft.sourceUrl || draft.id || ""));
  return `model-${hash}`.slice(0, 50);
}

function skuText(value) {
  return cleanText(value).toLowerCase().replace(/[|｜、，,;/]+/g, " ").replace(/\s+/g, " ").trim();
}

/** 为同一采集商品生成稳定的组号，并保留无法解析的 SKU。 */
export function classifySku(sku = {}, product = {}) {
  const source = cleanText(product.sourceUrl).split("#")[0].split("?")[0]
    || `${cleanText(product.platform)}:${skuText(product.title)}`;
  const label = skuText(sku.label || Object.values(sku.specs || {}).join(" "));
  const hasSpecs = Object.keys(sku.specs || {}).some((key) => skuText(key) || skuText(sku.specs[key]));
  const status = label || hasSpecs ? "variant" : "unclassified";
  return {
    skuGroup: `skugrp-${stableHash(source)}`,
    skuClassification: {
      status,
      reason: status === "variant" ? "按商品来源与规格归类" : "缺少可识别规格文本，请人工确认",
    },
  };
}

// 规格维度/值归一化：去空格、转小写、去「色/色系」等后缀，便于「红色」与「红」这类同义对齐
export function normalizeSpecText(value) {
  return cleanText(value).toLowerCase().replace(/\s+/g, "");
}

// 规格值归一到「基词」：去掉末尾的「色/色系」，使「红色」与「红」对齐；同时去空格转小写
function specBase(value) {
  return normalizeSpecText(value)
    .replace(/色系$/, "")
    .replace(/色$/, "");
}

/**
 * 按「维度名:值」在 specImages 里找对应小图，支持严格匹配与归一化模糊匹配。
 * 1688 采集时规格值可能是「红色」而 specImages 的 key 是「红」，直接全等会挂不上图，
 * 这里先做严格匹配，失败再按归一化（去空格/小写/去「色」后缀）匹配，提升「图片按 SKU 分类」的命中率。
 */
export function matchSpecImage(specImages = {}, name = "", value = "") {
  if (!specImages || !name) return "";
  const exact = specImages[`${name}:${value}`] || specImages[`${name}:${cleanText(value)}`];
  if (exact) return exact;
  const targetName = specBase(name);
  const targetValue = specBase(value);
  if (!targetValue) return "";
  for (const key of Object.keys(specImages)) {
    const idx = key.indexOf(":");
    if (idx < 0) continue;
    const kn = specBase(key.slice(0, idx));
    const kv = specBase(key.slice(idx + 1));
    if (kn === targetName && kv === targetValue) return specImages[key];
  }
  return "";
}

/**
 * 归一化一个 Ozon 类目属性定义。
 * v1.9.50 补上 is_aspect / is_collection / max_value_count / dictionary_id：
 *  - is_aspect 是 Ozon 官方的「变体属性」标记（颜色、尺码这类能把多个 SKU 合并成一张卡片、
 *    又能区分出多个规格的属性）。之前没读这个字段，只能靠属性名硬猜，于是「变体属性 ID」
 *    得让用户在界面上手填——留空就只上架 1 条，这是「上传了 4 个规格只上架 1 个」的根因。
 *  - dictionary_id > 0 说明是枚举型属性，上传时必须传 dictionary_value_id 而不是自由文本，
 *    否则 Ozon 会报「属性不正确，请从列表中选择一个属性值」。
 */
export function normalizeAttributeDefinition(attr = {}) {
  const dictionary = (attr.dictionary || attr.values || attr.options || [])
    .map((item) => typeof item === "object"
      ? {
        value: cleanText(item.value ?? item.name ?? item.title),
        id: Number(item.id ?? item.dictionary_value_id) || null,
        picture: cleanText(item.picture ?? item.image ?? ""),
      }
      : { value: cleanText(item), id: null, picture: "" })
    .filter((item) => item.value);
  return {
    ...attr,
    id: Number(attr.id ?? attr.attribute_id) || 0,
    name: cleanText(attr.name ?? attr.attribute_name ?? attr.title),
    is_required: Boolean(attr.is_required ?? attr.required),
    // 「变体属性」= Ozon 用来区分同一商品卡里不同规格的属性，是合并变体的唯一合法依据
    is_aspect: Boolean(attr.is_aspect ?? attr.isAspect),
    is_collection: Boolean(attr.is_collection),
    max_value_count: Number(attr.max_value_count) || 0,
    attribute_complex_id: Number(attr.attribute_complex_id) || 0,
    dictionary_id: Number(attr.dictionary_id) || 0,
    group_name: cleanText(attr.group_name),
    type: cleanText(attr.type ?? attr.attribute_type ?? "string").toLowerCase(),
    unit: cleanText(attr.unit ?? attr.unit_name),
    min: Number.isFinite(Number(attr.min ?? attr.min_value)) ? Number(attr.min ?? attr.min_value) : null,
    max: Number.isFinite(Number(attr.max ?? attr.max_value)) ? Number(attr.max ?? attr.max_value) : null,
    dictionary,
  };
}

/**
 * 把已填的属性值「就近落到字典」上（v1.9.50）。
 * 起因：Ozon 对枚举型属性只认字典值，AI 或采集来的文本哪怕只差一个词形就会被判
 * 「属性不正确：不要手输这些值，请从列表中选择一个属性值」，整条商品被封锁。
 * 这里做三级归一化匹配：原样 → 去空格/大小写 + 去「色」后缀 → 唯一的包含关系；
 * 命中就换成字典原文并带回 dictionary_value_id，命中不了的原样保留并记进 unmatched，
 * 由调用方决定是报错还是提示（不静默丢值，也不假装成功）。
 */
export function snapAttributeValues(definitions = [], values = {}) {
  const out = {};
  const ids = {};
  const unmatched = [];
  const normalized = new Map();
  for (const raw of definitions || []) {
    const def = normalizeAttributeDefinition(raw);
    if (def.id) normalized.set(String(def.id), def);
  }
  const norm = (s) => cleanText(s).toLowerCase().replace(/\s+/g, "");
  const base = (s) => norm(s).replace(/色系$/, "").replace(/色$/, "");
  for (const [id, rawValue] of Object.entries(values || {})) {
    const text = cleanText(rawValue);
    if (!text) continue;
    const def = normalized.get(String(id));
    const dict = def?.dictionary || [];
    if (!dict.length) {
      out[id] = text;
      continue;
    }
    const target = norm(text);
    const targetBase = base(text);
    let hit = dict.find((item) => norm(item.value) === target)
      || dict.find((item) => base(item.value) === targetBase);
    if (!hit) {
      // 包含关系只在「无歧义」时才认：唯一一个候选才敢替换
      const loose = dict.filter((item) => {
        const candidate = norm(item.value);
        return candidate && (candidate.includes(target) || target.includes(candidate));
      });
      if (loose.length === 1) hit = loose[0];
    }
    if (hit) {
      out[id] = cleanText(hit.value);
      if (Number(hit.id)) ids[id] = Number(hit.id);
    } else {
      out[id] = text;
      unmatched.push({ id: Number(id) || 0, name: def?.name || String(id), value: text });
    }
  }
  return { values: out, ids, unmatched };
}

/** 属性展示名（v1.9.58 全中文）：官方模板中文/AI 翻译中文优先，都没有才露原文并标「需确认」。
 *  仅用于**给用户看的文案**——上传 payload、匹配字典值等一律还用 attr.name 原文。 */
function attrLabel(attr) {
  const zh = cleanText(attr?.displayName);
  if (zh && /[\u4e00-\u9fa5]/.test(zh)) return zh;
  const raw = cleanText(attr?.name) || `属性 ${attr?.id ?? ""}`;
  return `${raw}（需确认）`;
}

/** 上传前严格校验属性，返回可直接展示给用户的中文错误。 */
export function validateAttributeValues(definitions = [], values = {}) {
  const errors = [];
  for (const raw of definitions || []) {
    const attr = normalizeAttributeDefinition(raw);
    if (!attr.id) continue;
    const label = attrLabel(attr);
    const value = cleanText(values[String(attr.id)]);
    if (attr.is_required && !value) errors.push(`缺少必填属性「${label}」`);
    if (!value) continue;
    if (attr.dictionary.length && !attr.dictionary.some((item) => item.value === value)) {
      errors.push(`属性「${label}」的值「${value}」不在允许枚举中`);
    }
    if (/(number|numeric|integer|float|double|重量|尺寸|长度|宽度|高度|体积)/i.test(attr.type)) {
      const number = Number(value.replace(",", ".").match(/-?\d+(?:\.\d+)?/)?.[0]);
      if (!Number.isFinite(number)) errors.push(`属性「${label}」不是有效数值`);
      if (!attr.unit && !/^[+-]?\d+(?:[.,]\d+)?$/.test(value)) {
        errors.push(`属性「${label}」包含无效数值或单位`);
      }
      if (/integer|целое/i.test(attr.type) && !Number.isInteger(number)) {
        errors.push(`属性「${label}」必须是整数`);
      }
      if (Number.isFinite(attr.min) && number < attr.min) errors.push(`属性「${label}」低于最小值 ${attr.min}`);
      if (Number.isFinite(attr.max) && number > attr.max) errors.push(`属性「${label}」高于最大值 ${attr.max}`);
      if (attr.unit && !new RegExp(`(?:^|\\s|数字)${attr.unit.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}(?:$|\\s)`, "i").test(value)) {
        errors.push(`属性「${label}」缺少有效单位「${attr.unit}」`);
      }
    }
  }
  return { ok: errors.length === 0, errors };
}

/**
 * 以 Ozon 官方类目属性元数据为准，对已填属性做一次「对账」（v1.9.55 新增）。
 *
 * 背景：过去校验只在 buildImportItems 提交那一刻跑，只抛错不修正，用户到最后一步
 * 才知道错、还不知道该填什么；而且草稿恢复时用的可能是过期属性定义，对着旧定义填的
 * 值怎么校都「对」。这里把「校」和「修」独立成纯函数（无 IO，方便自测），UI 和上传前
 * 共用一份实现：
 *  1. removed    —— 属性 ID 不在该类目定义里（平台下线/草稿串类目）：直接剔除，必须进报告；
 *  2. fixed      —— 枚举值不在字典但唯一就近命中：改成字典原文并绑定 dictionary_value_id；
 *                   匹配不上绝不瞎改，进 unmatched 标红让人手选（宁可让人选，不要瞎改）；
 *  3. missing    —— is_required 且无值：只列清单，默认不自动编（假参数比缺属性更糟）；
 *                   唯一例外：枚举字典只有一个候选值时允许自动填（没有猜的成分）；
 *  4. complex    —— attribute_complex_id 分组：Ozon 唯一暴露的「属性联动」机制（父=0、
 *                   子属性共享同一个非 0 组 ID）。组内填了任一子项但没填全 → 提示。
 *                   ⚠️ 这是按接口字段结构推断的模型，不是官方文档明文，报告里单独列一节供复核。
 */
export function reconcileAttributes({ definitions = [], values = {}, valueIds = {}, skus = [] } = {}) {
  const defs = (definitions || []).map(normalizeAttributeDefinition).filter((attr) => attr.id);
  const defById = new Map(defs.map((attr) => [String(attr.id), attr]));
  const out = { values: {}, valueIds: {}, removed: [], fixed: [], added: [], missing: [], unmatched: [], complex: [], warnings: [], ok: true };
  // ① 剔除不属于该类目的属性（值有、定义里没有）
  for (const [id, rawValue] of Object.entries(values || {})) {
    const text = cleanText(rawValue);
    if (!text) continue;
    if (!defById.has(String(id))) {
      out.removed.push({ id: Number(id) || 0, name: `属性 ${id}`, value: text, reason: "不属于当前类目（平台已下线或草稿串了类目）" });
    } else {
      out.values[String(id)] = text;
    }
  }
  // ② 枚举值就近修正（复用 snapAttributeValues 的三级匹配，但只接受「唯一命中」）
  const kept = { ...out.values };
  const snapped = snapAttributeValues(defs, out.values);
  for (const [id, text] of Object.entries(snapped.values)) {
    const attr = defById.get(String(id));
    const dict = attr?.dictionary || [];
    const before = cleanText(kept[id]);
    if (before && before !== text) {
      out.fixed.push({ id: Number(id) || 0, name: attr?.name || id, from: before, to: text, toZh: cleanText(dict.find((item) => item.value === text)?.displayValue), reason: "不在候选值里，已按唯一就近匹配改成官方值" });
    }
    if (dict.length && !dict.some((item) => item.value === text)) {
      // 就近落字典没接住 → 标红让人手选，值保留（不丢用户数据）
      out.unmatched.push({ id: Number(id) || 0, name: attr?.name || id, value: text, dictSize: dict.length });
    }
  }
  out.values = snapped.values;
  // 字典值 ID：用户下拉选过的最准，优先于就近匹配的结果
  for (const [id, valueId] of Object.entries(snapped.ids)) out.valueIds[String(id)] = Number(valueId);
  for (const [id, valueId] of Object.entries(valueIds || {})) {
    if (Number(valueId) && out.values[String(id)]) out.valueIds[String(id)] = Number(valueId);
  }
  for (const fix of snapped.unmatched) {
    if (!out.unmatched.some((item) => String(item.id) === String(fix.id))) out.unmatched.push(fix);
  }
  // ③ 缺失必填（唯一例外：枚举字典只有一个候选值 → 自动补，没有猜的成分）
  for (const attr of defs) {
    const id = String(attr.id);
    if (!attr.is_required || cleanText(out.values[id])) continue;
    const dict = attr.dictionary || [];
    if (dict.length === 1 && cleanText(dict[0].value)) {
      out.values[id] = cleanText(dict[0].value);
      if (Number(dict[0].id)) out.valueIds[id] = Number(dict[0].id);
      out.added.push({ id: attr.id, name: attr.name, value: out.values[id], reason: "该枚举属性只有唯一候选值，自动补上" });
    } else {
      out.missing.push({ id: attr.id, name: attr.name, type: attr.type || "string", dictSize: dict.length, unit: attr.unit || "" });
    }
  }
  // ④ 复合属性组（attribute_complex_id ≠ 0 的子属性归组）
  const groups = new Map();
  for (const attr of defs) {
    if (!attr.attribute_complex_id) continue;
    const key = String(attr.attribute_complex_id);
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key).push(attr);
  }
  for (const [complexId, members] of groups) {
    const filled = members.filter((attr) => cleanText(out.values[String(attr.id)]));
    if (!filled.length || filled.length === members.length) continue;
    const missingNames = members.filter((attr) => !cleanText(out.values[String(attr.id)])).map((attr) => attr.name || attr.id);
    out.complex.push({
      complexId: Number(complexId) || 0,
      filledCount: filled.length,
      total: members.length,
      missingNames,
      members: members.map((attr) => ({ id: attr.id, name: attr.name, required: Boolean(attr.is_required) })),
    });
  }
  // 软提示：数值范围 / 复用 validateAttributeValues 的结果但降级成警告（这里不抛错，报告为主）
  const check = validateAttributeValues(defs, out.values);
  out.warnings.push(...check.errors);
  // ok 的口径：缺必填或枚举值落不上字典才算不过（软提示不算）
  out.ok = out.missing.length === 0 && out.unmatched.length === 0;
  return out;
}

/**
 * 把 Ozon 导入报错解析成结构化中文条目（v1.9.55 新增）。
 *
 * 背景：/v1/product/import/info 里 item.errors 的 message 是整句俄文
 * （如 «Атрибут «Цвет» не поддерживается…»），过去直接 join(" / ") 糊成一堵墙，
 * 用户读不懂也看不出该改哪。这里按报错关键词分类，抽出属性名，给中文结论 + 修改建议：
 *  - не поддерживается  → 属性不属于该类目 → v1.9.55 会在校验时自动剔除
 *  - enum / dictionary / значение из списка → 枚举值不合法 → 建议从候选值里选
 *  - обязательно / required → 必填缺失
 *  - числовое / число → 非法数值
 *  - найдено несколько / multiple → 多值重复
 *  - 其它 → 原文保留（别硬翻，翻错了更坑）
 * 同文案去重（Ozon 会对每个变体重复报同一错），返回 [{ code, attrName, attrId, kind, title, advice, raw }]。
 */
const OZON_ERROR_RULES = [
  { kind: "unsupported", re: /не\s+поддерживается|не\s+поддерживают/i, title: "属性不被该类目支持", advice: "点「校验属性」自动剔除；本次上传已不带该属性" },
  { kind: "enum", re: /enum|dictionary|значени[еяю].*(списка|словаря)|выберите\s+значение|должно\s+содержать\s+значение/i, title: "属性值不在官方候选值里", advice: "在属性表该行从下拉/建议里重新选一个官方值" },
  { kind: "required", re: /обязательн|required|не\s+заполнен/i, title: "必填属性缺失", advice: "在属性表补填该必填项" },
  { kind: "number", re: /числов|числo|не\s+является\s+числом|должно\s+быть\s+числом/i, title: "属性值不是合法数值", advice: "只填数字（可带单位符号），去掉多余文字" },
  { kind: "range", re: /превышает|меньше\s+миним|больше\s+макс|out\s+of\s+range/i, title: "属性值超出允许范围", advice: "按该属性的最小/最大值调整" },
  { kind: "duplicate", re: /дубликат|duplicate|уже\s+существует|несколько\s+значений/i, title: "属性值重复", advice: "去掉重复的取值后重新上传" },
  { kind: "image", re: /фото|изображени|image|фотографи/i, title: "图片问题", advice: "检查图片链接能否公网打开（Ozon 是自己回源下载图片的）" },
  { kind: "price", re: /цен|price|старой\s+цен/i, title: "价格问题", advice: "检查售价与划线价（划线价必须严格大于售价，且都是人民币）" },
];

export function classifyOzonImportErrors(errors = [], categoryAttributes = []) {
  const defs = (categoryAttributes || []).map(normalizeAttributeDefinition);
  const byId = new Map(defs.map((attr) => [String(attr.id), attr]));
  const byName = new Map(defs.map((attr) => [cleanText(attr.name).toLowerCase(), attr]));
  const out = [];
  const seen = new Set();
  for (const raw of errors || []) {
    const code = cleanText(raw?.code);
    const message = cleanText(raw?.message || raw?.error || raw);
    if (!message) continue;
    const key = `${code}|${message}`;
    if (seen.has(key)) continue; // Ozon 会对每个变体重复报同一错，去重
    seen.add(key);
    // 抽属性名：俄文引号 «…» / "…"，或结构化 attribute_id
    let attrId = Number(raw?.attribute_id) || 0;
    let attrName = "";
    const quoted = message.match(/[«"]([^«»"]{2,80})[»"]/);
    if (quoted) attrName = cleanText(quoted[1]);
    if (!attrId && attrName) {
      const hit = byName.get(attrName.toLowerCase());
      if (hit) attrId = hit.id;
    }
    const attr = attrId ? byId.get(String(attrId)) : null;
    const rule = OZON_ERROR_RULES.find((item) => item.re.test(message)) || null;
    out.push({
      code,
      attrId: attrId || (attr ? attr.id : 0),
      attrName: attrName || (attr ? attr.name : ""),
      attrZh: attr ? (cleanText(attr.displayName) || "") : "",
      kind: rule?.kind || "other",
      title: rule?.title || "其它报错",
      advice: rule?.advice || "把原文反馈给开发者（这句还没收录）",
      raw: message,
    });
  }
  return out;
}

const FIELD_LABELS = Object.freeze({
  title: "标题",
  mainImage: "主图",
  images: "图片集",
  price: "价格",
  sales: "销量",
  stock: "库存",
  skus: "SKU 规格",
  attributes: "属性参数",
  shopName: "店铺",
  logistics: "物流/发货地",
  description: "详情描述",
});

function hasValue(value) {
  if (Array.isArray(value)) return value.length > 0;
  if (value && typeof value === "object") return Object.keys(value).length > 0;
  return Boolean(cleanText(value)) || Boolean(Number(value));
}

/**
 * 商品身份键：把「同一个商品详情页」的不同 URL 写法归一到同一个键。
 *
 * 用途：判断「这次采集的是不是还是上一件商品」。
 * 旧实现只按「当前有没有草稿」来决定要不要新建草稿，于是载入 A 的草稿后去采 B，
 * B 的图片会被并进 A 的草稿、标题还是 A 的 —— 用户看到的就是「采集的数据严重不准确」。
 * 有了这个键，换商品必然新建草稿，两件商品的数据物理上不可能混在一起。
 *
 * 归一规则：host + pathname + 商品 ID（id / goods_id / 1688 的 /offer/<数字>），
 * 丢掉 spm / from / 跟踪参数这类每次采集都可能变的查询串。
 */
export function productIdentity(url = "") {
  const raw = String(url || "").trim();
  if (!raw) return "";
  try {
    const u = new URL(raw);
    const id = u.searchParams.get("id")
      || u.searchParams.get("goods_id")
      || (u.pathname.match(/\/offer\/(\d+)/) || [])[1]
      || "";
    return `${u.hostname}${u.pathname}${id ? `#${id}` : ""}`.toLowerCase();
  } catch {
    return raw.toLowerCase();
  }
}

export function createEmptyProduct(platform = "", sourceUrl = "") {
  return {
    ...EMPTY_PRODUCT,
    platform,
    sourceUrl,
    capturedAt: new Date().toISOString(),
    price: { ...EMPTY_PRODUCT.price },
    logistics: { ...EMPTY_PRODUCT.logistics },
    parcel: { ...EMPTY_PRODUCT.parcel },
    images: [],
    detailImages: [],
    imageMeta: {},
    videos: [],
    specOptions: [],
    skus: [],
    attributes: [],
    diagnostics: { recognized: [], missing: [], notes: [] },
  };
}

// 把适配器产出的半成品补全为规范结构，并生成字段诊断（缺失字段不会被伪造填充）。
export function normalizeProduct(raw = {}) {
  const product = {
    ...createEmptyProduct(cleanText(raw.platform), cleanText(raw.sourceUrl)),
    ...raw,
  };

  product.title = cleanText(raw.title);
  // v1.9.74 商品编码：适配器给什么就用什么；老草稿没有这个字段时留空串（不伪造）
  product.productCode = cleanText(raw.productCode);
  product.shopName = cleanText(raw.shopName);
  product.shopUrl = cleanText(raw.shopUrl);
  product.salesText = cleanText(raw.salesText);
  product.description = cleanText(raw.description);
  product.capturedAt = cleanText(raw.capturedAt) || new Date().toISOString();

  const rawPrice = raw.price || {};
  const min = parseNumber(rawPrice.min ?? rawPrice.value ?? raw.price);
  const max = parseNumber(rawPrice.max ?? rawPrice.value ?? raw.price);
  product.price = {
    min: min || 0,
    max: max || min || 0,
    currency: cleanText(rawPrice.currency) || "CNY",
    raw: cleanText(rawPrice.raw),
  };

  product.sales = parseNumber(raw.sales ?? raw.salesText);
  product.stock = parseNumber(raw.stock);

  // sourceUrl 来自采集页，理论上可能是脏值；new URL 直接抛错会让整条采集结果规范化失败，
  // 这里失败时按「无 origin」处理（normalizeImageUrl 对空 origin 只会不做相对路径补全）
  let origin = "";
  try { origin = product.sourceUrl ? new URL(product.sourceUrl).origin : ""; } catch { origin = ""; }
  product.images = dedupeStrings(
    (Array.isArray(raw.images) ? raw.images : [])
      .map((url) => normalizeImageUrl(url, origin))
      .filter(Boolean),
  );
  product.mainImage = normalizeImageUrl(raw.mainImage, origin) || product.images[0] || "";
  // 详情长图单独存一组，并去掉与主图集重复的（重复会白占 Ozon 图片位）
  const mainImageSet = new Set(product.images);
  product.detailImages = dedupeStrings(
    (Array.isArray(raw.detailImages) ? raw.detailImages : [])
      .map((url) => normalizeImageUrl(url, origin))
      .filter((url) => url && !mainImageSet.has(url)),
  );
  // 采集阶段量到的尺寸，只保留还在图片列表里的条目（natural 一并带上：
  // 渲染尺寸不代表文件大小，面板二次筛选时据此避免误删懒加载真图）
  const rawMeta = raw.imageMeta && typeof raw.imageMeta === "object" ? raw.imageMeta : {};
  product.imageMeta = {};
  for (const url of product.images) {
    const meta = rawMeta[url];
    if (meta && (meta.width || meta.height)) {
      product.imageMeta[url] = {
        width: Number(meta.width) || 0,
        height: Number(meta.height) || 0,
        ...(meta.natural === false ? { natural: false } : {}),
      };
    }
  }
  product.videos = dedupeStrings(
    (Array.isArray(raw.videos) ? raw.videos : []).map((url) => normalizeImageUrl(url, origin)),
  );

  // 规格色卡图（产品分类图）：key 是「维度名:值」，值是图片地址。
  // 采集源给的多半是带 _100x100 后缀的缩略图，这里统一升到原图，并丢掉空条目。
  const rawSpecImages = raw.specImages && typeof raw.specImages === "object" ? raw.specImages : {};
  product.specImages = {};
  for (const [key, value] of Object.entries(rawSpecImages)) {
    const specKey = cleanText(key);
    const url = normalizeImageUrl(value, origin);
    if (specKey && url) product.specImages[specKey] = url;
  }

  product.specOptions = (Array.isArray(raw.specOptions) ? raw.specOptions : [])
    .map((option) => ({
      name: cleanText(option?.name),
      values: dedupeStrings(option?.values || []),
    }))
    .filter((option) => option.name && option.values.length);

  const skuSource = cleanText(raw.sourceUrl).split("#")[0].split("?")[0] || cleanText(raw.title) || "product";
  product.skus = (Array.isArray(raw.skus) ? raw.skus : []).map((sku, index) => {
    // 采集页偶尔混进负数/NaN（促销减价拼接、「-¥3」优惠券被当成价格）：
    // 负价不能当成本，落回整单采集价，两个都没有就是 0 让用户补
    const rawSkuPrice = parseNumber(sku?.price);
    const skuPrice = rawSkuPrice > 0 ? rawSkuPrice : (parseNumber(product.price.min) > 0 ? product.price.min : 0);
    const rawBasePrice = parseNumber(sku?.basePrice);
    return {
      // 采集源没有 SKU ID 时使用可追溯的本地序号，绝不生成随机 ID 或套用商品 ID。
      id: cleanText(sku?.id) || `sku-${stableHash(`${skuSource}|${index + 1}|${skuText(sku?.label || Object.values(sku?.specs || {}).join(" "))}`)}-${index + 1}`,
      idSource: cleanText(sku?.id) ? "采集" : "本地稳定序号（采集源缺失 ID）",
      specs: sku?.specs && typeof sku.specs === "object" ? sku.specs : {},
      price: skuPrice,
      // basePrice = 未加运费的采集原价（成本列展示的是含运费价）
      basePrice: rawBasePrice > 0 ? rawBasePrice : 0,
      stock: Math.max(0, parseNumber(sku?.stock)),
      // 库存原文（「42123箱」这类带单位文本），面板展示用
      stockText: cleanText(sku?.stockText),
      // 不可选/缺货组合（采集端标出来的）：面板默认不勾选，上传前自检会拦
      unavailable: Boolean(sku?.unavailable),
      unavailableReason: cleanText(sku?.unavailableReason),
      image: normalizeImageUrl(sku?.image, origin),
      images: dedupeStrings((Array.isArray(sku?.images) ? sku.images : [sku?.image])
        .map((url) => normalizeImageUrl(url, origin)).filter(Boolean)).slice(0, 9),
      label: cleanText(sku?.label) || Object.values(sku?.specs || {}).join(" / "),
      ...classifySku(sku, raw),
      skuGroup: cleanText(sku?.skuGroup) || classifySku(sku, raw).skuGroup,
      skuClassification: sku?.skuClassification || classifySku(sku, raw).skuClassification,
    };
  });
  product.skuGroup = cleanText(raw.skuGroup) || product.skus[0]?.skuGroup || classifySku({}, raw).skuGroup;
  product.skuClassification = raw.skuClassification || {
    status: product.skus.some((sku) => sku.skuClassification?.status === "unclassified") ? "partial" : "classified",
    reason: product.skus.some((sku) => sku.skuClassification?.status === "unclassified") ? "存在无法识别的 SKU，请人工确认" : "SKU 已按规格归类",
  };

  product.attributes = (Array.isArray(raw.attributes) ? raw.attributes : [])
    .map((attr) => ({ name: cleanText(attr?.name), value: cleanText(attr?.value) }))
    .filter((attr) => attr.name && attr.value);

  const logistics = raw.logistics || {};
  product.logistics = {
    from: cleanText(logistics.from),
    freightText: cleanText(logistics.freightText),
    freightCny: parseNumber(logistics.freightCny) || 0,
    express: cleanText(logistics.express),
  };

  // 包裹毛重与包装尺寸（定价/上传用），采集不到就是 0，由界面提示手填
  const parcel = raw.parcel || {};
  product.parcel = {
    weightKg: parseNumber(parcel.weightKg) || 0,
    lengthCm: parseNumber(parcel.lengthCm) || 0,
    widthCm: parseNumber(parcel.widthCm) || 0,
    heightCm: parseNumber(parcel.heightCm) || 0,
    raw: cleanText(parcel.raw),
    dimsRaw: cleanText(parcel.dimsRaw),
  };

  product.diagnostics = buildDiagnostics(product, raw.diagnostics);
  return product;
}

function buildDiagnostics(product, extra = {}) {
  const checkMap = {
    title: product.title,
    mainImage: product.mainImage,
    images: product.images,
    price: product.price.min,
    sales: product.sales,
    stock: product.skus.length ? product.skus.some((sku) => sku.stock > 0) : product.stock,
    skus: product.skus,
    attributes: product.attributes,
    shopName: product.shopName,
    logistics: product.logistics.from || product.logistics.freightText,
    description: product.description,
  };

  const recognized = [];
  const missing = [];
  for (const [field, value] of Object.entries(checkMap)) {
    if (hasValue(value)) recognized.push(FIELD_LABELS[field]);
    else missing.push(FIELD_LABELS[field]);
  }

  // 采集精度提示：把「可能影响上架准确性」的情况点出来，而不是假装数据完整
  const precision = [];
  if (product.price.max > product.price.min && product.price.min > 0) {
    precision.push(`价格为区间价（${product.price.min}~${product.price.max} ${product.price.currency}），定价时请确认用哪一档作为成本`);
  }
  if (product.images.length === 1) {
    precision.push("只识别到 1 张产品图，建议人工确认是否漏图");
  }
  if (product.skus.length && product.skus.every((sku) => !(Number(sku.price) > 0))) {
    precision.push("SKU 只有规格没有价格，定价前请先补成本价");
  }

  return {
    recognized,
    missing,
    notes: [
      ...(Array.isArray(extra?.notes) ? extra.notes.map(cleanText).filter(Boolean) : []),
      ...(product.skus.length
        ? []
        : [product.specOptions.length
          ? "只识别到规格维度（未取到价格矩阵），可在「SKU 与成本」里按规格生成 SKU 并补成本价"
          : "未识别到 SKU 规格，可在「SKU 与成本」里手动补规格"]),
      ...precision,
    ],
  };
}

// 采集结果摘要，用于列表展示
export function summarizeProduct(product) {
  return {
    id: product.id || "",
    platform: product.platform,
    title: product.title,
    mainImage: product.mainImage,
    priceText: product.price.min
      ? `${product.price.currency} ${product.price.min}${product.price.max && product.price.max !== product.price.min ? ` - ${product.price.max}` : ""}`
      : "",
    skuCount: product.skus.length,
    imageCount: product.images.length,
    missingCount: product.diagnostics?.missing?.length || 0,
  };
}
