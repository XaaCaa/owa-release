/**
 * 产品图判定规则（纯函数，不依赖 DOM），面板与测试共用。
 *
 * 重要：content script 不能 import ES module，所以 src/content/adapter-base.js 里有一份
 * 逻辑等价的经典脚本实现（采集阶段用真实尺寸先筛一遍）。两处关键词表必须保持一致，
 * tools/smoke-check.mjs 会逐字比对，改动时请同步修改。
 */

// 明确不是产品图的关键词：logo、图标、角标、按钮、占位图、平台自留地等
export const NON_PRODUCT_IMAGE_PATTERN =
  /(logo|icon|badge|watermark|sprite|avatar|qrcode|qr[-_]?code|erweima|brand|flag|cert|promo|banner|advert|ai[-_]?generated|ai[-_]?badge|heart|like|love|cart|shop|store|flagship|official|mark|tag|seal|guarantee|quality|supplier|factory|wholesale|retail|vip|member|discount|coupon|gift|hot|arrow|btn|button|loading|placeholder|blank|pixel|spacer|divider|star|rate|review|comment|share|collect|favorite|wishlist|service|customer|kefu|online|1688\.com|tmall\.com|taobao\.com|pinduoduo|yangkeduo)/i;

export const ICON_MAX_SIDE = 120;      // 最长边小于此值视为图标 / logo / 按钮
export const STRIP_MAX_SIDE = 300;     // 小于此值且长宽比悬殊的视为横幅 / 分割线
export const STRIP_MIN_RATIO = 0.25;

/**
 * 判断是否产品图。
 * meta 是采集阶段量到的真实尺寸 { [url]: { width, height, natural } }；拿不到尺寸时只按 URL 关键词判断。
 * v1.9.60：natural=false 表示量到的是**渲染尺寸**（CSS 拉大/缩小的结果，不代表文件本身大小），
 * 这种尺寸不可用来判图标/细长条——页面上 60px 的色卡被拉成 300px、或 800px 主图被缩成
 * 120px 显示都很常见，按渲染尺寸一刀切会误删真图。旧草稿没有 natural 字段（undefined），
 * 按可信处理保持原行为。
 */
export function isLikelyProductImage(url, meta) {
  const value = String(url || "");
  let decoded = value;
  try { decoded = decodeURIComponent(value); } catch { /* 保留原文 */ }
  if (NON_PRODUCT_IMAGE_PATTERN.test(decoded)) return false;

  const size = meta && meta[url];
  const width = Number(size?.width) || 0;
  const height = Number(size?.height) || 0;
  if (!width || !height) return true;
  if (size?.natural === false) return true;

  const maxSide = Math.max(width, height);
  const minSide = Math.min(width, height);
  if (maxSide < ICON_MAX_SIDE) return false;
  if (maxSide < STRIP_MAX_SIDE && minSide / maxSide < STRIP_MIN_RATIO) return false;
  return true;
}

/** 给界面用的判定说明，让用户知道为什么这张图被判为图标 */
export function productImageReason(url, meta) {
  const size = meta && meta[url];
  const width = Number(size?.width) || 0;
  const height = Number(size?.height) || 0;
  const trusted = size?.natural !== false;
  if (isLikelyProductImage(url, meta)) {
    return width ? `产品图 ${width}×${height}${trusted ? "" : "（渲染尺寸）"}` : "产品图";
  }
  if (width && Math.max(width, height) < ICON_MAX_SIDE) return `图标（${width}×${height}）`;
  return "疑似平台图标/水印";
}

/** 从图片列表里挑出产品图 */
export function filterProductImages(images, meta) {
  return (images || []).filter((url) => isLikelyProductImage(url, meta));
}
