/**
 * 订阅授权模块（v1.9.59）：机器码 + ECDSA 离线激活码。
 *
 * 为什么用 ECDSA 而不是常见的 HMAC/校验字符串：HMAC 的密钥必须打进插件，
 * Chrome 扩展解包即拿到 key，等于把造码机送给盗版者。ECDSA 是非对称的——
 * 插件里只有**公钥**（只能验签），私钥在烬本人的签发工具里（E:\工作\AI\GC\license-master\），
 * 永远不随插件分发。改插件代码换公钥属于"逆向改造"，普通卖家到不了这一步。
 *
 * 激活码格式： base64url(payload JSON) + "." + base64url(64 字节 ECDSA 签名)
 * payload：{ m: 机器码, e: 到期毫秒时间戳, n: 备注名, v: 1 }
 * 一台机器的码在另一台机器上验不过（m 不匹配），到期日由签名锁死改不了。
 *
 * 防回拨：本地持久化"见过的最大时间戳"，系统时间倒回去也按最大时间算，
 * 到期判断不吃亏。防不了重装清存储（重装后 trialStart 归零重新送 24 小时试用），
 * 但重装要重配 AI/Ozon 密钥、重新导出草稿——对客户来说成本比续费高，够用。
 *
 * 免费/付费边界（获客钩子设计）：
 *  免费：采集、草稿、核价、类目属性表（含官方离线属性/校验/中文显示）、导出表格——
 *        这些保证用户"装完 10 分钟就能感受到比人肉强在哪"。
 *  付费：AI 全流程、AI 填属性、AI 卖点、AI 生图、图片翻译、上传 Ozon、批量上传——
 *        所有花真金白银（AI key / 图引擎 key）和"一步到位上货"的动作。
 */

import { STORAGE_KEYS } from "./constants.js";

const TRIAL_MS = 24 * 60 * 60 * 1000;      // 装机试用 24 小时
const MAX_SEEN_SLACK_MS = 60 * 1000;       // 时钟检查容忍 1 分钟误差

// 公钥（JWK，P-256）。轮换密钥时替换这两段并重新发布插件；私钥不在此处、也不应在。
const PUB_X = "pXZMYt1uDF9O-x-eYR4eQnmeeCsiqKx8tBqug8vHKfY";
const PUB_Y = "IDwp-DAJ1BDTwgHXN2j4EJzvwXuJSbcvv6fwyBOyIJ4";

let pubKeyPromise = null;

function getPubKey() {
  if (!pubKeyPromise) {
    pubKeyPromise = crypto.subtle.importKey(
      "jwk",
      { kty: "EC", crv: "P-256", x: PUB_X, y: PUB_Y, ext: true },
      { name: "ECDSA", namedCurve: "P-256" },
      false,
      ["verify"],
    ).catch(() => null);
  }
  return pubKeyPromise;
}

// —— base64url ——
function bytesToB64url(bytes) {
  let bin = "";
  for (const b of bytes) bin += String.fromCharCode(b);
  return btoa(bin).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}
function b64urlToBytes(text) {
  let s = String(text).replace(/-/g, "+").replace(/_/g, "/");
  while (s.length % 4) s += "=";
  const bin = atob(s);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i += 1) out[i] = bin.charCodeAt(i);
  return out;
}

/** 机器码归一：去掉分隔符转大写后 16 位十六进制 */
export function normalizeMachineId(raw) {
  const hex = String(raw || "").toUpperCase().replace(/[^0-9A-F]/g, "");
  return hex.length === 16 ? hex : "";
}
/** 展示格式：ABCD-EFGH-IJKL-MNOP */
export function formatMachineId(hex) {
  return String(hex || "").replace(/(.{4})(?=.)/g, "$1-");
}

/**
 * 本机机器码：安装期随机种子 + 环境指纹，sha256 取 16 位。
 * 种子是关键——纯环境指纹（UA/屏幕/时区）太好伪造，加一个只有本机知道的随机数，
 * 机器码稳定且别人抄不走。种子存 chrome.storage.local，卸载重装会变（重新送试用，可接受）。
 */
export async function getMachineId() {
  const stored = await chrome.storage.local.get([STORAGE_KEYS.machineSeed]);
  let seed = stored?.[STORAGE_KEYS.machineSeed];
  if (!seed || typeof seed !== "string") {
    const buf = new Uint8Array(16);
    crypto.getRandomValues(buf);
    seed = Array.from(buf, (b) => b.toString(16).padStart(2, "0")).join("");
    await chrome.storage.local.set({ [STORAGE_KEYS.machineSeed]: seed });
  }
  const env = [
    seed,
    navigator.userAgent,
    Intl.DateTimeFormat().resolvedOptions().timeZone || "",
    navigator.language || "",
    `${screen.width}x${screen.height}`,
    navigator.hardwareConcurrency || 0,
    navigator.deviceMemory || 0,
  ].join("|");
  const digest = new Uint8Array(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(env)));
  let hex = "";
  for (const b of digest.slice(0, 8)) hex += b.toString(16).padStart(2, "0");
  return hex.toUpperCase();
}

/**
 * 校验激活码（纯函数，签发工具与自测共用同一份实现）。
 * 返回 { ok, reason?, payload?, exp? }。
 */
export async function verifyLicense(license, machineIdHex, now = Date.now()) {
  const text = String(license || "").trim();
  const parts = text.split(".");
  if (parts.length !== 2 || !parts[0] || !parts[1]) return { ok: false, reason: "格式不对：激活码应为「一串字符.另一串字符」，中间没有空格" };
  const pub = await getPubKey();
  if (!pub) return { ok: false, reason: "浏览器不支持 WebCrypto，无法校验授权" };
  let payload;
  try {
    payload = JSON.parse(new TextDecoder().decode(b64urlToBytes(parts[0])));
  } catch {
    return { ok: false, reason: "激活码已损坏，请找客服重新签发" };
  }
  let sig;
  try {
    sig = b64urlToBytes(parts[1]);
  } catch {
    return { ok: false, reason: "激活码已损坏，请找客服重新签发" };
  }
  if (sig.length !== 64) return { ok: false, reason: "激活码不完整，请整段复制（结尾不能少）" };
  const valid = await crypto.subtle.verify({ name: "ECDSA", hash: "SHA-256" }, pub, sig, new TextEncoder().encode(parts[0]));
  if (!valid) return { ok: false, reason: "签名校验失败：激活码无效或不是发给本机的" };
  if (Number(payload.v) !== 1) return { ok: false, reason: "激活码版本不受支持，请升级插件" };
  const want = normalizeMachineId(machineIdHex);
  if (!want || normalizeMachineId(payload.m) !== want) return { ok: false, reason: "这台机器的机器码与激活码不符，请把本机机器码发给客服换码" };
  const exp = Number(payload.e) || 0;
  if (!(exp > now)) return { ok: false, reason: `授权已到期（${new Date(exp).toLocaleDateString("zh-CN")}），续费后把新激活码粘贴回来即可，数据都在`, exp };
  return { ok: true, payload, exp };
}

/** 本地授权状态（含试用与防回拨） */
export async function getLicenseStatus() {
  const stored = await chrome.storage.local.get([STORAGE_KEYS.license, STORAGE_KEYS.trialStart, STORAGE_KEYS.licenseMaxSeen]);
  const now = Date.now();
  // 时钟回拨检测：见过未来时间说明用户往回调了表想白嫖，一律按"见过的最大时间"算
  let seen = Number(stored?.[STORAGE_KEYS.licenseMaxSeen]) || 0;
  const effectiveNow = Math.max(now, seen - MAX_SEEN_SLACK_MS);
  if (effectiveNow > seen) {
    seen = effectiveNow;
    await chrome.storage.local.set({ [STORAGE_KEYS.licenseMaxSeen]: seen });
  }
  const license = String(stored?.[STORAGE_KEYS.license] || "");
  if (license) {
    const machineId = await getMachineId();
    const result = await verifyLicense(license, machineId, effectiveNow);
    if (result.ok) return { kind: "licensed", exp: result.exp, name: String(result.payload?.n || ""), machineId };
    if (result.exp) {
      // 签名有效、只是到期：仍走试用判断（新装机器能白嫖 24h 续命窗口），到期原因带出去
      const trial = await trialState(stored, effectiveNow);
      return { ...trial, machineId, reason: result.reason };
    }
    // 换机器/损坏/版本不符：直接锁（试用也不给，装过就说明用过试用）
    return { kind: "locked", machineId, reason: result.reason };
  }
  const trial = await trialState(stored, effectiveNow);
  return { ...trial, machineId: await getMachineId() };
}

async function trialState(stored, now) {
  let start = Number(stored?.[STORAGE_KEYS.trialStart]) || 0;
  if (!start) {
    start = now;
    await chrome.storage.local.set({ [STORAGE_KEYS.trialStart]: start });
  }
  const left = start + TRIAL_MS - now;
  if (left > 0) return { kind: "trial", trialLeftMs: left };
  return { kind: "locked", trialLeftMs: 0 };
}

/** 保存激活码前先验一遍，坏码/错机器码当场拒收，不进存储 */
export async function activateLicense(license) {
  const machineId = await getMachineId();
  const result = await verifyLicense(license, machineId, Date.now());
  if (!result.ok) return result;
  await chrome.storage.local.set({ [STORAGE_KEYS.license]: String(license).trim() });
  return result;
}

/**
 * 付费功能闸门：在按钮处理器开头 await ensureLicensed("xxx")。
 * 放行 true；弹授权窗并返回 false。
 */
export async function ensureLicensed(label) {
  const st = await getLicenseStatus();
  if (st.kind === "licensed" || st.kind === "trial") return true;
  if (typeof window !== "undefined" && typeof window.__openLicenseModal === "function") {
    window.__openLicenseModal(label, st);
  }
  return false;
}

export function trialHoursLeft(status) {
  return Math.max(0, Math.ceil((status?.trialLeftMs || 0) / 3600000));
}
