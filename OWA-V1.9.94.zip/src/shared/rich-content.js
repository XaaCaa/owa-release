// Ozon「JSON 富内容」(Rich content) —— 类目属性 id 11254 的取值构造与校验。
//
// 平台规定这个属性是一段 JSON：顶层是小工具(widget)数组，每个小工具里放图块(block)，
// 图块带图片直链 + 标题 + 正文；商品卡片里有描述时，富内容会**替代**描述显示。
// 官方可视化编辑器：https://rich-content.ozon.ru/visual-editor
//
// 设计取舍（v1.9.64）：图片直链、宽高这些「事实」必须由插件用采集到的真实数据填，
// 绝不能让模型编 —— 模型编出来的图片地址一定 404，宽高对不上会让排版错乱。
// 所以模型只负责写每个图块的标题与正文，骨架由这里拼。

import { cleanText, highResImageUrl } from "./utils.js";

export const RICH_CONTENT_ATTR_ID = 11254;

/** Ozon 图片直链只认 jpg/jpeg/png（官方明确不接受 gif） */
const IMAGE_EXT_RE = /\.(?:jpe?g|png)(?:[?#].*)?$/i;
/** 图块上限：太多会把卡片拉得很长、也拖慢加载 */
export const RICH_CONTENT_MAX_BLOCKS = 6;
/** 拿不到真实宽高时的保守兜底（1688 / 淘宝主图基本都是方图） */
const FALLBACK_SIZE = 1000;

/** 能不能拿这张图当富内容图片：必须是 http(s) 直链，且以 jpg / jpeg / png 结尾 */
export function isRichContentImage(url) {
  const value = cleanText(url);
  if (!/^https?:\/\//i.test(value)) return false;
  return IMAGE_EXT_RE.test(value);
}

/**
 * 从草稿里挑出能用作富内容的图片，并带上宽高。
 * 宽高优先取采集时记下的真实尺寸（imageMeta[url].width/height），拿不到才用兜底方图。
 */
export function pickRichContentImages(draft = {}, limit = RICH_CONTENT_MAX_BLOCKS) {
  const images = Array.isArray(draft.images) ? draft.images : [];
  const meta = draft.imageMeta && typeof draft.imageMeta === "object" ? draft.imageMeta : {};
  const out = [];
  const seen = new Set();
  for (const raw of images) {
    const url = cleanText(raw);
    if (!url || seen.has(url)) continue;
    // v1.9.81 修复「富内容没有可用图片」：1688/淘宝采集图常带 xxx.jpg_.webp、
    // xxx.jpg_400x400.jpg 这类转码后缀，直接判 isRichContentImage 会被整批剔掉。
    // 先用 highResImageUrl 还原成真实原图地址，再判断——还原后是合法 jpg/png 就用还原地址。
    const resolved = highResImageUrl(url);
    if (!isRichContentImage(resolved)) continue;
    seen.add(url);
    const size = meta[resolved] || meta[url] || {};
    const width = Number(size.width) > 0 ? Math.round(Number(size.width)) : FALLBACK_SIZE;
    const height = Number(size.height) > 0 ? Math.round(Number(size.height)) : FALLBACK_SIZE;
    out.push({ url: resolved, width, height });
    if (out.length >= limit) break;
  }
  return out;
}

/**
 * 拼 Ozon 富内容 JSON。
 * 每个图块单独成一个小工具（type=billboard，最少 1 块），这样不会撞上 chess 之类
 * 「最少 2 块」的限制；桌面版与移动版先共用同一张图（Ozon 允许，后续可在官方
 * 可视化编辑器里单独换移动版图）。
 * 标题与正文都为空的图块会被丢掉 —— 宁缺毋滥。
 */
export function buildRichContentJson(images = [], blocks = []) {
  const list = [];
  images.forEach((image, index) => {
    const url = cleanText(image?.url);
    if (!isRichContentImage(url)) return;
    const block = blocks[index] || {};
    const title = cleanText(block.title);
    const text = cleanText(block.text);
    if (!title && !text) return;
    const width = Number(image.width) > 0 ? Math.round(Number(image.width)) : FALLBACK_SIZE;
    const height = Number(image.height) > 0 ? Math.round(Number(image.height)) : FALLBACK_SIZE;
    const item = {
      widgetName: "raShowcase",
      type: "billboard",
      blocks: [{
        img: {
          src: url,
          srcMobile: url,
          width,
          height,
          widthMobile: width,
          heightMobile: height,
        },
      }],
    };
    if (title) item.blocks[0].title = title;
    if (text) item.blocks[0].text = { content: [text] };
    list.push(item);
  });
  return list.length ? JSON.stringify(list, null, 2) : "";
}

/** 把详细描述按空行切成段落（富内容的正文就来自这里） */
export function splitRichContentParagraphs(description = "") {
  return String(description || "")
    .split(/\n{2,}/)
    .map((item) => cleanText(item))
    .filter(Boolean);
}

/**
 * 不调 AI 的兜底排版：把详细描述按段落配到图片上。
 * 模型不可用（没配 Key / 超时 / 返回中文）时也能一键出一版可用的富内容。
 */
export function buildRichContentFallback(images = [], description = "", title = "") {
  const paragraphs = splitRichContentParagraphs(description);
  if (!paragraphs.length || !images.length) return "";
  const count = Math.min(images.length, paragraphs.length);
  const blocks = [];
  for (let i = 0; i < count; i += 1) {
    blocks.push({ title: i === 0 ? cleanText(title) : "", text: paragraphs[i] });
  }
  return buildRichContentJson(images.slice(0, count), blocks);
}

/**
 * 校验一段富内容 JSON 是不是 Ozon 能接受的形状。
 * 只做「一定会被平台拒绝」的硬检查（不是合法 JSON / 缺 widgetName / 缺 blocks /
 * 图片链接不是 jpg-png 直链），不假装能替代官方沙箱。
 */
export function validateRichContentJson(text) {
  const raw = cleanText(text);
  if (!raw) return { ok: true, empty: true, value: null, widgets: 0, blocks: 0 };
  let parsed;
  try {
    parsed = JSON.parse(raw);
  } catch (error) {
    return { ok: false, error: `不是合法 JSON：${error?.message || error}` };
  }
  const list = Array.isArray(parsed) ? parsed : [parsed];
  if (!list.length) return { ok: false, error: "JSON 里没有任何小工具" };
  let blocks = 0;
  for (let index = 0; index < list.length; index += 1) {
    const widget = list[index];
    const at = `第 ${index + 1} 个小工具`;
    if (!widget || typeof widget !== "object" || Array.isArray(widget)) return { ok: false, error: `${at}不是对象` };
    if (!cleanText(widget.widgetName)) return { ok: false, error: `${at}缺 widgetName` };
    const items = Array.isArray(widget.blocks) ? widget.blocks : [];
    if (!items.length) return { ok: false, error: `${at}没有 blocks` };
    for (const item of items) {
      if (!item || typeof item !== "object" || Array.isArray(item)) return { ok: false, error: `${at}里的 block 不是对象` };
      const src = cleanText(item?.img?.src);
      if (src && !isRichContentImage(src)) {
        return { ok: false, error: `图片链接必须以 .jpg / .jpeg / .png 结尾（Ozon 不接受 gif）：${src.slice(0, 80)}` };
      }
      blocks += 1;
    }
  }
  return { ok: true, value: list, widgets: list.length, blocks };
}

/** 一句话描述这段富内容（给界面上的状态行用） */
export function summarizeRichContent(text) {
  const check = validateRichContentJson(text);
  if (!check.ok) return { ok: false, text: "JSON 有问题", error: check.error };
  if (check.empty) return { ok: true, text: "", widgets: 0, blocks: 0 };
  return { ok: true, text: `${check.widgets} 个小工具 / ${check.blocks} 个图块`, widgets: check.widgets, blocks: check.blocks };
}
