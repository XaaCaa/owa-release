// 全局常量：存储键、消息动作、流水线阶段、AI 服务预设。
// 仅被 background（module）与 ui（module）引用；content script 必须自包含，不 import 本文件。

export const STORAGE_KEYS = Object.freeze({
  settings: "ozon_lister_settings",
  drafts: "ozon_lister_drafts",
  lastCapture: "ozon_lister_last_capture",
  stores: "ozon_lister_stores",
  automation: "ozon_lister_automation",
  categoryCache: "ozon_lister_category_cache",
  categoryZhCache: "ozon_lister_category_zh",
  attributeValuesCache: "ozon_lister_attribute_values",
  // v1.9.55 类目属性「官方元数据」缓存：属性定义 + 版本指纹 + 回源时间。
  // 和候选值缓存分开管——定义会变（平台改类目就要立刻知道），候选值可以放 7 天。
  attributeMetaCache: "ozon_lister_attribute_meta",
  pricingTemplates: "ozon_lister_pricing_templates",
  // v1.9.59 订阅授权：机器种子 / 激活码 / 试用起点 / 见过的最大时间戳（防时钟回拨）
  machineSeed: "ozon_lister_machine_seed",
  license: "ozon_lister_license",
  trialStart: "ozon_lister_trial_start",
  // v1.9.87 自动检查更新的节流缓存：{ at, latest, url, notes }——6 小时内复用，不反复打更新源
  updateCheck: "owa_update_check",
  licenseMaxSeen: "ozon_lister_max_seen",
});

export const MESSAGE_ACTIONS = Object.freeze({
  captureProduct: "capture_product",
  listProductTabs: "list_product_tabs",
  diagnose: "diagnose",
  // v1.9.75 SKU 采集诊断：把 1688 页面的真实 DOM 结构吐回来定位选择器失效
  diagnoseSku: "diagnose_sku",
  aiGenerateText: "ai_generate_text",
  aiFillAttributes: "ai_fill_attributes",
  aiDetectSpecOptions: "ai_detect_spec_options",
  aiPickCategory: "ai_pick_category",
  // v1.9.66 类目树全量约束匹配：完整类目树写进提示词，AI 同时按「产品标题 + 产品外观图片」
  // 两路信息在树内选域/类目/类型，返回的行号必须能在树里原样查到，否则整体拒绝。
  aiMatchCategoryTree: "ai_match_category_tree",
  aiTranslateTexts: "ai_translate_texts",
  aiSellingPoints: "ai_selling_points",
  aiImagePlan: "ai_image_plan",
  // v1.9.73 策划师模式：先出卖点表（排序+唯一最强卖点）再出 8 图结构化方案
  aiImageStrategy: "ai_image_strategy",
  // v1.9.49 出图前视觉分析：看参考图对比差异，给每张待生成的图定制独立方案
  aiArtDirection: "ai_art_direction",
  // v1.9.64 JSON 富内容（类目属性 id 11254）：模型只写每个图块的标题与正文，
  // 图片直链与宽高由插件按采集数据拼（模型编的图片地址一定 404）
  aiRichContent: "ai_rich_content",
  aiGenerateTextStream: "ai_generate_text_stream",
  aiTestConnection: "ai_test_connection",
  ozonTestConnection: "ozon_test_connection",
  ozonCategoryTree: "ozon_category_tree",
  ozonCategoryAttributes: "ozon_category_attributes",
  // v1.9.50 枚举型属性的候选值字典（「属性不正确：请从列表中选择」的根治数据）
  ozonAttributeValues: "ozon_attribute_values",
  // v1.9.55 类目属性官方元数据（定义 + 指纹 + 全量候选值一次拿全，带 24h 缓存与强制刷新）
  ozonAttributeMeta: "ozon_attribute_meta",
  // v1.9.56 超大字典（品牌几十万个值）按需搜索：本地只存前 N 万，落不上的用官方搜索接口反查
  ozonAttributeValueSearch: "ozon_attribute_value_search",
  ozonImportProducts: "ozon_import_products",
  ozonImportInfo: "ozon_import_info",
  ozonProductList: "ozon_product_list",
  ozonStocks: "ozon_stocks",
  ozonUpdateStocks: "ozon_update_stocks",
  ozonUpdatePrices: "ozon_update_prices",
  ozonFbsOrders: "ozon_fbs_orders",
  ozonAnalytics: "ozon_analytics",
  ozonSalesIntel: "ozon_sales_intel",
  ozonBulkImport: "ozon_bulk_import",
  imageTranslate: "image_translate",
  imageRedraw: "image_redraw",
  imageTestXiangji: "image_test_xiangji",
  imageTestRedraw: "image_test_redraw",
  fetchImageAsDataUrl: "fetch_image_as_data_url",
  // v1.9.50 上传前探测图片能不能被 Ozon 抓到（商品卡片「没有照片」的根因排查）
  imageProbe: "image_probe",
});

// AI 服务预设。baseUrl 必须是 OpenAI 兼容的 /chat/completions 前缀。
export const AI_PRESETS = Object.freeze([
  {
    id: "deepseek",
    name: "DeepSeek",
    baseUrl: "https://api.deepseek.com/v1",
    models: ["deepseek-chat", "deepseek-reasoner"],
    defaultModel: "deepseek-chat",
  },
  {
    id: "qwen",
    name: "通义千问（DashScope 兼容）",
    baseUrl: "https://dashscope.aliyuncs.com/compatible-mode/v1",
    models: ["qwen-plus", "qwen-max", "qwen-turbo"],
    defaultModel: "qwen-plus",
  },
  {
    id: "moonshot",
    name: "Moonshot Kimi",
    baseUrl: "https://api.moonshot.cn/v1",
    models: ["moonshot-v1-8k", "moonshot-v1-32k", "moonshot-v1-128k"],
    defaultModel: "moonshot-v1-32k",
  },
  {
    id: "zhipu",
    name: "智谱 GLM",
    baseUrl: "https://open.bigmodel.cn/api/paas/v4",
    models: ["glm-4-plus", "glm-4-flash", "glm-4-air"],
    defaultModel: "glm-4-flash",
  },
  {
    id: "siliconflow",
    name: "硅基流动",
    baseUrl: "https://api.siliconflow.cn/v1",
    models: ["Qwen/Qwen2.5-72B-Instruct", "deepseek-ai/DeepSeek-V3"],
    defaultModel: "Qwen/Qwen2.5-72B-Instruct",
  },
  {
    id: "openai",
    name: "OpenAI",
    baseUrl: "https://api.openai.com/v1",
    models: ["gpt-4o-mini", "gpt-4o"],
    defaultModel: "gpt-4o-mini",
  },
  {
    id: "custom",
    name: "自定义（OpenAI 兼容）",
    baseUrl: "",
    models: [],
    defaultModel: "",
  },
]);

// AI 生图服务预设。baseUrl 必须是 OpenAI 兼容的 /images/generations 前缀。
// supportedSizes 是「官方文档里明确支持」的尺寸列表，仅作面板提示与生图前预校验用；
// 不在列表里不代表一定失败（部分中转放得更宽），但大多数情况下会让请求 400。
export const IMAGE_PRESETS = Object.freeze([
  {
    id: "siliconflow",
    name: "硅基流动（推荐，国内直连）",
    baseUrl: "https://api.siliconflow.cn/v1",
    models: ["Kwai-Kolors/Kolors", "black-forest-labs/FLUX.1-schnell", "Qwen/Qwen-Image"],
    defaultModel: "Kwai-Kolors/Kolors",
    defaultSize: "1024x1024",
    supportedSizes: ["1024x1024", "960x1280", "768x1024", "1024x576", "576x1024"],
    note: "官方直连服务，按量计费，发票与用量在硅基流动后台查看。",
  },
  {
    id: "aliyun-qwen",
    name: "阿里云百炼（Qwen-Image 原生）",
    baseUrl: "https://dashscope.aliyuncs.com/api/v1",
    models: ["qwen-image-edit", "qwen-image-3.0", "qwen-image-3.0-pro"],
    defaultModel: "qwen-image-3.0",
    defaultSize: "1024x1024",
    // 3.0 系列总像素在 512*512~2048*2048 之间即可；面板给常见比例，保存时不会强制校验。
    supportedSizes: ["1024x1024", "1024x1536", "1536x1024", "1024x1792", "1792x1024", "1344x1008", "1008x1344"],
    note: "阿里云百炼 DashScope 原生图像生成接口。Key 在百炼控制台「API-KEY」获取；模型、Key、Endpoint 必须属于同一地域，跨地域会 401。出图尺寸填写「宽x高」（如 1024x1024），插件会在请求时转成 DashScope 要求的「宽*高」。**做图生图（上架套图）请用 qwen-image-edit**——它是图像编辑模型，能按参考图「改一张图」；qwen-image-3.0 偏向纯文本生成，可能忽略参考图。",
  },
  {
    id: "openai",
    name: "OpenAI",
    baseUrl: "https://api.openai.com/v1",
    models: ["gpt-image-1", "dall-e-3"],
    defaultModel: "gpt-image-1",
    defaultSize: "1024x1024",
    // gpt-image-1 支持 auto / 1024x1024 / 1024x1536 / 1536x1024；
    // dall-e-3 支持 1024x1024 / 1792x1024 / 1024x1792 —— supportedSizes 给两者并集，
    // 再用 sizesByModel 收紧：命中模型的专属列表优先，避免「gpt-image-1 能过、dall-e-3 会 400」的尺寸被放过
    supportedSizes: ["auto", "1024x1024", "1024x1536", "1536x1024", "1792x1024", "1024x1792"],
    sizesByModel: { "dall-e-3": ["1024x1024", "1792x1024", "1024x1792"] },
    note: "OpenAI 官方接口，国内访问可能受限。",
  },
  {
    id: "custom",
    name: "自定义（OpenAI 兼容）",
    baseUrl: "",
    models: [],
    defaultModel: "",
    defaultSize: "1024x1024",
    supportedSizes: [],
    note: "",
  },
]);

/**
 * 取自定预设 + 模型的有效支持尺寸列表。
 * 优先用 sizesByModel 里命中模型的那份（更严格），没有才回落到预设的 supportedSizes。
 */
export function effectiveSupportedSizes(preset, model = "") {
  const name = String(model || "").trim().toLowerCase();
  const byModel = preset?.sizesByModel;
  if (byModel && name) {
    const hit = Object.keys(byModel).find((key) => key.toLowerCase() === name);
    if (hit && Array.isArray(byModel[hit])) return byModel[hit];
  }
  return Array.isArray(preset?.supportedSizes) ? preset.supportedSizes : [];
}

/**
 * 上架套图出图尺寸：Ozon 建议商品图 3:4，各服务支持的尺寸不一样
 * （如硅基流动是 960x1280、百炼是 1008x1344、OpenAI 是 1024x1536），
 * 这里从该服务支持的尺寸里挑宽高比最接近 3:4 的那个。
 */
export function pickListingSetSize(preset, model = "", targetRatio = 0.75) {
  const list = effectiveSupportedSizes(preset, model).filter((item) => /^\d{2,5}x\d{2,5}$/.test(String(item)));
  if (!list.length) return preset?.defaultSize || "1024x1024";
  let best = list[0];
  let bestDiff = Infinity;
  for (const item of list) {
    const [width, height] = String(item).split("x").map(Number);
    if (!width || !height) continue;
    const diff = Math.abs(width / height - targetRatio);
    if (diff < bestDiff) {
      bestDiff = diff;
      best = item;
    }
  }
  return best;
}

/* ---------------- 电商套图：尺寸比例库（1K / 2K / 4K） ----------------
 * 出图工具里让用户选的其实是「比例 + 分辨率档」，而不是死记某个像素值。
 * 1K/2K 是实测常见的可用尺寸，4K 由 2K 直接翻倍（多数服务对 4K 会拦，选之前心里有数）。
 */

export const IMAGE_SIZE_TIERS = Object.freeze(["1K", "2K", "4K"]);

export const DEFAULT_SIZE_RATIO = "3:4";

export const DEFAULT_SIZE_TIER = "1K";

export const IMAGE_SIZE_RATIOS = Object.freeze([
  { id: "1:1", label: "1:1", note: "正方形", "1K": "1024x1024", "2K": "2048x2048" },
  { id: "3:4", label: "3:4", note: "竖版 · Ozon 推荐", "1K": "896x1200", "2K": "1536x2048" },
  { id: "2:3", label: "2:3", note: "竖版", "1K": "848x1264", "2K": "1264x1896" },
  { id: "4:5", label: "4:5", note: "竖版 · 社交封面", "1K": "928x1152", "2K": "1408x1752" },
  { id: "9:16", label: "9:16", note: "竖版 · 手机全屏", "1K": "768x1376", "2K": "1152x2064" },
  { id: "1:3", label: "1:3", note: "超长竖版", "1K": "512x1536", "2K": "768x2304" },
  { id: "9:21", label: "9:21", note: "超长竖版 · 详情页", "1K": "576x1344", "2K": "864x2016" },
  { id: "4:3", label: "4:3", note: "横版", "1K": "1200x896", "2K": "2048x1536" },
  { id: "3:2", label: "3:2", note: "横版 · 主图备选", "1K": "1264x848", "2K": "1896x1264" },
  { id: "5:4", label: "5:4", note: "横版", "1K": "1152x928", "2K": "1752x1408" },
  { id: "16:9", label: "16:9", note: "宽屏", "1K": "1376x768", "2K": "2064x1152" },
  { id: "21:9", label: "21:9", note: "超宽屏 · 横幅", "1K": "1584x672", "2K": "3168x1344" },
  { id: "3:1", label: "3:1", note: "超宽横幅 · 店铺装修", "1K": "1536x512", "2K": "3072x1024" },
]);

export function findSizeRatio(id) {
  return IMAGE_SIZE_RATIOS.find((item) => item.id === id) || null;
}

/** 把尺寸串「宽x高」转成宽高比数值；解析不出来返回 0 */
export function sizeRatioValue(size) {
  const [width, height] = String(size || "").split("x").map(Number);
  if (!width || !height) return 0;
  return width / height;
}

/** 比例文案「3:4」→ 数值 0.75；解析不出来返回 0 */
export function ratioLabelValue(label) {
  const [a, b] = String(label || "").split(":").map(Number);
  if (!a || !b) return 0;
  return a / b;
}

/** 取某个比例在某个分辨率档下的尺寸。4K 由 2K 翻倍并按 16 的倍数取整 */
export function sizeForRatio(ratioId, tier = DEFAULT_SIZE_TIER) {
  const ratio = findSizeRatio(ratioId);
  if (!ratio) return "";
  if (ratio[tier]) return ratio[tier];
  const base2k = ratio["2K"];
  if (tier === "4K" && base2k) {
    const [width, height] = base2k.split("x").map(Number);
    const round16 = (value) => Math.round(value / 16) * 16;
    return `${round16(width * 2)}x${round16(height * 2)}`;
  }
  return ratio["1K"] || "";
}

/**
 * 把用户选的尺寸适配到当前生图服务真正支持的尺寸：
 *  - 服务没声明支持列表（自定义服务）→ 原样使用；
 *  - 列表里有 → 精确命中；
 *  - 列表里没有 → 挑该服务支持尺寸里比例最接近的，并报告「实际按 xxx 出图」。
 * 直接硬发不被支持的尺寸，服务端往往直接 400，所以这里必须拦一道。
 */
export function resolveProviderSize(preset, model = "", size = "", ratio = "") {
  const wanted = String(size || "").trim();
  if (!wanted) return { size: "", exact: true, requested: "" };
  const supported = effectiveSupportedSizes(preset, model).filter((item) => /^\d{2,5}x\d{2,5}$/.test(String(item)));
  if (!supported.length) return { size: wanted, exact: true, requested: wanted };
  if (supported.includes(wanted)) return { size: wanted, exact: true, requested: wanted };

  const target = ratioLabelValue(ratio) || sizeRatioValue(wanted);
  let best = supported[0];
  let bestDiff = Infinity;
  for (const item of supported) {
    const diff = Math.abs(sizeRatioValue(item) - target);
    if (diff < bestDiff) {
      bestDiff = diff;
      best = item;
    }
  }
  return { size: best, exact: false, requested: wanted, supported };
}


/**
 * 校验出图尺寸：根据当前预设（+ 模型）的支持列表给一个结构化结果。
 *  - { ok: true,  warning: null }                       尺寸在列表里，无需提示
 *  - { ok: true,  warning: "..." }                     格式合法但不在列表里（部分中转放得更宽，仍允许一试）
 *  - { ok: false, warning: null, error: "..." }        格式就不对（不是 宽x高）
 * custom 预设或列表为空时不阻塞、不提示（用户自己清楚）
 */
export function validateImageSize(preset, size, model = "") {
  const text = String(size || "").trim();
  if (!text) return { ok: false, error: "请填写出图尺寸，如 1024x1024", warning: null };
  if (!/^\d{2,5}x\d{2,5}$/.test(text)) {
    return { ok: false, error: `出图尺寸格式不对（读到的是「${text}」），应为「宽x高」，例如 1024x1024 或 1008x1344`, warning: null };
  }
  const supported = effectiveSupportedSizes(preset, model);
  if (!supported.length) return { ok: true, warning: null };
  if (supported.includes(text)) return { ok: true, warning: null };
  // 命中了模型专属列表时，措辞落在「模型」上，否则落在「预设」上
  const modelSpecific = effectiveSupportedSizes(preset, model) !== (preset?.supportedSizes || []);
  const who = modelSpecific ? `当前模型（${String(model).trim()}）只支持：${supported.join("、")}`
    : `当前预设（${preset?.name || ""}）的官方支持尺寸是：${supported.join("、")}`;
  return {
    ok: true,
    warning: `出图尺寸「${text}」不在官方支持列表里。${who}。服务可能拒绝请求，但部分中转放得更宽，所以仍会发出去试 —— 真不支持时生图会失败`,
  };
}

// 象寄翻译支持的文本引擎（对应 API 的 translation_vendor 枚举）
export const XIANGJI_VENDORS = Object.freeze([
  { id: "DeepL", label: "DeepL（俄语质量较好）" },
  { id: "ChatGPT", label: "ChatGPT" },
  { id: "Gemini", label: "Gemini" },
  { id: "Aliyun", label: "阿里云（默认）" },
  { id: "Google", label: "Google" },
  { id: "Papago", label: "Papago" },
  { id: "Baidu", label: "百度" },
]);

export const OZON_API_BASE = "https://api-seller.ozon.ru";
export const OZON_SELLER_ORIGIN = "https://seller.ozon.ru/";

export const PLATFORM_LABELS = Object.freeze({
  "1688": "1688",
  taobao: "淘宝/天猫",
  pdd: "拼多多",
});

// v1.9.86 更新源内置：客户不需要在设置里填地址，点顶栏版本号直接检查更新（超哥：这个不需要显示，点击即可更新）。
// 发布者（超哥）把 owa-update.json 的直链填到这里再打包，所有客户共用；
// 老客户在旧版本设置里手填过的 updateUrl 依然优先（灰度/测试渠道用）。
export const BUILT_IN_UPDATE_URL = "https://raw.githubusercontent.com/XaaCaa/owa-release/main/owa-update.json";
// v1.9.89 双源备份：GitHub raw 国内直连不稳（无代理常 000），备源走 jsDelivr CDN
// （国际 CDN 有国内节点，内容实时从同一个 GitHub 仓库拉取——超哥只维护 GitHub 一个仓库，
//  备源零维护）。主源失败自动落到备源；zip 下载同理（JSON 里带 url2）。
export const BUILT_IN_UPDATE_MIRROR = "https://cdn.jsdelivr.net/gh/XaaCaa/owa-release@main/owa-update.json";
