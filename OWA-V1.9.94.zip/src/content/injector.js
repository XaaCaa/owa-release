/**
 * 采集入口：按当前页面 host 选择适配器，并响应面板的采集请求。
 * 只负责取数，字段规范化交给后台（后台是 ES module，可复用 shared/product-model）。
 */
(function (global) {
  "use strict";

  const registry = global.__OZON_ADAPTERS__;
  if (!registry) return;

  function currentHost() {
    return location.hostname.replace(/^www\./, "");
  }

  function pickAdapter() {
    const host = currentHost();
    return registry.adapters.find((adapter) => adapter.matches(host)) || null;
  }

  async function capture() {
    const adapter = pickAdapter();
    if (!adapter) {
      return { ok: false, error: `当前页面（${currentHost()}）不在支持的采集站点内` };
    }
    try {
      const raw = await adapter.capture();
      if (!raw || !raw.title) {
        return {
          ok: false,
          error: "未能读取到商品标题，页面可能处于登录墙、验证码或未完成渲染状态，请刷新后重试",
        };
      }
      return { ok: true, data: raw };
    } catch (error) {
      return { ok: false, error: error?.message || String(error) };
    }
  }

  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    // 连通性自检：面板的「运行诊断」用它判断 content script 是否已注入
    if (message?.action === "ozon_ping") {
      sendResponse({
        ok: true,
        ready: true,
        host: location.hostname,
        path: location.pathname,
        adapters: registry.adapters.map((adapter) => adapter.platform),
        matched: Boolean(pickAdapter()),
      });
      return true;
    }
    // SKU 采集诊断（v1.9.75）：采集不准时把页面真实结构吐回面板，用于定位选择器失效。
    // 必须放在 capture_product 判断之前，否则会被那句 return false 拦掉。
    if (message?.action === "ozon_diagnose_sku") {
      try {
        const adapter = pickAdapter();
        const fn = registry.sku1688?.diagnoseSkuStructure;
        if (!adapter || adapter.platform !== "1688" || typeof fn !== "function") {
          sendResponse({ ok: false, error: "当前不是 1688 商品页，或采集脚本未就绪（请刷新商品页）" });
        } else {
          sendResponse({ ok: true, data: fn() });
        }
      } catch (error) {
        sendResponse({ ok: false, error: error?.message || String(error) });
      }
      return true;
    }
    if (message?.action !== "capture_product") return false;
    capture().then(sendResponse);
    return true; // 保持消息通道，异步回包
  });

  registry.ready = true;
})(window);
