/**
 * Ozon 卖家后台桥：在 seller.ozon.ru 页面上下文中读取已登录商品数据。
 *
 * 说明：Ozon 未公开卖家后台的内部接口，且随时可能调整。这里只做两件确定的事：
 *   1. 从当前已渲染的卖家后台页面里读取可见的商品行；
 *   2. 读不到时返回明确原因，绝不伪造销量数据。
 * 需要"销量情报"时，请在卖家后台打开商品列表/分析页面后再触发。
 */
(function () {
  "use strict";

  function clean(value) {
    return String(value == null ? "" : value).replace(/\s+/g, " ").trim();
  }

  function number(value) {
    const parsed = Number.parseFloat(String(value == null ? "" : value).replace(/[^\d.,\-]/g, "").replace(",", "."));
    return Number.isFinite(parsed) ? parsed : 0;
  }

  function readTableRows() {
    const rows = Array.from(document.querySelectorAll('[role="row"], tr, [class*="row"]'))
      .filter((row) => row.querySelectorAll('[role="cell"], td, [class*="cell"]').length >= 3);

    const out = [];
    for (const row of rows) {
      const cells = Array.from(row.querySelectorAll('[role="cell"], td, [class*="cell"]')).map((cell) =>
        clean(cell.innerText || cell.textContent),
      );
      if (!cells.some(Boolean)) continue;
      const hasSku = cells.some((cell) => /\d{6,}/.test(cell));
      if (!hasSku) continue;
      out.push(cells);
    }
    return out.slice(0, 200);
  }

  function collect() {
    const rows = readTableRows();
    if (!rows.length) {
      return {
        ok: false,
        error: "当前卖家后台页面未识别到商品行。请在卖家后台打开商品列表或分析页面，等待列表加载完成后重试。",
      };
    }
    return { ok: true, rows, url: location.href, capturedAt: new Date().toISOString() };
  }

  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message?.action !== "ozon_sales_intel") return false;
    try {
      sendResponse(collect());
    } catch (error) {
      sendResponse({ ok: false, error: error?.message || String(error) });
    }
    return true;
  });
})();
