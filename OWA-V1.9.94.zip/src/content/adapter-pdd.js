/**
 * 拼多多商品详情采集适配器。
 * 拼多多以移动端页面 + 内联数据为主，DOM 类名混淆严重，因此优先解析内联 JSON，
 * 失败再退回 DOM 兜底；读不到的字段留空并写诊断。
 */
(function (global) {
  "use strict";

  const registry = global.__OZON_ADAPTERS__;
  if (!registry) return;
  const U = registry.utils;
  const { cleanText, parseNumber, normalizeImageUrl, dedupe, all, text, sleep } = U;

  const ORIGIN = location.origin;

  function pickDataModel(cache) {
    return (
      U.findInlineJson([
        /window\.rawData\s*=\s*(\{[\s\S]{0,500000}?\});?\s*(?:<\/script>|window\.)/,
        /window\.__INIT_DATA__\s*=\s*(\{[\s\S]{0,500000}?\});?\s*(?:<\/script>|window\.)/,
        /window\.__INITIAL_STATE__\s*=\s*(\{[\s\S]{0,500000}?\});?\s*(?:<\/script>|window\.)/,
        /"goodsDetailResponse"\s*:\s*(\{[\s\S]{0,400000}?\})\s*[,}]/,
      ], null, cache) || null
    );
  }

  function digModel(data) {
    if (!data || typeof data !== "object") return null;
    const paths = [
      data.goods, data.goodsDetail, data.detail, data.data,
      data.data && data.data.goods, data.data && data.data.goodsDetail,
      data.store && data.store.goods, data.initData && data.initData.goods,
      data.goodsDetailResponse,
    ];
    for (const candidate of paths) {
      if (candidate && typeof candidate === "object") return candidate;
    }
    return data;
  }

  function pickTitle(model) {
    // v1.9.69：内联数据（model）来自当前页面的商品 JSON，最可信；其次是权威标题
    // （og:title / document.title）。通用 DOM 选择器 [class*=title] 排在最后 ——
    // 它会命中推荐位里**另一件商品**的标题。
    const authoritative = U.authoritativeTitle();
    const value = cleanText(model?.goodsName || model?.name || model?.title || authoritative || text("[class*=goods-name]"));
    const cleaned = U.sanitizeTitle(value) || value;
    // v1.9.63：整个标题退化成一个店铺名时宁可不给——发给 AI 只会换来「未知商品」
    return U.looksLikeShopName(cleaned) ? "" : cleaned;
  }

  function pickPrice(model, cache) {
    const rawMin = model?.minGroupPrice ?? model?.price ?? model?.minOnSaleGroupPrice ?? model?.minNormalPrice ?? "";
    const rawMax = model?.maxGroupPrice ?? model?.maxOnSaleGroupPrice ?? model?.maxNormalPrice ?? "";
    // 拼多多价格单位为分
    let min = parseNumber(rawMin) / 100;
    let max = parseNumber(rawMax) / 100;
    let raw = cleanText(rawMin);
    if (!min) {
      // 兜底顺序：JSON-LD → meta → 已知选择器 → 类名带 price 的元素 → 全页第一个 ¥ 数字
      const picked = U.pickPagePrice({
        cache,
        selectors: [
          "[class*=price] [class*=num]",
          "[class*=goodsPrice]",
          "[class*=priceText]",
          "[class*=mainPrice]",
          ".goods-price",
          ".price",
        ],
      });
      if (picked.min > 0) { min = picked.min; max = picked.max; raw = picked.raw; }
    }
    return { min: min || 0, max: max > min ? max : 0, raw };
  }

  /* ------------------------------------------------------------------
   * 图片采集：轮播主图 / 图集缩略图 / 详情长图 分开抓，互不污染。
   *
   * 老实现有三个硬伤：
   *   ① 容器里混了 [class*=thumb] 和 [class*=banner-list]，又完全没排除评论晒图与推荐位
   *      —— 于是「主图」经常是买家秀、猜你喜欢或者活动 banner；
   *   ② 内联 JSON 里的干净大图被追加在**最后**，images[0] 永远轮不到它，而拼多多的
   *      内联数据恰恰是唯一带真实宽高的来源，「按尺寸挑主图」也就没了依据；
   *   ③ 容器一个都没命中就退回全页扫描，把图标、活动图、店铺卡片全收进来。
   *
   * 现在改成：内联 JSON 优先（带真实宽高）→ aria-label 锚点 → 通用图集容器兜底，
   * 全程排除评论/推荐位，最后按尺寸挑主图并把主图排到第一位。
   * aria-label 是拼多多自己打在轮播图和详情图上的标记（"商品大图" / "查看图片"），
   * 页面改版时类名会变，这两个标记最稳。
   * ------------------------------------------------------------------ */

  // 评论晒图 / 推荐位 / 店铺卡片里的图不是本商品图，必须排除
  const IMAGE_EXCLUDE_ZONES = [
    "[class*=review]", "[class*=Review]", "[class*=comment]", "[class*=Comment]",
    "[class*=评价]", "[class*=appraise]", "[class*=pingjia]",
    "[class*=recommend]", "[class*=Recommend]", "[class*=similar]", "[class*=Similar]",
    "[class*=related]", "[class*=guess]", "[class*=mayLike]", "[class*=maylike]",
    "[class*=mallCard]", "[class*=mall-card]", "[class*=shopCard]", "[class*=shop-card]",
    "[class*=storeCard]", "[class*=store-card]", "[class*=sellerInfo]", "[class*=coupon]",
  ];

  // 轮播主图：aria-label="商品大图" 排最前（以 "@" 开头表示是完整选择器，不再补 " img"）
  const GALLERY_MAIN_SELECTORS = [
    '@img[aria-label="商品大图"]',
    "[class*=goodsGallery] [class*=mainImg] img",
    "[class*=goods-gallery] [class*=main-img] img",
    "[class*=gallery] [class*=mainImg] img",
    "[class*=gallery] [class*=main-img] img",
    "[class*=swiper] [class*=slide] img",
    "[class*=carousel] [class*=item] img",
    "[class*=goodsImg] img",
    "[class*=goods-img] img",
  ];

  // 缩略图列表：主图下面那排小图，代表完整图集
  const GALLERY_THUMB_SELECTORS = [
    "[class*=goodsGallery] [class*=thumb] img",
    "[class*=gallery] [class*=thumb] img",
    "[class*=swiper] [class*=thumb] img",
    "[class*=thumbList] img",
    "[class*=thumb-list] img",
  ];

  // 兜底：主图/缩略图选择器都没命中（拼多多改版）时才用的整块图集容器
  const GALLERY_FALLBACK_SELECTORS = [
    "[class*=goodsGallery]",
    "[class*=goods-gallery]",
    "[class*=gallery]",
    "[class*=swiper]",
    "[class*=carousel]",
    ".goods-img",
  ];

  // 商品详情长图所在容器（拼多多详情区类名混淆严重，多备几套 + aria-label 锚点）
  const DETAIL_IMAGE_SELECTORS = [
    '@img[aria-label="查看图片"]',
    "[class*=detailContent]",
    "[class*=detail-content]",
    "[class*=goodsDetail]",
    "[class*=goods-detail]",
    "[class*=detailDesc]",
    "[class*=detail-desc]",
    "[class*=descContent]",
    "[class*=richText]",
    "[class*=rich-text]",
    "#detailContent",
  ];

  const DETAIL_IMAGE_LIMIT = 60;
  // 图集最多收多少张：拼多多商品页的图集通常 5~12 张，多出来的基本是推荐位漏网的
  const GALLERY_IMAGE_LIMIT = 24;

  /** 图片面积：挑主图时用它排序 */
  function imageAreaScore(meta) {
    const width = Number(meta && meta.width) || 0;
    const height = Number(meta && meta.height) || 0;
    return width * height;
  }

  /**
   * 挑主图：主图通常是图集里尺寸最大且接近正方形的那张（800x800 / 1200x1200），
   * 详情长图那种细长条会被降权。没有任何尺寸信息时退回第一张（保持卖家排序）。
   * 渲染尺寸（natural=false，懒加载没量到真实文件尺寸）打 25% 折，避免页面上被拉大的
   * 缩略图压过真正量到 1200x1200 的主图。
   */
  function pickMainImage(images = [], imageMeta = {}) {
    const list = Array.isArray(images) ? images : [];
    if (!list.length) return "";
    let best = list[0];
    let bestScore = -1;
    let squarePicked = "";
    let squareArea = -1;
    for (const url of list) {
      const meta = imageMeta[url] || {};
      const width = Number(meta.width) || 0;
      const height = Number(meta.height) || 0;
      if (!width || !height) continue;
      const trusted = meta.natural === false ? 0.25 : 1;
      const area = imageAreaScore(meta);
      const squareness = Math.min(width, height) / Math.max(width, height);
      if (squareness >= 0.7 && trusted === 1 && area > squareArea) {
        squareArea = area;
        squarePicked = url;
      }
      const score = area * (squareness >= 0.7 ? 1 : squareness) * trusted;
      if (score > bestScore) {
        bestScore = score;
        best = url;
      }
    }
    return squarePicked || best;
  }

  /** 合并多个来源的尺寸元数据：同一 URL 取各来源里的最大尺寸与 natural 标记 */
  function mergeImageMeta(...metas) {
    const out = {};
    for (const meta of metas) {
      for (const [url, size] of Object.entries(meta || {})) {
        const known = out[url];
        if (!known) {
          out[url] = { width: Number(size.width) || 0, height: Number(size.height) || 0, natural: Boolean(size.natural) };
          continue;
        }
        known.width = Math.max(known.width, Number(size.width) || 0);
        known.height = Math.max(known.height, Number(size.height) || 0);
        known.natural = known.natural || Boolean(size.natural);
      }
    }
    return out;
  }

  /**
   * 从内联 JSON 的图集字段里取图。拼多多的内联数据里每一项常带 width/height，
   * 一并带出去当尺寸依据——这是「按尺寸挑主图」在拼多多唯一靠得住的来源。
   */
  function jsonGallery(model) {
    const urls = [];
    const meta = {};
    const push = (item) => {
      if (item == null) return;
      const raw = typeof item === "string"
        ? item
        : (item.url || item.imgUrl || item.image || item.src || item.hdUrl || item.hdThumbUrl);
      const url = normalizeImageUrl(raw, ORIGIN);
      if (!url) return;
      if (typeof item === "object") {
        const width = Number(item.width || item.w) || 0;
        const height = Number(item.height || item.h) || 0;
        if (width > 0 && height > 0) meta[url] = { width, height };
      }
      if (!urls.includes(url)) urls.push(url);
    };
    for (const source of [
      model?.detailGallery, model?.topGallery, model?.gallery, model?.thumbnails,
      model?.goodsGallery, model?.images, model?.carousel, model?.mainImages,
      model?.detailPics, model?.detailImgs,
    ]) {
      if (!Array.isArray(source)) continue;
      for (const item of source) push(item);
    }
    for (const single of [model?.hdThumbUrl, model?.hdUrl, model?.thumbUrl, model?.mainImage]) {
      if (typeof single === "string") push(single);
    }
    return { urls, meta };
  }

  const IMAGE_PICK_BASE = { origin: ORIGIN, excludeZones: IMAGE_EXCLUDE_ZONES, noPageFallback: true };

  /** 主图 + 图集：内联 JSON 优先，再 aria-label/大图容器，最后整块图集兜底 */
  function pickImages(model, cache) {
    const json = jsonGallery(model);
    for (const block of cache.jsonLd()) {
      const list = block.image ? (Array.isArray(block.image) ? block.image : [block.image]) : [];
      for (const item of list) {
        const url = normalizeImageUrl(typeof item === "string" ? item : item?.url, ORIGIN);
        if (url && !json.urls.includes(url)) json.urls.push(url);
      }
    }
    const main = U.collectImages({
      ...IMAGE_PICK_BASE,
      containers: GALLERY_MAIN_SELECTORS,
      extra: json.urls,
      extraMeta: json.meta,
      extraFirst: true,     // 内联 JSON 的图最干净，排前面才能当 images[0]
      limit: GALLERY_IMAGE_LIMIT,
    });
    const thumbs = U.collectImages({ ...IMAGE_PICK_BASE, containers: GALLERY_THUMB_SELECTORS, allowSmall: true });
    let fallback = { images: [], imageMeta: {} };
    if (!main.images.length && !thumbs.images.length) {
      // 兜底时才开 background-image：拼多多偶尔把轮播图铺在背景上
      fallback = U.collectImages({
        ...IMAGE_PICK_BASE,
        containers: GALLERY_FALLBACK_SELECTORS,
        includeBackground: true,
        // v1.9.67 关键修复：兜底层必须允许小图。轮播只有 60×60 缩略图 <img> 时
        // （主图位是 <video> 或懒加载未触发），不带 allowSmall 会被「最长边 < 120px
        // 当图标丢掉」的规则整批误杀，表现就是「未识别到产品图」。
        allowSmall: true,
      });
    }

    // 逐 URL 取最大尺寸：旧写法 Object.assign 会让后写入的小尺寸覆盖先写入的大尺寸
    const imageMeta = mergeImageMeta(fallback.imageMeta, thumbs.imageMeta, main.imageMeta);
    const ordered = dedupe([].concat(main.images, thumbs.images, fallback.images)).slice(0, GALLERY_IMAGE_LIMIT);
    for (const url of ordered) if (!imageMeta[url]) imageMeta[url] = { width: 0, height: 0 };
    // 主图排到第一位，其余保持采集顺序
    const mainImage = pickMainImage(ordered, imageMeta);
    const images = mainImage ? [mainImage].concat(ordered.filter((url) => url !== mainImage)) : ordered;
    return {
      images,
      imageMeta,
      mainImage,
      // 每层各捞到多少张：采集结果的备注里会写出来，页面再改版时一眼能看出是哪一层失灵
      layers: {
        main: main.images.length,
        thumbs: thumbs.images.length,
        fallback: fallback.images.length,
        host: 0,
      },
    };
  }

  /**
   * 商品详情长图：详情描述区里的图，单独一组，用户确认后才并入图片集。
   * exclude 传图集已有的地址——详情区第一张往往就是轮播主图的封面，重复的没必要再勾一遍。
   */
  function pickDetailImages(exclude = []) {
    const skip = new Set((exclude || []).map((url) => normalizeImageUrl(url, ORIGIN)).filter(Boolean));
    const picked = U.collectImages({
      origin: ORIGIN,
      containers: DETAIL_IMAGE_SELECTORS,
      allowSmall: true,        // 详情长图基本都是懒加载，没有 naturalWidth
      includeBackground: true, // 详情区常把长图铺在 background-image 上
      excludeZones: IMAGE_EXCLUDE_ZONES,
      noPageFallback: true,
      limit: DETAIL_IMAGE_LIMIT,
    });
    return picked.images.filter((url) => !skip.has(url));
  }

  /**
   * 懒加载「轻扫」：不滚到那个位置，<img> 的地址根本不会写进 DOM。
   * 记住当前滚动位置 → 逐段下滚并派发 scroll → 回到原位。失败也不抛错。
   * （与 adapter-1688.js / adapter-taobao.js 的同名函数保持一致；顺手把 loading="lazy"
   *   的图强制成 eager，滚过去一次就让浏览器真开始加载，采集完不还原。）
   */
  async function sweepForLazyImages(steps = 6, stepDelay = 140) {
    const scroller = document.scrollingElement || document.documentElement;
    if (!scroller) return;
    const startY = scroller.scrollTop;
    const total = Math.max(scroller.scrollHeight - (window.innerHeight || 0), 0);
    try {
      for (let index = 1; index <= steps; index += 1) {
        scroller.scrollTop = Math.round((total * index) / steps);
        window.dispatchEvent(new Event("scroll"));
        document.dispatchEvent(new Event("scroll"));
        // eslint-disable-next-line no-await-in-loop
        await sleep(stepDelay);
      }
      for (const img of all("img[loading='lazy']")) {
        if (img.getAttribute("loading") === "lazy") img.setAttribute("loading", "eager");
      }
    } catch {
      /* 滚动失败就当没扫过，后面的采集照旧 */
    } finally {
      scroller.scrollTop = startY;
      window.dispatchEvent(new Event("scroll"));
    }
  }

  function pickSkus(model) {
    const raw = model?.skus || model?.skuList || model?.goodsProperties || [];
    const list = Array.isArray(raw) ? raw : [];
    const out = [];
    list.forEach((entry, index) => {
      if (!entry || typeof entry !== "object") return;
      const specs = {};
      const specSource = entry.specs || entry.spec || entry.properties || [];
      if (Array.isArray(specSource)) {
        for (const item of specSource) {
          const name = cleanText(item.spec_key || item.key || item.name || item.attrName);
          const value = cleanText(item.spec_value || item.value || item.attrValue);
          if (name && value) specs[name] = value;
        }
      } else if (specSource && typeof specSource === "object") {
        for (const [key, value] of Object.entries(specSource)) specs[cleanText(key)] = cleanText(value);
      }
      const stockRaw = entry.quantity ?? entry.stock ?? entry.availableStock;
      const stock = parseNumber(stockRaw);
      out.push({
        id: cleanText(entry.skuId || entry.sku_id || entry.id || `sku_${index}`),
        specs,
        price: parseNumber(entry.price ?? entry.normalPrice ?? entry.groupPrice) / 100,
        stock,
        // 内联数据显式给了 0 库存 → 售罄/不可选组合，面板默认不勾选
        ...(stockRaw != null && stock === 0 ? { unavailable: true, unavailableReason: "页面数据显示该规格已售罄（库存 0）" } : {}),
        image: normalizeImageUrl(entry.thumbUrl || entry.image || entry.img, ORIGIN),
        label: Object.values(specs).join(" / "),
      });
    });
    return U.dedupeSkus(out);
  }

  function pickSpecOptions(skus) {
    const map = {};
    for (const sku of skus) {
      for (const [name, value] of Object.entries(sku.specs || {})) {
        if (!map[name]) map[name] = [];
        if (!map[name].includes(value)) map[name].push(value);
      }
    }
    return Object.entries(map).map(([name, values]) => ({ name, values }));
  }

  function pickAttributes(model) {
    const out = [];
    const props = model?.goodsProperty || model?.properties || model?.attrs || [];
    const list = Array.isArray(props) ? props : [];
    for (const item of list) {
      const name = cleanText(item.name || item.key || item.attrName || item.pname);
      const value = cleanText(item.value || item.val || item.attrValue || item.vname);
      if (name && value) out.push({ name, value });
    }
    if (!out.length) out.push(...U.extractAttributePairs(["[class*=attr]", "[class*=spec]"]));
    return U.dedupeAttributes(out);
  }

  const adapter = registry.createAdapter({
    platform: "pdd",
    label: "拼多多",
    matchHosts: ["yangkeduo.com", "pinduoduo.com"],
    async capture() {
      const cache = U.createPageCache();
      const notes = [];
      const startedAt = Date.now();
      // 拼多多的商品数据在内联 JSON 里，通常首屏就有；只在确实拿不到时才等一下
      let model = digModel(await cache.time("读取内联数据", () => Promise.resolve(pickDataModel(cache))));
      if (!model) {
        await cache.time("等待页面就绪", () => U.waitForImages(["[class*=gallery] img", "[class*=thumb] img"], { timeout: 700 }));
        cache.reset();
        model = digModel(pickDataModel(cache));
      }
      if (!model) notes.push("未解析到页面内联商品数据，已回退到 DOM 抓取，字段可能不完整");

      const skus = await cache.time("SKU", () => Promise.resolve(pickSkus(model)));
      if (!skus.length) notes.push("未识别到 SKU 规格矩阵，可在「SKU 与成本」里按规格维度手动补齐");
      const price = await cache.time("价格", () => Promise.resolve(pickPrice(model, cache)));
      let picked = await cache.time("图片", () => Promise.resolve(pickImages(model, cache)));
      // 拼多多移动端几乎全站懒加载：首屏常常只挂出 1~2 张（其余全是占位图）。
      // 只在「图明显偏少」时才轻扫一遍，避免每次采集都白等 800ms。
      let swept = false;
      if (picked.images.length < 4) {
        await cache.time("图片懒加载", () => sweepForLazyImages());
        cache.reset();
        picked = pickImages(model, cache);
        swept = true;
      }
      const images = picked.images;
      let detailImages = await cache.time("详情长图", () => Promise.resolve(pickDetailImages(images)));
      if (!detailImages.length && !swept) {
        await cache.time("详情长图懒加载", () => sweepForLazyImages());
        cache.reset();
        detailImages = pickDetailImages(images);
      }

      const videos = dedupe(
        all("video[src], source[src]")
          .map((node) => node.getAttribute("src"))
          .filter((value) => /^https?:/i.test(value || "")),
      );
      if (!images.length) {
        const l = picked.layers || {};
        notes.push(`未识别到产品图（轮播位 ${l.main || 0} / 缩略图位 ${l.thumbs || 0} / 图集兜底 ${l.fallback || 0}），页面结构可能又改版了，请把这条备注发给开发者`);
      }
      const salesText = cleanText(model?.salesTip || model?.soldQuantity || "");
      if (price.max > price.min) {
        notes.push(`识别到区间价 ¥${price.min}~${price.max}，定价时请确认用哪一档作为成本`);
      }
      if (images.length === 1) notes.push("只识别到 1 张产品图，建议人工确认是否漏图");
      if (videos.length) notes.push("该商品带主图视频：轮播首图有可能是视频封面，请在「④ 图片」确认主图是实拍商品图");
      if (detailImages.length) notes.push(`识别到 ${detailImages.length} 张详情长图，可在「④ 图片」确认后并入图片集`);

      const title = pickTitle(model);
      if (!title) {
        notes.push("没能从页面取到商品标题（页面上的候选标题都是店铺名 / 公司名）。请在「商品词 / 品类」手动填写品类后再生成文案");
      }

      return {
        platform: "pdd",
        sourceUrl: location.href,
        title,
        shopName: cleanText(model?.mallName || model?.mall?.name || model?.mallNameAbbr || text("[class*=mall-name]")),
        shopUrl: "",
        price: { min: price.min, max: price.max, currency: "CNY", raw: price.raw },
        salesText,
        sales: parseNumber(salesText) || parseNumber(model?.soldQuantity),
        stock: parseNumber(model?.stock ?? model?.quantity),
        mainImage: picked.mainImage || images[0] || "",
        images,
        detailImages,
        imageMeta: picked.imageMeta,
        videos,
        specOptions: pickSpecOptions(skus),
        skus,
        attributes: pickAttributes(model),
        logistics: {
          // v1.9.69：发货地只在**商品主体区**里找，避免命中推荐位里别的商品的产地
          from: cleanText(model?.deliveryInfo || cache.scopeText().match(/(?:发货|产地)[^\n]{0,20}/)?.[0] || ""),
          freightText: cleanText(model?.freightText || ""),
          express: "",
        },
        description: cleanText(U.meta("og:description") || (model?.goodsDesc || "")).slice(0, 3000),
        timings: { ...cache.timing, total: Date.now() - startedAt },
        diagnostics: { notes: notes.concat(this.takeNotes()) },
      };
    },
  });

  registry.adapters.push(adapter);
})(window);
