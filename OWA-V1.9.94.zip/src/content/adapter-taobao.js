/**
 * 淘宝 / 天猫商品详情采集适配器。
 *
 * v1.9.48 重构要点（超哥反馈「SKU 采集不准」）：
 *  1. **SKU 按「分类」采集**：优先读内联的 skuBase / skuCore —— 那是卖家后台配的真规格
 *     （维度名、维度值、每个值的色卡图、每个 SKU 的 propPath 组合、价格、库存），
 *     比扫 DOM 准得多。而且内联 JSON 不会被浏览器翻译改写，页面被翻成外文时也能拿到原始中文。
 *  2. DOM 兜底时**只在 SKU 选择区容器里找规格**，并排掉「分期付款 / 月供 / 数量 / 优惠」这类
 *     非规格块 —— 老实现满页找「标题 + 若干短选项」，于是把分期月供（15 期 / 20 期）当成了规格维度。
 *  3. 图片分三组抓：主图+图集 / 规格色卡图（产品分类图）/ 详情长图，互不污染。
 *  4. 详情长图是懒加载的，采集前做一次「轻扫」（滚到底再回原位）把图逼出来。
 *
 * 站点 DOM 类名高度动态且常有登录墙，这里以"多候选选择器 + 内联数据"兜底，
 * 读不到的字段留空并写诊断，不猜测填充。
 */
(function (global) {
  "use strict";

  const registry = global.__OZON_ADAPTERS__;
  if (!registry) return;
  const U = registry.utils;
  const { cleanText, parseNumber, normalizeImageUrl, dedupe, all, text } = U;

  const ORIGIN = location.origin;

  function isTmall() {
    return /tmall\.com/i.test(location.hostname);
  }

  function pickTitle(cache) {
    // v1.9.69：**权威标题优先**。og:title / document.title 一定属于当前这件商品；
    // 旧顺序是先跑 DOM 选择器（含通用 "h1"），命中的可能是推荐位里**另一件商品**的标题，
    // 于是「采 A 得到 B 的标题」。
    const authoritative = U.authoritativeTitle();
    if (authoritative) return authoritative;

    // 权威标题拿不到时才退回 DOM 选择器，且命中必须落在**商品主体区**内
    const scope = cache && cache.scope ? cache.scope() : null;
    const inScope = (node) => !scope
      || scope === document.body
      || scope === document.documentElement
      || scope === node
      || Boolean(scope.contains && scope.contains(node));
    const candidates = isTmall()
      ? [".tb-detail-hd h1", "[class*=ItemHeader] [class*=mainTitle]", "h1", "[class*=title] h1"]
      : [".tb-main-title", "[class*=ItemTitle] [class*=mainTitle]", "h1", "#J_Title h3"];
    for (const selector of candidates) {
      for (const node of all(selector)) {
        if (!inScope(node)) continue;
        const value = cleanText(node.textContent);
        if (value && value.length > 3) {
          const cleaned = U.sanitizeTitle(value) || value;
          // v1.9.63：命中店铺名就跳过，继续找下一个候选（见 adapter-base 的 looksLikeShopName）
          if (!U.looksLikeShopName(cleaned)) return cleaned;
        }
      }
    }
    // 整个标题退化成一个店铺名时宁可不给——发给 AI 只会换来「未知商品」
    return "";
  }

  function pickPrice(cache) {
    // 兜底顺序：JSON-LD → meta → 已知选择器 → 类名带 price 的元素 → 全页第一个 ¥ 数字
    const picked = U.pickPagePrice({
      cache,
      selectors: [
        ".tb-rmb-num",
        "[class*=highlightPrice] [class*=text]",
        ".tm-price",
        ".tm-promo-price .tm-price",
        "#J_StrPrice .tb-rmb-num",
        "[class*=price] [class*=rmb]",
        "[class*=priceText]",
        "[class*=mainPrice]",
        "[class*=skuPrice]",
        ".sale-price",
        ".main-price",
      ],
    });
    return picked.min > 0 ? picked : { min: 0, max: 0, raw: "" };
  }

  /* ------------------------------------------------------------------
   * 图片采集：主图 / 图集缩略图 / 规格色卡图 / 详情长图 分开抓。
   * 老实现把十来个 gallery/thumb 选择器一股脑塞给 collectImages，容器一个没命中
   * 就退回全页扫描，把推荐位、店铺卡片、图标全收进来。
   * ------------------------------------------------------------------ */

  // 推荐位 / 猜你喜欢 / 店铺卡片里的图不是本商品图，必须排除。
  // v1.9.62 补评价区：淘宝/天猫的「累计评价」模块里也是一排 <img>，
  // 缩略图选择器（[class*=thumbnails] / [class*=picList]）会连买家秀一起命中，
  // 于是买家实拍混进图集、甚至被尺寸规则判成产品图抢走主图位。
  const IMAGE_EXCLUDE_ZONES = [
    "[class*=recommend]",
    "[class*=Recommend]",
    "[class*=similar]",
    "[class*=Similar]",
    "[class*=related]",
    "[class*=guess]",
    "[class*=mayLike]",
    "[class*=may-like]",
    "[class*=shopCard]",
    "[class*=shop-card]",
    "[class*=shopInfo]",
    "[class*=sellerInfo]",
    "[class*=review]",
    "[class*=Review]",
    "[class*=comment]",
    "[class*=Comment]",
    "[class*=评价]",
    "[class*=appraise]",
    "[class*=rate-]",
    "[class*=Rate]",
    "[class*=tm-rate]",
    "[class*=tb-rate]",
    "[class*=footer]",
    "[class*=breadcrumb]",
  ];

  // 主图：图集里当前展示的大图
  const GALLERY_MAIN_SELECTORS = [
    "#J_ImgBooth",
    ".tb-gallery .tb-booth img",
    ".tb-pic .tb-booth img",
    "[class*=PicGallery] [class*=mainImg] img",
    "[class*=imagesView] [class*=mainImg] img",
    "[class*=gallery] [class*=mainImg] img",
    "[class*=gallery] [class*=main-image] img",
    "[class*=mainPic] img",
    "[class*=MainPic] img",
    "[class*=bigPic] img",
  ];

  // 缩略图列表：主图下面那排小图，代表完整图集
  const GALLERY_THUMB_SELECTORS = [
    "#J_UlThumb img",
    "[class*=thumbnails] img",
    "[class*=Thumbnails] img",
    "[class*=thumbnail] img",
    "[class*=thumbList] img",
    "[class*=thumb-list] img",
    "[class*=picList] img",
    "[class*=PicList] img",
    "[class*=imagesView] [class*=thumb] img",
  ];

  // 兜底：主图/缩略图选择器都没命中（改版）时才用的整块图集容器
  const GALLERY_FALLBACK_SELECTORS = [
    "#J_UlThumb",
    "[class*=imagesView]",
    "[class*=PicGallery]",
    ".tb-gallery",
    "[class*=gallery]",
  ];

  // 商品详情长图所在容器（淘宝/天猫新旧版都有好几套类名）
  const DETAIL_IMAGE_SELECTORS = [
    "#J_DivItemDesc",
    "#description",
    "[class*=descV8]",
    "[class*=desc-v8]",
    "[class*=DetailDesc]",
    "[class*=detailDesc]",
    "[class*=itemDesc]",
    "[class*=item-desc]",
    "[class*=descContent]",
    "[class*=desc-content]",
    "[class*=detailContent]",
    "[class*=detail-content]",
    "[class*=richText]",
    "[class*=rich-text]",
    "[class*=description]",
  ];

  const DETAIL_IMAGE_LIMIT = 60;

  /** 图片面积：挑主图时用它排序 */
  function imageAreaScore(meta) {
    const width = Number(meta && meta.width) || 0;
    const height = Number(meta && meta.height) || 0;
    return width * height;
  }

  /**
   * 挑主图：主图通常是图集里尺寸最大且接近正方形的那张（800x800 / 1000x1000），
   * 详情长图那种细长条会被降权。没有任何尺寸信息时退回第一张（保持卖家排序）。
   * v1.9.60：渲染尺寸（natural=false）打 25% 折，避免页面上被拉大的缩略图抢走主图位。
   */
  function pickMainImage(images = [], imageMeta = {}) {
    const list = Array.isArray(images) ? images : [];
    if (!list.length) return "";
    let best = list[0];
    let bestScore = -1;
    let squarePicked = "";
    let squareArea = -1;
    for (const url of list) {
      const meta = imageMeta[url] || {};
      const width = Number(meta.width) || 0;
      const height = Number(meta.height) || 0;
      if (!width || !height) continue;
      const trusted = meta.natural === false ? 0.25 : 1;
      const area = imageAreaScore(meta);
      const squareness = Math.min(width, height) / Math.max(width, height);
      if (squareness >= 0.7 && trusted === 1 && area > squareArea) {
        squareArea = area;
        squarePicked = url;
      }
      const score = area * (squareness >= 0.7 ? 1 : squareness) * trusted;
      if (score > bestScore) {
        bestScore = score;
        best = url;
      }
    }
    return squarePicked || best;
  }

  /** 合并多个来源的尺寸元数据：同一 URL 取各来源里的最大尺寸与 natural 标记 */
  function mergeImageMeta(...metas) {
    const out = {};
    for (const meta of metas) {
      for (const [url, size] of Object.entries(meta || {})) {
        const known = out[url];
        if (!known) {
          out[url] = { width: Number(size.width) || 0, height: Number(size.height) || 0, natural: Boolean(size.natural) };
          continue;
        }
        known.width = Math.max(known.width, Number(size.width) || 0);
        known.height = Math.max(known.height, Number(size.height) || 0);
        known.natural = known.natural || Boolean(size.natural);
      }
    }
    return out;
  }

  function jsonLdImages(cache) {
    const out = [];
    for (const block of cache.jsonLd()) {
      if (!block.image) continue;
      const list = Array.isArray(block.image) ? block.image : [block.image];
      for (const item of list) out.push(typeof item === "string" ? item : item.url);
    }
    return out;
  }

  // v1.9.67：阿里系商品图都挂在固定图床路径下（1688 是 /img/ibank/，淘宝是 /imgextra/）。
  // 这是比类名、比尺寸都可靠的「这是商品图」信号，用来做选择器全部落空时的最后兜底。
  const ALI_GALLERY_IMAGE_RE = /^https?:\/\/[^/]*(?:alicdn|alibaba|1688|taobaocdn|tbcdn)\.com\/(?:img\/ibank|imgextra)\//i;

  const IMAGE_PICK_BASE = { origin: ORIGIN, excludeZones: IMAGE_EXCLUDE_ZONES, noPageFallback: true };

  // 图集最多收多少张：淘宝图集通常 5~15 张，多出来的基本是漏网的推荐位/评价图
  const GALLERY_IMAGE_LIMIT = 30;

  /** 主图 + 图集：先大图容器，再缩略图列表，都空了才用整块图集兜底 */
  function pickImages(cache) {
    const fromJsonLd = jsonLdImages(cache);
    // v1.9.62 extraFirst：JSON-LD 的图最干净（不含图标、不含推荐位），排到 DOM 图前面，
    // 这样「其余图片」的顺序也贴近结构化数据里的卖家排序，而不是页面 DOM 的偶然顺序。
    const main = U.collectImages({
      ...IMAGE_PICK_BASE,
      containers: GALLERY_MAIN_SELECTORS,
      extra: fromJsonLd,
      extraFirst: true,
      limit: GALLERY_IMAGE_LIMIT,
    });
    const thumbs = U.collectImages({ ...IMAGE_PICK_BASE, containers: GALLERY_THUMB_SELECTORS, allowSmall: true });
    let fallback = { images: [], imageMeta: {} };
    if (!main.images.length && !thumbs.images.length) {
      fallback = U.collectImages({
        origin: ORIGIN,
        excludeZones: IMAGE_EXCLUDE_ZONES,
        containers: GALLERY_FALLBACK_SELECTORS,
        // v1.9.67 关键修复：兜底层必须允许小图。图集只有 60×60 缩略图 <img> 时
        // （主图位是 <video> 或懒加载未触发），不带 allowSmall 会被「最长边 < 120px
        // 当图标丢掉」的规则整批误杀，表现就是「未识别到产品图」。
        allowSmall: true,
      });
    }

    // 逐 URL 取最大尺寸：旧写法 Object.assign 会让后写入的小尺寸覆盖先写入的大尺寸
    // v1.9.67 最后一道网：按阿里图床路径 + 文档顺序捞，类名整批换掉也不怕，且不做尺寸过滤
    let hostPicked = { images: [], imageMeta: {} };
    if (!main.images.length && !thumbs.images.length && !fallback.images.length) {
      hostPicked = U.collectImagesByHostPattern({
        pattern: ALI_GALLERY_IMAGE_RE,
        stopSelector: DETAIL_IMAGE_SELECTORS.join(", "),
        excludeZones: IMAGE_EXCLUDE_ZONES,
        origin: ORIGIN,
        limit: GALLERY_IMAGE_LIMIT,
      });
    }

    const imageMeta = mergeImageMeta(fallback.imageMeta, thumbs.imageMeta, main.imageMeta, hostPicked.imageMeta);
    const ordered = dedupe([].concat(main.images, thumbs.images, fallback.images, hostPicked.images)).slice(0, GALLERY_IMAGE_LIMIT);
    for (const url of ordered) if (!imageMeta[url]) imageMeta[url] = { width: 0, height: 0 };
    // 主图排到第一位，其余保持采集顺序
    const mainImage = pickMainImage(ordered, imageMeta);
    const images = mainImage ? [mainImage].concat(ordered.filter((url) => url !== mainImage)) : ordered;
    return {
      images,
      imageMeta,
      mainImage,
      // 每层各捞到多少张：采集结果的备注里会写出来，页面再改版时一眼能看出是哪一层失灵
      layers: {
        main: main.images.length,
        thumbs: thumbs.images.length,
        fallback: fallback.images.length,
        host: hostPicked.images.length,
      },
    };
  }

  /**
   * 商品详情长图：详情描述区里的图，单独一组，用户确认后才并入图片集。
   * exclude 传图集已有的地址——详情区第一张往往就是主图封面，重复的没必要再勾一遍。
   */
  function pickDetailImages(exclude = []) {
    const skip = new Set((exclude || []).map((url) => normalizeImageUrl(url, ORIGIN)).filter(Boolean));
    const picked = U.collectImages({
      origin: ORIGIN,
      containers: DETAIL_IMAGE_SELECTORS,
      allowSmall: true,        // 详情长图基本都是懒加载，没有 naturalWidth
      includeBackground: true, // 详情区常把长图铺在 background-image 上
      excludeZones: IMAGE_EXCLUDE_ZONES,
      noPageFallback: true,
      limit: DETAIL_IMAGE_LIMIT,
    });
    return picked.images.filter((url) => !skip.has(url));
  }

  /**
   * 详情长图懒加载「轻扫」：不滚到那个位置，<img> 的地址根本不会写进 DOM。
   * 记住当前滚动位置 → 逐段下滚并派发 scroll → 回到原位。失败也不抛错。
   */
  async function sweepForLazyImages(steps = 6, stepDelay = 140) {
    const scroller = document.scrollingElement || document.documentElement;
    if (!scroller) return;
    const startY = scroller.scrollTop;
    const total = Math.max(scroller.scrollHeight - (window.innerHeight || 0), 0);
    try {
      for (let index = 1; index <= steps; index += 1) {
        scroller.scrollTop = Math.round((total * index) / steps);
        window.dispatchEvent(new Event("scroll"));
        document.dispatchEvent(new Event("scroll"));
        // eslint-disable-next-line no-await-in-loop
        await U.sleep(stepDelay);
      }
      // 原生懒加载（loading="lazy"）的图滚过去未必已触发：强制成 eager，让浏览器真去加载，
      // 采集到的地址可用性更高（Ozon 回源 / 面板预览 / 翻译都依赖这张图真的可达）
      for (const img of all("img[loading='lazy']")) {
        if (img.getAttribute("loading") === "lazy") img.setAttribute("loading", "eager");
      }
    } catch {
      /* 滚动失败就当没扫过，后面的采集照旧 */
    } finally {
      scroller.scrollTop = startY;
      window.dispatchEvent(new Event("scroll"));
    }
  }

  /**
   * 规格色卡 / SKU 缩略图：优先取 img 的懒加载属性，取不到再看选项节点的背景图
   * （淘宝/天猫新版颜色色卡常把图放在 background-image 里，只读 src 会抓空）。
   */
  function nodeImageUrl(node, img) {
    const fromImg = img ? U.imageSource(img) : "";
    if (fromImg) return fromImg;
    const style = node && node.getAttribute ? node.getAttribute("style") : "";
    if (style && /url\(/i.test(style)) {
      const match = /url\((['"]?)([^'")]+)\1\)/i.exec(style);
      if (match) return normalizeImageUrl(match[2], ORIGIN);
    }
    return "";
  }

  /* ------------------------------------------------------------------
   * SKU 采集（按分类）
   * ------------------------------------------------------------------ */

  // 分期付款 / 月供 / 数量 / 优惠券 这类块不是「规格」，出现在 SKU 区里也必须排掉
  const SPEC_NAME_NOISE_PATTERN =
    /(数量|购买数量|送货|送至|配送|服务|保障|运费|快递|包邮|优惠|活动|促销|分期|花呗|月供|免息|白条|推荐|猜你|评价|排行|参数|以旧换新|保障服务|服务保障)/;

  // 规格值里混进来的价格 / 库存 / 运费 / 期数 / 月供片段不是规格值
  // 其中 `^\d+\s*[+＋]?[\s/]*(?:期|个月|月|месяц)` 专门拦「15期」「15+/месяц」这类分期月供文案
  // （斜杠那一段是必须的：页面上分期常写成「15+/月」，被翻译后又变成「15+/месяц」）
  const SPEC_VALUE_NOISE_PATTERN =
    /[¥￥]|库存|可售|起批|快递|运费|包邮|月销|已售|分期|月供|免息|花呗|白条|^\d+\s*[+＋]?[\s/]*(?:期|个月|月|месяц)|^(?:г|кг|шт)$/i;

  // 页面文字被浏览器翻译过时，规格名/值会变成外文（曾采集到俄文的「Объём / месяц」）
  const CYRILLIC_PATTERN = /[\u0400-\u04FF]/;

  function isNoiseSpecValue(value) {
    const flat = cleanText(value);
    if (!flat) return true;
    return SPEC_VALUE_NOISE_PATTERN.test(flat);
  }

  // 规格值选项上的「不可选」信号：禁用类名（pro-disabled / disabled）、aria-disabled、
  // 划线售罄文字。淘宝色卡把售罄款置灰，选中它上架就是缺货变体，采集时标出来。
  const SPEC_DISABLED_PATTERN = /disabled|sold.?out|cannot|unselect|nostock|out.?of|无货|缺货|售罄|已售完|置灰/i;

  function isDisabledSpecOption(item, label) {
    if (!item) return false;
    const classes = typeof item.className === "string" ? item.className : "";
    if (SPEC_DISABLED_PATTERN.test(classes)) return true;
    if (item.getAttribute && (item.getAttribute("aria-disabled") === "true" || item.hasAttribute("disabled"))) return true;
    if (label && SPEC_DISABLED_PATTERN.test(String(label))) return true;
    return false;
  }

  // SKU 选择区容器：DOM 兜底时只在这里面找规格
  const SKU_CONTAINER_SELECTORS = [
    "[class*=SkuContent]",
    "[class*=skuContent]",
    "[class*=sku-content]",
    "[class*=SkuWrapper]",
    "[class*=skuWrapper]",
    "[class*=sku-wrapper]",
    "[class*=SkuPanel]",
    "[class*=skuPanel]",
    "[class*=sku-panel]",
    "[class*=skuItemWrap]",
    "#J_Sku",
    ".tb-sku",
    ".tb-sku-panel",
    "[class*=DetailMeta]",
    "[class*=detailMeta]",
  ];

  // 规格分组：一个维度一块
  const SPEC_GROUP_SELECTORS = [
    "[class*=skuProp]",
    "[class*=sku-prop]",
    "[class*=SkuProp]",
    "[class*=propItem]",
    "[class*=prop-item]",
    "[class*=PropItem]",
    "[class*=skuItem]",
    "[class*=SkuItem]",
    ".tb-prop",
    ".tb-sku-item",
    "dl",
  ];

  const SPEC_NAME_SELECTORS =
    "[class*=propTitle], [class*=prop-title], [class*=PropTitle], [class*=skuName], [class*=sku-name], [class*=PropName], .tb-prop-title, dt, [class*=name]";

  const SPEC_VALUE_SELECTORS =
    "[class*=valueItem], [class*=ValueItem], [class*=value-item], [class*=propValue], [class*=prop-value], li, a, button, dd";

  function mergeSpecOptions(groups) {
    const byName = new Map();
    for (const group of groups) {
      const name = cleanText(group.name);
      if (!name) continue;
      const existing = byName.get(name);
      if (existing) existing.values = dedupe(existing.values.concat(group.values)).slice(0, 40);
      else byName.set(name, { name, values: dedupe(group.values).slice(0, 40) });
    }
    return Array.from(byName.values()).filter((option) => option.values.length);
  }

  /**
   * 收集规格维度（颜色分类 / 尺码 / 容量…），同时收集每个规格值对应的色卡图。
   * 只在 SKU 选择区容器里找分组，并把分期/月供/数量等噪音块排掉。
   * 返回 { options, images, disabled }，images 是「维度名:值」→ 图片地址 的映射，
   * disabled 是「维度名:值」→ 置灰/售罄 的集合。
   */
  function pickSpecOptions() {
    const containers = [];
    for (const selector of SKU_CONTAINER_SELECTORS) {
      for (const node of all(selector)) if (!containers.includes(node)) containers.push(node);
    }
    const scopes = containers.length ? containers : [document];

    const groups = [];
    for (const root of scopes) {
      const found = [];
      for (const selector of SPEC_GROUP_SELECTORS) {
        for (const node of all(selector, root)) if (!found.includes(node)) found.push(node);
      }
      if (found.length) {
        groups.push(...found);
        break; // 第一个有货的容器就够了，别把推荐位/详情区也扫进来
      }
    }

    const out = [];
    const images = {};
    const disabled = {};
    for (const group of groups) {
      // 大容器（整块详情 / 参数区）不是规格分组：规格块里全是短词，整块文本很短
      if (cleanText(group.textContent || "").length > 2000) continue;
      const nameNode = group.querySelector(SPEC_NAME_SELECTORS);
      const name = cleanText(nameNode ? nameNode.textContent : "");
      if (!name || name.length > 12 || SPEC_NAME_NOISE_PATTERN.test(name)) continue;
      const values = [];
      for (const item of all(SPEC_VALUE_SELECTORS, group)) {
        const classes = typeof item.className === "string" ? item.className : "";
        // 维度名节点本身不算规格值（它有图时例外，色卡标题常带图）
        if (/propTitle|prop-title|PropTitle|skuName|sku-name|propName|prop-name/i.test(classes) && !item.querySelector("img")) continue;
        const img = item.querySelector("img");
        let label = cleanText(item.getAttribute("title") || item.getAttribute("data-value") || item.textContent);
        if (!label && img) label = cleanText(img.getAttribute("alt") || img.getAttribute("title"));
        if (!label || label.length > 60 || label === name || isNoiseSpecValue(label)) continue;
        if (values.includes(label)) continue;
        values.push(label);
        if (isDisabledSpecOption(item, label)) disabled[`${name}:${label}`] = true;
        const src = nodeImageUrl(item, img);
        if (src) images[`${name}:${label}`] = src;
      }
      if (values.length < 2 || values.length > 40) continue;
      out.push({ name, values });
    }
    if (out.length) return { options: mergeSpecOptions(out), images, disabled };
    return pickSpecOptionsByHeuristic(scopes);
  }

  // 结构兜底：新版详情页类名混淆时，找「规格词标题 + 多个短选项」的结构。
  // 同样只在 SKU 容器里找，避免把详情文案块误判成规格。
  function pickSpecOptionsByHeuristic(scopes = [document]) {
    const LABEL_PATTERN = /^(颜色|颜色分类|规格|尺码|尺寸|型号|款式|容量|材质|套餐|口味|版本|净含量|规格属性|分类)$/;
    const out = [];
    const images = {};
    const disabled = {};
    for (const root of scopes) {
      for (const node of all("div, dl, section, ul", root)) {
        const nameNode = node.querySelector(":scope > dt, :scope > .name, :scope > [class*=title], :scope > [class*=label], :scope > h3, :scope > h4");
        const name = cleanText(nameNode ? nameNode.textContent : "");
        if (!LABEL_PATTERN.test(name)) continue;
        const options = all("li, a, button, dd, [class*=value], [class*=item]", node);
        if (options.length < 2 || options.length > 40) continue;
        const values = [];
        for (const item of options) {
          const label = cleanText(item.getAttribute("title") || item.getAttribute("data-value") || item.textContent);
          if (!label || label.length > 40 || label === name || isNoiseSpecValue(label)) continue;
          if (values.includes(label)) continue;
          values.push(label);
          if (isDisabledSpecOption(item, label)) disabled[`${name}:${label}`] = true;
          const img = item.querySelector("img");
          const src = nodeImageUrl(item, img);
          if (src) images[`${name}:${label}`] = src;
        }
        if (values.length >= 2) out.push({ name, values });
      }
      if (out.length) break;
    }
    return { options: mergeSpecOptions(out), images, disabled };
  }

  /* ---------- 内联数据：skuBase / skuCore（最可靠的一路） ---------- */

  /**
   * 从一段（可能是 JS 源码的）文本里，按 key 取出一个**完整的对象字面量**。
   * 用大括号配平扫描而不是正则：skuBase 里的 props / values / skus 嵌套很深，
   * 任何 `\{[\s\S]*?\}` 的正则都会在第一个内层 `}` 就截断。
   */
  function sliceBalancedObject(content, key, maxLength = 400000) {
    if (!content) return null;
    const at = content.indexOf(`"${key}"`);
    if (at < 0) return null;
    const start = content.indexOf("{", at);
    if (start < 0) return null;
    let depth = 0;
    let inString = false;
    let escaped = false;
    const end = Math.min(content.length, start + maxLength);
    for (let index = start; index < end; index += 1) {
      const char = content[index];
      if (inString) {
        if (escaped) escaped = false;
        else if (char === "\\") escaped = true;
        else if (char === '"') inString = false;
        continue;
      }
      if (char === '"') inString = true;
      else if (char === "{") depth += 1;
      else if (char === "}") {
        depth -= 1;
        if (depth === 0) return content.slice(start, index + 1);
      }
    }
    return null;
  }

  /** 内联数据有时是被转义后塞进 JS 字符串的，这里两种都试 */
  function parseLooseJson(raw) {
    if (!raw) return null;
    try {
      return JSON.parse(raw);
    } catch {
      /* 继续试转义版 */
    }
    try {
      return JSON.parse(raw.replace(/\\(["\\])/g, "$1"));
    } catch {
      return null;
    }
  }

  /**
   * 读卖家后台配的真实 SKU 模型：
   *   skuBase.props = [{ pid, name, values: [{ vid, name, image }] }]
   *   skuBase.skus  = [{ skuId, propPath: "pid:vid;pid:vid", quantity }]
   *   skuCore.sku2info[skuId].price = { priceText, price }
   * 返回 { options, images, skus }；没有这块数据时返回 null。
   */
  function readInlineSkuModel(cache) {
    let base = null;
    let core = null;
    for (const source of [cache.scripts(), cache.html()]) {
      if (!base) base = parseLooseJson(sliceBalancedObject(source, "skuBase"));
      if (!core) core = parseLooseJson(sliceBalancedObject(source, "skuCore"));
      if (base && core) break;
    }
    if (!base || !Array.isArray(base.props)) return null;

    const valueIndex = new Map(); // "pid:vid" -> { dimName, valueName, image }
    const options = [];
    const images = {};
    for (const prop of base.props) {
      const dimName = cleanText(prop.name);
      if (!dimName || SPEC_NAME_NOISE_PATTERN.test(dimName)) continue;
      const values = [];
      for (const value of prop.values || []) {
        const valueName = cleanText(value.name);
        if (!valueName || isNoiseSpecValue(valueName)) continue;
        const image = normalizeImageUrl(value.image || value.imageUrl, ORIGIN);
        values.push(valueName);
        valueIndex.set(`${prop.pid}:${value.vid}`, { dimName, valueName, image });
        if (image) images[`${dimName}:${valueName}`] = image;
      }
      if (values.length) options.push({ name: dimName, values: dedupe(values) });
    }

    const info = (core && core.sku2info && typeof core.sku2info === "object") ? core.sku2info : {};
    const skus = [];
    for (const sku of base.skus || []) {
      const skuId = cleanText(sku.skuId);
      const specs = {};
      let swatch = "";
      for (const pair of String(sku.propPath || "").split(";")) {
        const [pid, vid] = pair.split(":");
        const hit = valueIndex.get(`${pid}:${vid}`);
        if (!hit) continue;
        specs[hit.dimName] = hit.valueName;
        if (!swatch && hit.image) swatch = hit.image;
      }
      const detail = info[skuId] || {};
      const priceObj = detail.price && typeof detail.price === "object" ? detail.price : {};
      const quantityRaw = sku.quantity ?? detail.quantity ?? detail.stock;
      const stock = parseNumber(quantityRaw);
      // 内联数据里显式给了 0 库存 → 这是一个「不可选/售罄」组合，标出来，
      // 面板默认不勾选，避免上架一个传上去就缺货的变体
      const soldOut = quantityRaw != null && stock === 0;
      skus.push({
        id: skuId || `sku_${skus.length}`,
        specs,
        price: parseNumber(detail.priceText || priceObj.priceText || priceObj.price || sku.price),
        stock,
        ...(soldOut ? { unavailable: true, unavailableReason: "内联数据显示该组合库存为 0（售罄/不可选）" } : {}),
        image: swatch,
        images: swatch ? [swatch] : [],
        label: Object.values(specs).join(" / "),
      });
    }
    return { options: mergeSpecOptions(options), images, skus: U.dedupeSkus(skus) };
  }

  /** 老路：内联 skuList / skuMap / sku2info / skuCore 片段（取不到 skuBase 时才用） */
  function pickSkusFromData(cache) {
    const data = U.findInlineJson([
      /"skuList"\s*:\s*(\[[\s\S]{0,200000}?\])\s*[,}]/,
      /"skuMap"\s*:\s*(\{[\s\S]{0,200000}?\})\s*[,}]/,
      /"sku2info"\s*:\s*(\{[\s\S]{0,200000}?\})\s*[,}]/,
      /"skuCore"\s*:\s*(\{[\s\S]{0,200000}?\})\s*[,}]/,
    ], null, cache);
    if (!data) return [];
    const entries = Array.isArray(data) ? data : Object.values(data.skuList || data.skuMap || data.sku2info || data);
    const out = [];
    entries.forEach((entry, index) => {
      if (!entry || typeof entry !== "object") return;
      const specs = {};
      const names = entry.names || entry.specs || entry.props || entry.properties || "";
      if (typeof names === "string") {
        for (const chunk of names.split(/[;；]/)) {
          const pair = chunk.split(/[:：]/);
          if (pair.length >= 2) specs[cleanText(pair[0])] = cleanText(pair[1]);
        }
      } else if (Array.isArray(names)) {
        for (const item of names) {
          const n = cleanText(item.name || item.propName);
          const v = cleanText(item.value || item.propValue);
          if (n && v) specs[n] = v;
        }
      } else if (names && typeof names === "object") {
        for (const [key, value] of Object.entries(names)) specs[cleanText(key)] = cleanText(value);
      }
      const priceObj = entry.price || entry.priceUnit || {};
      out.push({
        id: cleanText(entry.skuId || entry.sku || `sku_${index}`),
        specs,
        price: parseNumber(entry.priceText || entry.price || priceObj.priceText || priceObj.promotionPrice),
        stock: parseNumber(entry.quantity || entry.stock || entry.sellableQuantity),
        image: normalizeImageUrl(entry.image || entry.img, ORIGIN),
        label: Object.values(specs).join(" / "),
      });
    });
    return U.dedupeSkus(out);
  }

  /** 给没有图的 SKU 按「维度名:值」挂上色卡图 */
  function attachSpecImages(skus, specImages = {}) {
    let filled = 0;
    for (const sku of skus || []) {
      if (sku.image) continue;
      for (const [name, value] of Object.entries(sku.specs || {})) {
        const hit = specImages[`${name}:${value}`];
        if (hit) {
          sku.image = hit;
          sku.images = [hit];
          filled += 1;
          break;
        }
      }
    }
    return filled;
  }

  /** 按规格维度笛卡尔积生成 SKU（最多 60 个），并挂上色卡图；命中置灰/售罄的组合标成不可选 */
  function buildSkusFromOptions(options, specImages = {}, specDisabled = {}) {
    const dims = (options || []).filter((option) => option.name && option.values.length).slice(0, 2);
    if (!dims.length) return [];
    const combos = [];
    const walk = (index, specs) => {
      if (combos.length >= 60) return;
      if (index === dims.length) {
        combos.push({ ...specs });
        return;
      }
      for (const value of dims[index].values) walk(index + 1, { ...specs, [dims[index].name]: value });
    };
    walk(0, {});
    return combos.map((specs, index) => {
      const image = Object.entries(specs)
        .map(([name, value]) => specImages[`${name}:${value}`])
        .find(Boolean) || "";
      const blocked = Object.entries(specs).find(([name, value]) => specDisabled[`${name}:${value}`]);
      return {
        id: `gen_${index}`,
        specs,
        price: 0,
        stock: 0,
        image,
        images: image ? [image] : [],
        label: Object.values(specs).join(" / "),
        ...(blocked
          ? { unavailable: true, unavailableReason: `规格「${blocked[0]}:${blocked[1]}」在页面上是置灰/售罄状态` }
          : {}),
      };
    });
  }

  function pickSales(cache) {
    const selectors = [".tb-sell-counter", "[class*=soldText]", ".tm-ind-sellCount", "#J_SellCounter"];
    for (const selector of selectors) {
      const value = text(selector);
      if (value) return { text: value, number: parseNumber(value) };
    }
    const hit = cache.scopeText().match(/(?:月销|累计销量|销量)[^\d]{0,10}([\d.,]+\s*[件笔单]?)/);
    if (hit) return { text: hit[0], number: parseNumber(hit[1]) };
    return { text: "", number: 0 };
  }

  function pickShop() {
    const selectors = [
      ".tb-shop-name",
      ".slogo-shopname strong",
      "[class*=shopName] [class*=text]",
      "[class*=ShopName]",
      ".shop-name",
      "#J_ShopInfo .name",
    ];
    for (const selector of selectors) {
      const value = text(selector);
      if (value) return value;
    }
    return "";
  }

  function pickAttributes() {
    const pairs = U.extractAttributePairs(["#J_AttrUL", ".tb-metainfo", "[class*=attributes]", ".tm-attr-list"]);
    if (pairs.length) return U.dedupeAttributes(pairs);
    const out = [];
    const rows = all("#J_AttrUL li, .attributes-list li");
    for (const row of rows) {
      const value = cleanText(row.textContent);
      const match = value.match(/^([^:：]{2,12})[:：](.+)$/);
      if (match) out.push({ name: cleanText(match[1]), value: cleanText(match[2]) });
    }
    return U.dedupeAttributes(out);
  }

  function pickDescription(cache) {
    const rich = document.querySelector("#J_DivItemDesc, [class*=descV8], .tb-detail-desc");
    if (rich) return cleanText(rich.innerText || rich.textContent || "").slice(0, 3000);
    return cleanText(U.meta("og:description") || cache.scopeText()).slice(0, 3000);
  }

  const adapter = registry.createAdapter({
    platform: "taobao",
    label: "淘宝/天猫",
    matchHosts: ["taobao.com", "tmall.com"],
    async capture() {
      const cache = U.createPageCache();
      const notes = [];
      const startedAt = Date.now();
      if (/login|登录/i.test(document.title) && !document.querySelector(".tb-main-title, h1")) {
        notes.push("页面疑似处于登录墙状态，字段可能大量缺失");
      }
      // 先看现有 DOM，没有才等（最多 900ms）
      await cache.time("等待页面就绪", () => U.waitForImages(
        ["#J_UlThumb img", "[class*=imagesView] img", "[class*=thumbnails] img", ".tb-gallery img"],
        { timeout: 900 },
      ));

      // ① SKU：优先内联真数据（skuBase/skuCore），其次 DOM（只在 SKU 容器里找）
      const inline = await cache.time("SKU 内联数据", () => readInlineSkuModel(cache));
      let specOptions = [];
      let specImages = {};
      const specDisabled = {};
      let skus = [];
      if (inline) {
        specOptions = inline.options;
        specImages = inline.images;
        skus = inline.skus;
      }
      if (!specOptions.length || !skus.length) {
        const dom = await cache.time("规格维度", () => pickSpecOptions());
        if (!specOptions.length) specOptions = dom.options;
        for (const [key, value] of Object.entries(dom.images || {})) if (!specImages[key]) specImages[key] = value;
        Object.assign(specDisabled, dom.disabled || {});
      }
      if (!skus.length) skus = await cache.time("SKU 矩阵", () => pickSkusFromData(cache));
      if (!skus.length && specOptions.length) {
        notes.push("未取到 SKU 价格矩阵，已按「规格维度」展开组合，需要人工补价");
        skus = buildSkusFromOptions(specOptions, specImages, specDisabled);
      }
      // 置灰/售罄的规格值：命中的 SKU 标成 unavailable，面板默认不勾选，避免上架缺货变体
      if (Object.keys(specDisabled).length) {
        let marked = 0;
        for (const sku of skus) {
          if (sku.unavailable) continue;
          for (const [name, value] of Object.entries(sku.specs || {})) {
            if (specDisabled[`${name}:${value}`]) {
              sku.unavailable = true;
              sku.unavailableReason = `规格「${name}:${value}」在页面上是置灰/售罄状态`;
              marked += 1;
              break;
            }
          }
        }
        if (marked) notes.push(`${marked} 个 SKU 命中不可选规格（置灰/售罄），默认未勾选，上架前请核对`);
      }
      if (skus.length && specOptions.length) {
        const filled = attachSpecImages(skus, specImages);
        if (filled) notes.push(`已把 ${filled} 个「分类色卡图」挂到对应 SKU 上`);
      }
      if (!skus.length && !specOptions.length) {
        notes.push("未识别到 SKU 规格，可在「SKU 与成本」里手动补规格");
      }
      if (specOptions.some((option) => CYRILLIC_PATTERN.test(option.name) || option.values.some((value) => CYRILLIC_PATTERN.test(value)))) {
        notes.push("规格名/规格值里出现了西里尔字母，页面文字疑似被浏览器翻译过 —— 建议关掉网页翻译后重新采集，否则规格名会是外文");
      }

      // ② 图片：主图+图集 / 色卡图 / 详情长图，分三组
      const picked = await cache.time("图片", () => pickImages(cache));
      const images = picked.images;
      if (!images.length) {
        const l = picked.layers || {};
        notes.push(`未识别到产品图（主图位 ${l.main || 0} / 缩略图位 ${l.thumbs || 0} / 图集兜底 ${l.fallback || 0} / 图床兜底 ${l.host || 0}），页面结构可能又改版了，请把这条备注发给开发者`);
      } else if (picked.layers?.host) {
        notes.push(`图集选择器全部落空，已按阿里图床路径兜底捞到 ${picked.layers.host} 张商品图，请核对`);
      }
      const specImageCount = Object.keys(specImages).length;
      if (specImageCount) {
        notes.push(`另采集到 ${specImageCount} 张「产品分类图」（规格色卡），已挂到对应 SKU 的图片列`);
      }
      // 详情长图是懒加载的：先轻扫一遍把图逼出来，再收
      await cache.time("详情长图懒加载", () => sweepForLazyImages());
      const detailImages = await cache.time("详情长图", () => pickDetailImages(images));
      if (detailImages.length) {
        notes.push(`另采集到 ${detailImages.length} 张商品详情长图，可在「图片 → 商品详情长图」里勾选并入`);
      } else {
        notes.push("未采到详情长图：新版详情页的「图文详情」通常要点开该标签后才会加载，可先点开再重新采集");
      }

      const price = await cache.time("价格", () => pickPrice(cache));
      const sales = await cache.time("销量", () => pickSales(cache));
      // v1.9.69：库存 / 发货地 / 运费都只在**商品主体区**里找 ——
      // 旧实现扫全页，推荐位里另一件商品的「库存 500」「发货地 广东」会被当成本商品的
      const bodyText = cache.scopeText();
      if (price.max > price.min) {
        notes.push(`识别到区间价 ¥${price.min}~¥${price.max}，定价时请确认用哪一档作为成本`);
      }
      if (images.length === 1) notes.push("只识别到 1 张产品图，建议人工确认是否漏图");

      const title = pickTitle(cache);
      if (!title) {
        notes.push("没能从页面取到商品标题（页面上的候选标题都是店铺名 / 公司名）。请在「商品词 / 品类」手动填写品类后再生成文案");
      }

      return {
        platform: "taobao",
        sourceUrl: location.href,
        title,
        shopName: pickShop(),
        shopUrl: (() => {
          const node = document.querySelector(".tb-shop-name a, .slogo-shopname a");
          return node ? node.href : "";
        })(),
        price: { min: price.min, max: price.max, currency: "CNY", raw: price.raw },
        salesText: sales.text,
        sales: sales.number,
        stock: (() => {
          const hit = bodyText.match(/(?:库存)[^\d]{0,10}([\d.,]+)/);
          return hit ? parseNumber(hit[1]) : 0;
        })(),
        mainImage: picked.mainImage || images[0] || "",
        images,
        imageMeta: picked.imageMeta,
        detailImages,
        specImages,
        videos: dedupe(all("video[src], source[src]").map((node) => node.getAttribute("src")).filter((v) => /^https?:/i.test(v || ""))),
        specOptions,
        skus,
        attributes: await cache.time("属性", () => pickAttributes()),
        logistics: {
          from: cleanText((bodyText.match(/(?:发货|所在地)[^\n]{0,20}/) || [""])[0]),
          freightText: cleanText((bodyText.match(/(?:快递|运费)[^\n]{0,30}/) || [""])[0]),
          express: "",
        },
        description: await cache.time("详情", () => pickDescription(cache)),
        timings: { ...cache.timing, total: Date.now() - startedAt },
        diagnostics: { notes: notes.concat(this.takeNotes()) },
      };
    },
  });

  registry.adapters.push(adapter);
  // 暴露纯函数给 tools/self-test.mjs 在 vm 里直接回归（不参与运行时逻辑）
  registry.skuTaobao = {
    sliceBalancedObject,
    parseLooseJson,
    readInlineSkuModel,
    pickSpecOptions,
    pickSpecOptionsByHeuristic,
    isNoiseSpecValue,
    mergeSpecOptions,
    buildSkusFromOptions,
    attachSpecImages,
    pickMainImage,
    imageAreaScore,
  };
})(window);
