/**
 * 采集适配器基类与公共工具。
 * content script 不是 ES module（MV3 content_scripts 顺序加载），因此这里挂在
 * window.__OZON_ADAPTERS__ 上供各平台适配器与 injector 使用。
 */
(function (global) {
  "use strict";

  const registry = global.__OZON_ADAPTERS__ || (global.__OZON_ADAPTERS__ = {});

  function cleanText(value) {
    return String(value == null ? "" : value).replace(/\s+/g, " ").trim();
  }

  function parseNumber(value) {
    if (typeof value === "number") return Number.isFinite(value) ? value : 0;
    const raw = String(value == null ? "" : value).replace(/[^\d.,\-]/g, "");
    if (!raw) return 0;
    let normalized = raw;
    const lastComma = raw.lastIndexOf(",");
    const lastDot = raw.lastIndexOf(".");
    if (lastComma > -1 && lastDot > -1) {
      normalized = lastComma > lastDot ? raw.replace(/\./g, "").replace(",", ".") : raw.replace(/,/g, "");
    } else if (lastComma > -1) {
      normalized = raw.length - lastComma - 1 === 3 ? raw.replace(/,/g, "") : raw.replace(",", ".");
    }
    const parsed = Number.parseFloat(normalized);
    return Number.isFinite(parsed) ? parsed : 0;
  }

  // 已知「会把尺寸写在文件名里」的图床域名。只有这些站点的地址才允许按尺寸规则裁后缀
  //（v1.9.60：原来「点号+宽高」那条规则对全站生效，站方真实命名 photo.1920x1080.jpg /
  //  带 x 的货号名会被裁成 photo.jpg 直接 404 —— 和下面单下划线规则保留同一道闸门）。
  // v1.9.62：补 pddpic / pinduoduo —— 拼多多的真实图床是 img.pddpic.com，白名单里原来
  //  写的是并不存在的 pinduoduoimg.com，等于拼多多的尺寸后缀从来没被裁过，一直采到小图。
  const SIZE_SUFFIX_HOST = /(?:alicdn|taobaocdn|tbcdn|mmstat|alibaba|1688|aliyuncs|pddpic|pinduoduo|yangkeduo|tb\.ele)/i;
  // 拼多多系图床：它的变体后缀是「点号」形式（<base>.jpeg.w800.jpeg），和阿里系的下划线形式不同
  const PDD_IMAGE_HOST = /(?:pddpic|pinduoduo|yangkeduo)/i;

  function normalizeImageUrl(url, origin) {
    let value = cleanText(url)
      .replace(/^&quot;|&quot;$/g, "")
      .trim();
    if (!value) return "";
    if (value.indexOf("//") === 0) value = "https:" + value;
    else if (value.charAt(0) === "/" && origin) value = origin + value;
    if (!/^https?:\/\//i.test(value)) return "";
    // 阿里 OSS 的 query 缩放参数（?x-oss-process=image/resize,w_400）只会降画质，去掉；
    // 其它 query 原样保留，避免把带签名/带版本号的地址改坏。
    value = value.replace(/([?&])x-oss-process=[^&]*/gi, "$1")
      .replace(/([?&])&+/g, "$1")
      .replace(/[?&]+$/, "");
    // v1.9.62 拼多多的 query 缩放走腾讯云数据万象：?imageMogr2/thumbnail/400x400/strip、
    //   ?imageView2/2/w/400/h/400，同样只降画质（还常顺带把格式转成 webp），去掉即回原图。
    if (PDD_IMAGE_HOST.test(value)) {
      value = value.replace(/([?&])(?:imageMogr2|imageView2)\/[^&]*/gi, "$1")
        .replace(/([?&])&+/g, "$1")
        .replace(/[?&]+$/, "");
    }
    if (SIZE_SUFFIX_HOST.test(value)) {
      value = value.replace(/\._\d+x\d+(?:q\d+)?\.(jpg|jpeg|png|webp)$/i, ".$1");
      value = value.replace(/\.(\d+)x(\d+)\.(jpg|jpeg|png|webp)$/i, ".$3");
      // 阿里系的「小图」标记：abc.jpg.sum.jpg（sum = summary，图集列表用的小图）
      value = value.replace(/\.(jpe?g|png|webp)\.sum\.(jpe?g|png|webp)$/i, ".$1");
    }
    // v1.9.48 阿里图床的「单下划线」尺寸后缀：规格色卡图 / 图集小图几乎全是这种缩略图
    //   abc.jpg_100x100.jpg   abc.jpg_400x400q90.jpg   abc.jpg_50x50c.jpg   abc.jpg_.webp
    // 只有已知图床才敢这么裁 —— 别的站点可能真把文件命名成 photo_1920x1080.jpg，裁了就 404。
    if (SIZE_SUFFIX_HOST.test(value)) {
      value = value.replace(
        /\.(jpe?g|png|webp|gif)_[qQ]?\d+x\d+(?:[qQ]\d+)?[a-z]{0,2}\.(jpe?g|png|webp|gif)$/i,
        ".$1",
      );
      value = value.replace(/\.(jpe?g|png|webp|gif)_\.(jpe?g|png|webp|gif)$/i, ".$1");
    }
    // v1.9.62 拼多多的「点号变体」后缀：<base>.jpeg.w800.jpeg / .h800 / .q75 → <base>.jpeg。
    // 只认 w/h/q + 数字这一种，所以拼多多自己的「原图」标记 <base>.jpeg.a.jpeg 不受影响（a 不是数字）。
    if (PDD_IMAGE_HOST.test(value)) {
      value = value.replace(/\.(jpe?g|png|webp|gif)\.[whq]\d+\.(jpe?g|png|webp|gif)$/i, ".$1");
    }
    return value;
  }

  function dedupe(list) {
    const seen = Object.create(null);
    const out = [];
    for (const item of list || []) {
      const value = cleanText(item);
      if (!value || seen[value]) continue;
      seen[value] = true;
      out.push(value);
    }
    return out;
  }

  /* ---------------- 采集精度：标题清洗、价格区间、SKU 去重 ---------------- */

  // 标题里的营销噪音词（只删这些明确与商品描述无关的词，不猜内容）
  const TITLE_NOISE_WORDS = "(?:包邮|限时特价|限时秒杀|限时|特价|清仓|亏本|批发|一件代发|厂家直销|工厂直销|源头工厂|厂家直供|现货|新品上市|新品|爆款|热卖|热销|促销|秒杀|正品|正品保障|官方旗舰店|旗舰店|专营店|专卖店|企业店|支持一件代发)";
  const TITLE_NOISE_BRACKETS = new RegExp(`[【\\[(（]\\s*${TITLE_NOISE_WORDS}(?:\\s*[+＋/、]\\s*${TITLE_NOISE_WORDS})*\\s*[】\\])）]`, "gi");
  const TITLE_NOISE_PREFIX = new RegExp(`^(?:[\\s\\-|｜,，、。·:：]*${TITLE_NOISE_WORDS}[\\s\\-|｜,，、。·:：]*)+`, "i");
  // v1.9.63 对称补上「结尾噪声」：1688/淘宝的标题经常把店铺后缀挂在末尾，
  //   例「5L可视空气炸锅 官方旗舰店」→「5L可视空气炸锅」。
  // 旧写法只剥前缀，于是整个标题退化成一个店铺名，AI 拿到后只会回「不知道这是什么商品」。
  const TITLE_NOISE_SUFFIX = new RegExp(`(?:[\\s\\-|｜,，、。·:：]+(?:${TITLE_NOISE_WORDS}))+[\\s\\-|｜,，、。·:：]*$`, "gi");
  const TITLE_PLATFORM_TAIL = /\s*[-|｜/]\s*(?:1688\.com|alibaba\.com|阿里巴巴|淘宝网|天猫|tmall\.com|taobao\.com|拼多多|品多多|yangkeduo\.com).*$/i;

  /**
   * 清洗采集到的标题：去掉零宽字符 / emoji / 【包邮】这类营销括号 / 结尾的平台名。
   * 只做「明显不是商品信息」的删除，其余原样保留（不伪造、不拼接）。
   */
  function sanitizeTitle(value, maxLength = 200) {
    let out = String(value == null ? "" : value);
    if (!out) return "";
    out = out.replace(/[\u200B-\u200D\uFEFF\u00A0\u3000]/g, " ");        // 零宽/全角空格
    out = out.replace(/[\uD800-\uDBFF][\uDC00-\uDFFF]/g, " ");           // emoji（代理对）
    out = out.replace(/[\u2190-\u21FF\u2600-\u27BF\u2B00-\u2BFF\uFE0F]/g, " "); // 箭头/符号
    out = out.replace(TITLE_NOISE_BRACKETS, " ");
    out = out.replace(TITLE_PLATFORM_TAIL, "");
    out = cleanText(out);
    out = out.replace(TITLE_NOISE_PREFIX, "");
    // v1.9.63：剥完前缀再剥结尾的店铺噪声；剥空了说明这串本来就只有噪声，退回原值
    // （宁可留着一个带店铺后缀的标题，也不能把标题剥没，那等于告诉 AI「没拿到标题」）
    const noSuffix = out.replace(TITLE_NOISE_SUFFIX, "");
    if (cleanText(noSuffix)) out = noSuffix;
    out = cleanText(out).replace(/^[\-|｜,，、。·:：;；\s]+/, "").replace(/[\-|｜,，、。·:：;；\s]+$/, "");
    if (maxLength > 0 && out.length > maxLength) out = cleanText(out.slice(0, maxLength));
    return out;
  }

  /**
   * 标题是不是「店铺名 / 公司名」而不是商品名（v1.9.63）。
   * 判据很保守：短、不含数字（商品标题几乎一定带规格/数量/型号数字）、以 厂/公司/店 等结尾。
   * 用来挡住「整个标题退化成一个店铺名」——这种标题发给 AI，AI 只会回「不知道这是什么商品」。
   */
  const SHOP_NAME_RE = /^(?:[\u4e00-\u9fa5]{1,4}市)?.{0,14}(?:厂|公司|店|商行|经营部|批发部)$/;
  function looksLikeShopName(value) {
    const text = cleanText(value);
    if (!text || text.length > 20) return false;
    if (/\d/.test(text)) return false;
    return SHOP_NAME_RE.test(text);
  }

  const PRICE_MAX_SANE = 10000000;

  /**
   * 从一段价格文本里解析区间价，例如 "¥12.50 - 15.80"、"12.5~15.8"、"12.50起"。
   * 会跳过明显不是价格的数字（月销/库存/件数/折扣等），避免把销量当价格。
   */
  function parsePriceRange(value) {
    const raw = cleanText(value);
    if (!raw) return { min: 0, max: 0, raw: "" };
    // 数字后面必须不是数字/小数点/加号（防止「1200 件」被回溯成「120」、「750+」销量被当价格），
    // 也不是件/人/月等计量词或「起批」（起批量）
    const re = /(\d{1,3}(?:,\d{3})+(?:\.\d+)?|\d+(?:\.\d+)?)(?![\d.,+])(?!\s*(?:件|个|人|笔|天|月|年|次|折|%|小时|分钟|秒|万|起批))/g;
    const numbers = [];
    let match;
    while ((match = re.exec(raw))) {
      const numberText = match[0];
      // 三位以上小数基本是 DOM 拼接产物（「¥100.00」+「1起批」→ 100.001），真价格最多两位小数
      if ((numberText.split(".")[1] || "").length >= 3) continue;
      const number = parseNumber(numberText);
      if (number > 0 && number <= PRICE_MAX_SANE) numbers.push(number);
      if (numbers.length >= 8) break;
    }
    if (!numbers.length) return { min: 0, max: 0, raw };
    const min = Math.min(...numbers);
    const max = Math.max(...numbers);
    return { min, max, raw, range: max > min };
  }

  /**
   * 通用价格拾取：各平台改版都很快，写死选择器必然失效，所以按「结构化数据 → 已知选择器
   * → 类名/ID 里带 price 的元素 → 全页带 ¥ 的文本」逐级兜底。
   * selectors 可由各适配器补充自己平台的专属选择器。
   */
  const PRICE_EXCLUDE_PATTERN = /(recommend|related|similar|guess|footer|nav|menu|banner|ad-|advert|promo-|coupon|history|bought|cart|order|comment|review)/i;

  function priceFromJsonLd(jsonLd) {
    for (const block of jsonLd || []) {
      const offers = block.offers || block.Offer;
      if (!offers) continue;
      const list = Array.isArray(offers) ? offers : [offers];
      for (const offer of list) {
        if (!offer || typeof offer !== "object") continue;
        const low = parseNumber(offer.lowPrice ?? offer.price);
        const high = parseNumber(offer.highPrice ?? offer.price);
        const min = low || high;
        if (min > 0) return { min, max: high > min ? high : min, raw: cleanText(String(offer.lowPrice ?? offer.price ?? min)) };
      }
    }
    return null;
  }

  function priceFromMeta() {
    for (const name of ["product:price:amount", "og:price:amount", "twitter:data1", "price"]) {
      const value = meta(name, true) || meta(name);
      if (!value) continue;
      const range = parsePriceRange(value);
      if (range.min > 0) return { min: range.min, max: range.max, raw: range.raw };
    }
    for (const node of all("[itemprop=price]")) {
      const value = cleanText(node.getAttribute("content") || node.textContent);
      const range = parsePriceRange(value);
      if (range.min > 0) return { min: range.min, max: range.max, raw: range.raw };
    }
    return null;
  }

  function pickPagePrice({ cache = null, selectors = [], scope = null } = {}) {
    const jsonLd = cache?.jsonLd ? cache.jsonLd() : readJsonLd();
    const fromJsonLd = priceFromJsonLd(jsonLd);
    if (fromJsonLd) return fromJsonLd;

    const fromMeta = priceFromMeta();
    if (fromMeta) return fromMeta;

    for (const selector of selectors) {
      const value = text(selector);
      if (!value) continue;
      const range = parsePriceRange(value);
      if (range.min > 0) return { min: range.min, max: range.max, raw: range.raw };
    }

    // 商品主体区：类名扫描与最后的 ¥ 兜底都必须限定在它里面，
    // 否则推荐位里另一件商品的价格会被当成当前商品的价格。
    const scopeNode = scope || (cache && cache.scope ? cache.scope() : null);
    const inScope = (node) => !scopeNode
      || scopeNode === document.body
      || scopeNode === document.documentElement
      || scopeNode === node
      || Boolean(scopeNode.contains && scopeNode.contains(node));

    // 类名/ID 里带 price 的元素：排除推荐位/广告位，优先带 ¥ 的
    const candidates = [];
    for (const node of all("[class*='price' i], [id*='price' i]")) {
      if (!inScope(node)) continue;
      const mark = `${node.className || ""} ${node.id || ""}`;
      if (PRICE_EXCLUDE_PATTERN.test(mark)) continue;
      const value = cleanText(node.textContent);
      if (!value || value.length > 40) continue;
      const range = parsePriceRange(value);
      if (!(range.min > 0)) continue;
      candidates.push({ range, hasSymbol: /[¥￥]/.test(value), depth: (() => { let d = 0; let p = node; while (p && p !== document.body) { d += 1; p = p.parentElement; } return d; })() });
      if (candidates.length >= 40) break;
    }
    if (candidates.length) {
      candidates.sort((a, b) => (Number(b.hasSymbol) - Number(a.hasSymbol)) || (a.depth - b.depth));
      const picked = candidates[0].range;
      return { min: picked.min, max: picked.max, raw: picked.raw };
    }

    // 最后兜底：在**商品主体区**里找第一个「¥ 数字」。
    // 旧实现扫的是全页，推荐位里另一件商品的价格会被当成当前商品的价格 ——
    // 这是「采集数据不准确」的典型来源之一。
    const body = scopeNode ? scopeTextOf(scopeNode) : cleanText(document.body?.innerText || "");
    const match = body.match(/[¥￥]\s*(\d{1,3}(?:,\d{3})+(?:\.\d+)?|\d+(?:\.\d+)?)/);
    if (match) {
      const value = parseNumber(match[1]);
      if (value > 0) return { min: value, max: value, raw: match[0] };
    }
    return { min: 0, max: 0, raw: "" };
  }

  // 单个「维度=值」最长多少字符还算真的是规格。超长说明规格值被污染了
  //（整页营销文本 / 无换行的多行文本被拼成一行当作规格名），签名不再代表变体身份。
  const SKU_SIG_MAX_PART = 40;
  const SKU_SIG_MAX_TOTAL = 160;

  function skuSignature(sku) {
    const specs = sku && sku.specs && typeof sku.specs === "object" ? sku.specs : null;
    if (specs) {
      const parts = Object.keys(specs)
        .sort()
        .map((key) => `${cleanText(key)}=${cleanText(specs[key])}`)
        .filter((part) => part.length > 1);
      // v1.9.74 关键修复：规格值被污染成长段落时**不能**再拿它当去重依据。
      // 真实案例：1688 新版把 30 多个变体挤进一行没有换行的 innerText，整段文本被
      // 当成了「规格」值 —— 于是 30 个变体算出同一个签名，dedupeSkus 只留下第 1 条，
      // 界面上就是「页面上 30 多个 SKU，插件只采到 1 个」。
      // 这时退回按行内位置生成的 id 去重：位置一定唯一，不会再互相覆盖。
      const polluted = parts.some((part) => part.length > SKU_SIG_MAX_PART)
        || parts.join("|").length > SKU_SIG_MAX_TOTAL;
      if (parts.length && !polluted) return parts.join("|");
    }
    return cleanText(sku && sku.id);
  }

  /** 去掉重复 SKU（同规格组合只留第一条），并丢掉既无规格又无价格的空条目 */
  function dedupeSkus(list) {
    const seen = Object.create(null);
    const out = [];
    for (const sku of list || []) {
      if (!sku) continue;
      const hasSpecs = sku.specs && Object.keys(sku.specs).length > 0;
      if (!hasSpecs && !Number(sku.price)) continue;
      const key = skuSignature(sku);
      if (key && seen[key]) continue;
      if (key) seen[key] = true;
      out.push(sku);
    }
    return out;
  }

  /* ---------------- 图片过滤：采集阶段就丢掉图标/水印/按钮图 ---------------- */

  // 明确不是产品图的关键词（与 src/shared/image-filter.js 的 NON_PRODUCT_IMAGE_PATTERN 逐字一致，
  // smoke-check 会比对，改动必须同步两处：content script 不能 import ES module，只能各留一份）
  const NON_PRODUCT_PATTERN =
    /(logo|icon|badge|watermark|sprite|avatar|qrcode|qr[-_]?code|erweima|brand|flag|cert|promo|banner|advert|ai[-_]?generated|ai[-_]?badge|heart|like|love|cart|shop|store|flagship|official|mark|tag|seal|guarantee|quality|supplier|factory|wholesale|retail|vip|member|discount|coupon|gift|hot|arrow|btn|button|loading|placeholder|blank|pixel|spacer|divider|star|rate|review|comment|share|collect|favorite|wishlist|service|customer|kefu|online|1688\.com|tmall\.com|taobao\.com|pinduoduo|yangkeduo)/i;

  // 页面框架区域内的图基本不是产品图
  const NON_PRODUCT_ZONE = "header, nav, footer, aside, [class*=header], [class*=footer], [class*=nav], [class*=breadcrumb], [class*=crumb], [class*=sidebar], [class*=toolbar], [class*=float], [class*=aside]";

  // 单次采集最多检查多少张图，防止图文详情页上千个 img 拖慢采集
  const MAX_IMAGE_NODES = 300;

  // 从 <img> 上找可用的原图地址（懒加载属性优先，避免拿到 1px 占位图）
  // v1.9.60 补全各站懒加载属性：1688/淘宝用 data-actualsrc / data-lazy-img，淘宝图片
  // 组件用 data-src，PDD 用 data-testid-src；currentSrc 是浏览器已真实加载的地址，
  // 排在 src 之前（src 此时多半还是占位图）。gif/svg 占位、base64 缩略图一律跳过。
  /**
   * v1.9.62 明确的「占位图文件名」。三平台都有 <img src="/static/blank.gif" srcset="真图"> 这种写法：
   * 旧实现只看「是不是合法 http 地址」，于是占位图的地址被当成真图返回，后面按 URL 关键词也筛不掉
   * （文件名里根本没有 logo/icon 这些词）。这里认得出占位图就让位给 srcset / currentSrc。
   */
  const PLACEHOLDER_FILE_RE = /(?:^|[/_.-])(?:blank|loading|load|placeholder|spacer|pixel|transparent|empty|grey|gray|default|noimg|no[-_]?image|nopic|logo[-_]?holder)(?:[/_.-]|$)/i;

  function imageSource(node) {
    let fallback = "";
    for (const attr of [
      "data-lazy-src", "data-ks-lazyload", "data-lazyload-src", "data-actualsrc",
      "data-lazy-img", "data-original", "data-image", "data-src", "data-origin",
      "data-testid-src", "data-lazyload", "data-original-src", "src",
    ]) {
      const value = node.getAttribute && node.getAttribute(attr);
      if (!value) continue;
      if (/^data:image\/(?:gif|svg)/i.test(value)) continue;
      const normalized = normalizeImageUrl(value, location.origin || "https:");
      if (!normalized) continue;
      // 占位图不当真图，但要留着当最后的兜底（真找不到别的总比没有强）
      if (PLACEHOLDER_FILE_RE.test(normalized)) {
        if (!fallback) fallback = normalized;
        continue;
      }
      return normalized;
    }
    // currentSrc / srcset：懒加载库真正写入后才有值，取最大的一张
    const current = node.currentSrc || node.src || "";
    if (/^https?:\/\//i.test(current) && !/^data:/i.test(current)) {
      const normalized = normalizeImageUrl(current, location.origin || "https:");
      if (normalized && !PLACEHOLDER_FILE_RE.test(normalized)) return normalized;
    }
    const srcset = node.getAttribute && node.getAttribute("srcset");
    if (srcset) {
      let bestUrl = "";
      let bestWidth = 0;
      for (const entry of srcset.split(",")) {
        const parts = entry.trim().split(/\s+/);
        const url = normalizeImageUrl(parts[0], location.origin || "https:");
        if (!url) continue;
        const descriptor = parseInt(parts[1]) || 0;
        if (descriptor > bestWidth) { bestWidth = descriptor; bestUrl = url; }
      }
      if (bestUrl) return bestUrl;
    }
    return fallback;
  }

  // 1px / 2px 透明占位图：尺寸极小且没有真实加载完成时，这张地址不可信
  function isPlaceholderSource(url, node, size) {
    if (/^data:/i.test(String(url))) return false; // data 图在 imageSource 已按类型过滤
    const loaded = Boolean(node && node.complete && size.natural);
    if (loaded) return size.width <= 2 && size.height <= 2;
    return false;
  }

  // 量出图片真实尺寸：naturalWidth 是文件本身尺寸，最能区分产品图与图标。
  // 读 getBoundingClientRect 会触发布局，只在拿不到 naturalWidth 时才读。
  function imageSize(node) {
    const naturalWidth = Number(node.naturalWidth) || 0;
    const naturalHeight = Number(node.naturalHeight) || 0;
    if (naturalWidth > 0) {
      return { width: naturalWidth, height: naturalHeight || naturalWidth, natural: true };
    }
    let renderedWidth = 0;
    let renderedHeight = 0;
    if (typeof node.getBoundingClientRect === "function") {
      const rect = node.getBoundingClientRect();
      renderedWidth = Math.round(rect.width);
      renderedHeight = Math.round(rect.height);
    }
    return { width: renderedWidth, height: renderedHeight, natural: false };
  }

  function inNonProductZone(node) {
    return Boolean(node.closest && node.closest(NON_PRODUCT_ZONE));
  }

  // 1688 详情长图 / 规格色卡常把图放在 background-image 里（没有 <img>），必须一起收
  const BACKGROUND_IMAGE_PATTERN = /url\((['"]?)([^'")]+)\1\)/gi;
  const MAX_BACKGROUND_NODES = 2000;
  // 计算样式兜底的扫描上限：getComputedStyle 会触发布局/样式重算，必须限量
  const MAX_COMPUTED_BG_NODES = 120;

  /** 取容器及其后代上内联样式里的 background-image 地址 */
  function backgroundImageUrls(root) {
    const out = [];
    if (!root || !root.querySelectorAll) return out;
    const candidates = [root].concat(Array.from(root.querySelectorAll("*")));
    for (const node of candidates.slice(0, MAX_BACKGROUND_NODES)) {
      const style = node.getAttribute && node.getAttribute("style");
      if (!style || !/url\(/i.test(style)) continue;
      let match;
      BACKGROUND_IMAGE_PATTERN.lastIndex = 0;
      while ((match = BACKGROUND_IMAGE_PATTERN.exec(style))) {
        const raw = cleanText(match[2]);
        if (raw && !/^data:/i.test(raw)) out.push(raw);
      }
    }
    return out;
  }

  /** 取元素计算样式里的 background-image（内联 style 之外的 CSS 规则铺图，懒加载库常见） */
  function computedBackgroundUrls(node) {
    const out = [];
    if (!node || typeof window === "undefined" || typeof window.getComputedStyle !== "function") return out;
    let style;
    try { style = window.getComputedStyle(node); } catch { return out; }
    const value = (style && (style.backgroundImage || style.getPropertyValue("background-image"))) || "";
    if (!value || !/url\(/i.test(value)) return out;
    let match;
    BACKGROUND_IMAGE_PATTERN.lastIndex = 0;
    while ((match = BACKGROUND_IMAGE_PATTERN.exec(value))) {
      const raw = cleanText(match[2]);
      if (raw && !/^data:/i.test(raw)) out.push(raw);
    }
    return out;
  }

  /**
   * 判断一张图是否大概率是产品图。
   * 规则（宽严有序，宁缺毋滥但不误删）：URL 关键词命中 → 排除；
   * 有真实尺寸时，最长边 < 120px（图标/按钮）或 < 300px 且明显是细长条（横幅/分割线）→ 排除。
   * 没有尺寸信息时只按关键词判断，避免误删缩略图。
   */
  function isLikelyProductImage({ url = "", width = 0, height = 0, natural = false } = {}) {
    let decoded = String(url);
    try { decoded = decodeURIComponent(decoded); } catch { /* 保留原文 */ }
    if (NON_PRODUCT_PATTERN.test(decoded)) return false;
    if (!width || !height) return true;
    const maxSide = Math.max(width, height);
    const minSide = Math.min(width, height);
    if (natural) {
      if (maxSide < 120) return false;                                  // 图标 / logo / 按钮
      if (maxSide < 300 && minSide / maxSide < 0.25) return false;      // 细长条：横幅 / 分割线
    }
    return true;
  }

  /* ------------------------------------------------------------------
   * v1.9.69 商品主体区（product scope）
   *
   * 背景：1688 / 淘宝 / 拼多多的详情页里，除了「当前这件商品」之外，还塞了大量
   * 「猜你喜欢 / 看了又看 / 掌柜热卖 / 搭配购」模块，每个模块都是**另一件商品**的
   * 标题、价格、图片、成交数。旧实现里有一批「全页扫描」的取值方式：
   *   - pickTitle 的通用 h1 选择器（可能命中推荐位里的标题）
   *   - pickPagePrice 最后的「全页第一个 ¥ 数字」
   *   - pickSales / pickStock / pickLogistics / pickParcel / pickAttributes 直接
   *     对 document.body.innerText 做正则
   *   - collectImages「容器没命中就退回全页扫描」
   * 这些扫描会命中**别的商品**，于是采出来的是页面里另一件商品的数据 ——
   * 用户看到的就是「采集的数据严重不准确」「没按我采的产品来」。
   *
   * 修法：先把「商品主体区」定位出来，所有全页扫描一律收敛到这块区域里。
   * 定位不依赖任何具体类名（新版页面类名全混淆），而是用「权威标题」做锚点：
   * og:title / document.title 一定是当前这件商品的标题，拿它去 DOM 里找到对应的
   * 标题节点，再往上找同时含价格符号（¥/￥）的最近祖先 —— 那就是商品主信息区。
   * ------------------------------------------------------------------ */

  // 推荐位 / 猜你喜欢 / 店铺卡片 / 评价区：这些区域里的数据属于**别的商品**或用户内容
  const RECOMMEND_ZONE_SELECTORS = [
    "[class*=recommend]", "[class*=Recommend]",
    "[class*=similar]", "[class*=Similar]",
    "[class*=related]", "[class*=Related]",
    "[class*=guess]", "[class*=Guess]",
    "[class*=mayLike]", "[class*=maylike]", "[class*=MayLike]",
    "[class*=footLike]", "[class*=foot-like]",
    "[class*=likeList]", "[class*=like-list]",
    "[class*=shopCard]", "[class*=shop-card]",
    "[class*=supplierCard]", "[class*=supplier-card]",
    "[class*=companyCard]", "[class*=company-card]",
    "[class*=hotSale]", "[class*=hot-sale]",
    "[class*=hotProduct]", "[class*=hot-product]",
    "[class*=boughtTogether]", "[class*=bought-together]",
    "[class*=combine]", "[class*=bundle]",
    "[class*=review]", "[class*=Review]",
    "[class*=comment]", "[class*=Comment]",
    "[class*=评价]", "[class*=appraise]", "[class*=rate-]",
    "[class*=advert]", "[class*=ad-]",
    "[class*=coupon]", "[class*=Coupon]",
    "[class*=footer]", "[class*=Footer]",
  ];

  // 站点名 / 平台通用标题：这些不是商品标题，不能当权威标题用
  const SITE_TITLE_RE = /^(?:阿里巴巴(?:1688)?|1688(?:\.com)?|中国站|淘宝网|天猫|拼多多|阿里巴巴集团)/;

  /**
   * 权威标题：og:title → document.title（去掉站点后缀）。
   * 这两者一定属于**当前页面这件商品**，是唯一可信的「我在采哪件商品」的锚点。
   */
  function authoritativeTitle() {
    const raw = meta("og:title") || meta("og:title", true) || "";
    const doc = cleanText(document.title)
      .replace(/[-_|]\s*(?:阿里巴巴(?:1688)?|1688(?:\.com)?|中国站|阿里巴巴集团|淘宝网|天猫|拼多多).*$/i, "")
      .replace(/^(?:阿里巴巴(?:1688)?|1688(?:\.com)?)\s*[-_|]\s*/i, "")
      .trim();
    for (const candidate of [raw, doc]) {
      const value = sanitizeTitle(candidate) || cleanText(candidate);
      if (!value || value.length <= 3) continue;
      if (SITE_TITLE_RE.test(value)) continue;   // 「阿里巴巴1688.com - 全球领先的采购批发平台」
      if (/1688\.com|taobao\.com|tmall\.com|yangkeduo\.com|pinduoduo\.com/i.test(value)) continue;
      return value;
    }
    return "";
  }

  /** 在有限的一组「像标题」的节点里，按文本找到承载权威标题的那个节点 */
  function findTitleNode(title) {
    const target = cleanText(title);
    if (!target) return null;
    const nodes = all("h1, h2, h3, h4, [class*=title], [class*=Title], [class*=name], [class*=Name], [data-title], [title]");
    let loose = null;
    for (const node of nodes) {
      const value = cleanText(node.textContent);
      if (!value) continue;
      if (value === target) return node;
      if (!loose && value.length >= target.length && value.indexOf(target) === 0) loose = node;
    }
    return loose;
  }

  // 商品主体区的已知容器（锚点定位失败时的第二选择）
  const PRODUCT_SCOPE_SELECTORS = [
    "#mod-detail",
    ".detail-content",
    "[class*=offerContent]", "[class*=offer-content]",
    "[class*=detailContent]", "[class*=detail-content]",
    "[class*=productContent]", "[class*=product-content]",
    "[class*=goodsContent]", "[class*=goods-content]",
    "[class*=itemContent]", "[class*=item-content]",
    "[class*=mainContent]", "[class*=main-content]",
    "main",
  ];

  /**
   * 商品主体区：以权威标题为锚，向上找同时含价格符号（¥/￥）的最近祖先。
   * 找不到锚点时退回已知主体容器选择器，最后才退 body。
   */
  function resolveProductScope() {
    try {
      const title = authoritativeTitle();
      const node = title ? findTitleNode(title) : null;
      if (node) {
        let cur = node;
        for (let i = 0; i < 10 && cur && cur !== document.body && cur.parentElement; i += 1) {
          const value = cur.innerText || cur.textContent || "";
          if (/[¥￥]/.test(value)) return cur;
          cur = cur.parentElement;
        }
        // 没找到价格符号：往上退 3 层当主体区，总比用整页强
        cur = node;
        for (let i = 0; i < 3 && cur && cur.parentElement && cur !== document.body; i += 1) cur = cur.parentElement;
        if (cur && cur !== document.body && cur !== document.documentElement) return cur;
      }
    } catch { /* 定位失败就走下面的兜底 */ }
    for (const selector of PRODUCT_SCOPE_SELECTORS) {
      const node = document.querySelector(selector);
      if (node) return node;
    }
    return (document.body || document.documentElement || null);
  }

  /**
   * 商品主体区的文本。所有「正则扫全页文本」的取值都必须换成它，
   * 否则「成交 12 件」「库存 500」这类数字很容易来自推荐位里的另一件商品。
   * body 兜底时把推荐区文本减掉。
   */
  function scopeTextOf(root) {
    if (!root) return cleanText(document.body && document.body.innerText);
    if (root === document.body || root === document.documentElement) {
      let out = cleanText(root.innerText || root.textContent || "");
      for (const zone of all(RECOMMEND_ZONE_SELECTORS.join(", ")).slice(0, 40)) {
        const zoneText = cleanText(zone.innerText || zone.textContent || "");
        if (zoneText.length < 20) continue;
        out = out.split(zoneText).join(" ");
      }
      return out;
    }
    return cleanText(root.innerText || root.textContent || "");
  }

  /**
   * 采集产品图：在给定容器里找图，量尺寸、按产品图规则过滤，并返回尺寸元数据。
   * 返回 { images: string[], imageMeta: { [url]: { width, height } } }
   *
   * 可调开关（1688 主图 / 缩略图 / 详情长图要分开抓，规则不一样）：
   *  - allowSmall: 缩略图与详情长图多数是懒加载（naturalWidth=0），只按 URL 关键词过滤，不按尺寸丢弃
   *  - includeBackground: 同时收容器里的 background-image（详情长图铺图用）
   *  - excludeZones: 额外排除的区域（推荐位 / 猜你喜欢 / 店铺卡片等），避免抓到别的商品
   *  - noPageFallback: 容器一个都没命中时不要退回全页扫描（否则会把整页图标都收进来）
   *  - limit: 最多返回多少张
   *  - scopeRoot: 只收这块区域（商品主体区）里的图。v1.9.69 新增 —— 页面上的
   *    推荐位/猜你喜欢里全是**别的商品**的图，不设边界就会采到别的商品的主图。
   *  - extraFirst: 结构化数据（内联 JSON / JSON-LD）的图排到 DOM 抓到的图**前面**。
   *    这些图最干净（不含图标、不含推荐位），排前面才能成为 images[0]。
   *  - extraMeta: { [url]: { width, height } }，结构化数据自带的真实尺寸。
   *    拼多多的内联数据就带 width/height，喂进来之后「按尺寸挑主图」才有依据。
   *
   * containers 里以 "@" 开头的条目按**完整选择器**使用（不再自动补 " img"），
   * 用于 `@img[aria-label="商品大图"]` 这种直接命中 <img> 的选择器。
   */
  function collectImages({
    containers = [],
    extra = [],
    extraMeta = null,
    extraFirst = false,
    origin,
    allowSmall = false,
    includeBackground = false,
    excludeZones = [],
    noPageFallback = false,
    limit = 0,
    scopeRoot = null,
  } = {}) {
    const meta = Object.create(null);
    const urls = [];
    const zoneSelector = (excludeZones || []).filter(Boolean).join(", ");
    const inExcludedZone = (node) => Boolean(zoneSelector && node.closest && node.closest(zoneSelector));
    const baseOrigin = origin || location.origin || "https:";

    // allowSmall 时尺寸信息不可信（懒加载占位），交给 URL 关键词判断，避免把真图删掉
    const judge = (url, size) => isLikelyProductImage(
      allowSmall
        ? { url, width: 0, height: 0, natural: false }
        : { url, width: size.width, height: size.height, natural: size.natural },
    );

    const push = (url, size) => {
      const normalized = normalizeImageUrl(url, baseOrigin);
      if (!normalized) return;
      const safeSize = size || { width: 0, height: 0, natural: false };
      // 同一个 URL 可能出现多次（缩略图 + 大图），只要有一次判定为产品图就保留，并记录最大尺寸
      const known = meta[normalized];
      if (known) {
        known.width = Math.max(known.width, safeSize.width);
        known.height = Math.max(known.height, safeSize.height);
        known.natural = known.natural || safeSize.natural;
        if (!known.product && judge(normalized, known)) known.product = true;
        return;
      }
      meta[normalized] = {
        width: safeSize.width,
        height: safeSize.height,
        natural: safeSize.natural,
        product: judge(normalized, safeSize),
      };
      urls.push(normalized);
    };

    // 结构化数据的图没有 DOM 节点，先塞进来（extraFirst 时它们排在 DOM 图前面）
    const addExtra = () => {
      for (const url of extra || []) {
        const normalized = normalizeImageUrl(url, baseOrigin);
        if (!normalized || meta[normalized]) continue;
        const hint = extraMeta && extraMeta[normalized];
        const hintWidth = Number(hint && hint.width) || 0;
        const hintHeight = Number(hint && hint.height) || 0;
        // 结构化数据给了真实宽高就当作可信尺寸（natural=true），否则只按关键词判断
        const sized = hintWidth > 0 && hintHeight > 0;
        meta[normalized] = {
          width: hintWidth,
          height: hintHeight,
          natural: sized,
          product: isLikelyProductImage(
            sized ? { url: normalized, width: hintWidth, height: hintHeight, natural: true } : { url: normalized },
          ),
        };
        urls.push(normalized);
      }
    };
    if (extraFirst) addExtra();

    // 以 "@" 开头的容器是完整选择器（不再补 " img"），其余按「容器 img」展开。
    // 注意 "@" 前缀不能直接丢给 querySelectorAll —— "@img[...]" 是非法 CSS，会抛 SyntaxError。
    const isFullSelector = (selector) => selector.charAt(0) === "@";
    const resolveSelector = (selector) => (isFullSelector(selector) ? selector.slice(1) : `${selector} img`);
    const resolveContainer = (selector) => (isFullSelector(selector) ? selector.slice(1) : selector);

    let nodes = [];
    for (const selector of containers) {
      nodes = nodes.concat(all(resolveSelector(selector)));
      // 图集容器已经够多了，别把整页几十个选择器都扫一遍
      if (nodes.length > MAX_IMAGE_NODES) break;
    }
    const scoped = nodes.length > 0;
    // 容器里没找到就退回全页，但排除页面框架区域，减少抓进 logo / 导航图标
    if (!scoped && !noPageFallback) nodes = all("img").filter((node) => !inNonProductZone(node));
    if (nodes.length > MAX_IMAGE_NODES) nodes = nodes.slice(0, MAX_IMAGE_NODES);

    const inScope = (node) => !scopeRoot
      || scopeRoot === document.body
      || scopeRoot === document.documentElement
      || scopeRoot === node
      || Boolean(scopeRoot.contains && scopeRoot.contains(node));

    for (const node of nodes) {
      if (inExcludedZone(node)) continue;
      if (!inScope(node)) continue;
      // 页面框架区（header/nav/footer…）里的图一般不是产品图，但「容器已经命中的图集节点」
      // 例外：拼多多的轮播就挂在 [class*=goods-header] 里，1688/淘宝的图集也常被套在
      // [class*=swiper]/[class*=carousel] 中。v1.9.62 把这几类容器和 aria-label（页面
      // 自己打的图注，等于显式声明「这是商品图」）一并列入豁免，避免真主图被误杀。
      if (scoped && inNonProductZone(node)
        && !node.closest(".detail-gallery, [class*=gallery], [class*=thumb], [class*=swiper], [class*=carousel], [aria-label]")) continue;
      const size = imageSize(node);
      let url = imageSource(node);
      // 1px 占位图剔除：懒加载还没触发时 src 往往是透明占位，地址本身也量不出尺寸；
      // 量到真实尺寸 ≤2px 且已加载完成的直接丢弃，未加载的先保留（后面 includeBackground
      // / 计算样式还可能拿到同一节点的图）
      if (url && isPlaceholderSource(url, node, size)) url = "";
      push(url, size);
    }

    if (includeBackground) {
      // 容器去重：多个选择器经常指向同一棵子树（#mod-detail-description 与 [class*=descContent]），
      // 重复扫描既慢又没意义。下面两种扫描都复用这份列表。
      const containerNodes = [];
      const seenContainers = new Set();
      for (const selector of containers) {
        for (const node of all(resolveContainer(selector))) {
          if (seenContainers.has(node)) continue;
          seenContainers.add(node);
          containerNodes.push(node);
        }
      }
      let inlineFound = 0;
      for (const node of containerNodes) {
        if (inExcludedZone(node)) continue;
        const urls = backgroundImageUrls(node);
        inlineFound += urls.length;
        for (const url of urls) push(url, { width: 0, height: 0, natural: false });
      }
      // 计算样式兜底：有些站把详情图通过 CSS 规则（而非内联 style）铺背景，
      // 只在常规手段抓不到时限量扫一次，避免在大页面上强制全量样式重算拖慢采集
      if (inlineFound === 0) {
        // v1.9.67 修预算 bug：旧写法只在「命中背景图」时给 scanned 计数，等于没有预算——
        // 详情区上千个节点会逐个 getComputedStyle（强制样式重算），大页面上这一步能跑出好几秒。
        // 现在按「检查过的节点数」计预算，并且连容器本身一起看（旧写法漏了容器自己的背景图）。
        for (const node of containerNodes) {
          let scanned = 0;
          if (inExcludedZone(node)) continue;
          for (const url of computedBackgroundUrls(node)) push(url, { width: 0, height: 0, natural: false });
          for (const child of node.querySelectorAll("*")) {
            if (scanned >= MAX_COMPUTED_BG_NODES) break;
            scanned += 1;
            if (inExcludedZone(child)) continue;
            for (const url of computedBackgroundUrls(child)) push(url, { width: 0, height: 0, natural: false });
          }
        }
      }
    }

    // 结构化数据里的图通常是最干净的产品图，没有尺寸时按关键词过滤后合并进来
    if (!extraFirst) addExtra();

    let images = urls.filter((url) => meta[url].product);
    if (limit > 0) images = images.slice(0, limit);
    const imageMeta = {};
    for (const url of images) {
      // natural=true 表示尺寸来自文件本身（可信）；false 只是渲染尺寸（懒加载占位常是 0 或 1px）
      imageMeta[url] = { width: meta[url].width, height: meta[url].height, natural: Boolean(meta[url].natural) };
    }
    return { images, imageMeta };
  }

  /**
   * v1.9.67：按「图床域名 + 文档顺序」捞图，完全不依赖类名。
   *
   * 背景：新版 1688 详情页把图集的类名整批换掉了（detail-gallery / thumbList / thumb 全部落空），
   * 于是「未识别到产品图」——但同一个页面的 SKU 色卡图却抓得到，说明 <img> 本身在页面上，
   * 只是我们的选择器一个都没命中。类名可以随便改，有两件事改不掉：
   *   ① 商品图一定挂在固定图床路径下（1688 是 /img/ibank/，淘宝是 /imgextra/）；
   *   ② 图集一定排在「详情描述区」**之前**（详情长图在描述区里面，不能混进图集）。
   * 所以这里按 URL 特征 + 文档顺序捞，作为选择器全部落空时的最后一道兜底。
   *
   * 注意这里**不做尺寸过滤**：1688 新版图集只有 60×60 的缩略图 <img>（主图位是 <video>），
   * 按「最长边 < 120px 当图标丢掉」的规则会整批误杀 —— 这正是 v1.9.67 要修的那个 bug。
   * 图床路径本身就是最强的「这是商品图」信号，比尺寸可靠。
   *
   * @param {RegExp}   pattern        只收地址匹配它的图（不要带 g 标志，避免 lastIndex 污染）
   * @param {string}   stopSelector   命中它的第一个节点之后的图全部不要（详情描述区）
   * @param {string}   insideSelector 只收这些容器内部的图（详情长图恢复用；与 stopSelector 二选一）
   * @param {string[]} excludeZones   排除区域（推荐位 / 评价 / 店铺卡片…）
   * @param {string}   origin         相对地址的补全基准
   * @param {number}   limit          最多收多少张
   * @param {boolean}  pierceShadow   是否穿透 shadow root（组件化改造后图集可能被封装）
   * @param {Element}  scopeRoot      只收这块区域（商品主体区）里的图，避免采到推荐位的图
   */
  function collectImagesByHostPattern({
    pattern,
    stopSelector = "",
    insideSelector = "",
    excludeZones = [],
    origin,
    limit = 30,
    pierceShadow = true,
    scopeRoot = null,
  } = {}) {
    const meta = Object.create(null);
    const urls = [];
    const zoneSelector = (excludeZones || []).filter(Boolean).join(", ");
    const baseOrigin = origin || location.origin || "https:";

    // 候选 <img>：光 DOM +（可选）shadow DOM。querySelectorAll 不跨 shadow 边界，
    // 只能逐层递归；用 seenRoots 去重，避免同一个宿主被反复遍历。
    const nodes = [];
    const seenRoots = new Set();
    const visit = (root, depth) => {
      if (!root || depth > 5 || typeof root.querySelectorAll !== "function" || seenRoots.has(root)) return;
      seenRoots.add(root);
      for (const node of root.querySelectorAll("img")) nodes.push(node);
      if (!pierceShadow) return;
      for (const host of root.querySelectorAll("*")) {
        if (host.shadowRoot) visit(host.shadowRoot, depth + 1);
      }
    };
    visit(document, 0);

    // 详情描述区的第一个节点：文档顺序在它之后的图属于详情长图，不是图集。
    // 用 compareDocumentPosition 判断先后，比 getBoundingClientRect 便宜得多（不会触发布局）。
    let stopNode = null;
    if (stopSelector && !insideSelector) {
      const found = all(stopSelector);
      if (found.length) {
        stopNode = found.reduce((a, b) => (a.compareDocumentPosition(b) & 2 ? b : a));
      }
    }
    const beforeStop = (node) => !stopNode || Boolean(stopNode.compareDocumentPosition(node) & 2);
    const insideBox = insideSelector
      ? (node) => Boolean(node.closest && node.closest(insideSelector))
      : () => true;

    const inScope = (node) => !scopeRoot
      || scopeRoot === document.body
      || scopeRoot === document.documentElement
      || scopeRoot === node
      || Boolean(scopeRoot.contains && scopeRoot.contains(node));

    for (const node of nodes) {
      if (!beforeStop(node) || !insideBox(node)) continue;
      if (!inScope(node)) continue;
      if (zoneSelector && node.closest && node.closest(zoneSelector)) continue;
      const normalized = normalizeImageUrl(imageSource(node), baseOrigin);
      if (!normalized || !pattern.test(normalized)) continue;
      const size = imageSize(node);
      const known = meta[normalized];
      if (known) {
        known.width = Math.max(known.width, size.width);
        known.height = Math.max(known.height, size.height);
        known.natural = known.natural || size.natural;
        continue;
      }
      meta[normalized] = { width: size.width, height: size.height, natural: size.natural };
      urls.push(normalized);
      if (urls.length >= limit) break;
    }

    const imageMeta = {};
    for (const url of urls) {
      imageMeta[url] = { width: meta[url].width, height: meta[url].height, natural: Boolean(meta[url].natural) };
    }
    return { images: urls, imageMeta };
  }
  function text(selector, root) {
    const node = (root || document).querySelector(selector);
    return node ? cleanText(node.textContent) : "";
  }

  function all(selector, root) {
    return Array.from((root || document).querySelectorAll(selector));
  }

  function meta(name) {
    const attr = arguments.length > 1 && arguments[1] ? "property" : "name";
    const node = document.querySelector(`meta[${attr}="${name}"]`);
    return node ? cleanText(node.getAttribute("content")) : "";
  }

  // 读取页面 JSON-LD，常用于拿标题/图片/价格
  function readJsonLd() {
    const blocks = [];
    for (const node of all('script[type="application/ld+json"]')) {
      try {
        const parsed = JSON.parse(node.textContent || "{}");
        blocks.push(parsed);
      } catch {
        /* 忽略单个坏块 */
      }
    }
    const flat = [];
    const walk = (value) => {
      if (Array.isArray(value)) value.forEach(walk);
      else if (value && typeof value === "object") {
        flat.push(value);
        if (value["@graph"]) walk(value["@graph"]);
      }
    };
    blocks.forEach(walk);
    return flat;
  }

  // 从整页 HTML/内联脚本中按 key 抓取 JSON 片段（应对无 JSON-LD 的站点）
  // 性能要点：整页 innerHTML 序列化 + 大正则回溯是采集最慢的一步。
  // 因此优先只在 <script> 文本里搜（体积通常小一个数量级），找不到才退回整页 HTML。
  function findInlineJson(patterns, source, cache) {
    const sources = source
      ? [source]
      : cache
        ? [cache.scripts(), cache.html()]
        : [document.documentElement.innerHTML];
    for (const text of sources) {
      if (!text) continue;
      for (const pattern of patterns) {
        const match = text.match(pattern);
        if (match && match[1]) {
          try {
            return JSON.parse(match[1]);
          } catch {
            try {
              return JSON.parse(match[1].replace(/\\"/g, '"'));
            } catch {
              /* 继续尝试下一个 pattern */
            }
          }
        }
      }
    }
    return null;
  }

  /**
   * 单次采集的页面数据缓存。innerText / innerHTML / script 文本 / JSON-LD 都很贵，
   * 而各 pick* 函数会重复读同一份数据（实测 innerText 在商品详情页要上百毫秒），
   * 统一缓存成读一次，并顺带记录每步耗时用于诊断。
   */
  function createPageCache() {
    let innerTextCache = null;
    let scriptsCache = null;
    let htmlCache = null;
    let jsonLdCache = null;
    let scopeCache = null;
    let scopeTextCache = null;
    const timing = Object.create(null);

    return {
      timing,
      /** 把一步操作的耗时记进 timing（单位 ms） */
      async time(label, fn) {
        const start = typeof performance !== "undefined" ? performance.now() : Date.now();
        try {
          return await fn();
        } finally {
          const end = typeof performance !== "undefined" ? performance.now() : Date.now();
          timing[label] = Math.round(end - start);
        }
      },
      innerText() {
        if (innerTextCache === null) innerTextCache = (document.body && document.body.innerText) || "";
        return innerTextCache;
      },
      /**
       * 商品主体区（v1.9.69）。所有「正则扫全页文本」的取值都必须改用 scopeText()，
       * 否则「成交 / 库存 / 发货地 / 毛重 / 参数」很容易来自推荐位里的另一件商品。
       */
      scope() {
        if (scopeCache === null) scopeCache = resolveProductScope();
        return scopeCache;
      },
      scopeText() {
        if (scopeTextCache === null) scopeTextCache = scopeTextOf(this.scope());
        return scopeTextCache;
      },
      scripts() {
        if (scriptsCache === null) scriptsCache = all("script").map((node) => node.textContent || "").join("\n");
        return scriptsCache;
      },
      html() {
        if (htmlCache === null) htmlCache = document.documentElement ? document.documentElement.innerHTML : "";
        return htmlCache;
      },
      jsonLd() {
        if (jsonLdCache === null) jsonLdCache = readJsonLd();
        return jsonLdCache;
      },
      reset() {
        innerTextCache = null;
        scriptsCache = null;
        htmlCache = null;
        jsonLdCache = null;
        scopeCache = null;
        scopeTextCache = null;
      },
    };
  }

  function waitFor(selector, timeout = 3000) {
    return new Promise((resolve) => {
      const immediate = document.querySelector(selector);
      if (immediate) return resolve(immediate);
      if (timeout <= 0) return resolve(null);
      const start = Date.now();
      // 用 80ms 轮询代替 rAF：同样即时，但长等待时不会每帧都跑一遍选择器
      const timer = setInterval(() => {
        const node = document.querySelector(selector);
        if (node || Date.now() - start > timeout) {
          clearInterval(timer);
          resolve(node || null);
        }
      }, 80);
    });
  }

  /** 等到容器里出现至少 minCount 张图（用于懒加载图集），超时直接放行不阻塞 */
  function waitForImages(selectors, { timeout = 900, minCount = 1 } = {}) {
    const list = Array.isArray(selectors) ? selectors : [selectors];
    const selector = list.join(", ");
    const count = () => all(selector).length;
    if (count() >= minCount) return Promise.resolve(count());
    return new Promise((resolve) => {
      const start = Date.now();
      const timer = setInterval(() => {
        const found = count();
        if (found >= minCount || Date.now() - start > timeout) {
          clearInterval(timer);
          resolve(found);
        }
      }, 80);
    });
  }

  function sleep(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  // 属性表：常见 "名称 / 值" 表格与 dl/dt/dd 结构
  // 大页面里 all("li, tr, div", container) 可能命中上千个节点，这里逐容器限量，避免拖慢采集
  const MAX_ATTR_ROWS_PER_CONTAINER = 200;

  // 明显不是「商品参数」的名字（多来自页面上的按钮/运营文案），采集时直接丢掉，提高精度
  const ATTR_NAME_BLOCKLIST = /^(?:月销|销量|成交|成交量|评价|评价数|评分|收藏|收藏数|分享|浏览|关注|加入购物车|立即购买|立即下单|客服|联系客服|服务|服务保障|优惠|促销|活动|包邮|运费|配送|发货|库存|数量|数量选择|请选择|宝贝|商品|详情|参数|推荐|猜你喜欢|相关推荐|看了又看)$/;
  const ATTR_VALUE_BAD = /^(?:https?:\/\/|￥?\s*0(?:\.0+)?\s*元?$|[-—–]+|无|暂无|null|undefined|NaN|\d+\.\d{3,})$/i;

  function extractAttributePairs(selectors) {
    const pairs = [];
    outer:
    for (const containerSel of selectors) {
      for (const container of all(containerSel)) {
        const rows = all("li, tr, div", container).slice(0, MAX_ATTR_ROWS_PER_CONTAINER);
        for (const row of rows) {
          const labelNode =
            row.querySelector(".name, .title, .key, th, dt, .attr-name, .J_AttrName") ||
            row.children[0];
          const valueNode =
            row.querySelector(".value, .val, .desc, td:last-child, dd, .attr-value, .J_AttrValue") ||
            row.children[row.children.length - 1];
          if (!labelNode || !valueNode || labelNode === valueNode) continue;
          const name = cleanText(labelNode.textContent).replace(/[:：]$/, "");
          const value = cleanText(valueNode.textContent);
          if (!name || !value) continue;
          if (name.length > 20 || value.length > 120) continue;
          if (name === value) continue;
          if (ATTR_NAME_BLOCKLIST.test(name)) continue;   // 运营文案/按钮，不是参数
          if (ATTR_VALUE_BAD.test(value)) continue;       // URL、0、纯横线等无意义值
          if (/^[\d.,\s￥¥$%]+$/.test(name)) continue;      // 「12.50」这种不是属性名
          if (!/[\u4e00-\u9fa5a-zA-Z]/.test(name)) continue; // 名字里得有中文或字母
          pairs.push({ name, value });
          if (pairs.length >= 400) break outer;
        }
      }
    }
    const seen = Object.create(null);
    return pairs.filter((pair) => {
      const key = pair.name + "|" + pair.value;
      if (seen[key]) return false;
      seen[key] = true;
      return true;
    });
  }

  function dedupeAttributes(list) {
    const seen = Object.create(null);
    const out = [];
    for (const item of list || []) {
      const name = cleanText(item && item.name);
      const value = cleanText(item && item.value);
      if (!name || !value) continue;
      const key = name;
      if (seen[key]) continue;
      seen[key] = true;
      out.push({ name, value });
    }
    return out;
  }

  /**
   * 创建适配器骨架。子类提供 capture()，基类负责注入公共字段与容错。
   */
  function createAdapter(config) {
    const notes = [];
    return Object.assign(
      {
        platform: config.platform,
        label: config.label || config.platform,
        matchHosts: config.matchHosts || [],
        note(message) {
          notes.push(String(message));
        },
        takeNotes() {
          const copy = notes.slice();
          notes.length = 0;
          return copy;
        },
        matches(host) {
          return this.matchHosts.some((item) => host === item || host.endsWith("." + item));
        },
        async capture() {
          return config.capture.call(this);
        },
      },
      config.overrides || {},
    );
  }

  registry.utils = {
    cleanText,
    parseNumber,
    normalizeImageUrl,
    dedupe,
    text,
    all,
    meta,
    readJsonLd,
    findInlineJson,
    createPageCache,
    waitFor,
    waitForImages,
    sleep,
    extractAttributePairs,
    dedupeAttributes,
    // 采集精度
    sanitizeTitle,
    looksLikeShopName,
    // v1.9.69 商品主体区：所有全页扫描都要收敛到它里面，避免采到页面里别的商品
    resolveProductScope,
    scopeTextOf,
    authoritativeTitle,
    RECOMMEND_ZONE_SELECTORS,
    parsePriceRange,
    dedupeSkus,
    pickPagePrice,
    // 图片采集与过滤
    collectImagesByHostPattern,
    collectImages,
    isLikelyProductImage,
    imageSource,
    imageSize,
    backgroundImageUrls,
    NON_PRODUCT_PATTERN,
  };

  // v1.9.92：懒加载轻扫调度器由 src/shared/lazy-sweep.js 自挂全局（content script 不能 import ESM），
  // 这里转放进 utils，adapter 与自测共用同一套调度数学。
  //
  // v1.9.94 关键加固：这张表以前只要有一个函数缺失，adapter 里就报
  // "withRetry is not a function" —— 整次采集中断，但错误信息完全指不到真因
  // （真因是 lazy-sweep.js 顶层写了 export，在 content script 这种传统脚本里是语法错误，
  //  整个文件加载失败、全局压根没挂上）。现在缺项直接在控制台点名，
  // 并且装一层兜底实现，保证「调度器没到位」最多让轻扫退化，不会让整个采集崩掉。
  const lazySweep = (typeof globalThis !== "undefined" && globalThis.__OZON_LAZY_SWEEP__) || null;
  const SWEEP_FNS = ["planSweepSteps", "sweepBudgetMs", "shouldRetrySweep", "withRetry", "countLoadableImages"];
  const missing = SWEEP_FNS.filter((name) => !lazySweep || typeof lazySweep[name] !== "function");
  if (missing.length) {
    console.error(
      `[Ozon] 懒加载调度器不可用，缺：${missing.join(", ")}。`
      + "请确认 manifest 的 content_scripts 里 src/shared/lazy-sweep.js 排在 adapter-base.js 之前，"
      + "且该文件不含顶层 import/export（content script 是传统脚本，不是 ES module）。",
    );
  }
  registry.utils.planSweepSteps = lazySweep?.planSweepSteps || (() => ({ steps: 1, stride: 0, continuous: false, note: "调度器缺失" }));
  registry.utils.sweepBudgetMs = lazySweep?.sweepBudgetMs || (() => 1500);
  registry.utils.shouldRetrySweep = lazySweep?.shouldRetrySweep || (() => false);
  registry.utils.withRetry = lazySweep?.withRetry || (async (fn) => {
    // 兜底：不重试也不抛，直接执行一次——降级但可用
    try { return { ok: true, value: await fn(0), error: null, attempts: 1 }; }
    catch (error) { return { ok: false, value: null, error, attempts: 1 }; }
  });
  registry.utils.countLoadableImages = lazySweep?.countLoadableImages || (() => 0);
  registry.createAdapter = createAdapter;
  registry.adapters = registry.adapters || [];
})(window);
