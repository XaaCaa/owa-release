/**
 * 图片处理服务（后台）。两种能力：
 *   1. 图片翻译：调用象寄开放平台（xiangjifanyi.com）把图上的中文整图替换为俄文。
 *      —— 图片发给象寄，返回翻译后的图片链接；按张计费。
 *   2. AI 重绘：调用 OpenAI 兼容的 /v1/images/generations 生成不含中文的新图（推荐硅基流动 Kolors）。
 */
import { sleep, normalizeApiBase, imagesEndpoint, modelsEndpoint } from "../shared/utils.js";
import { buildRedrawPrompt, buildShotPrompt, MAX_REFERENCE_IMAGES } from "../shared/image-prompts.js";

const XIANGJI_BASE = "https://api.tosoiot.com";
const CREATE_PATH = "/task/v1/image/translate";
const RESULT_PATH = "/task/v1/image/translate/result";
const POLL_INTERVAL_MS = 3000;
const BATCH_TIMEOUT_MS = 180000;
const SINGLE_TIMEOUT_MS = 60000;

export { normalizeKeyPool, chunkImages };

function cleanKey(apiKey) {
  const key = String(apiKey || "").trim();
  if (!key) throw new Error("未配置象寄 ImgTransKey，请到「插件设置 → 图片翻译与 AI 生图」添加密钥");
  return key;
}

/**
 * 把请求用的密钥归一化成 [{ key, vendor }]。
 * 兼容旧调用（只传 apiKey）：会当成单密钥池。
 */
function normalizeKeyPool({ keys, apiKey, vendor } = {}) {
  const list = (Array.isArray(keys) ? keys : [])
    .map((item) => (typeof item === "string"
      ? { key: item, vendor: vendor || "" }
      : { key: String(item?.key || ""), vendor: String(item?.vendor || vendor || "") }))
    .filter((item) => item.key);
  if (!list.length && apiKey) list.push({ key: String(apiKey), vendor: vendor || "" });
  if (!list.length) cleanKey(""); // 抛中文提示
  return list;
}

/** 把待翻译图片按可用密钥数切成若干块，让每个 Key 各自并行处理一批 */
function chunkImages(images, keyCount) {
  const size = Math.max(1, Math.ceil(images.length / Math.max(1, keyCount)));
  const chunks = [];
  for (let i = 0; i < images.length; i += size) chunks.push(images.slice(i, i + size));
  return chunks;
}

async function xiangjiRequest(path, apiKey, body) {
  const response = await fetch(`${XIANGJI_BASE}${path}`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "X-API-Key": cleanKey(apiKey),
    },
    body: JSON.stringify(body),
  });
  const payload = await response.json().catch(() => null);
  if (!response.ok) {
    const detail = payload?.message || payload?.error?.message || payload?.error || "";
    if (response.status === 401 || response.status === 403) {
      throw new Error("象寄 ImgTransKey 无效或已过期，请到 xiangjifanyi.com 开放平台重新获取");
    }
    throw new Error(`象寄翻译 HTTP ${response.status}${detail ? `：${detail}` : ""}`);
  }
  if (!payload || payload.code !== 0) {
    const detail = payload?.message || payload?.error || `code ${payload?.code}`;
    throw new Error(`象寄翻译返回错误：${detail}`);
  }
  return payload.data || {};
}

/** 创建任务并轮询到完成。返回与传入顺序一致的 results。 */
async function runTranslateTasks(images, { apiKey, vendor, source, target, useBase64 = false }) {
  const body = { source_language: source, target_language: target };
  if (vendor) body.translation_vendor = vendor;
  if (useBase64) {
    body.image_file_b64 = images[0];
    body.image_name = "ozon-translate.png";
  } else {
    body.image_urls = images;
  }

  const created = await xiangjiRequest(CREATE_PATH, apiKey, body);
  const taskIds = (created?.results || []).map((item) => item.task_id).filter(Boolean);
  if (taskIds.length !== images.length) {
    throw new Error(`象寄只受理了 ${taskIds.length}/${images.length} 张图片，请重试`);
  }

  const results = images.map((original) => ({ original, translated: "", textRemoved: "", error: "" }));
  const pending = new Set(taskIds);
  const deadline = Date.now() + (useBase64 ? SINGLE_TIMEOUT_MS : BATCH_TIMEOUT_MS);

  while (pending.size && Date.now() < deadline) {
    await sleep(POLL_INTERVAL_MS);
    let data;
    try {
      data = await xiangjiRequest(RESULT_PATH, apiKey, { task_ids: [...pending] });
    } catch (error) {
      // 单次查询失败不终止整体轮询，等下一次
      if (Date.now() >= deadline) throw error;
      continue;
    }
    for (const item of data?.results || []) {
      const index = taskIds.indexOf(item.task_id);
      if (index < 0) continue;
      if (item.translated_image) {
        results[index].translated = item.translated_image;
        results[index].textRemoved = item.text_removed_image || "";
        pending.delete(item.task_id);
      } else if (item.code && item.code !== 0 && item.code !== 114) {
        results[index].error = `象寄 code ${item.code}${item.message ? `：${item.message}` : ""}`;
        pending.delete(item.task_id);
      }
    }
  }

  for (const item of results) {
    if (!item.translated && !item.error) item.error = "翻译超时未完成，可稍后在象寄后台查看";
  }
  return results;
}

/**
 * 批量翻译图片文字（中文 → 俄语）。
 * 支持多密钥：把图片按密钥数切块并行提交，明显快于单 Key 串行；
 * 某块失败会自动换另一个 Key 重试。个别因防盗链取不到的，自动改用 base64 单张重试一次。
 * @param {{keys?: Array<{key:string,vendor:string}>, apiKey?: string, images: string[], vendor?: string,
 *          source?: string, target?: string, fetchAsDataUrl?: Function}} options
 */
export async function translateImagesWithXiangji({
  keys, apiKey, images = [], vendor = "", source = "CHS", target = "RUS", fetchAsDataUrl,
}) {
  const pool = normalizeKeyPool({ keys, apiKey, vendor });
  const list = images.filter((url) => /^https?:\/\//i.test(String(url || "").trim()));
  if (!list.length) throw new Error("草稿里没有可翻译的图片链接");

  // 单密钥时保持原来的整体提交（象寄一张请求受理多图，额度利用更紧凑）
  if (pool.length === 1) {
    const results = await runTranslateTasks(list, { apiKey: pool[0].key, vendor: pool[0].vendor || vendor, source, target });
    return retryFailedWithBase64(results, { pool, vendor, source, target, fetchAsDataUrl });
  }

  // 多密钥：切块并行，每块用自己的 Key；失败的块换 Key 再试一次
  const chunks = chunkImages(list, pool.length);
  const batches = await Promise.all(chunks.map((chunk, chunkIndex) => {
    const credentialIndex = chunkIndex % pool.length;
    const credential = pool[credentialIndex];
    return runTranslateTasks(chunk, { apiKey: credential.key, vendor: credential.vendor || vendor, source, target })
      // 把「这一块的密钥下标」带出去，换 Key 重试时才躲得开同一把（老实现恒取最后一把，
      // 最后一块失败时"换 Key"其实没换，重试白费）
      .then((results) => ({ credentialIndex, results }))
      .catch((error) => ({
        credentialIndex,
        results: chunk.map((original) => ({ original, translated: "", textRemoved: "", error: error?.message || String(error) })),
      }));
  }));
  for (const batch of batches) {
    for (const item of batch.results) {
      if (item.error && pool.length > 1) {
        // 换一个 Key 重试一次，多半是额度/并发限制
        const other = pool[(batch.credentialIndex + 1) % pool.length];
        try {
          const [retried] = await runTranslateTasks([item.original], { apiKey: other.key, vendor: other.vendor || vendor, source, target });
          if (retried?.translated) {
            item.translated = retried.translated;
            item.textRemoved = retried.textRemoved;
            item.error = "";
          }
        } catch {
          /* 保留原始错误 */
        }
      }
    }
  }
  const results = batches.map((batch) => batch.results).flat();
  return retryFailedWithBase64(results, { pool, vendor, source, target, fetchAsDataUrl });
}

/** URL 模式失败的改用 base64 逐张重试（防盗链场景） */
async function retryFailedWithBase64(results, { pool, vendor, source, target, fetchAsDataUrl }) {
  if (!results.some((item) => item.error) || typeof fetchAsDataUrl !== "function") return results;
  for (const item of results) {
    if (!item.error) continue;
    try {
      const dataUrl = await fetchAsDataUrl(item.original);
      const [retried] = await runTranslateTasks([dataUrl], {
        apiKey: pool[0].key,
        vendor: pool[0].vendor || vendor,
        source,
        target,
        useBase64: true,
      });
      if (retried?.translated) {
        item.translated = retried.translated;
        item.textRemoved = retried.textRemoved;
        item.error = "";
      }
    } catch (error) {
      item.error = `${item.error}；改用 base64 重试也失败：${error?.message || error}`;
    }
  }
  return results;
}

/** 阿里云百炼 Qwen-Image 系列：官方文档明确「图像生成不走 OpenAI 兼容模式」，
 * 只支持 DashScope 原生 /api/v1/services/aigc/multimodal-generation/generation；
 * /compatible-mode/v1/images/generations 会 404（实测）。
 * 用户在面板填 /api/v1、compatible-mode/v1 甚至裸域名，都统一归到原生端点。
 */
function isDashScopeImageModel(model) {
  const name = String(model || "").trim().toLowerCase();
  return /^qwen-image/.test(name);
}

/** DashScope 原生端点：无论用户填根域名、/api/v1 还是 compatible-mode/v1，都归到 origin + /api/v1 原生路径 */
function dashScopeEndpoint(baseUrl) {
  const base = normalizeApiBase(baseUrl);
  if (!base) return "";
  try {
    return `${new URL(base).origin}/api/v1/services/aigc/multimodal-generation/generation`;
  } catch {
    return "";
  }
}

/** DashScope 原生 API：qwen-image / qwen-image-2.0 / qwen-image-max 等。
 * 端点：POST {origin}/api/v1/services/aigc/multimodal-generation/generation
 * 尺寸格式：DashScope 用「宽*高」，插件统一存「宽x高」，这里做转换。
 * referenceImage（URL 或 data URL）传进来即为图生图：content 里先放参考图再放文字指令。
 * v1.9.38：支持 referenceImages（多张参考图）——图集 + 各变体图一起参考，全部排在文字前面。
 */
async function redrawWithDashScope({ baseUrl, apiKey, model, prompt = "", referenceImage = "", referenceImages = [], size = "1024x1024" }) {
  const url = dashScopeEndpoint(baseUrl);
  if (!url) throw new Error("请先填写 DashScope Base URL（如 https://dashscope.aliyuncs.com/api/v1）");
  if (!/^https?:\/\//i.test(url)) {
    throw new Error(`生图 Base URL 格式不对（读到的是「${normalizeApiBase(baseUrl)}」），应以 http:// 或 https:// 开头`);
  }
  const key = String(apiKey || "").trim();
  if (!key) throw new Error("请先填写 DashScope API Key");

  const rawSize = String(size || "").trim() || "1024x1024";
  const dashSize = rawSize.replace(/x/g, "*");
  // 参考全部产品图：主参考图 + 其余图集/SKU 图（去重，上限 MAX_REFERENCE_IMAGES）
  const refs = [...new Set([referenceImage, ...(Array.isArray(referenceImages) ? referenceImages : [])]
    .map((item) => String(item || "").trim()))].filter(Boolean).slice(0, MAX_REFERENCE_IMAGES);

  const body = {
    model: String(model || "").trim(),
    input: {
      messages: [
        {
          role: "user",
          // 图生图必须把参考图放在文字前面，DashScope 才按「编辑这张图」处理
          content: [
            ...refs.map((image) => ({ image })),
            { text: prompt },
          ],
        },
      ],
    },
    parameters: {
      size: dashSize,
      watermark: false,
      prompt_extend: true,
    },
  };

  // 调试日志：扩展管理页 → service worker → 控制台 可看到完整请求与响应
  // 生成失败时第一手信息在这里，复制这段发出来最快定位问题
  console.log("[Ozon/DashScope] request", { url, model, hasReference: refs.length > 0, referenceCount: refs.length, body });

  let response;
  try {
    response = await fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${key}`,
      },
      body: JSON.stringify(body),
    });
  } catch (networkError) {
    // 通常是 host_permissions 没拿到、或网络/SSL 出问题
    const host = (() => { try { return new URL(url).hostname; } catch { return "DashScope 域名"; } })();
    console.error("[Ozon/DashScope] fetch failed", networkError);
    throw new Error(
      `DashScope 请求失败（${host}）。最常见原因：扩展没拿到该域名的主机权限（请确认 manifest 已授予 *.maas.aliyuncs.com / *.aliyuncs.com，并重新加载扩展）。原始错误：${networkError?.message || networkError}`,
    );
  }

  const payload = await response.json().catch(() => null);
  console.log("[Ozon/DashScope] response", { status: response.status, body: payload });
  if (!response.ok) {
    const detail = payload?.message || payload?.error?.message || payload?.error || "";
    // 把服务端原始 body（截断）也带上，方便用户/开发者一眼看出参数被拒的原因
    const rawBody = payload ? JSON.stringify(payload).slice(0, 400) : "";
    if (response.status === 401) {
      throw new Error("DashScope API Key 无效或地域不匹配（模型、Key、Endpoint 必须同属一个地域）");
    }
    if (response.status === 404) {
      throw new Error(`DashScope 接口不存在（${url}）。请确认 Base URL 是 ${new URL(url).origin}/api/v1 这种形式；如果 URL 是工作空间专属域名，确认里面包含 WorkspaceId。另外也请核对模型名「${body.model}」是否存在于百炼控制台——模型不存在也会报 404。`);
    }
    // 传了参考图但模型不支持图生图 / 张数超限时，服务端往往只说「参数错误」，这里补一句人话
    const countLimitHint = /0-3 image|image content items/i.test(String(detail) + rawBody)
      ? "。参考图张数超过了模型上限（qwen-image-edit 最多 3 张）——插件已把参考图截到 3 张，若仍报错请更新插件版本"
      : "";
    const refHint = refs.length && /image|image_url|content|param|invalid/i.test(String(detail) + rawBody)
      ? "。当前请求带了参考图（图生图），如果报参数错误，多半是模型不支持图片输入——请改用 qwen-image-edit 系列（百炼图像编辑模型）"
      : "";
    throw new Error(
      `DashScope 生图失败：HTTP ${response.status}${detail ? `：${detail}` : ""}。请求模型：${body.model}，尺寸：${dashSize}${refs.length ? `，模式：图生图（${refs.length} 张参考图）` : ""}${countLimitHint}${refHint}。原始响应：${rawBody}`,
    );
  }

  const choices = payload?.output?.choices;
  const first = Array.isArray(choices) ? choices[0] : null;
  const content = first?.message?.content || [];
  const imageItem = content.find((item) => item && typeof item.image === "string");
  if (imageItem?.image) return { url: imageItem.image };

  throw new Error(`DashScope 生图接口返回成功但无图片 URL。原始响应：${JSON.stringify(payload).slice(0, 400)}`);
}

/** 调用生图。返回 data URL 或图片 URL。
 * Qwen-Image（DashScope/百炼）走原生接口；其它服务走 OpenAI 兼容 /v1/images/generations。
 * referenceImage 传了就是图生图（基于本产品出图），不传就是纯文生图。
 * v1.9.38：referenceImages 可传多张（图集 + 变体图全参考）；OpenAI 兼容端点大多只认单张，取主参考图。
 * shot 传了则用上架套图的对应拍摄方案拼提示词。
 */
export async function redrawImage({
  baseUrl, apiKey, model, context = "", styleHint = "", size = "1024x1024", aspectRatio = "",
  shot = "", points = "", referenceImage = "", referenceImages = [],
  extraInfo = "", title = "", subtitle = "", labels = [],
  direction = null, allowWhiteBg = false,
  layoutSeed = 0, framingSeed = 0, artDirection = "", reworkNote = "",
  plannedPrompt = "",
}) {
  // v1.9.73 策划师模式：面板已用 image-plan.buildPlannedPrompt 拼好完整英文出图指令（含俄文渲染文字与硬约束），
  // 直接采用，跳过逐张轮换那套。缺省时走原来的方案/兜底链路，旧行为一行不变。
  const prompt = plannedPrompt
    ? plannedPrompt
    : shot
      ? buildShotPrompt({
        shot, context, styleHint, points, extraInfo, title, subtitle, labels, direction, allowWhiteBg,
        // v1.9.49 逐图定制：版式/取景种子 + 该图专属导演方案 + 重出时的调整方向
        layoutSeed, framingSeed, artDirection, reworkNote,
      })
      : buildRedrawPrompt({ context, styleHint });

  // 阿里云百炼 Qwen-Image：官方明确不支持 OpenAI 兼容模式（/compatible-mode/v1/images/generations 会 404），
  // 必须走 DashScope 原生 /api/v1/services/aigc/multimodal-generation/generation。
  if (isDashScopeImageModel(model)) {
    if (!baseUrl) throw new Error("请先填写生图 Base URL（如 https://dashscope.aliyuncs.com/api/v1）");
    try {
      return await redrawWithDashScope({ baseUrl, apiKey, model, prompt, referenceImage, referenceImages, size });
    } catch (error) {
      // 实测：工作空间专属域名（*.maas.aliyuncs.com）对浏览器裸 fetch 会报
      // 「required OSS authorization headers are missing or invalid」——那是给 SDK 用的网关。
      // 此时自动改用官方标准域名 dashscope.aliyuncs.com 重试一次（官方文档明确「现有域名仍可正常使用」）。
      const isMaas = /\.maas\.aliyuncs\.com/i.test(String(baseUrl));
      const message = String(error?.message || error);
      if (isMaas && !/Key 无效/.test(message)) {
        console.warn("[Ozon/DashScope] 工作空间域名失败，自动回退标准域名 dashscope.aliyuncs.com：", message);
        return await redrawWithDashScope({
          baseUrl: "https://dashscope.aliyuncs.com/api/v1",
          apiKey, model, prompt, referenceImage, referenceImages, size,
        });
      }
      throw error;
    }
  }

  if (!baseUrl) throw new Error("请先填写生图 Base URL（如 https://api.siliconflow.cn/v1）");
  if (!/^https?:\/\//i.test(normalizeApiBase(baseUrl))) {
    throw new Error(`生图 Base URL 格式不对（读到的是「${normalizeApiBase(baseUrl)}」），应以 http:// 或 https:// 开头，例如 https://api.siliconflow.cn/v1`);
  }
  return generateImageOpenAICompatible({ base: baseUrl, apiKey, model, prompt, referenceImage, referenceImages, size, aspectRatio });
}

/** OpenAI 兼容生图请求体与响应解析（被 redrawImage 复用） */
async function generateImageOpenAICompatible({ base, apiKey, model, prompt, referenceImage = "", referenceImages = [], size, aspectRatio }) {
  const url = imagesEndpoint(base);
  if (!url) throw new Error("请先填写生图 Base URL（如 https://api.siliconflow.cn/v1）");
  if (!/^https?:\/\//i.test(url)) {
    throw new Error(`生图 Base URL 格式不对（读到的是「${normalizeApiBase(base)}」），应以 http:// 或 https:// 开头，例如 https://api.siliconflow.cn/v1`);
  }
  const finalSize = String(size || "").trim() || "1024x1024";
  // OpenAI 兼容端点大多只认单张参考图：主参考图优先，没传再退到多参考图的第一张
  const ref = String(referenceImage || "").trim()
    || (Array.isArray(referenceImages) ? String(referenceImages[0] || "").trim() : "");
  const payloadBody = {
    model: String(model || "").trim(),
    prompt,
    // size 与 image_size 同时带上：OpenAI 与硅基流动各自认一个，多余字段会被忽略
    size: finalSize,
    image_size: finalSize,
    n: 1,
    batch_size: 1,
    // 硅基流动 Kolors 的图生图：image 传 URL 或 base64 都行；不带该字段就是文生图
    ...(ref ? { image: ref } : {}),
  };

  console.log("[Ozon/生图] request", { url, model: payloadBody.model, size: finalSize, hasReference: Boolean(ref) });

  const response = await fetch(url, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${String(apiKey || "").trim()}`,
    },
    body: JSON.stringify(payloadBody),
  });
  const payload = await response.json().catch(() => null);
  console.log("[Ozon/生图] response", { status: response.status, url, body: payload });
  if (!response.ok) {
    const message = payload?.error?.message || payload?.message || "";
    if (response.status === 401) throw new Error("生图 API Key 无效，请检查插件设置里的 Key");
    if (response.status === 404) throw new Error(`生图接口不存在：${url}。请确认 Base URL 结尾是 /v1（如 https://api.siliconflow.cn/v1）`);
    throw new Error(`生图失败：HTTP ${response.status}${message ? `：${message}` : ""}`);
  }
  const item = payload?.data?.[0] || payload?.images?.[0];
  if (item) {
    if (typeof item === "string") return { url: item };
    if (item.b64_json) return { dataUrl: `data:image/png;base64,${item.b64_json}` };
    if (item.url) return { url: item.url };
    throw new Error("生图接口返回内容无法识别");
  }
  // 服务返回了任务号、没直接给图 —— 进入异步轮询（兼容中转站常见的「async task」流程）
  const taskId = payload?.task_id || payload?.taskId || payload?.id || payload?.data?.task_id || "";
  if (taskId) {
    return await pollAsyncImageTask({ baseUrl: base, apiKey, submitUrl: url, taskId });
  }
  throw new Error("生图接口未返回图片，也未返回任务号");
}

/**
 * 异步出图轮询。兼容中转站「先返回 task_id、需轮询取图」的常见实现。
 * - 轮询 90s（每 2s 一次）；
 * - 候选端点按提交地址推出，覆盖大多数中转的命名习惯；
 * - 状态包含 fail/canceled 等明确错误时立即抛错，不傻等到超时。
 */
async function pollAsyncImageTask({
  baseUrl, apiKey, submitUrl, taskId,
  timeoutMs = 90000, pollIntervalMs = 2000,
}) {
  // 从 submitUrl 推候选轮询端点。daWa 实测走 /v1/images/edits/{taskId}，
  // 但其它中转可能放在 /v1/images/generations/{taskId} 或 /v1/tasks/{taskId}，
  // 这里一并尝试，第一个返回 200 且带图片的就采用。
  const basePath = String(submitUrl || "").replace(/\/(generations|edits)\/?$/, "");
  const candidates = [
    `${basePath}/generations/${taskId}`,
    `${basePath}/edits/${taskId}`,
    `${basePath}/tasks/${taskId}`,
  ];
  const headers = { Authorization: `Bearer ${String(apiKey || "").trim()}` };
  const startedAt = Date.now();
  let lastError = "";

  for (let attempt = 1; ; attempt++) {
    if (Date.now() - startedAt >= timeoutMs) {
      throw new Error(`生图任务等待超时（task ${taskId}，${Math.round(timeoutMs / 1000)}s 内未完成）。最后一次错误：${lastError || "无"}`);
    }

    for (const pollUrl of candidates) {
      try {
        const r = await fetchWithTimeout(pollUrl, { method: "GET", headers }, 8000);
        if (!r.ok) { lastError = `${pollUrl} HTTP ${r.status}`; continue; }
        const p = await r.json().catch(() => null);
        const it = p?.data?.[0] || p?.images?.[0];
        if (it) {
          if (typeof it === "string") return { url: it };
          if (it.b64_json) return { dataUrl: `data:image/png;base64,${it.b64_json}` };
          if (it.url) return { url: it.url };
        }
        const status = String(p?.status || p?.state || "").toLowerCase();
        if (status && /(fail|error|canceled|cancelled|rejected)/.test(status)) {
          throw new Error(`生图任务被服务端标记为失败（task ${taskId}，状态：${status}）`);
        }
        // 200 但没图片、没失败 → 还在跑，继续
      } catch (e) {
        if (e?.message?.includes("服务端标记为失败")) throw e;
        lastError = `${pollUrl} ${e?.message || e}`;
      }
    }
    await sleep(pollIntervalMs);
  }
}

/* ---------------- 可用性检测（不消耗额度的探针） ---------------- */

function maskKey(key) {
  const value = String(key || "");
  if (value.length <= 8) return value ? "••••" : "";
  return `${value.slice(0, 4)}••••${value.slice(-4)}`;
}

async function fetchWithTimeout(url, init = {}, timeoutMs = 30000) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const response = await fetch(url, { ...init, signal: controller.signal });
    return response;
  } finally {
    clearTimeout(timer);
  }
}

// 象寄返回的 message 里若带这些词，说明是鉴权/密钥问题，而不是「任务不存在」这类正常业务错
const AUTH_ERROR_PATTERN = /(key|密钥|标识码|鉴权|认证|未授权|无效|invalid|unauthor|forbidden|过期|expire|额度|余额|quota|balance)/i;

/**
 * 探测单把象寄 ImgTransKey 是否可用。
 * 走「查询翻译任务」接口并传一个不存在的 task_id：
 *   - 该接口不创建任务、不上传图片，因此不消耗额度；
 *   - 鉴权在业务之前，密钥无效会直接 401/403，能准确区分。
 */
export async function testXiangjiKey({ apiKey, vendor = "" }) {
  const key = String(apiKey || "").trim();
  if (!key) return { ok: false, vendor, keyMask: "", error: "未填写密钥" };
  let response;
  try {
    response = await fetchWithTimeout(`${XIANGJI_BASE}${RESULT_PATH}`, {
      method: "POST",
      headers: { "Content-Type": "application/json", "X-API-Key": key },
      body: JSON.stringify({ task_ids: ["__ozon_lister_probe__"] }),
    }, 15000);
  } catch (error) {
    const aborted = error?.name === "AbortError";
    return { ok: false, vendor, keyMask: maskKey(key), error: aborted ? "连接象寄超时（15s），请检查网络" : `无法连接象寄：${error?.message || error}` };
  }

  const payload = await response.json().catch(() => null);
  const detail = String(payload?.message || payload?.error?.message || payload?.error || "");
  if (response.status === 401 || response.status === 403) {
    return { ok: false, vendor, keyMask: maskKey(key), error: "ImgTransKey 无效或已过期，请到 xiangjifanyi.com 开放平台重新获取" };
  }
  if (!response.ok) {
    return { ok: false, vendor, keyMask: maskKey(key), error: `象寄 HTTP ${response.status}${detail ? `：${detail}` : ""}` };
  }
  // 2xx：鉴权已通过。code!==0 多半只是「任务不存在」，但只要 message 指向鉴权/额度问题就仍判失败
  if (payload && payload.code !== 0) {
    if (AUTH_ERROR_PATTERN.test(detail)) {
      return { ok: false, vendor, keyMask: maskKey(key), error: `密钥不可用：${detail || `code ${payload.code}`}` };
    }
    return { ok: true, vendor, keyMask: maskKey(key), note: `密钥可用（象寄返回 code ${payload.code}${detail ? `：${detail}` : ""}）` };
  }
  return { ok: true, vendor, keyMask: maskKey(key), note: "密钥可用" };
}

/** 批量检测多把密钥（同引擎可多把）。返回逐条结果 + 汇总。 */
export async function testXiangjiKeys({ keys = [] } = {}) {
  const pool = (Array.isArray(keys) ? keys : []).filter((item) => item && item.key);
  if (!pool.length) {
    return { ok: false, error: "没有可取用的密钥，请先添加该引擎的 ImgTransKey", results: [] };
  }
  const results = await Promise.all(pool.map((item) => testXiangjiKey({ apiKey: item.key, vendor: item.vendor })));
  const okCount = results.filter((item) => item.ok).length;
  return {
    ok: okCount > 0,
    results,
    total: results.length,
    usable: okCount,
    error: okCount ? "" : "所有密钥都不可用，请检查密钥是否填错或已过期",
  };
}

/**
 * 探测 AI 生图服务是否可用。
 * 走 OpenAI 兼容的 GET /models：只校验地址与 Key，不生成图片，因此不消耗额度。
 * 部分服务未开放该接口（404/405）时会明确说明无法免额度验证。
 */
export async function testImageGeneration({ baseUrl, apiKey, model }) {
  const raw = String(baseUrl ?? "").trim();
  const base = normalizeApiBase(baseUrl);
  const key = String(apiKey || "").trim();
  if (!base) return { ok: false, error: "请先填写生图 Base URL（如 https://api.siliconflow.cn/v1）" };
  if (!/^https?:\/\//i.test(base)) {
    // 输入是一整段配置文本（含 { } 或超长）时不再回显，避免把 JSON 又怼回给用户
    const isBlob = /[{}]/.test(raw) || raw.length > 120;
    const echo = raw && !isBlob ? `；原始输入：「${raw}」` : "";
    return {
      ok: false,
      baseUrl: base,
      error: `生图 Base URL 格式不对（读到的是「${base}」）。请填成 https://api.siliconflow.cn/v1 这样；如果是从网页复制来的，注意里面可能混了全角冒号或看不见的零宽字符${echo}`,
    };
  }
  const endpoint = imagesEndpoint(base);
  const url = modelsEndpoint(base);
  if (!key) {
    return { ok: false, baseUrl: base, endpoint, error: "请先填写生图 API Key（留空时会复用上方 AI 配置的 Key）" };
  }

  // 阿里云百炼 Qwen-Image 走 DashScope 原生接口（不提供 /models 探测），实际生图打原生端点
  if (isDashScopeImageModel(model)) {
    const endpoint = dashScopeEndpoint(base);
    return {
      ok: true,
      baseUrl: base,
      endpoint,
      probeUnsupported: true,
      model: String(model || "").trim(),
      note: "DashScope / 百炼 Qwen-Image 只走原生接口，且不提供 /models 探测，地址与 Key 格式已校验。可点「生成重绘图」实测（会消耗一次额度）。实际生图会请求 " + endpoint,
    };
  }

  let response;
  try {
    response = await fetchWithTimeout(url, {
      method: "GET",
      headers: { Authorization: `Bearer ${key}` },
    }, 20000);
  } catch (error) {
    const aborted = error?.name === "AbortError";
    return {
      ok: false,
      baseUrl: base,
      endpoint,
      error: aborted ? `连接生图服务超时（20s）：${url}` : `无法连接生图服务：${error?.message || error}`,
    };
  }

  const payload = await response.json().catch(() => null);
  const detail = String(payload?.error?.message || payload?.message || "");
  if (response.status === 401 || response.status === 403) {
    return { ok: false, baseUrl: base, endpoint, error: "生图 API Key 无效或没有权限，请检查插件设置里的 Key" };
  }
  if (response.status === 404 || response.status === 405) {
    return {
      ok: false,
      baseUrl: base,
      endpoint,
      probeUnsupported: true,
      error: `该服务未开放 ${url} 探测接口（HTTP ${response.status}），无法免额度验证。可点「生成重绘图」实测（会消耗一次额度）。实际生图会请求 ${endpoint}`,
    };
  }
  if (!response.ok) {
    return { ok: false, baseUrl: base, endpoint, error: `生图服务返回 HTTP ${response.status}${detail ? `：${detail}` : ""}（探测地址 ${url}）` };
  }

  // 200：地址与 Key 都通过。顺便核对模型名是否存在
  const models = (Array.isArray(payload?.data) ? payload.data : [])
    .map((item) => String(item?.id || item?.name || "").trim())
    .filter(Boolean);
  const wanted = String(model || "").trim();
  const modelFound = wanted ? models.some((id) => id === wanted || id.toLowerCase() === wanted.toLowerCase()) : true;
  return {
    ok: true,
    baseUrl: base,
    endpoint,
    probeUrl: url,
    modelCount: models.length,
    modelFound,
    model: wanted,
    models: models.slice(0, 12),
    note: !wanted
      ? `地址与 Key 可用（${endpoint}），但尚未填写生图模型名称`
      : modelFound
        ? `连接正常，模型「${wanted}」在可用列表里`
        // 「wanted」就是面板「生图模型名称」输入框里填的值 —— 写清楚来源，免得用户以为这个模型名是插件自己冒出来的
        : `地址与 Key 可用，但可用模型列表里没有「${wanted}」。「${wanted}」是你在「生图模型名称」里填的值，请照下方可用模型列表核对（见下）`,
  };
}
