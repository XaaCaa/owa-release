/**
 * OpenAI 兼容的 AI 客户端。
 * 只请求用户自己填写的 baseUrl；不要在 baseUrl 里填不受信任的第三方中转站，
 * 因为 API Key 会随请求一起发送。
 */
import { cleanText, normalizeApiBase } from "../shared/utils.js";

export function normalizeBaseUrl(baseUrl) {
  // 统一走 normalizeApiBase：去掉复制粘贴带进来的零宽字符 / 全角冒号，漏写协议时补 https://
  const value = normalizeApiBase(baseUrl);
  if (!value) throw new Error("请先填写 AI Base URL");
  if (!/^https?:\/\//i.test(value)) {
    throw new Error(`AI Base URL 必须以 http:// 或 https:// 开头（当前读到的是「${value}」）`);
  }
  return value;
}

/**
 * 拼接 chat 端点。规则与生图（imagesEndpoint）保持一致：
 *   裸域名（https://api.siliconflow.cn）        → https://api.siliconflow.cn/v1/chat/completions
 *   带 /v1                              → https://x.cn/v1/chat/completions
 *   已是完整端点                        → 原样返回
 *   自定义非 /vN 路径（https://x.cn/api）→ https://x.cn/api/chat/completions
 * 少这一步，「从渠道配置里拆出来的裸域名」会打到 /chat/completions 直接 404。
 */
export function buildChatEndpoint(baseUrl) {
  const base = normalizeBaseUrl(baseUrl);
  if (/\/chat\/completions$/i.test(base)) return base;
  if (/\/v\d+$/i.test(base)) return `${base}/chat/completions`;
  if (/^https?:\/\/[^/?#]+$/i.test(base)) return `${base}/v1/chat/completions`;
  return `${base}/chat/completions`;
}

function assertKey(apiKey) {
  if (!cleanText(apiKey)) throw new Error("请先填写 AI API Key");
  return cleanText(apiKey);
}

/** 一次性生成（非流式），返回完整文本 */
export async function chatComplete({ baseUrl, apiKey, model, messages, temperature = 0.7, timeoutMs = 120000 }) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const response = await fetch(buildChatEndpoint(baseUrl), {
      method: "POST",
      signal: controller.signal,
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${assertKey(apiKey)}`,
      },
      body: JSON.stringify({
        model: cleanText(model) || "deepseek-chat",
        messages,
        temperature,
        stream: false,
      }),
    });
    const payload = await response.json().catch(() => null);
    if (!response.ok) {
      throw new Error(extractError(payload) || `AI 请求失败：HTTP ${response.status}`);
    }
    const content = payload?.choices?.[0]?.message?.content;
    if (typeof content !== "string" || !content.trim()) throw new Error("AI 返回内容为空");
    return content;
  } finally {
    clearTimeout(timer);
  }
}

/**
 * 流式生成，逐块回调。用于面板实时预览。
 * onDelta(textChunk) => void
 */
export async function chatCompleteStream({ baseUrl, apiKey, model, messages, temperature = 0.7, onDelta, timeoutMs = 180000 }) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  let full = "";
  try {
    const response = await fetch(buildChatEndpoint(baseUrl), {
      method: "POST",
      signal: controller.signal,
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${assertKey(apiKey)}`,
        Accept: "text/event-stream",
      },
      body: JSON.stringify({
        model: cleanText(model) || "deepseek-chat",
        messages,
        temperature,
        stream: true,
      }),
    });
    if (!response.ok || !response.body) {
      const payload = await response.json().catch(() => null);
      throw new Error(extractError(payload) || `AI 请求失败：HTTP ${response.status}`);
    }

    const reader = response.body.getReader();
    const decoder = new TextDecoder("utf-8");
    let buffer = "";
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split("\n");
      buffer = lines.pop() || "";
      for (const line of lines) {
        const trimmed = line.trim();
        if (!trimmed.startsWith("data:")) continue;
        const data = trimmed.slice(5).trim();
        if (!data || data === "[DONE]") continue;
        let parsed = null;
        try {
          parsed = JSON.parse(data);
        } catch {
          continue;
        }
        const delta = parsed?.choices?.[0]?.delta?.content;
        if (typeof delta === "string" && delta) {
          full += delta;
          onDelta?.(delta, full);
        }
      }
    }
    return full;
  } finally {
    clearTimeout(timer);
  }
}

/** 连通性自检：用极短请求验证 Key 与地址可用 */
export async function testConnection({ baseUrl, apiKey, model }) {
  // 把规范化后的地址回给面板：用户填的地址若混了全角冒号/零宽字符或漏了协议，面板可以直接纠正
  const normalized = normalizeApiBase(baseUrl);
  try {
    const content = await chatComplete({
      baseUrl: normalized,
      apiKey,
      model,
      messages: [{ role: "user", content: "ping" }],
      timeoutMs: 30000,
    });
    return { ok: true, sample: String(content || "").slice(0, 80), baseUrl: normalized };
  } catch (error) {
    return { ok: false, error: error?.message || String(error), baseUrl: normalized };
  }
}

function extractError(payload) {
  if (!payload) return "";
  if (typeof payload.error === "string") return payload.error;
  return payload.error?.message || payload.message || "";
}

export { assertKey };
