/**
 * Ozon Seller API 封装。
 * 所有请求固定打到官方 https://api-seller.ozon.ru，凭证只来自本地存储。
 * 接口字段以官方当前文档为准；这里不猜测未确认的接口。
 */
import { OZON_API_BASE } from "../shared/constants.js";
import { cleanText } from "../shared/utils.js";
import { normalizeAttributeDefinition, validateAttributeValues, snapAttributeValues, buildStableModel, buildProductModelName } from "../shared/product-model.js";
import { collectBrandRisks, formatBrandRisk } from "../shared/brand-risk.js";

function assertCredentials({ clientId, apiKey }) {
  if (!cleanText(clientId) || !cleanText(apiKey)) {
    throw new Error("请先填写 Ozon Client-Id 与 Api-Key");
  }
}

/**
 * 中文规格维度 → Ozon 类目属性的匹配字典（达瓦式思路：依规格名把每个 SKU 维度映射到
 * 该类目真实存在的 Ozon 属性，从而生成「真变体」而非只挂一个规格标签）。
 * ru 为 Ozon 属性名里常见的俄文/英文片段；dim 为采集端常出现的中文维度名。
 */
const SPEC_ATTR_DICT = [
  { dim: ["颜色", "色彩", "花色", "颜色分类"], needle: ["цвет", "color"] },
  { dim: ["尺码", "尺寸", "大小", "号型", "鞋码"], needle: ["размер", "size"] },
  { dim: ["材质", "面料", "材料", "成份", "成分"], needle: ["материал", "material", "состав", "composition"] },
  { dim: ["型号", "款式", "样式", "型号规格"], needle: ["модель", "model", "стиль", "style"] },
  { dim: ["容量", "容积"], needle: ["объем", "capacity", "ёмкость", "емкость"] },
  { dim: ["功率"], needle: ["мощность", "power"] },
  { dim: ["电压"], needle: ["напряжение", "voltage"] },
  { dim: ["适用季节", "季节"], needle: ["сезон", "season"] },
  { dim: ["图案", "花纹"], needle: ["узор", "pattern", "рисунок"] },
  { dim: ["版型"], needle: ["крой", "fit"] },
  { dim: ["品牌"], needle: ["бренд", "brand"] },
  { dim: ["数量", "件数", "支数", "条数"], needle: ["количество", "quantity", "count"] },
  { dim: ["风格"], needle: ["стиль", "style"] },
  { dim: ["形状"], needle: ["форма", "shape"] },
  { dim: ["适用人群", "人群"], needle: ["возраст", "age", "пол", "gender"] },
  { dim: ["套餐", "套装"], needle: ["комплект", "set", "набор"] },
];

/**
 * 把某个中文规格维度名，在该类目属性定义里找到对应的 Ozon 属性对象。
 * v1.9.50 起优先级变了：**先找 Ozon 标记为变体属性（is_aspect=true）的**，
 * 因为只有变体属性才能把多个 SKU 合并成同一张商品卡并区分出规格；
 * 名字对得上但不是变体属性时仍返回（旧行为，少量类目确实用普通属性区分规格），
 * 名字完全对不上、而该类目又只有一个变体属性时，就认那一个（如「颜色」）。
 */
function matchSpecToAttribute(dimName, categoryAttributes = []) {
  const dim = cleanText(dimName).toLowerCase();
  if (!dim) return null;
  const attrs = (categoryAttributes || []).filter((attr) => Number(attr?.id));
  if (!attrs.length) return null;
  const entry = SPEC_ATTR_DICT.find((e) => e.dim.some((d) => dim.includes(d) || d.includes(dim)));
  // 兜底：有些类目属性名会直接带中文（本地化），把中文维度名也作为匹配串
  const allNeedles = [...new Set([...(entry ? entry.needle : []), dim])];
  const byName = (pool) => pool.find((attr) => {
    const name = cleanText(attr.name || attr.attribute_name || attr.title).toLowerCase();
    if (!name) return false;
    return allNeedles.some((n) => n && name.includes(n));
  });
  const aspects = attrs.filter((attr) => attr.is_aspect);
  const aspectHit = byName(aspects);
  if (aspectHit) return aspectHit;
  const nameHit = byName(attrs);
  if (nameHit) return nameHit;
  // 维度名连字典都没收录、而该类目只有一个变体属性：几乎只能是它（极少数情况会认错，
  // 所以面板会把「维度 → 属性」的对应关系显示出来，用户可手改）
  if (!entry && aspects.length === 1) return aspects[0];
  return null;
}

/**
 * 把一个 SKU 的各个规格维度，映射成 Ozon 上传用的变体属性数组
 * （每个维度 = 一条 {complex_id:0, id, values:[...]}）。
 * 只输出「确实存在于该类目属性定义」的维度，避免编造不存在的属性 ID 导致 400。
 * v1.9.50：枚举型变体属性（颜色等）优先发 dictionary_value_id —— 只发自由文本会被 Ozon
 * 判成「属性不正确：不要手输这些值，请从列表中选择一个属性值」。
 */
export function buildVariantAttributes(sku = {}, categoryAttributes = []) {
  const specs = (sku && sku.specs) || {};
  const out = [];
  const usedIds = new Set();
  for (const [dim, valueRaw] of Object.entries(specs)) {
    const value = cleanText(valueRaw);
    if (!value) continue;
    const attr = matchSpecToAttribute(dim, categoryAttributes);
    if (!attr || !attr.id || usedIds.has(Number(attr.id))) continue;
    usedIds.add(Number(attr.id));
    out.push({ complex_id: 0, id: Number(attr.id), values: [matchDictionaryValue(attr.dictionary, value)] });
  }
  return out;
}

/**
 * 把一批选用 SKU 的规格维度，汇总成「这个商品的变体属性」清单。
 * 面板用它自动识别变体属性 ID（替掉过去让用户手填 10096 的做法），
 * 上传时也用它判断「能不能真的出成多变体」。
 * 返回 [{ id, name, dim, isAspect, dictionaryId, values }]。
 */
export function resolveVariantAttributes(skus = [], categoryAttributes = []) {
  const dims = new Map(); // 维度名 → 出现过的值
  for (const sku of skus || []) {
    for (const [dimRaw, valueRaw] of Object.entries(sku?.specs || {})) {
      const dim = cleanText(dimRaw);
      const value = cleanText(valueRaw);
      if (!dim) continue;
      if (!dims.has(dim)) dims.set(dim, new Set());
      if (value) dims.get(dim).add(value);
    }
  }
  const out = [];
  const used = new Set();
  for (const [dim, values] of dims) {
    if (!values.size) continue;
    const attr = matchSpecToAttribute(dim, categoryAttributes);
    const id = Number(attr?.id) || 0;
    if (!id || used.has(id)) continue;
    used.add(id);
    out.push({
      id,
      name: cleanText(attr.name) || dim,
      dim,
      isAspect: Boolean(attr.is_aspect),
      dictionaryId: Number(attr.dictionary_id) || 0,
      values: [...values],
    });
  }
  return out;
}

/**
 * 把一个规格值对到字典项上，返回 Ozon 上传用的 value 对象。
 * 命中字典 → 同时给 dictionary_value_id（Ozon 靠它认枚举值）；
 * 没命中 → 只给文本，由调用方决定要不要拦。
 * 匹配做三级：原样 → 去空格/大小写 → 去「色」这类后缀的基词。
 */
export function matchDictionaryValue(dictionary = [], value = "") {
  const text = cleanText(value);
  const plain = { value: text };
  if (!dictionary.length || !text) return plain;
  const norm = (s) => cleanText(s).toLowerCase().replace(/\s+/g, "");
  const base = (s) => norm(s).replace(/色系$/, "").replace(/色$/, "");
  const target = norm(text);
  const targetBase = base(text);
  const hit = dictionary.find((item) => norm(item.value) === target)
    || dictionary.find((item) => base(item.value) === targetBase);
  if (!hit) return plain;
  return Number(hit.id) ? { value: hit.value, dictionary_value_id: Number(hit.id) } : { value: hit.value };
}

async function request(credentials, path, body = {}, timeoutMs = 60000) {
  assertCredentials(credentials);
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const response = await fetch(`${OZON_API_BASE}${path}`, {
      method: "POST",
      signal: controller.signal,
      headers: {
        "Content-Type": "application/json",
        "Client-Id": cleanText(credentials.clientId),
        "Api-Key": cleanText(credentials.apiKey),
      },
      body: JSON.stringify(body || {}),
    });
    const payload = await response.json().catch(() => null);
    if (!response.ok) {
      const message = payload?.message || payload?.error?.message || payload?.error || "";
      // 常见凭证问题给中文指引，避免用户面对英文原文无从下手
      if (response.status === 403 && /deactivated/i.test(message)) {
        throw new Error(
          "Ozon 返回 403：这个 Api-Key 已失效（deactivated）。请登录 seller.ozon.ru → 设置 → API 密钥，生成新的 Api-Key，然后在扩展「设置」页替换（Client-Id 不变）。",
        );
      }
      if (response.status === 401) {
        throw new Error(
          "Ozon 返回 401：Client-Id 或 Api-Key 不正确。请到 seller.ozon.ru → 设置 → API 密钥 核对后重新填写。",
        );
      }
      if (response.status === 404) {
        throw new Error(
          `Ozon 返回 404：接口路径不存在（${path}）。可能是 Ozon 调整了 API 版本，请把此信息反馈给开发者。`,
        );
      }
      throw new Error(`Ozon HTTP ${response.status}${message ? `：${message}` : ""}`);
    }
    return payload || {};
  } finally {
    clearTimeout(timer);
  }
}

export async function testConnection(credentials) {
  try {
    // 用最小分页请求验证凭证
    const result = await request(credentials, "/v3/product/list", { filter: { visibility: "ALL" }, limit: 1 }, 30000);
    return { ok: true, total: result?.result?.total ?? null };
  } catch (error) {
    return { ok: false, error: error?.message || String(error) };
  }
}

/** 类目树。语言默认 ru；结果通常较大，UI 侧需自行缓存。 */
/**
 * 类目树。官方 v1 是 /v1/description-category/tree（三级叶子为「类型」，带 type_id + type_name），
 * 老接口 /v2/category/tree 仍在服务，做成兜底，避免单一端点变动导致类目完全选不了。
 * 统一归一化节点形状（title / description_category_id / type_id），否则最后一层类型节点
 * 会因为字段叫 type_name 而渲染成空白，用户点不到 → 上传时 type_id 为 0 被 Ozon 拒绝。
 */
// Ozon 官方只支持 RU / EN / DEFAULT。请求 zh 时若返回的仍不是中文，说明该语言不被支持，
// 必须显式回落 ru —— 否则拿到的是未定义语言的默认值，界面与匹配都会错乱。
function hasCJK(nodes, limit = 20) {
  let seen = 0;
  const walk = (list) => {
    for (const node of list || []) {
      if (seen >= limit) return true;
      seen += 1;
      if (/[\u4e00-\u9fa5]/.test(String(node?.title || node?.category_name || node?.type_name || ""))) return true;
      if (walk(node?.children)) return true;
    }
    return false;
  };
  return walk(nodes);
}

export async function fetchCategoryTree(credentials, { language = "ru" } = {}) {
  const requested = String(language || "ru");
  const load = async (lang) => {
    let raw = null;
    try {
      const result = await request(credentials, "/v1/description-category/tree", { language: lang }, 90000);
      raw = result?.result || null;
    } catch (error) {
      if (!/HTTP 40[04]/.test(String(error?.message))) throw error;
    }
    if (!Array.isArray(raw) || !raw.length) {
      const fallback = await request(credentials, "/v2/category/tree", { language: lang }, 90000);
      raw = fallback?.result || [];
    }
    return raw || [];
  };

  let raw = await load(requested);
  if (requested.toLowerCase() === "zh" && raw.length && !hasCJK(raw)) {
    raw = await load("ru");
  }
  return (raw || []).map((node) => normalizeCategoryNode(node));
}

function normalizeCategoryNode(node, parentCategoryId = 0) {
  const categoryId = Number(node.description_category_id || node.category_id) || parentCategoryId || 0;
  const typeId = Number(node.type_id) || 0;
  return {
    title: cleanText(node.title || node.category_name || node.type_name || node.name),
    description_category_id: categoryId,
    category_id: categoryId,
    type_id: typeId,
    children: (node.children || []).map((child) => normalizeCategoryNode(child, categoryId)),
  };
}

/**
 * 上传前预检：把 Ozon 那些英文 400（最常见的是
 * `Request.items.type_id: value must be greater than 0`）翻译成可操作的中文提示，
 * 避免用户拿到一句看不懂的报错却不知道去哪改。
 */
/**
 * 上传前体检。problems 是 Ozon 一定会拒绝的硬伤，warnings 是能传但不完整的软提示。
 * 原来只查类目/价格/标题，Ozon 真正 400 的常见原因（没图、划线价不高于售价、必填属性没填）没覆盖到，
 * 结果用户只能看到一句英文报错，这里一次性列全。
 */
export function collectImportDiagnostics(draft, options = {}) {
  const problems = [];
  const warnings = [];
  if (!draft) {
    problems.push("草稿不存在");
    return { problems, warnings };
  }

  const category = options.category || draft?.ozonCategory || {};
  const categoryId = Number(category.descriptionCategoryId ?? category.description_category_id ?? category.category_id) || 0;
  const typeId = Number(category.typeId ?? category.type_id) || 0;
  if (!categoryId) {
    problems.push("未选择 Ozon 类目（description_category_id = 0）：到「② 类目与属性」拉取类目树后，展开到最后一层「类型」点选");
  } else if (!typeId) {
    problems.push(`只选了类目 ${categoryId}，没选到「类型」（type_id = 0）：把类目树展开到最后一层「类型」再点选，Ozon 要求 type_id 必须大于 0`);
  }

  const pricing = options.pricing || draft?.pricing || {};
  // 兼容旧字段 priceForCost 结果里的 priceRub，避免误报
  const price = Number(pricing.priceCny ?? pricing.priceRub) || 0;
  const oldPrice = Number(pricing.oldPriceCny ?? pricing.oldPriceRub) || 0;
  if (!(price > 0)) {
    problems.push("售价为 0：到「③ 价格与库存」按上架表口径点「反推售价并应用」");
  }
  // Ozon 要求 old_price 严格大于 price；相等或更低会整条被拒，只能去掉划线价。
  if (oldPrice > 0 && oldPrice <= price) {
    // v1.9.50：实付价走 price、划线价走 old_price，这里命中的成因通常是「活动折扣为 0」
    // ——此时两者本就相等，不带划线价是正常结果，不必让用户以为出错了。
    warnings.push(
      oldPrice === price
        ? `活动折扣为 0，划线价与成交价同为 ${price} CNY：已按 Ozon 规则不带划线价（正常现象，成交价不受影响）。想让商品显示折扣，到「③ 价格与库存」把活动折扣设成大于 0`
        : `划线价 ${oldPrice} CNY 低于成交价 ${price} CNY，已按 Ozon 规则不带划线价（成交价 ${price} CNY 不受影响）。请检查「③ 价格与库存」的折扣设置`,
    );
  }

  // 多规格：某个 SKU 没单独定价时会上传成整单价——这是隐形的价格错误，必须提前提示
  const selectedSkus = Array.isArray(options.selectedSkus) ? options.selectedSkus.filter(Boolean) : [];
  if (selectedSkus.length >= 2) {
    const perSku = draft?.pricing?.perSku && typeof draft.pricing.perSku === "object" ? draft.pricing.perSku : {};
    const unpriced = selectedSkus.filter((sku) => !(Number(perSku[sku?.id]?.priceCny) > 0));
    if (unpriced.length) {
      warnings.push(
        `有 ${unpriced.length} 个选用 SKU 没有单独定价（${unpriced.slice(0, 3).map((sku) => cleanText(sku?.label) || sku?.id).join("、")}），`
        + "会按整单价上传：到「③ 价格与库存」点「反推售价并应用」，让每个规格都有自己的价格",
      );
    }
  }

  if (!cleanText(draft?.ru?.title || draft?.title)) {
    problems.push("商品名称为空：先填俄语标题（可在「① 主要信息」点 AI 生成）");
  }
  if (!cleanText(draft?.id)) {
    problems.push("草稿没有 ID（offer_id 会为空），请重新保存一次草稿");
  }

  const images = (draft.images || []).map(cleanText).filter(Boolean);
  if (!images.length) {
    problems.push("没有图片：Ozon 要求至少一张主图，到「④ 图片」载入并勾选");
  }
  // Ozon 明文禁止主图出现汉字/英文（「商品图片：商品卡片中使用了汉字或英文」），
  // 而 1688 采集的原图几乎都带中文文案。本地没法可靠判断「这张图里有没有字」，
  // 所以只在「主图不是 AI 生成图」时提示，不假装检测过。
  const aiImages = new Set((Array.isArray(draft.aiImageUrls) ? draft.aiImageUrls : []).map(cleanText).filter(Boolean));
  if (images.length && !aiImages.has(images[0])) {
    warnings.push(
      "主图用的是采集原图：Ozon 禁止主图出现汉字或英文，1688 原图基本都带中文文案，"
      + "容易被判「商品图片：使用了汉字或英文」并封锁。建议先用 AI 套图生成俄文主图，或在「④ 图片」把带字原图换掉",
    );
  }

  // Ozon 对多 SKU / 部分类目要求 model_name；缺了会报「型号名称必填」
  const modelName = buildProductModelName(draft);
  if (!modelName) {
    problems.push("型号名称为空：请填写俄语标题或商品名称，以便自动生成 model_name");
  } else if (modelName.length < 2) {
    warnings.push("型号名称过短，可能被 Ozon 拒绝，建议完善标题");
  }

  const weight = Number(options.weightGrams) || 0;
  const depth = Number(options.depthMm) || 0;
  const width = Number(options.widthMm) || 0;
  const height = Number(options.heightMm) || 0;
  if (!(weight > 0)) warnings.push("重量还是默认值 500g：填真实毛重，否则物流费与核价都不准");
  if (!(depth > 0 && width > 0 && height > 0)) warnings.push("包装尺寸还是默认 100mm：填真实长宽高，否则物流费与核价都不准");

  // 必填属性：Ozon 最常见的 400 之一就是「缺少必填特征」
  const required = Array.isArray(options.requiredAttributeIds) ? options.requiredAttributeIds : [];
  const missingRequiredIds = [];
  if (required.length) {
    const values = options.attributeValues || draft.attributeValues || {};
    const missing = required.filter((id) => !cleanText(values[String(id)]));
    if (missing.length) {
      missingRequiredIds.push(...missing);
      problems.push(`有 ${missing.length} 个必填类目属性没填（ID：${missing.join("、")}）：请补齐后再上传`);
    }
  }
  if (Array.isArray(options.attributeDefinitions) && options.attributeDefinitions.length) {
    const check = validateAttributeValues(options.attributeDefinitions, options.attributeValues || draft.attributeValues || {});
    problems.push(...check.errors);
  }

  // 品牌合规（v1.9.61）：Ozon 最常见的封锁原因就是「缺少品牌文件」。
  // 这一类不像 400 那样当场报错，而是上架几天后才发通知封锁商品，用户往往一头雾水，
  // 所以必须在上传前把「品牌属性没填 / 标题带品牌词却没申报」这类组合先拦下来。
  const brand = collectBrandRisks({
    title: draft?.ru?.title || draft?.title,
    description: draft?.ru?.description || draft?.description,
    attributes: draft?.attributes,
    attributeValues: options.attributeValues || draft?.attributeValues || {},
    categoryAttributes: options.categoryAttributes || options.attributeDefinitions || [],
    images: draft?.images,
    skipAttributeIds: missingRequiredIds, // 必填缺失已单独报过，品牌项不再重复刷一行
  });
  for (const item of brand.items) {
    (item.level === "problem" ? problems : warnings).push(formatBrandRisk(item));
  }

  return { problems, warnings };
}

export function assertReadyToImport(draft, options = {}) {
  const { problems } = collectImportDiagnostics(draft, options);
  // 真跑一遍条目组装：这样「多规格识别不出变体属性」「属性值不在字典里」这类只有组装时
  // 才会暴露的问题能在**提交之前**变成中文提示（批量上传的预检也走这条路）。
  try {
    buildImportItems(draft, options);
  } catch (error) {
    problems.push(error?.message || String(error));
  }
  if (problems.length) {
    throw new Error(`上传前检查未通过：${problems.join("；")}。`);
  }
  return true;
}

/** 指定类目的属性定义（Ozon 要求按类目填属性）。两个端点互为兜底，避免单一端点下线导致不可用。 */
export async function fetchCategoryAttributes(credentials, { descriptionCategoryId, typeId, language = "ru" }) {
  const body = {
    description_category_id: Number(descriptionCategoryId) || 0,
    type_id: Number(typeId) || 0,
    language,
  };
  // 调试日志：方便排查「属性未加载」到底是参数错、接口 404 还是返回空
  console.log("[ozon-api] fetchCategoryAttributes request:", JSON.stringify(body));
  // 正确的类目属性定义接口是 /v1/description-category/attribute（不是 /v3/products/info/attributes，
  // 后者是查已有商品的属性，且请求体不同，传 category_id 会 404）。
  const tryFetch = async (lang) => {
    const res = await request(credentials, "/v1/description-category/attribute", { ...body, language: lang }, 60000);
    console.log(`[ozon-api] /v1/description-category/attribute (${lang}) response:`, JSON.stringify(res).slice(0, 500));
    const list = res?.attributes || res?.result?.attributes || res?.result || [];
    return Array.isArray(list) ? list.map(normalizeAttributeDefinition) : [];
  };
  try {
    // 先尝试中文；Ozon 对该接口可能不支持 zh（返回俄文，甚至直接报错）。
    // 注意 zh 的失败不能影响 ru：单独 try/catch，只有 zh 正常返回且带中文才用它。
    let zhList = [];
    try {
      zhList = await tryFetch("zh");
    } catch (zhError) {
      console.warn("[ozon-api] language=zh 请求失败，改用 ru：", zhError?.message || zhError);
    }
    if (zhList.length && zhList.some((a) => /[\u4e00-\u9fa5]/.test(String(a.name)))) return zhList;
    return await tryFetch("ru");
  } catch (error) {
    console.warn("[ozon-api] /v1/description-category/attribute error:", error?.message || error);
    if (!/HTTP 404/.test(String(error?.message))) throw error;
  }
  // 兜底：/v3/category/attribute（旧版类目属性接口）
  const fallback = await request(
    credentials,
    "/v3/category/attribute",
    {
      attribute_type: "ALL",
      category_id: [Number(descriptionCategoryId) || 0],
      language,
      type_id: Number(typeId) || 0,
    },
    60000,
  );
  console.log("[ozon-api] /v3/category/attribute fallback response:", JSON.stringify(fallback).slice(0, 500));
  const list = fallback?.result?.[0]?.attributes || fallback?.result || [];
  return Array.isArray(list) ? list.map(normalizeAttributeDefinition) : [];
}

/**
 * 类目属性「版本指纹」（v1.9.55）：由官方定义里影响填值与校验的字段拼成短哈希。
 * 平台改了必填/枚举标记/字典绑定/复合分组时指纹会变 → 缓存整体失效，强制回源。
 * 之所以不用整个 JSON 哈希：候选值翻译、displayName 这类展示字段不该触发失效。
 */
export function buildAttributesFingerprint(attributes = []) {
  const meaningful = (attributes || []).map((attr) => {
    const a = normalizeAttributeDefinition(attr);
    return [a.id, a.name, a.is_required ? 1 : 0, a.is_aspect ? 1 : 0, a.dictionary_id, a.attribute_complex_id, a.type, a.min, a.max, a.unit].join(":");
  }).sort();
  const text = meaningful.join("|");
  let hash = 5381;
  for (let i = 0; i < text.length; i += 1) hash = ((hash << 5) + hash + text.charCodeAt(i)) >>> 0;
  return hash.toString(16);
}

/**
 * 拉某个枚举型属性的**候选值字典**（v1.9.50 新增）。
 *
 * 这是「属性不正确：不要手输这些值，请从列表中选择一个属性值」的根治办法：
 * /v1/description-category/attribute 只给属性定义（含 dictionary_id），**不给候选值**，
 * 所以之前 attr.dictionary 永远是空的 —— AI 没有候选值可挑只能自己编，上传时又只发自由文本，
 * Ozon 必然拒收。候选值要单独走这个接口拿，拿到后既能渲染成下拉框，也能发 dictionary_value_id。
 * 分页取全（last_value_id 游标），单属性上限 2000 条，防止颜色类属性把内存撑爆。
 */
export async function fetchAttributeValues(credentials, {
  descriptionCategoryId, typeId, attributeId, language = "ru", maxValues = 2000,
} = {}) {
  const numericAttr = Number(attributeId) || 0;
  if (!numericAttr) return [];
  const out = [];
  let lastValueId = 0;
  for (let page = 0; page < 12; page += 1) {
    const result = await request(credentials, "/v1/description-category/attribute/values", {
      description_category_id: Number(descriptionCategoryId) || 0,
      type_id: Number(typeId) || 0,
      attribute_id: numericAttr,
      language,
      last_value_id: lastValueId,
      limit: 5000,
    }, 60000);
    const list = result?.result || result?.values || [];
    if (!Array.isArray(list) || !list.length) break;
    for (const item of list) {
      const value = cleanText(item?.value ?? item?.name);
      const id = Number(item?.id ?? item?.dictionary_value_id) || 0;
      if (value) out.push({ id: id || null, value, displayValue: "", picture: cleanText(item?.picture || "") });
      if (out.length >= maxValues) return out;
    }
    lastValueId = Number(list[list.length - 1]?.id) || 0;
    if (!result?.has_next || !lastValueId) break;
  }
  return out;
}

/**
 * 按关键字搜某个枚举属性的候选值（v1.9.56）。
 *
 * 为什么需要：品牌字典有几十万个值，/attribute/values 全量拉既慢又会撑爆内存
 * （fetchAttributeValues 上限 2000 条，超出直接截断——所以 SHANBEN 这种排在 2000
 * 之后的品牌永远「字典里没有」）。Ozon 提供 /v1/description-category/attribute/values/search
 * 按词搜，输入 SHANBEN 只回相关的几条，拿到真正的 dictionary_value_id。
 * 响应结构做三形态兼容（result / values / 直接数组），字段取不到就返回空让调用方降级。
 */
export async function searchAttributeValues(credentials, {
  descriptionCategoryId, typeId, attributeId, query, language = "ru", limit = 50,
} = {}) {
  const numericAttr = Number(attributeId) || 0;
  const text = cleanText(query);
  if (!numericAttr || !text) return [];
  const result = await request(credentials, "/v1/description-category/attribute/values/search", {
    description_category_id: Number(descriptionCategoryId) || 0,
    type_id: Number(typeId) || 0,
    attribute_id: numericAttr,
    value: text,
    language,
    limit: Math.min(Math.max(Number(limit) || 50, 1), 200),
    offset: 0,
  }, 30000);
  const list = Array.isArray(result?.result) ? result.result
    : Array.isArray(result?.values) ? result.values
    : Array.isArray(result?.result?.values) ? result.result.values
    : Array.isArray(result) ? result : [];
  const out = [];
  for (const item of list) {
    const value = cleanText(item?.value ?? item?.name);
    const id = Number(item?.id ?? item?.dictionary_value_id) || 0;
    if (value) out.push({ id: id || null, value, picture: cleanText(item?.picture || "") });
  }
  return out;
}

/** 已上架商品列表 */
export async function fetchProductList(credentials, { limit = 100, lastId = "", visibility = "ALL" } = {}) {
  const result = await request(credentials, "/v3/product/list", {
    filter: { visibility },
    last_id: lastId,
    limit: Math.min(Math.max(Number(limit) || 100, 1), 1000),
  });
  return result?.result || { items: [], total: 0 };
}

/** 商品详情（含价格、库存、状态） */
export async function fetchProductInfo(credentials, offerIds = [], productIds = []) {
  const result = await request(credentials, "/v3/product/info/list", {
    offer_id: offerIds.slice(0, 1000),
    product_id: productIds.slice(0, 1000),
  });
  return result?.result?.items || [];
}

/** 库存查询 */
export async function fetchStocks(credentials, { limit = 100, lastId = "" } = {}) {
  const result = await request(credentials, "/v3/product/info/stocks", { filter: {}, last_id: lastId, limit });
  return result?.result || { items: [] };
}

/** 库存更新（FBO 仓库）。stocks: [{ offer_id, stock }]，warehouseId 必填 */
export async function updateStocks(credentials, stocks = [], warehouseId) {
  if (!Number(warehouseId) > 0) {
    throw new Error("更新库存需要 warehouse_id（FBO 仓库 ID），请在界面填写。仓库列表可在卖家后台或 /v1/analytics 查询。");
  }
  const result = await request(credentials, "/v2/products/stocks", {
    stocks: stocks.map((item) => ({ ...item, warehouse_id: Number(warehouseId) })),
  });
  return result?.result || [];
}

/** 价格更新。prices: [{ offer_id, price, old_price }] */
export async function updatePrices(credentials, prices = []) {
  const result = await request(credentials, "/v1/product/import/prices", { prices });
  return result?.result || [];
}

/** FBS 订单列表 */
export async function fetchFbsOrders(credentials, { dir = "ASC", limit = 100, offset = 0, since = "", to = "", status = "" } = {}) {
  const body = { dir, filter: {}, limit, offset };
  if (since) body.filter.since = since;
  if (to) body.filter.to = to;
  if (status) body.filter.status = status;
  if (!since && !to) {
    const now = new Date();
    const weekAgo = new Date(now.getTime() - 7 * 24 * 3600 * 1000);
    body.filter.since = weekAgo.toISOString();
    body.filter.to = now.toISOString();
  }
  const result = await request(credentials, "/v3/posting/fbs/list", body);
  return result?.result || { postings: [] };
}

/**
 * 创建/更新商品。items 由 buildImportItem 生成。
 * 返回 task_id，需要用 /v1/product/import/info 轮询结果。
 * 注意：v2/product/import 已下线（404），必须用 v3。
 */
export async function importProducts(credentials, items = []) {
  if (!items.length) throw new Error("没有可上传的商品");
  const result = await request(credentials, "/v3/product/import", { items }, 120000);
  return result?.result || {};
}

/** 查询导入任务结果 */
export async function fetchImportInfo(credentials, taskId) {
  const result = await request(credentials, "/v1/product/import/info", { task_id: Number(taskId) || 0 });
  return result?.result || {};
}

/** 销售/流量分析数据 */
export async function fetchAnalytics(credentials, { dateFrom, dateTo, metrics = ["ordered_units"], dimension = ["sku"], limit = 100 } = {}) {
  const result = await request(credentials, "/v1/analytics/data", {
    date_from: dateFrom,
    date_to: dateTo,
    metrics,
    dimension,
    limit,
  });
  return result?.result || { data: [] };
}

/**
 * 把本地草稿转成 Ozon /v3/product/import 的单条 item。
 * v3 要点：类目用 description_category_id；attributes 结构为 {complex_id, id, values}；
 * 描述不是独立字段而是类目属性（默认用 4191「Аннотация」，可在界面改）。
 *
 * options.variant 用于多规格：{ attrId, value, index }，会把该规格值写成属性，
 * 并按规格单独设置价格/库存/主图，Ozon 会按相同属性集自动合并成一张卡片。
 */
export function buildImportItem(draft, options = {}) {
  // 注意：options.category 可能是空对象 {}（调用方兜底），空对象在 JS 里是 truthy，
  // 必须显式判断有没有类目/类型值，否则上传时 description_category_id 会错误地变成 0。
  const explicit = options.category || {};
  const hasExplicitCategory = Boolean(
    explicit.descriptionCategoryId || explicit.description_category_id || explicit.category_id
      || explicit.typeId || explicit.type_id,
  );
  const category = hasExplicitCategory ? explicit : (draft.ozonCategory || {});
  const descriptionCategoryId = Number(category.descriptionCategoryId ?? category.description_category_id ?? category.category_id) || 0;
  const typeId = Number(category.typeId ?? category.type_id) || 0;
  const pricing = options.pricing || draft.pricing || {};
  const variant = options.variant || null;
  // 每个 SKU 规格维度匹配到的真实 Ozon 变体属性（多轴变体）；为空时回落到单一 variantAttrId
  const variantAttrs = Array.isArray(options.variantAttrs) ? options.variantAttrs : [];
  const descriptionAttributeId = Number(options.descriptionAttributeId ?? 4191) || 0;
  // v1.9.50 枚举型属性必须发 dictionary_value_id，否则 Ozon 判「属性不正确：请从列表中选择」。
  // 先把 AI/采集来的值就近落到字典上（差一个词形就会被拒），再交给 buildAttributes。
  const attributeDefs = Array.isArray(options.attributeDefinitions) && options.attributeDefinitions.length
    ? options.attributeDefinitions
    : (Array.isArray(options.categoryAttributes) ? options.categoryAttributes : []);
  const dictById = new Map();
  for (const def of attributeDefs) {
    const id = Number(def?.id) || 0;
    if (id) dictById.set(id, def);
  }
  const snapped = snapAttributeValues(attributeDefs, options.attributeValues || draft.attributeValues || {});
  // 下拉框选过的 ID 最准，优先于文本匹配结果
  const valueIds = { ...snapped.ids, ...(options.attributeValueIds || draft.attributeValueIds || {}) };
  const toOzonValue = (id, text) => {
    const numeric = Number(id) || 0;
    const picked = Number(valueIds[String(numeric)]);
    const def = dictById.get(numeric);
    const dict = Array.isArray(def?.dictionary) ? def.dictionary : [];
    if (picked) {
      const hit = dict.find((item) => Number(item.id) === picked);
      return { value: cleanText(hit?.value) || cleanText(text), dictionary_value_id: picked };
    }
    return matchDictionaryValue(dict, text);
  };
  const attributes = buildAttributes(
    draft,
    options.attributeMap || {},
    descriptionAttributeId,
    variant,
    variantAttrs,
    snapped.values,
    toOzonValue,
  );
  if (attributeDefs.length) {
    const check = validateAttributeValues(attributeDefs, snapped.values);
    if (!check.ok) throw new Error(`属性校验未通过：${check.errors.join("；")}`);
  }

  const prefix = cleanText(options.skuPrefix || draft.skuPrefix);
  const imageVariant = variant || ((draft.skus || []).length === 1 ? draft.skus[0] : null);
  const skuImages = Array.isArray(imageVariant?.images) ? imageVariant.images : (imageVariant?.image ? [imageVariant.image] : []);
  const commonImages = (draft.images || []).map(cleanText).filter(Boolean);
  const images = [...new Set([...skuImages, ...commonImages])];
  const limitedImages = images.slice(0, 9);

  // 价格统一用人民币：店铺合同/个人中心要求货币为 CNY，传 RUB 会报「货币指定错误」
  const price = Number(variant?.priceCny ?? pricing.priceCny) || 0;
  const rawOldPrice = Number(variant?.oldPriceCny ?? pricing.oldPriceCny) || 0;
  // Ozon 规定 old_price 必须严格大于 price，相等或更低会整条被拒；宁可不展示划线价也不能上传失败
  const oldPrice = rawOldPrice > price ? rawOldPrice : 0;

  const model = buildStableModel(draft, options.modelSku || imageVariant, prefix);
  const modelName = cleanText(options.modelName) || buildProductModelName(draft);

  // v1.9.81 自动补齐两个「几乎每个类目都有、AI 又经常漏填」的属性（只在有定义且没填时补，不覆盖手填）。
  // 必须在 modelName 定义之后：9048 复用 model_name（多变体合并同一张卡用的是同一个值）。
  // ① 9048 型号名称（合并卡片依据）：没填就用 model_name。
  // ② 23171 #主题标签：没填就把 AI 搜索关键词拼成 "#词1 #词2"（去空格、去已有 #，最多 30 个）。
  // 两者都是 String 单值、无字典（已核离线库），发自由文本安全。
  {
    const hasAttrDef = (id) => attributeDefs.some((d) => Number(d?.id) === id);
    const filledAttrIds = new Set(attributes.map((a) => Number(a.id)));
    if (hasAttrDef(9048) && !filledAttrIds.has(9048) && modelName) {
      attributes.push({ complex_id: 0, id: 9048, values: [{ value: modelName }] });
    }
    if (hasAttrDef(23171) && !filledAttrIds.has(23171)) {
      const tags = (Array.isArray(draft.ru?.keywords) ? draft.ru.keywords : [])
        .map((k) => cleanText(k).replace(/^#+/, "").replace(/\s+/g, ""))
        .filter(Boolean).slice(0, 30);
      if (tags.length) {
        attributes.push({ complex_id: 0, id: 23171, values: [{ value: tags.map((t) => `#${t}`).join(" ") }] });
      }
    }
  }

  return {
    // 型号即 offer_id：优先真实/稳定 SKU，重试、保存、批量上传均保持不变。
    offer_id: model,
    model,
    model_name: modelName,
    name: cleanText(draft.ru?.title || draft.title).slice(0, 255),
    description_category_id: Number(descriptionCategoryId) || 0,
    category_id: Number(descriptionCategoryId) || 0,
    type_id: Number(typeId) || 0,
    price: String(Number(price) || 0),
    old_price: String(Number(oldPrice) || 0),
    currency_code: "CNY",
    vat: options.vat || "0",
    weight: Math.round(Number(options.weightGrams) || 500),
    weight_unit: "g",
    depth: Number(options.depthMm) || 100,
    width: Number(options.widthMm) || 100,
    height: Number(options.heightMm) || 100,
    dimension_unit: "mm",
    primary_image: cleanText(limitedImages[0] || draft.images?.[0] || draft.mainImage),
    images: limitedImages,
    attributes,
    complex_attributes: [],
  };
}

/** 把 SKU 规格维度映射出的变体属性，与手工/AI 属性合并进最终 attributes 数组 */
function appendVariantAttributes(out, variantAttrs, variant) {
  const used = new Set(out.map((item) => Number(item.id)));
  for (const va of variantAttrs || []) {
    const numeric = Number(va?.id) || 0;
    const first = va?.values?.[0];
    const text = cleanText(first?.value);
    if (!numeric || !text || used.has(numeric)) continue;
    used.add(numeric);
    // 原样带上 dictionary_value_id（枚举型变体属性只认 ID）
    out.push({ complex_id: 0, id: numeric, values: [{ ...first, value: text }] });
  }
  // 没有匹配到任何规格维度时，回落到界面配置的单一 variantAttributeId + 规格标签（旧行为）
  if ((!variantAttrs || !variantAttrs.length) && variant?.attrId && cleanText(variant.value)) {
    const numeric = Number(variant.attrId);
    if (numeric && !used.has(numeric)) {
      out.push({ complex_id: 0, id: numeric, values: [{ value: cleanText(variant.value) }] });
    }
  }
  return out;
}

/** 一个 SKU 展开成上传条目时，它自己那份「变体属性 + 价格 + 图片」 */
function variantPayloadOf(sku, index, priced, variantAttrId, categoryAttributes) {
  const attrs = (sku?.specs && Object.keys(sku.specs).length)
    ? buildVariantAttributes(sku, categoryAttributes)
    : [];
  const skuPricing = priced[sku?.id] || {};
  return {
    variantAttrs: attrs,
    variant: {
      id: sku?.id,
      // 已经按规格维度挂上真变体属性时，就不要再拿 label 当属性值塞进去（那是旧兜底逻辑）
      attrId: attrs.length ? 0 : variantAttrId,
      value: sku?.label || sku?.id || "",
      index,
      image: sku?.image || "",
      images: Array.isArray(sku?.images) ? sku.images : (sku?.image ? [sku.image] : []),
      priceCny: skuPricing.priceCny,
      oldPriceCny: skuPricing.oldPriceCny,
    },
  };
}

/**
 * 生成一次导入所需的全部 item。
 *
 * v1.9.50 重写「条目数」这条规则——这是「上传了 4 个规格，系统只上架 1 个」的根因所在：
 * 旧逻辑是「没有手填变体属性 ID 就 return [base]」，于是选了 4 个规格也只提交 1 条，
 * 而且那 1 条用的还是草稿级价格，各 SKU 的 perSku 价根本没被用上。
 * 现在：
 *   - **条目数严格等于选用的 SKU 数**，每个 SKU 用自己的规格、价格、图片；
 *   - 变体属性优先从类目属性里**自动识别**（Ozon 的 is_aspect 标记 + 规格维度名），
 *     界面手填的 ID 只作为兜底；
 *   - 多规格但一个变体属性都识别不出来、也没手填时**明确报错**，
 *     而不是静默地上架成 1 个（漏上是比报错严重得多的问题）。
 */
export function buildImportItems(draft, options = {}) {
  const variantAttrId = Number(options.variantAttributeId) || 0;
  const skus = (Array.isArray(options.selectedSkus) && options.selectedSkus.length
    ? options.selectedSkus
    : (draft.skus || [])).filter(Boolean);
  // model_name 是商品级别字段，所有 SKU 必须相同才能合并成一张卡片
  const modelName = buildProductModelName(draft);
  // 类目属性定义：用于在 SKU 规格维度与 Ozon 真实属性之间做匹配（生成真变体）
  const categoryAttributes = options.categoryAttributes || draft.categoryAttributes || [];
  const priced = draft.pricing?.perSku && typeof draft.pricing.perSku === "object" ? draft.pricing.perSku : {};

  if (!skus.length) {
    return [buildImportItem(draft, { ...options, modelName, categoryAttributes })];
  }

  // 单规格：1 条，价格/图片取这个 SKU 自己的（不再回落到草稿级的第一个价）
  if (skus.length === 1) {
    const { variant, variantAttrs } = variantPayloadOf(skus[0], 0, priced, variantAttrId, categoryAttributes);
    return [buildImportItem(draft, {
      ...options,
      modelName,
      categoryAttributes,
      modelSku: skus[0],
      variant,
      variantAttrs,
    })];
  }

  const resolved = resolveVariantAttributes(skus, categoryAttributes);
  if (!resolved.length && !variantAttrId) {
    const label = (draft.skus || []).length ? `选用了 ${skus.length} 个 SKU` : "该商品有多个 SKU";
    throw new Error(
      `无法把规格映射到 Ozon 的「变体属性」：${label}，但当前类目的属性里没找到能区分规格的变体属性（is_aspect）。`
      + "请到「② 类目与属性」确认已加载该类目属性，并在上传区的「变体属性ID」里手填一个（如 10096＝颜色）；"
      + "没有变体属性的类目请改为按单规格上传。",
    );
  }

  return skus.map((sku, index) => {
    const { variant, variantAttrs } = variantPayloadOf(sku, index, priced, variantAttrId, categoryAttributes);
    return buildImportItem(draft, {
      ...options,
      modelName,
      categoryAttributes,
      // v1.9.47 每个变体用自己那一行的「上架 SKU」：
      // 不传的话 buildStableModel 只会收到 variant 那个精简对象（没有 offerId/offerIdAuto），
      // 手工填的货号在多变体上传时会被忽略。
      modelSku: sku,
      variantAttrs,
      variant,
    });
  });
}

// 把草稿属性按 Ozon 属性 id 映射；映射不到的属性丢弃，避免 400
function buildAttributes(draft, attributeMap, descriptionAttributeId, variant = null, variantAttrs = [], attributeValues = {}, toOzonValue = null) {
  const out = [];
  const used = new Set();
  const push = (id, value) => {
    const numeric = Number(id) || 0;
    const text = cleanText(value);
    if (!numeric || !text || used.has(numeric)) return;
    used.add(numeric);
    // 有字典的属性走 dictionary_value_id（Ozon 只认枚举 ID，自由文本会被判「属性不正确」）
    out.push({ complex_id: 0, id: numeric, values: [toOzonValue ? toOzonValue(numeric, text) : { value: text }] });
  };
  // v1.9.81 变体属性优先占位：各 SKU 自己的规格值（颜色/尺寸）先写入。
  // 下面产品级 attributeValues（AI/预填）若含同一个属性 id，会被 used 去重跳过——
  // 修「AI 填了产品级颜色=红，导致所有变体上传成同一个红、每个 SKU 各自的颜色被挤掉」。
  // 无匹配时才回落到界面配置的单一 variantAttributeId + 规格标签（旧行为）。
  appendVariantAttributes(out, variantAttrs, variant);
  for (const attr of draft.attributes || []) {
    const targetId = attributeMap[attr.name] || attributeMap[attr.value];
    if (targetId) push(targetId, attr.value);
  }
  // AI 自动填写的类目属性（"属性ID": "值"），与上面手工映射的属性合并，同 id 不重复写
  for (const [id, value] of Object.entries(attributeValues || {})) push(id, value);
  // 描述：Ozon 用类目属性「Аннотация」承载长文本（通用 id 4191，可在界面按类目调整）
  if (descriptionAttributeId && cleanText(draft.ru?.description)) {
    push(descriptionAttributeId, draft.ru.description);
  }
  const keywordId = attributeMap.__keywords__;
  if (keywordId && draft.ru?.keywords?.length) {
    out.push({
      complex_id: 0,
      id: Number(keywordId),
      values: draft.ru.keywords.slice(0, 10).map((value) => ({ value })),
    });
  }
  return out;
}
