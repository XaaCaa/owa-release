/**
 * 后台服务入口：消息路由。
 * 面板（UI）不直接发外部请求，统一经由这里，便于集中处理凭据与错误。
 */
import { MESSAGE_ACTIONS, OZON_SELLER_ORIGIN, STORAGE_KEYS } from "../shared/constants.js";
import {
  loadSettings,
  normalizeXiangjiKeys,
  resolveAiCredentials,
  resolveVisionCredentials,
  resolveOzonCredentials,
  resolveXiangjiCredentials,
  resolveImageCredentials,
} from "../shared/settings.js";
import { normalizeProduct, productIdentity } from "../shared/product-model.js";
import { loadOfflineCategory, enrichAttributesFromOffline } from "../shared/offline-kb.js";
import {
  buildListingMessages, parseListingResult, buildAttributeMessages, parseAttributeResult,
  inspectListingResult, weakListingError,
  buildTranslateMessages, parseTranslateResult, parseCategoryPickDetails,
  buildCategoryPickMessages, buildSpecDetectMessages, parseSpecDetectResult,
  // v1.9.66 类目树全量约束匹配（产品标题 + 产品外观图片双通道，AI 只能在树内选）
  buildCategoryTreeDomainMessages, buildCategoryTreeTypeMessages,
  parseCategoryTreeDomainResult, parseCategoryTreeTypeResult, composeCategoryTreeMatch,
  buildSellingPointsMessages, parseSellingPointsResult,
  buildImagePlanMessages, parseImagePlanResult,
  buildArtDirectionMessages, parseArtDirectionResult,
  buildRichContentMessages, parseRichContentPlanResult,
} from "../shared/prompts.js";
// v1.9.73 策划师模式：先卖点（排序+唯一最强）→ 8 图结构化方案（画面中文/图内俄文/出图prompt英文）
import { buildPlanMessages, parsePlanResult, buildPlannedPrompt, renderPlanMarkdown } from "../shared/image-plan.js";
import { computeListing, normalizeListingTemplate, splitCostCny } from "../shared/pricing.js";
import { sleep } from "../shared/utils.js";
import { chatComplete, chatCompleteStream, testConnection as testAi } from "./ai-client.js";
import { translateImagesWithXiangji, redrawImage, testXiangjiKeys, testImageGeneration } from "./image-service.js";
// v1.9.78 修复：MV3 service worker 按 HTML 规范禁止动态 import（报错原文
// "import is disallowed on ServiceWorkerGlobalScope"，超哥截图状态行实证）。
// v1.9.66 的 AI 类目匹配从上线起每次都在「加载类目树」这步抛错、被 catch 吞掉，
// 全部悄悄退成本地打分——这就是「AI 未给出可用结果」的真正原因，不是模型没配。
// 改顶层静态 import：SW 本身是 module，合法；1.3MB 数据冷启动解析一次，V8 缓存编译结果。
import { OZON_CATEGORY_TREE_BUNDLE } from "../../assets/ozon-category-tree.js";
import * as ozon from "./ozon-api.js";

const SUPPORTED_PRODUCT_DOMAINS = [
  "1688.com",
  "taobao.com",
  "tmall.com",
  "yangkeduo.com",
  "pinduoduo.com",
];

/**
 * v1.9.68 商品详情页的**路径**规则。
 *
 * 旧实现只看域名，于是 `www.1688.com`（1688 首页）、`s.1688.com`（搜索结果页）、
 * 店铺页 / 类目页全都被当成「商品页」列出来。用户点这些行的「采集这一页」，
 * 适配器只能在首页的推荐位里瞎抓——抓出来的标题、价格、图片跟用户想采的商品
 * 完全无关，看起来就是「采集的数据严重不准确」。
 *
 * 这里给每个平台补一条「详情页长什么样」的判定：
 *  - 命中 → 商品页，可以采集，列表里正常显示；
 *  - 不命中但域名匹配 → 标记为「非商品页」，列表里显式提示，并且**不会被自动选为目标**。
 * 判定刻意写得宽松（只要求「像详情页」），避免平台改版后把真商品页挡在外面。
 */
const PRODUCT_PAGE_RULES = [
  // https://detail.1688.com/offer/685447891234.html（也兼容 m.1688.com / 无 .html 后缀）
  { domain: "1688.com", test: (u) => /^\/offer\/\d+/i.test(u.pathname) },
  // https://item.taobao.com/item.htm?id=123
  { domain: "taobao.com", test: (u) => /^\/item\.htm$/i.test(u.pathname) && u.searchParams.has("id") },
  // https://detail.tmall.com/item.htm?id=123
  { domain: "tmall.com", test: (u) => /^\/item\.htm$/i.test(u.pathname) && u.searchParams.has("id") },
  // https://mobile.yangkeduo.com/goods.html?goods_id=123（goods2.html 等同理）
  { domain: "yangkeduo.com", test: (u) => /^\/goods\d*\.html?$/i.test(u.pathname) && u.searchParams.has("goods_id") },
  { domain: "pinduoduo.com", test: (u) => /^\/goods\d*\.html?$/i.test(u.pathname) && u.searchParams.has("goods_id") },
];

/** 域名是否属于支持的平台（决定「能不能采集」） */
function isSupportedProductUrl(url) {
  try {
    const host = new URL(url).hostname.toLowerCase();
    return SUPPORTED_PRODUCT_DOMAINS.some((domain) => host === domain || host.endsWith(`.${domain}`));
  } catch {
    return false;
  }
}

/**
 * 是否是**商品详情页**（决定「采出来有没有意义」）。
 * 域名不匹配 → false；域名匹配但路径不是详情页（首页 / 搜索页 / 店铺页 / 类目页）→ false。
 */
function isProductPageUrl(url) {
  if (!isSupportedProductUrl(url)) return false;
  let parsed;
  try {
    parsed = new URL(url);
  } catch {
    return false;
  }
  const host = parsed.hostname.toLowerCase();
  const rule = PRODUCT_PAGE_RULES.find((item) => host === item.domain || host.endsWith(`.${item.domain}`));
  if (!rule) return false;
  try {
    return Boolean(rule.test(parsed));
  } catch {
    return false;
  }
}

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  handle(message).then(sendResponse).catch((error) => sendResponse({ ok: false, error: error?.message || String(error) }));
  return true; // 异步回包
});

async function handle(message = {}) {
  const action = String(message.action || "");
  switch (action) {
    case MESSAGE_ACTIONS.captureProduct:
      return captureProduct(message.tabId);
    case MESSAGE_ACTIONS.listProductTabs:
      return listProductTabs();
    case MESSAGE_ACTIONS.diagnose:
      return diagnose();
    // v1.9.75 SKU 采集诊断
    case MESSAGE_ACTIONS.diagnoseSku:
      return diagnoseSku();
    case MESSAGE_ACTIONS.aiGenerateText:
      return generateText(message);
    case MESSAGE_ACTIONS.aiFillAttributes:
      return fillAttributes(message);
    case MESSAGE_ACTIONS.aiDetectSpecOptions:
      return detectSpecOptions(message);
    case MESSAGE_ACTIONS.aiPickCategory:
      return pickCategory(message);
    case MESSAGE_ACTIONS.aiMatchCategoryTree:
      return matchCategoryTree(message);
    case MESSAGE_ACTIONS.aiTranslateTexts:
      return translateTexts(message);
    case MESSAGE_ACTIONS.aiSellingPoints:
      return generateSellingPoints(message);
    case MESSAGE_ACTIONS.aiImagePlan:
      return generateImagePlan(message);
    // v1.9.73 策划师模式：一次产出「卖点表 + 8 图方案」结构化结果
    case MESSAGE_ACTIONS.aiImageStrategy:
      return generateImageStrategy(message);
    case MESSAGE_ACTIONS.aiArtDirection:
      return analyzeArtDirection(message);
    case MESSAGE_ACTIONS.aiRichContent:
      return buildRichContent(message);
    case MESSAGE_ACTIONS.aiTestConnection:
      return testAiConnection(message);
    case MESSAGE_ACTIONS.ozonTestConnection:
      return ozonCall((cred) => ozon.testConnection(cred), message.storeId);
    case MESSAGE_ACTIONS.ozonCategoryTree:
      return ozonCall((cred) => ozon.fetchCategoryTree(cred, message.payload || {}), message.storeId);
    case MESSAGE_ACTIONS.ozonCategoryAttributes:
      return ozonCall((cred) => ozon.fetchCategoryAttributes(cred, message.payload || {}), message.storeId);
    case MESSAGE_ACTIONS.ozonAttributeValues:
      return fetchAttributeDictionaries(message);
    case MESSAGE_ACTIONS.ozonAttributeValueSearch:
      // v1.9.56 超大字典（品牌）按需搜索候选值：本地只存前 2000 条，其余靠这个反查
      return ozonCall((cred) => ozon.searchAttributeValues(cred, message.payload || {}), message.storeId);
    case MESSAGE_ACTIONS.ozonAttributeMeta:
      return fetchCategoryAttributeMeta(message);
    case MESSAGE_ACTIONS.ozonImportProducts:
      return ozonCall((cred) => ozon.importProducts(cred, message.items || []), message.storeId);
    case MESSAGE_ACTIONS.ozonImportInfo:
      return ozonCall((cred) => ozon.fetchImportInfo(cred, message.taskId), message.storeId);
    case MESSAGE_ACTIONS.ozonProductList:
      return ozonCall((cred) => ozon.fetchProductList(cred, message.payload || {}), message.storeId);
    case MESSAGE_ACTIONS.ozonStocks:
      return ozonCall((cred) => ozon.fetchStocks(cred, message.payload || {}), message.storeId);
    case MESSAGE_ACTIONS.ozonUpdateStocks:
      return ozonCall((cred) => ozon.updateStocks(cred, message.stocks || [], message.warehouseId), message.storeId);
    case MESSAGE_ACTIONS.ozonUpdatePrices:
      return ozonCall((cred) => ozon.updatePrices(cred, message.prices || []), message.storeId);
    case MESSAGE_ACTIONS.ozonFbsOrders:
      return ozonCall((cred) => ozon.fetchFbsOrders(cred, message.payload || {}), message.storeId);
    case MESSAGE_ACTIONS.ozonAnalytics:
      return ozonCall((cred) => ozon.fetchAnalytics(cred, message.payload || {}), message.storeId);
    case MESSAGE_ACTIONS.ozonSalesIntel:
      return salesIntel();
    case MESSAGE_ACTIONS.ozonBulkImport:
      return bulkImport(message);
    case MESSAGE_ACTIONS.imageTranslate:
      return translateImages(message);
    case MESSAGE_ACTIONS.imageRedraw:
      return redraw(message);
    case MESSAGE_ACTIONS.imageTestXiangji:
      return testXiangji(message);
    case MESSAGE_ACTIONS.imageTestRedraw:
      // 必须把 message 传下去：面板测的是「输入框里刚填的值」，不是已保存的设置。
      // 漏传 message 会让 testRedraw 走兜底分支，静默拿存储里的旧值去测 —— 曾因此
      // 出现「输入框是 gpt-image-2、检测却报「通用」」的诡异现象。
      return testRedraw(message);
    case MESSAGE_ACTIONS.fetchImageAsDataUrl:
      return fetchImageAsDataUrl(message.url);
    case MESSAGE_ACTIONS.imageProbe:
      return { ok: true, data: await probeImageUrls(message.urls || []) };
    default:
      return { ok: false, error: `未知的消息动作：${action}` };
  }
}

/* ---------- 采集 ---------- */

// 面板本身是一个独立标签页，"当前活动标签页"多半是面板自己。
// 因此采集目标按优先级解析：指定的 tabId → 活动标签页（若匹配）→ 所有窗口里最近访问的匹配标签页。
async function captureProduct(requestedTabId) {
  const tab = await resolveCaptureTab(requestedTabId);
  if (!tab?.id) {
    return {
      ok: false,
      error: "未检测到打开的商品页。请先打开 1688 / 淘宝 / 拼多多商品详情页，再回到本面板点「检测商品页」。",
    };
  }

  let response = await sendToTab(tab.id, { action: MESSAGE_ACTIONS.captureProduct });
  if (!response) {
    // 扩展刚安装/更新而页面未注入脚本时，动态注入后重试
    try {
      await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        files: [
          "src/content/adapter-base.js",
          "src/content/adapter-1688.js",
          "src/content/adapter-taobao.js",
          "src/content/adapter-pdd.js",
          "src/content/injector.js",
        ],
      });
      await sleep(40); // 给注入的脚本一点初始化时间
      response = await sendToTab(tab.id, { action: MESSAGE_ACTIONS.captureProduct });
      // 脚本刚注入可能还没挂上监听，短暂重试两次（合计最多约 160ms）比一次性等 150ms 更快也更稳
      for (let attempt = 0; !response && attempt < 2; attempt++) {
        await sleep(60);
        response = await sendToTab(tab.id, { action: MESSAGE_ACTIONS.captureProduct });
      }
    } catch (error) {
      return { ok: false, error: `无法向商品页注入采集脚本：${error?.message || error}。请先刷新商品页再试。` };
    }
  }
  if (!response) return { ok: false, error: "采集脚本无响应，请刷新商品页后重试" };
  if (!response.ok) return response;

  const product = normalizeProduct(response.data);
  // v1.9.68：把「这次数据是从哪一页采的」写进结果本身。
  // 面板据此在采集结果卡上标明来源页与采集时间 —— 旧实现把 fromTab 丢掉，
  // 卡片里没有任何来源标识，一旦采集没执行/失败，用户就会把上一次的旧结果
  // 当成「这次采的商品」，看起来就是「采集的数据严重不准确」。
  product.captureSource = {
    tabId: tab.id,
    url: tab.url || "",
    pageTitle: tab.title || "",
    identity: productIdentity(tab.url || ""),
    at: new Date().toISOString(),
  };
  await chrome.storage.local.set({ [STORAGE_KEYS.lastCapture]: product });
  return { ok: true, data: product, fromTab: { id: tab.id, title: tab.title, url: tab.url } };
}

async function resolveCaptureTab(requestedTabId) {
  if (requestedTabId) {
    const tab = await chrome.tabs.get(requestedTabId).catch(() => null);
    return tab?.url && isSupportedProductUrl(tab.url) ? tab : null;
  }
  const active = await new Promise((resolve) => {
    chrome.tabs.query({ active: true, lastFocusedWindow: true }, (tabs) => resolve(tabs?.[0] || null));
  });
  if (active?.url && isSupportedProductUrl(active.url)) return active;

  const matched = await findProductTabs();
  // v1.9.68：优先挑真正的商品详情页。旧实现直接取 matched[0]，
  // 而列表里可能混着 1688 首页 / 搜索页 —— 采出来就是一堆推荐位垃圾数据。
  return matched.find((tab) => isProductPageUrl(tab.url)) || matched[0] || null;
}

/**
 * 所有窗口里打开着的、平台域名匹配的标签页，按「商品详情页优先 → 活动优先 → 最近访问」排序。
 * 注意：这里保留「域名匹配但不是详情页」的标签页（首页 / 搜索页 / 店铺页），
 * 因为它们要出现在列表里让用户看清「为什么这一页采不出东西」，但会带 productPage:false 标记。
 */
async function findProductTabs() {
  const tabs = await new Promise((resolve) => chrome.tabs.query({}, resolve));
  return (tabs || [])
    .filter((tab) => tab.url && isSupportedProductUrl(tab.url))
    .sort((a, b) => Number(isProductPageUrl(b.url)) - Number(isProductPageUrl(a.url))
      || Number(b.active) - Number(a.active)
      || (b.lastAccessed || 0) - (a.lastAccessed || 0))
    .slice(0, 10);
}

async function listProductTabs() {
  const tabs = await findProductTabs();
  return { ok: true, data: tabs.map((tab) => ({
    id: tab.id,
    title: tab.title || "",
    url: tab.url,
    active: Boolean(tab.active),
    // v1.9.68：面板据此把「首页 / 搜索页」这类非详情页标出来，避免用户点错行采到垃圾数据
    productPage: isProductPageUrl(tab.url),
  })) };
}

/**
 * 采集自检：把"为什么采集不了"的原因逐项列出来，
 * 而不是只回一句含糊的失败提示。
 */
async function diagnose() {
  const report = {
    manifestVersion: chrome.runtime.getManifest?.().manifest_version ?? null,
    permissions: null,
    allTabs: [],
    matchedTabs: [],
    target: null,
    ping: null,
    inject: null,
    hints: [],
  };

  try {
    const granted = await chrome.permissions.getAll();
    report.permissions = {
      permissions: (granted.permissions || []).slice(),
      origins: (granted.origins || []).slice(),
    };
  } catch (error) {
    report.permissions = { error: String(error?.message || error) };
  }

  const tabs = await new Promise((resolve) => chrome.tabs.query({}, resolve));
  report.allTabs = (tabs || []).map((tab) => ({
    id: tab.id,
    active: Boolean(tab.active),
    url: tab.url || "",
    hostname: (() => {
      try { return new URL(tab.url).hostname; } catch { return ""; }
    })(),
    supported: Boolean(tab.url) && isSupportedProductUrl(tab.url),
    // v1.9.68：域名匹配 ≠ 是商品详情页。首页 / 搜索页 / 店铺页会被标出来，
    // 否则用户点了「采集这一页」只会得到首页推荐位的数据。
    productPage: Boolean(tab.url) && isProductPageUrl(tab.url),
  }));
  report.matchedTabs = report.allTabs.filter((tab) => tab.supported);
  report.productTabs = report.allTabs.filter((tab) => tab.productPage);

  if (!report.matchedTabs.length) {
    report.hints.push(
      "没有检测到匹配的商品页。请确认：① 商品页确实打开着；② 网址是 1688 / taobao / tmall / yangkeduo / pinduoduo 的商品详情页；③ 不是扩展自己的页面。",
    );
    return { ok: true, data: report };
  }
  if (!report.productTabs.length) {
    report.hints.push(
      `检测到 ${report.matchedTabs.length} 个平台页面，但没有一个是「商品详情页」（都是首页 / 搜索页 / 店铺页 / 类目页）。请打开具体的商品详情页再采集。`,
    );
  }

  const target = await resolveCaptureTab();
  if (!target?.id) {
    report.hints.push("找到匹配的标签页但无法定位目标，请刷新商品页后重试。");
    return { ok: true, data: report };
  }
  report.target = { id: target.id, url: target.url };

  // 1) content script 是否已注入
  report.ping = await sendToTab(target.id, { action: "ozon_ping" });
  if (!report.ping?.ok) {
    report.hints.push("商品页里没有响应——通常是因为扩展刚安装/刚更新，旧页面的脚本已失效。请先刷新商品页。");
  } else if (report.ping.matched === false) {
    report.hints.push("采集脚本已注入，但当前网址没有匹配到任何平台适配器。请把完整网址发给我。");
  }

  // 2) 动态注入是否可用（ping 不通时的兜底路径）
  try {
    await chrome.scripting.executeScript({
      target: { tabId: target.id },
      files: [
        "src/content/adapter-base.js",
        "src/content/adapter-1688.js",
        "src/content/adapter-taobao.js",
        "src/content/adapter-pdd.js",
        "src/content/injector.js",
      ],
    });
    await sleep(120);
    report.inject = { ok: true };
  } catch (error) {
    report.inject = { ok: false, error: String(error?.message || error) };
    report.hints.push(
      `动态注入失败（${String(error?.message || error)}）。一般是缺少该站点的主机权限，或页面处于特殊状态（chrome:// 页面、无痕窗口被限制等）。`,
    );
  }

  if (report.inject?.ok) {
    const after = await sendToTab(target.id, { action: "ozon_ping" });
    report.pingAfterInject = after || null;
    if (after?.ok) report.hints.push("注入后脚本已就绪，现在可以直接点「检测商品页并采集」。");
  }

  return { ok: true, data: report };
}

function sendToTab(tabId, message) {
  return new Promise((resolve) => {
    chrome.tabs.sendMessage(tabId, message, (response) => {
      if (chrome.runtime.lastError) return resolve(null);
      resolve(response || null);
    });
  });
}

/**
 * SKU 采集诊断（v1.9.75）：让 content script 把 1688 页面的真实 DOM 结构吐回来。
 * 采集不准时用它定位——是选择器失效、还是页面结构又改版了。
 */
async function diagnoseSku() {
  const target = await resolveCaptureTab();
  if (!target?.id) {
    return { ok: false, error: "没有找到可诊断的 1688 商品页。请先打开商品详情页并刷新一次。" };
  }
  let reply = await sendToTab(target.id, { action: "ozon_diagnose_sku" });
  // content script 可能是旧版（扩展刚更新、页面没刷新）→ 先补注入再试一次
  if (!reply?.ok) {
    try {
      await chrome.scripting.executeScript({
        target: { tabId: target.id },
        files: [
          "src/content/adapter-base.js",
          "src/content/adapter-1688.js",
          "src/content/adapter-taobao.js",
          "src/content/adapter-pdd.js",
          "src/content/injector.js",
        ],
      });
      await sleep(150);
      reply = await sendToTab(target.id, { action: "ozon_diagnose_sku" });
    } catch { /* 注入失败就把第一次的结果返回 */ }
  }
  if (!reply?.ok) {
    return { ok: false, error: reply?.error || "诊断脚本没有响应，请刷新商品页后重试。" };
  }
  return { ok: true, data: reply.data, tab: { id: target.id, url: target.url } };
}

/* ---------- AI ---------- */

// 非流式生成。需要实时预览时请走名为 ai_stream 的 port 连接（见下方 onConnect）。
async function generateText(message) {
  const settings = await loadSettings();
  const credentials = resolveAiCredentials(settings);
  const product = message.product || {};
  const messages = buildListingMessages(product, message.options || {});

  const content = await chatComplete({ ...credentials, messages, temperature: 0.7 });
  const parsed = parseListingResult(content);
  if (!parsed) return { ok: false, error: "AI 返回内容无法解析为 JSON", raw: content.slice(0, 500) };
  // v1.9.63：把「未知商品 / 未指定 / 信息不足」这类放弃式输出挡在这里，
  // 而不是让它变成草稿里的绿点——否则用户永远不知道其实是采集没拿到数据。
  const quality = inspectListingResult(parsed);
  if (quality.weak) return { ok: false, error: weakListingError(quality, product), raw: content.slice(0, 500) };
  return { ok: true, data: parsed };
}

/**
 * 类目二次精选：候选由真实类目树给出，AI 只负责选一个下标。
 * 这样即使模型说错也只是选错候选，不会编出根本不存在的类目 ID。
 */
async function pickCategory(message) {
  const candidates = Array.isArray(message.candidates) ? message.candidates : [];
  if (!candidates.length) return { ok: false, error: "没有候选类目" };
  const settings = await loadSettings();
  const credentials = resolveAiCredentials(settings);
  const messages = buildCategoryPickMessages(message.product || {}, candidates, message.domains || []);
  const content = await chatComplete({ ...credentials, messages, temperature: 0.1 });
  const picked = parseCategoryPickDetails(content, candidates.length);
  if (!picked || picked.index < 0) return { ok: false, error: "AI 没有选出候选末级类目", raw: content.slice(0, 500) };
  const candidate = candidates[picked.index] || {};
  const node = candidate.node || {};
  const categoryId = Number(node.description_category_id ?? node.category_id) || 0;
  const typeId = Number(node.type_id) || 0;
  const expectedPath = Array.isArray(candidate.path) ? candidate.path.join(" / ").trim() : "";
  const returnedPath = String(picked.path || "").replace(/\s*\/\s*/g, " / ").trim();
  if (!categoryId || !typeId
    || picked.categoryId !== categoryId
    || picked.typeId !== typeId
    || !returnedPath
    || returnedPath !== expectedPath) {
    return { ok: false, error: "AI 返回的类目 ID 与真实候选不一致，已拒绝本次匹配", raw: content.slice(0, 500) };
  }
  return {
    ok: true,
    data: {
      ...picked,
      categoryId,
      typeId,
      path: Array.isArray(candidate.path) ? candidate.path : [],
    },
  };
}

let _categoryTreeBundlePromise = null;

/**
 * v1.9.66：懒加载内置的 Ozon 官方完整类目树（26 域 / 542 类目 / 8600 类型，全部带数字 ID）。
 * v1.9.78：改为读顶层静态 import 进来的 bundle——SW 里动态 import 被规范禁止，
 * 旧实现每次调用都抛异常（被上层 catch 后伪装成「AI 不可用」）。现在保留 Promise 形态，
 * 调用方（matchCategoryTree 等）一行不用改。
 */
function loadCategoryTreeBundle() {
  if (!_categoryTreeBundlePromise) {
    _categoryTreeBundlePromise = (async () => {
      const bundle = OZON_CATEGORY_TREE_BUNDLE;
      const tree = (bundle && bundle.tree) || [];
      if (!Array.isArray(tree) || !tree.length) throw new Error("内置类目树为空");
      return tree;
    })().catch((error) => {
      _categoryTreeBundlePromise = null; // 失败不缓存，下次调用重试
      throw error;
    });
  }
  return _categoryTreeBundlePromise;
}

/**
 * v1.9.66：类目树全量约束匹配（产品标题 + 产品外观图片 双通道）。
 *
 * 阶段 1：把完整类目树的「域 + 类目」清单（约 570 行）+ 商品文字 + 商品外观图交给 AI，选域与类目；
 * 阶段 2：把命中类目下的「类型」清单交给 AI，选类型。
 * 两阶段返回的都是清单行号，这里逐个回查到真实节点才作数——AI 永远编不出树外的类目 ID。
 * 行号对不上、清单里没有合适项（AI 返回 -1）、或该类目下没有可上传类型时，一律判失败，
 * 由面板回退到本地打分候选，不会静默选一个错的。
 */
async function matchCategoryTree(message) {
  const product = message.product || {};
  const imageDataUrls = Array.isArray(message.imageDataUrls)
    ? message.imageDataUrls.filter(Boolean).slice(0, 4)
    : [];
  const tree = await loadCategoryTreeBundle();
  const settings = await loadSettings();
  // 类目匹配是视觉任务：优先使用设置里的 aiVisionModel，不能把默认的纯文本模型
  // （如 deepseek-chat）当成视觉模型。旧实现这里误用了 resolveAiCredentials，导致带图
  // 请求被服务商拒绝后自动降级成纯文字，面板却继续展示「本地匹配度 100%」的候选，
  // 用户看到的自然不是按图片匹配的结果。
  const credentials = resolveVisionCredentials(settings);

  // 双通道是增强、不该成为单点故障：用户配的是纯文本模型（如 deepseek-chat）时，
  // 带图请求会被服务端直接拒掉。这里遇到错误就自动退回纯文字再问一次，并如实回报 imageUsed=false。
  let imageUsed = imageDataUrls.length > 0;
  const ask = async (messages) => {
    try {
      return await chatComplete({ ...credentials, messages, temperature: 0.1 });
    } catch (error) {
      if (!imageUsed) throw error;
      imageUsed = false;
      const textOnly = (messages || []).map((item) => (Array.isArray(item.content)
        ? { role: item.role, content: item.content.filter((part) => part.type === "text").map((part) => part.text).join("\n") }
        : item));
      return chatComplete({ ...credentials, messages: textOnly, temperature: 0.1 });
    }
  };

  const stage1Messages = buildCategoryTreeDomainMessages(product, tree, { imageDataUrls });
  const stage1Raw = await ask(stage1Messages);
  const domainPick = parseCategoryTreeDomainResult(stage1Raw, tree);
  if (!domainPick) {
    return {
      ok: false,
      error: "AI 没有在类目树范围内选出可用的域与类目",
      raw: String(stage1Raw || "").slice(0, 500),
      data: { stage: 1, imageCount: imageDataUrls.length, imageUsed },
    };
  }

  const category = domainPick.category;
  if (!(category.types || []).length) {
    return {
      ok: false,
      error: `AI 选中的类目「${category.name}」下没有可上传的类型`,
      raw: String(stage1Raw || "").slice(0, 500),
      data: { stage: 1, imageCount: imageDataUrls.length, imageUsed },
    };
  }

  // 该类目下只有一个类型时不必再问一次，直接定
  let typePick;
  if (category.types.length === 1) {
    typePick = { type: category.types[0], confidence: domainPick.confidence, reason: "该类目下只有一个可上传类型" };
  } else {
    const stage2Messages = buildCategoryTreeTypeMessages(product, domainPick, { imageDataUrls: imageUsed ? imageDataUrls : [] });
    const stage2Raw = await ask(stage2Messages);
    typePick = parseCategoryTreeTypeResult(stage2Raw, category);
    if (!typePick) {
      return {
        ok: false,
        error: `AI 没有在「${category.name}」下选出可用的类型`,
        raw: String(stage2Raw || "").slice(0, 500),
        data: { stage: 2, domain: domainPick.domain.name, category: category.name, categoryId: category.categoryId, imageUsed },
      };
    }
  }

  const data = composeCategoryTreeMatch(domainPick, typePick, { imageCount: imageUsed ? imageDataUrls.length : 0 });
  if (!data) return { ok: false, error: "AI 选出的类目/类型无法还原为真实节点" };
  return { ok: true, data: {
    ...data,
    imageUsed,
    visionModel: credentials.model || "deepseek-chat",
  } };
}
/**
 * 批量翻译（主要用于把 Ozon 的俄/英类目名翻成中文）。
 * 条数对不上直接判失败：错位的翻译比没翻译更误导。
 */
async function translateTexts(message) {
  const texts = Array.isArray(message.texts) ? message.texts.filter(Boolean) : [];
  if (!texts.length) return { ok: true, data: { translations: [] } };
  const settings = await loadSettings();
  const credentials = resolveAiCredentials(settings);
  const messages = buildTranslateMessages(texts, message.options || { to: "zh" });
  const content = await chatComplete({ ...credentials, messages, temperature: 0.2 });
  const parsed = parseTranslateResult(content, texts.length);
  if (!parsed) return { ok: false, error: "AI 返回内容无法解析为等长数组", raw: content.slice(0, 500) };
  return { ok: true, data: { translations: parsed } };
}

/**
 * AI 自动填写类目属性：把类目要求的属性清单交给模型，按商品信息填值。
 * 返回 { values: { "<属性ID>": "<值>" } }；解析不出来时直接报错，不返回半成品。
 */
async function fillAttributes(message) {
  const settings = await loadSettings();
  const credentials = resolveAiCredentials(settings);
  const product = message.product || {};
  const attributes = Array.isArray(message.attributes) ? message.attributes : [];
  if (!attributes.length) return { ok: false, error: "当前类目没有可填写的属性" };

  const messages = buildAttributeMessages(product, attributes, message.options || {});
  const content = await chatComplete({ ...credentials, messages, temperature: 0.3 });
  const parsed = parseAttributeResult(content);
  if (!parsed) return { ok: false, error: "AI 返回内容无法解析为 JSON", raw: content.slice(0, 500) };
  return { ok: true, data: parsed };
}

/**
 * v1.9.64 JSON 富内容（类目属性 id 11254）的文字方案。
 * 模型只写每个图块的标题与正文，图片直链与宽高由面板侧用采集到的真实数据拼
 * （模型编出来的图片地址一定 404，宽高对不上会让排版错乱）。
 * 返回 { blocks: [{ title, text }] }；解析不出来时报错，面板改走不调 AI 的兜底排版。
 */
async function buildRichContent(message) {
  const settings = await loadSettings();
  const credentials = resolveAiCredentials(settings);
  const images = Array.isArray(message.images) ? message.images.filter((item) => item?.url) : [];
  if (!images.length) {
    return { ok: false, error: "没有可用作富内容的图片（Ozon 只接受 jpg / jpeg / png 直链，不接受 gif）" };
  }
  const messages = buildRichContentMessages(message.product || {}, images, message.options || {});
  const content = await chatComplete({ ...credentials, messages, temperature: 0.4 });
  const parsed = parseRichContentPlanResult(content);
  if (!parsed) {
    return { ok: false, error: "AI 返回内容无法解析为富内容方案（或整段混进了中文）", raw: content.slice(0, 500) };
  }
  return { ok: true, data: parsed };
}

async function detectSpecOptions(message) {
  const settings = await loadSettings();
  const credentials = resolveAiCredentials(settings);
  const product = message.product || {};
  const messages = buildSpecDetectMessages(product);
  const content = await chatComplete({ ...credentials, messages, temperature: 0.3 });
  const options = parseSpecDetectResult(content);
  if (!options) return { ok: false, error: "AI 返回的规格维度无法解析", raw: content.slice(0, 500) };
  return { ok: true, data: options };
}

/**
 * 上架套图：生成俄文卖点（图上要出现的字，必须先定死）。
 * 没配 AI 时返回明确错误，由面板兜底成「让用户手填」而不是瞎编。
 */
async function generateSellingPoints(message) {
  const settings = await loadSettings();
  const credentials = resolveAiCredentials(settings);
  const product = message.product || {};
  const options = message.options || {};
  const messages = buildSellingPointsMessages(product, options);
  const content = await chatComplete({ ...credentials, messages, temperature: 0.6 });
  const points = parseSellingPointsResult(content, Number(options.count) || 8);
  if (!points) return { ok: false, error: "AI 返回的卖点无法解析", raw: content.slice(0, 500) };
  return { ok: true, data: { points } };
}

/**
 * v1.9.73 策划师模式：一次产出「卖点表（按影响力排序 + 唯一最强卖点）+ 8 图结构化方案」。
 * 与 generateImagePlan（只配标题）不同：这里连画面、图内俄文、英文出图 prompt 一起出，
 * 供面板逐张直接调 redrawImage 出图。校验不过（缺图/卖点空）返回 ok:false，界面提示重试。
 */
async function generateImageStrategy(message) {
  const settings = await loadSettings();
  const credentials = resolveAiCredentials(settings);
  const product = message.product || {};
  const messages = buildPlanMessages(product, message.options || {});
  const content = await chatComplete({ ...credentials, messages, temperature: 0.75 });
  const result = parsePlanResult(content);
  if (!result.ok) {
    return { ok: false, error: `策划方案解析失败：${(result.problems || []).join("；") || "AI 返回无法解析"}`, raw: content.slice(0, 500) };
  }
  return { ok: true, data: { plan: result.data, problems: result.problems || [] } };
}

/** 上架套图：给每个带文字的拍摄方案配俄文标题 + 副标题 */
async function generateImagePlan(message) {  const settings = await loadSettings();
  const credentials = resolveAiCredentials(settings);
  const product = message.product || {};
  const shots = Array.isArray(message.shots) ? message.shots : [];
  if (!shots.length) return { ok: false, error: "没有需要拟定标题的图片" };
  const messages = buildImagePlanMessages(product, shots, message.options || {});
  const content = await chatComplete({ ...credentials, messages, temperature: 0.7 });
  const plan = parseImagePlanResult(content);
  if (!plan) return { ok: false, error: "AI 返回的标题方案无法解析", raw: content.slice(0, 500) };
  return { ok: true, data: { plan } };
}

/**
 * v1.9.49 出图前视觉分析：把参考图发给视觉模型，先对比图与图之间的差异
 * （构图/风格/色调/光影/材质/主体表现），再为每张待生成的图各出一份独立方案。
 * 模型没配 / 不支持图片输入时返回 ok:false —— 面板降级为「版式逐张轮换」，不阻断出图。
 */
async function analyzeArtDirection(message) {
  const settings = await loadSettings();
  const credentials = resolveVisionCredentials(settings);
  const shots = Array.isArray(message.shots) ? message.shots : [];
  const refs = (Array.isArray(message.referenceImages) ? message.referenceImages : [])
    .map((item) => String(item || "").trim())
    .filter(Boolean)
    .slice(0, 3);
  if (!shots.length) return { ok: false, error: "没有需要定制方案的图片" };
  if (!refs.length) return { ok: false, error: "没有可分析的参考图" };
  if (!credentials.model) return { ok: false, error: "未配置 AI 模型（视觉分析需要支持图片输入的模型）" };
  const messages = buildArtDirectionMessages(message.product || {}, shots, {
    ...message.options, referenceImages: refs,
  });
  const content = await chatComplete({ ...credentials, messages, temperature: 0.8, timeoutMs: 180000 });
  const result = parseArtDirectionResult(content);
  if (!result) return { ok: false, error: "视觉分析结果无法解析", raw: String(content || "").slice(0, 500) };
  return { ok: true, data: result };
}

/**
 * AI 文案连通性自检。
 * 面板会带上界面上当前填的地址/模型/Key —— 用户点「测试连接」想验的是「我刚填的这套」，
 * 而不是「上次保存的那套」。没带时（例如工作台）才回落到已保存的设置。
 */
async function testAiConnection(message = {}) {
  const settings = await loadSettings();
  const provided = message.credentials || null;
  const credentials = provided
    ? {
      baseUrl: cleanTextValue(provided.baseUrl) || settings.aiBaseUrl,
      apiKey: cleanTextValue(provided.apiKey) || settings.aiApiKey,
      model: cleanTextValue(provided.model) || settings.aiModel,
    }
    : resolveAiCredentials(settings);
  return testAi(credentials);
}

/* ---------- AI 流式（port） ---------- */

chrome.runtime.onConnect.addListener((port) => {
  if (port.name !== "ai_stream") return;
  port.onMessage.addListener(async (message) => {
    try {
      const settings = await loadSettings();
      const credentials = resolveAiCredentials(settings);
      const messages = buildListingMessages(message.product || {}, message.options || {});
      const content = await chatCompleteStream({
        ...credentials,
        messages,
        onDelta: (delta) => port.postMessage({ type: "delta", delta }),
      });
      const parsed = parseListingResult(content);
      // v1.9.63：流式路径同样要过质量闸门（见 generateText 的说明）
      const quality = inspectListingResult(parsed);
      if (quality.weak) {
        port.postMessage({ type: "done", ok: false, error: weakListingError(quality, message.product || {}), raw: content.slice(0, 2000) });
        return;
      }
      port.postMessage({ type: "done", ok: Boolean(parsed), data: parsed, raw: content.slice(0, 2000) });
    } catch (error) {
      port.postMessage({ type: "error", error: error?.message || String(error) });
    }
  });
});

/* ---------- Ozon ---------- */

async function ozonCall(fn, storeId = "") {
  const settings = await loadSettings();
  const credentials = resolveOzonCredentials(settings, storeId);
  if (!credentials.clientId || !credentials.apiKey) {
    const label = storeId ? "所选店铺" : "默认店铺";
    return { ok: false, error: `${label}未填写 Client-Id / Api-Key：请到「插件设置 → 店铺管理 → 编辑默认店铺凭证」填写后重试；或在顶部「已绑定的 OZON 店铺信息 / 上传」区的店铺下拉里选一家已填好凭证的店铺。` };
  }
  try {
    const data = await fn(credentials);
    return { ok: true, data };
  } catch (error) {
    return { ok: false, error: error?.message || String(error) };
  }
}

/**
 * 批量拉枚举型属性的候选值字典（v1.9.50）。
 *
 * 为什么必须单独做：/v1/description-category/attribute 只返回属性定义（带 dictionary_id），
 * **不返回候选值**。所以过去 attr.dictionary 一直是空的 —— AI 没有候选值可挑只能自己编，
 * 上传时又只发自由文本，Ozon 必然回「属性不正确：不要手输这些值，请从列表中选择」。
 * 候选值只能一个属性一次请求地拿，所以这里做了并发限制 + 7 天缓存 + 单属性失败不拖垮整批。
 */
const ATTR_VALUE_CACHE_TTL = 7 * 24 * 60 * 60 * 1000;
const ATTR_VALUE_CACHE_MAX = 200;
// v1.9.55 属性「定义」缓存：平台会改类目属性（加必填、换字典绑定），24 小时必须回源一次，
// 靠指纹判断「定义变没变」——变了立刻失效。候选值几乎不变，可以放 7 天，所以两份分开管。
const ATTR_META_CACHE_TTL = 24 * 60 * 60 * 1000;
const ATTR_META_CACHE_MAX = 60;

/**
 * 批量拉枚举候选值：先读 attributeValuesCache，缺的并发 3 回源，再写回（LRU 上限）。
 * v1.9.55 从 fetchAttributeDictionaries 里抽出来，供元数据加载复用（定义一拿到就顺手
 * 把全部枚举属性的候选值补齐，而不是只补必填+变体）。
 */
async function loadEnumDictionaries(credentials, { categoryId, typeId, language, ids }) {
  const stored = await chrome.storage.local.get(STORAGE_KEYS.attributeValuesCache);
  const cache = stored?.[STORAGE_KEYS.attributeValuesCache] || {};
  const now = Date.now();
  const out = {};
  const missing = [];
  for (const id of ids) {
    const key = `${categoryId}:${typeId}:${id}:${language}`;
    const hit = cache[key];
    if (hit && now - (hit.at || 0) < ATTR_VALUE_CACHE_TTL && Array.isArray(hit.values)) {
      out[id] = hit.values;
    } else {
      missing.push(id);
    }
  }
  // 并发 3：同一 Api-Key 有 QPS 限制，别一次把几十个请求打出去
  let cursor = 0;
  const workers = Array.from({ length: Math.min(3, missing.length) }, async () => {
    while (cursor < missing.length) {
      const id = missing[cursor];
      cursor += 1;
      try {
        const values = await ozon.fetchAttributeValues(credentials, {
          descriptionCategoryId: categoryId, typeId, attributeId: id, language,
        });
        out[id] = values;
        cache[`${categoryId}:${typeId}:${id}:${language}`] = { at: now, values };
      } catch {
        out[id] = []; // 单个属性拉不到不影响其它属性
      }
    }
  });
  await Promise.all(workers);
  const keys = Object.keys(cache);
  if (keys.length > ATTR_VALUE_CACHE_MAX) {
    keys.sort((a, b) => (cache[a]?.at || 0) - (cache[b]?.at || 0));
    for (const key of keys.slice(0, keys.length - ATTR_VALUE_CACHE_MAX)) delete cache[key];
  }
  try {
    await chrome.storage.local.set({ [STORAGE_KEYS.attributeValuesCache]: cache });
  } catch { /* 缓存写不下不影响本次返回 */ }
  return out;
}

async function fetchAttributeDictionaries(message) {
  const payload = message.payload || {};
  const categoryId = Number(payload.descriptionCategoryId) || 0;
  const typeId = Number(payload.typeId) || 0;
  const language = payload.language || "ru";
  const ids = [...new Set((payload.attributeIds || []).map((id) => Number(id) || 0).filter(Boolean))];
  if (!ids.length) return { ok: true, data: {} };
  return ozonCall((credentials) => loadEnumDictionaries(credentials, { categoryId, typeId, language, ids }), message.storeId);
}

/**
 * 类目属性「官方元数据」加载（v1.9.55）：定义 + 版本指纹 + 全量候选值，一次拿全。
 *
 * 三层判定：
 *  1. 缓存 24h 内命中且未 force → 直接返回（0 网络请求）；
 *  2. 回源后算指纹，与缓存里的一致 → 保留原回源时间（平台没改，不算新数据）；
 *  3. 空清单按失败处理（不是「该类目没有属性」——接口临时挂了会把用户属性表清空）。
 * v1.9.57 加第四层：官方离线属性库（后台类目模板解析出来的全量属性，见 shared/offline-kb.js）。
 *   - 接口正常：定义用接口的（类型级，更准），候选值吃离线库的（全量、不截断、0 请求）；
 *   - 接口挂了 / 没填密钥：整份属性表由离线库顶上，来源标 offline，界面会写明。
 * 全量候选值是过去错值率高的根因之一：只拉必填+变体，其余枚举字典恒空 → 界面给文本框
 * → AI 自由发挥 → 上传发自由文本 → Ozon 判「属性不正确：请从列表中选择」。
 * 属性定义是平台级的，缓存键不带 storeId。
 */
async function fetchCategoryAttributeMeta(message) {
  const payload = message.payload || {};
  const categoryId = Number(payload.descriptionCategoryId) || 0;
  const typeId = Number(payload.typeId) || 0;
  const language = payload.language || "ru";
  const force = Boolean(payload.force);
  if (!typeId) return { ok: false, error: "还没选到类目「类型」，先选好类目再加载属性" };
  const key = `${categoryId}:${typeId}`;
  const stored = await chrome.storage.local.get(STORAGE_KEYS.attributeMetaCache);
  const cache = stored?.[STORAGE_KEYS.attributeMetaCache] || {};
  const hit = cache[key];
  const now = Date.now();
  // v1.9.58 缓存代际：v1.9.57 曾把离线库的中文候选值直接塞进 dictionary 缓存过，
  // 上传枚举值必须是俄文官方值 —— 旧代际缓存一律作废重来（gen 不匹配当未命中处理）。
  const CACHE_GEN = 2;
  if (!force && hit && hit.gen === CACHE_GEN && Array.isArray(hit.attributes) && hit.attributes.length && now - (hit.at || 0) < ATTR_META_CACHE_TTL) {
    return { ok: true, data: { attributes: hit.attributes, meta: { source: "cache", at: hit.at, fingerprint: hit.fingerprint, offline: hit.offline || null } } };
  }
  // v1.9.57 官方离线属性库：本地文件，几十毫秒，先探一下这个类目有没有。
  // v1.9.58 职责调整：候选值（上传用的俄文官方值）仍从接口拉，离线库负责
  // 中文显示层（属性名/候选值 displayValue/填写说明）+ 变体标记 + 接口挂掉时的整表兜底。
  const offline = await loadOfflineCategory(categoryId).catch(() => null);
  const run = async (credentials) => {
    let attributes = [];
    let source = "network";
    let offlineInfo = null;
    try {
      attributes = await ozon.fetchCategoryAttributes(credentials, { descriptionCategoryId: categoryId, typeId, language });
      if (!Array.isArray(attributes) || !attributes.length) {
        throw new Error("Ozon 返回了空的属性清单：该类目可能未绑定属性，或接口临时不可用。已保留本地现有属性表，请稍后点「强制刷新元数据」重试。");
      }
      // 第一轮：定义级对齐（中文名、变体标记、字典真实规模）。此时接口定义还没带候选值，
      // 候选值的中文对齐在拉完 values 之后做（第二轮）。
      if (offline) {
        const filled = enrichAttributesFromOffline(attributes, offline);
        offlineInfo = { dictionaries: 0, aspects: filled.aspects, hints: filled.hints, zhNames: filled.zhNames, name: offline.name };
      }
    } catch (error) {
      // 接口没走通：离线库能顶就顶，但必须标清楚来源（离线库是类目级的，比类型级宽；
      // 且候选值是模板里的中文翻译，上传靠官方 dictionary_value_id 认，界面照常中文）
      if (offline && offline.attributes.length) {
        attributes = offline.attributes;
        offlineInfo = { dictionaries: 0, aspects: 0, hints: 0, zhNames: 0, name: offline.name, fallbackReason: error?.message || String(error) };
        source = "offline";
      } else {
        throw error;
      }
    }
    const fingerprint = ozon.buildAttributesFingerprint(attributes);
    const at = hit && hit.fingerprint === fingerprint ? (hit.at || now) : now;
    // 补候选值（v1.9.58：一律以接口俄文值为准 —— 上传 payload 的枚举 value 必须是俄文官方值，
    // 离线库的中文值只做显示）。dictionary_state === "huge" 的（>2000）接口也拿不全，
    // 别浪费请求，这类走 v1.9.56 的 /values/search 按词反查。
    const enumIds = attributes
      .filter((attr) => Number(attr.dictionary_id) > 0 && !(Array.isArray(attr.dictionary) && attr.dictionary.length) && attr.dictionary_state !== "huge")
      .map((attr) => Number(attr.id))
      .filter(Boolean);
    if (enumIds.length && source === "network") {
      const dicts = await loadEnumDictionaries(credentials, { categoryId, typeId, language: "ru", ids: enumIds });
      for (const attr of attributes) {
        const values = dicts[String(attr.id)] || dicts[attr.id];
        if (Array.isArray(values) && values.length) attr.dictionary = values;
      }
    }
    // 第二轮（v1.9.58）：俄文候选值到手，按 dictionary_value_id 对齐离线库里的官方中文
    if (offline && source === "network") {
      const filled = enrichAttributesFromOffline(attributes, offline);
      if (offlineInfo) {
        offlineInfo.zhValues = filled.zhValues;
        offlineInfo.dictionaries = attributes.filter((a) => Number(a.dictionary_id) > 0).length;
      }
    }
    // 接口顶上的（source=offline）不写缓存：候选值是模板中文，接口一恢复就要按俄文重拉
    if (source === "network") {
      cache[key] = { gen: CACHE_GEN, at, fingerprint, attributes, offline: offlineInfo };
      const keys = Object.keys(cache);
      if (keys.length > ATTR_META_CACHE_MAX) {
        keys.sort((a, b) => (cache[a]?.at || 0) - (cache[b]?.at || 0));
        for (const k of keys.slice(0, keys.length - ATTR_META_CACHE_MAX)) delete cache[k];
      }
      try {
        await chrome.storage.local.set({ [STORAGE_KEYS.attributeMetaCache]: cache });
      } catch { /* 属性清单太大写不进去也不影响本次返回 */ }
    }
    return { attributes, meta: { source, at, fingerprint, offline: offlineInfo } };
  };
  const result = await ozonCall(run, message.storeId);
  if (result.ok) return result;
  // 没填 Client-Id / Api-Key 时 ozonCall 根本不会调接口 —— 这种也用离线库顶上，
  // 用户至少能先把属性表填完。不写缓存：等他把密钥填好，下次自然走接口。
  if (offline && offline.attributes.length) {
    return {
      ok: true,
      data: {
        attributes: offline.attributes,
        meta: {
          source: "offline",
          at: Date.now(),
          fingerprint: ozon.buildAttributesFingerprint(offline.attributes),
          offline: { dictionaries: 0, aspects: 0, hints: 0, name: offline.name, fallbackReason: result.error },
        },
      },
    };
  }
  return result;
}

/**
 * 多店铺批量上传：草稿 × 店铺 逐个提交，逐条记录结果。
 * 放在后台执行，面板关闭也不会中断；请求之间按 bulkDelayMs 间隔，避免触发 Ozon 限流。
 */
async function bulkImport(message) {
  const { draftIds = [], storeIds = [], options = {} } = message;
  if (!draftIds.length) return { ok: false, error: "请先选择要上传的草稿" };

  const settings = await loadSettings();
  const stored = await chrome.storage.local.get(STORAGE_KEYS.drafts);
  const drafts = (stored?.[STORAGE_KEYS.drafts] || []).filter((item) => draftIds.includes(item.id));
  if (!drafts.length) return { ok: false, error: "选中的草稿不存在" };

  const stores = storeIds.length
    ? (settings.stores || []).filter((store) => storeIds.includes(store.id))
    : [resolveOzonCredentials(settings)];
  if (!stores.length) return { ok: false, error: "没有可用的店铺凭证" };

  const results = [];
  for (const store of stores) {
    for (const draft of drafts) {
      const selectedSkus = Array.isArray(draft.selectedSkus) && draft.selectedSkus.length
        ? (draft.skus || []).filter((sku) => draft.selectedSkus.includes(sku.id))
        : [];
      // 优先用草稿自己保存的定价；没有则按上架表口径现算一个（统一走 OZON 核价，不再混用旧的 cost+加价公式）
      let pricing = draft.pricing;
      if (!pricing) {
        const parcel = draft.parcel || {};
        const template = normalizeListingTemplate(settings.listing || {});
        // 现算口径与核价表一致：拿货成本 = 采购价 + 国内运费（splitCostCny 里防重复加运费）
        const costs = selectedSkus.map((sku) => splitCostCny({ sku, draft, template }).cost).filter(Boolean);
        const fallbackCost = Number(draft.costCny) || Number(draft.skus?.[0]?.price) || 0;
        const avg = costs.length
          ? costs.reduce((sum, value) => sum + value, 0) / costs.length
          : (fallbackCost ? splitCostCny({ sku: { price: fallbackCost }, draft, template }).cost : 0);
        const calc = computeListing({
          costCny: avg,
          weightG: Math.round((Number(parcel.weightKg) || 0) * 1000),
          lengthCm: Number(parcel.lengthCm) || 0,
          widthCm: Number(parcel.widthCm) || 0,
          heightCm: Number(parcel.heightCm) || 0,
          template,
        });
        // v1.9.50 口径同面板：price = 买家实付（活动价），old_price = 划线价（原价）
        pricing = {
          priceCny: calc.promoCny,
          oldPriceCny: calc.priceCny,
          priceRub: Math.round(calc.promoRub),
          oldPriceRub: Math.round(calc.priceRub),
        };
      }
      try {
        const importOptions = {
          category: draft.ozonCategory || {},
          pricing,
          weightGrams: options.weightGrams,
          depthMm: options.depthMm,
          widthMm: options.widthMm,
          heightMm: options.heightMm,
          vat: options.vat,
          skuPrefix: store.skuPrefix || settings.skuPrefix,
          variantAttributeId: Number(options.variantAttributeId) || Number(settings.variantAttributeId) || 0,
          selectedSkus,
          attributeDefinitions: draft.categoryAttributes || [],
          attributeValues: draft.attributeValues || {},
        };
        // 逐条预检：类目/类型/售价/名称缺一不可，否则先把中文原因回给用户，别浪费一次 Ozon 请求
        ozon.assertReadyToImport(draft, importOptions);
        const items = ozon.buildImportItems(draft, importOptions);
        const data = await ozon.importProducts(
          { clientId: store.clientId, apiKey: store.apiKey },
          items,
        );
        results.push({
          store: store.name || store.id || "默认店铺",
          draftId: draft.id,
          title: draft.ru?.title || draft.title || "",
          ok: true,
          count: items.length,
          taskId: data?.task_id || "",
          error: "",
        });
      } catch (error) {
        results.push({
          store: store.name || store.id || "默认店铺",
          draftId: draft.id,
          title: draft.ru?.title || draft.title || "",
          ok: false,
          taskId: "",
          error: error?.message || String(error),
        });
      }
      await sleep(Math.max(0, Number(settings.bulkDelayMs) || 1500));
    }
  }

  const succeeded = results.filter((item) => item.ok).length;
  return { ok: true, data: { results, total: results.length, succeeded } };
}

/** 在已登录的卖家后台页面里读取商品行数据 */
async function salesIntel() {
  const cookies = await chrome.cookies.getAll({ url: OZON_SELLER_ORIGIN });
  const companyId = cookies.find((cookie) => cookie.name === "sc_company_id")?.value || "";
  if (!companyId) return { ok: false, error: "未找到 sc_company_id，请先在浏览器登录 seller.ozon.ru" };

  const tabs = await new Promise((resolve) => {
    chrome.tabs.query({ url: "https://seller.ozon.ru/*" }, resolve);
  });
  const tab = (tabs || []).find((item) => item.id);
  if (!tab) return { ok: false, error: "请先打开 seller.ozon.ru 的商品列表或分析页面" };

  let response = await sendToTab(tab.id, { action: MESSAGE_ACTIONS.ozonSalesIntel });
  if (!response) {
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      files: ["src/content/seller-intel.js"],
    });
    response = await sendToTab(tab.id, { action: MESSAGE_ACTIONS.ozonSalesIntel });
  }
  if (!response) return { ok: false, error: "卖家后台脚本无响应，请刷新页面后重试" };
  return { ...response, companyId };
}

/* ---------- 图片 ---------- */

// 图片翻译：走象寄开放平台，把中文整图替换为俄文（图片会发送到象寄服务器）
async function translateImages(message) {
  const settings = await loadSettings();
  // 象寄每个引擎有各自的标识码，这里按用户选的引擎取对应密钥（同引擎可配多个，并行提速）
  const { keys, vendor, all } = resolveXiangjiCredentials(settings, message.vendor);
  if (!all.length) {
    return { ok: false, error: "请先在「插件设置 → 图片翻译与 AI 生图」添加至少一个象寄 ImgTransKey（每个引擎一个）" };
  }
  if (!keys.length) {
    return { ok: false, error: "没有可用于该翻译引擎的象寄密钥，请在设置里为该引擎添加 ImgTransKey，或换一个已配置的引擎" };
  }
  try {
    const data = await translateImagesWithXiangji({
      keys,
      vendor,
      images: message.images || [],
      fetchAsDataUrl: readImageAsDataUrl,
    });
    return { ok: true, data, meta: { keyCount: keys.length, vendor } };
  } catch (error) {
    return { ok: false, error: error?.message || String(error) };
  }
}

// 象寄密钥可用性检测：不创建任务、不上传图片，因此不消耗额度。
// 传了 vendor 就只测该引擎的密钥；不传则测全部已配置的密钥。
// message.keys 允许面板直接传「界面上正在编辑、还没保存」的密钥，测的就是所见内容。
async function testXiangji(message = {}) {
  const settings = await loadSettings();
  const vendor = cleanVendor(message.vendor);
  const fromUi = Array.isArray(message.keys) && message.keys.length
    ? normalizeXiangjiKeys({ xiangjiKeys: message.keys, xiangjiVendor: vendor || settings.xiangjiVendor })
    : null;
  const all = fromUi || normalizeXiangjiKeys(settings);
  const keys = vendor ? all.filter((item) => item.vendor === vendor) : all;
  if (!keys.length) {
    return {
      ok: false,
      error: vendor
        ? `没有为「${vendor}」配置密钥，请到「插件设置 → 图片翻译与 AI 生图」添加`
        : "还没有配置任何象寄 ImgTransKey，请到「插件设置 → 图片翻译与 AI 生图」添加",
      results: [],
    };
  }
  const data = await testXiangjiKeys({ keys });
  return { ...data, vendor };
}

// AI 生图可用性检测：走 /models 探针，不生成图片，因此不消耗额度。
// message.credentials 允许面板直接传界面上未保存的配置，测的就是所见内容。
async function testRedraw(message = {}) {
  const settings = await loadSettings();
  const provided = message.credentials || null;
  const credentials = provided
    ? {
      baseUrl: cleanTextValue(provided.baseUrl) || settings.aiBaseUrl,
      apiKey: cleanTextValue(provided.apiKey) || settings.aiApiKey,
      model: cleanTextValue(provided.model),
    }
    : resolveImageCredentials(settings);
  return testImageGeneration(credentials);
}

function cleanVendor(value) {
  return cleanTextValue(value);
}

function cleanTextValue(value) {
  return String(value == null ? "" : value).replace(/\s+/g, " ").trim();
}

// AI 重绘：调用 /v1/images/generations 生成不含中文的新图
async function redraw(message) {
  const settings = await loadSettings();
  const credentials = resolveImageCredentials(settings);
  if (!credentials.model) {
    return { ok: false, error: "请先在「插件设置 → 图片翻译与 AI 生图」填写生图模型名称（推荐 硅基流动 + Kwai-Kolors/Kolors）" };
  }
  try {
    const data = await redrawImage({
      ...credentials,
      context: message.context,
      styleHint: message.styleHint,
      // 上架套图：按拍摄方案（主图/场景/细节…）拼提示词；无 shot 时走以前的通用重绘
      shot: message.shot || "",
      points: message.points || "",
      // 图上要写死的文字（俄文标题 / 副标题）与规格标签、补充信息
      title: message.title || "",
      subtitle: message.subtitle || "",
      labels: Array.isArray(message.labels) ? message.labels : [],
      extraInfo: message.extraInfo || "",
      // 参考图（本产品图，URL 或 data URL）：传了才是「基于本产品」的图生图
      referenceImage: message.referenceImage || "",
      // v1.9.38 多张参考图（图集 + 各变体图全参考），生图侧统一去重并限量
      referenceImages: Array.isArray(message.referenceImages) ? message.referenceImages : [],
      // v1.9.42 风格方向（纯色棚拍/居家/街景…）与「棚拍允许纯白底」开关
      direction: message.direction || null,
      allowWhiteBg: Boolean(message.allowWhiteBg),
      // v1.9.49 去模板化：逐张版式/取景种子、该图专属导演方案、重出时的调整方向
      layoutSeed: Number(message.layoutSeed) || 0,
      framingSeed: Number(message.framingSeed) || 0,
      artDirection: message.artDirection || "",
      reworkNote: message.reworkNote || "",
      // v1.9.73 策划师模式：面板已拼好的完整出图指令（有值就直连采用，跳过逐张轮换）
      plannedPrompt: message.plannedPrompt || "",
      // 面板没传就用设置里的预设尺寸（如达瓦中转 1008x1344），别被 undefined 覆盖掉
      size: message.size || credentials.size,
      aspectRatio: message.aspectRatio || credentials.aspectRatio,
    });
    return { ok: true, data };
  } catch (error) {
    const message = error?.message || String(error);
    // MV3 没拿到主机权限时 fetch 会报 Failed to fetch / NetworkError，信息很含糊；
    // 这里把域名点出来，方便用户去扩展管理页确认权限或重装扩展。
    if (/failed to fetch|networkerror|not allowed|not permitted|could not connect/i.test(message)) {
      const host = (() => {
        try { return new URL(credentials.baseUrl).hostname; } catch { return "当前生图域名"; }
      })();
      return {
        ok: false,
        error: `生图请求被浏览器拦截（${host}）。最常见原因：扩展没有该域名的主机权限；更新扩展后请重新加载或重装插件。原始错误：${message}`,
      };
    }
    return { ok: false, error: message };
  }
}

// 用后台 fetch 取回图片并转成 data URL（绕过防盗链与 CORS）。失败时抛错。
// v1.9.60：加 30s 超时——图床挂起不响应时，没有超时的 fetch 会让整条翻译/参考图流水线卡死。
async function readImageAsDataUrl(url) {
  const clean = String(url || "").trim();
  if (!/^https?:\/\//i.test(clean)) throw new Error("图片地址无效");
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 30000);
  let response;
  try {
    response = await fetch(clean, { credentials: "omit", referrerPolicy: "no-referrer", signal: controller.signal });
  } catch (error) {
    if (error?.name === "AbortError") throw new Error("取图超时（30 秒）");
    throw error;
  } finally {
    clearTimeout(timer);
  }
  if (!response.ok) throw new Error(`取图失败：HTTP ${response.status}`);
  const blob = await response.blob();
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = () => reject(new Error("图片读取失败"));
    reader.readAsDataURL(blob);
  });
}

// 图片下载常受防盗链与 CORS 限制，这里用后台 fetch 取回并转成 data URL
async function fetchImageAsDataUrl(url) {
  try {
    return { ok: true, dataUrl: await readImageAsDataUrl(url) };
  } catch (error) {
    return { ok: false, error: error?.message || String(error) };
  }
}

/**
 * 上传前探测图片是否真的可用（v1.9.50）。
 *
 * 起因：Ozon 是拿**图片 URL 自己回源下载**的，抓不到就把商品判成「商品卡片中没有照片」直接封锁。
 * 而草稿里的图片有几种一定会失败的情况：
 *   - data:/blob: 地址（Ozon 根本解析不了，AI 出图若只回 base64 就是这种）；
 *   - 图床的临时签名链（DashScope 等中转的 OSS 链接会过期）；
 *   - 需要登录/带防盗链的地址，回源回来的是 HTML 错误页而不是图片。
 * 这里对每个地址发一次 GET，检查内容类型是不是 image/*；不是就明确回报原因。
 * 注意：探测通过只代表「地址现在是好的」，不代表 Ozon 一定能抓到（它那边有独立的出网策略），
 * 所以这里只用来拦掉**确定不可用**的地址，不做反向承诺。
 */
async function probeImageUrls(urls = []) {
  const list = [...new Set((urls || []).map((url) => String(url || "").trim()).filter(Boolean))].slice(0, 30);
  const results = await Promise.all(list.map(async (url) => {
    if (/^data:/i.test(url)) return { url, ok: false, reason: "本地 base64 图（data:），Ozon 无法抓取，需要先上传到图床" };
    if (/^blob:/i.test(url)) return { url, ok: false, reason: "本地 blob 地址，Ozon 无法抓取" };
    if (!/^https?:\/\//i.test(url)) return { url, ok: false, reason: "不是 http(s) 地址" };
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 10000);
    // v1.9.60：先发 HEAD（图床普遍支持，不用下载整张图），HEAD 明确「方法不支持/路径不存在」
    // （405/501/400）时才退回 GET；GET 只需要头部，读到 content-type 立即取消流，
    // 批量上传前探测几十张图不再把几十张原图全下载一遍。
    const contentTypeOf = async (response) => String(response.headers.get("content-type") || "").toLowerCase();
    const verdict = (type) => {
      if (/^image\//.test(type)) return { url, ok: true, reason: "" };
      if (/text\/html|application\/json/.test(type)) {
        return { url, ok: false, reason: `返回的不是图片（${type}），可能是防盗链/需登录/链接已过期` };
      }
      // 有些图床 content-type 给得不规范（空、octet-stream 等），这里宽容一点：只有明确 html/json 才算坏
      return { url, ok: true, reason: "" };
    };
    try {
      let response = await fetch(url, { method: "HEAD", signal: controller.signal, credentials: "omit" });
      // v1.9.84 回落条件从 400/405/501 扩到含 401/403：
      // 通义万相（DashScope）返回的是 OSS 签名直链，签名按 GET 方法算——HEAD 必回
      // 403 SignatureDoesNotMatch。旧列表不含 403，8 张 AI 图全被误判「Ozon 抓不到」拦下
      //（超哥截图「已拦下 8 张」实证）。签名类 403 不代表图坏了，必须 GET 复核。
      if (!response.ok && [400, 401, 403, 404, 405, 501].includes(response.status)) {
        response = await fetch(url, { method: "GET", signal: controller.signal, credentials: "omit" });
        // GET 只取头部，不等 body —— 立即取消，省掉整张图的下载
        try { await response.body?.cancel(); } catch { /* 已关闭也无妨 */ }
      }
      if (!response.ok) return { url, ok: false, reason: `HTTP ${response.status}` };
      const type = await contentTypeOf(response);
      // HEAD 有不少图床不给 content-type（或给空），这种拿不准的情况补一次 GET 头确认
      if (!type) {
        const viaGet = await fetch(url, { method: "GET", signal: controller.signal, credentials: "omit" }).catch(() => null);
        if (viaGet) {
          const getType = await contentTypeOf(viaGet);
          try { await viaGet.body?.cancel(); } catch { /* 忽略 */ }
          if (getType) return verdict(getType);
        }
        return { url, ok: true, reason: "" };
      }
      return verdict(type);
    } catch (error) {
      return { url, ok: false, reason: error?.name === "AbortError" ? "请求超时（10 秒）" : (error?.message || String(error)) };
    } finally {
      clearTimeout(timer);
    }
  }));
  return { results, bad: results.filter((item) => !item.ok).length };
}

/* ---------- 安装 ---------- */

// 点击扩展图标：在独立标签页打开工作台（popup 尺寸太小，不适合本面板）
chrome.action.onClicked.addListener(() => {
  const url = chrome.runtime.getURL("src/ui/panel.html");
  chrome.tabs.query({ url }, (tabs) => {
    if (tabs?.length) chrome.tabs.update(tabs[0].id, { active: true });
    else chrome.tabs.create({ url });
  });
});

chrome.runtime.onInstalled.addListener(async () => {
  // 首次安装时落一份默认设置，保证面板打开即可用
  const settings = await loadSettings();
  await chrome.storage.local.set({ [STORAGE_KEYS.settings]: settings });
});
