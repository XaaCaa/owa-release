"""OWA 一键发布：升版本号 → 生成更新 JSON → 打包 zip。

用法（在项目根目录或任意目录执行）：
    python tools/release.py --zip-url "https://你的直链/OWA-V1.9.87.zip" --notes "修复了XX；新增YY"

做了四件事：
1. manifest.json 版本号自动 +1（或 --version 指定）；
2. 在项目上级目录生成 owa-update.json（version/url/notes 三字段）——
   把它**覆盖上传**到与 BUILT_IN_UPDATE_URL 相同的固定地址，所有客户即可发现新版；
3. 若 constants.js 里 BUILT_IN_UPDATE_URL 还是空的，用 --update-url 一次性写进去
   （这个地址以后永远不变，客户包里的内置地址指向它）；
4. 调用 package.py 打出 OWA-V<新版本>.zip。

客户侧零配置：打开面板自动检查（6 小时节流），点版本号 → 下载 → 覆盖文件夹 → 重新加载。
激活码/草稿/设置都在浏览器存储里，升级不丢、不需要重新激活。
"""
import argparse
import json
import os
import re
from urllib.parse import urlparse
import subprocess
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
MANIFEST = os.path.join(ROOT, "manifest.json")
CONSTANTS = os.path.join(ROOT, "src", "shared", "constants.js")


def ensure_host_permission(url):
    """把更新源域名写进 manifest 的 host_permissions。
    面板页 fetch 受 CORS 限制（Gitee raw 等不给 CORS 头直接失败）；
    域名进了 host_permissions，Chrome 就为这个扩展放行——托管方零配置。"""
    origin = "{0.scheme}://{0.netloc}/*".format(urlparse(url))
    with open(MANIFEST, encoding="utf-8") as f:
        manifest = json.load(f)
    hosts = manifest.setdefault("host_permissions", [])
    if origin in hosts:
        return origin
    hosts.append(origin)
    with open(MANIFEST, "w", encoding="utf-8") as f:
        json.dump(manifest, f, ensure_ascii=False, indent=2)
        f.write("\n")
    print(f"已把更新源域名加入 host_permissions：{origin}（托管方无需配 CORS）")
    return origin


def read_version():
    with open(MANIFEST, encoding="utf-8") as f:
        return json.load(f)["version"]


def bump_version(version):
    parts = version.split(".")
    parts[-1] = str(int(parts[-1]) + 1)
    return ".".join(parts)


def write_version(version):
    with open(MANIFEST, encoding="utf-8") as f:
        text = f.read()
    text = re.sub(r'("version"\s*:\s*")[^"]+(")', r"\g<1>" + version + r"\g<2>", text, count=1)
    with open(MANIFEST, "w", encoding="utf-8") as f:
        f.write(text)


def ensure_builtin_update_url(update_url):
    """把固定更新源地址写进 constants.js（只写一次；已有值不一致时警告不覆盖）"""
    with open(CONSTANTS, encoding="utf-8") as f:
        text = f.read()
    match = re.search(r'export const BUILT_IN_UPDATE_URL = "([^"]*)"', text)
    if not match:
        print("!! constants.js 里找不到 BUILT_IN_UPDATE_URL，跳过写入（请手动确认）")
        return
    current = match.group(1)
    if not update_url:
        if not current:
            print("!! BUILT_IN_UPDATE_URL 还是空的，客户将无法自动检查更新。")
            print("   下次发布请加 --update-url \"https://固定地址/owa-update.json\"（该地址以后不再变）")
        return
    if current and current != update_url:
        print(f"!! BUILT_IN_UPDATE_URL 已内置为 {current}，与本次 --update-url 不一致，保持原值不改")
        print("   （客户包里的地址必须固定；确要换源请手动评估老客户影响）")
        return
    if current == update_url:
        return
    text = text.replace(match.group(0), f'export const BUILT_IN_UPDATE_URL = "{update_url}"')
    # v1.9.89 双源：主源是 GitHub raw 时，同步把 jsDelivr 镜像备源写进 BUILT_IN_UPDATE_MIRROR
    mirror = to_jsdelivr_mirror(update_url)
    mirror_match = re.search(r'export const BUILT_IN_UPDATE_MIRROR = "([^"]*)"', text)
    if mirror and mirror_match and mirror_match.group(1) != mirror:
        text = text.replace(mirror_match.group(0), f'export const BUILT_IN_UPDATE_MIRROR = "{mirror}"')
        print(f"已把备源镜像写入 constants.js：{mirror}")
    with open(CONSTANTS, "w", encoding="utf-8") as f:
        f.write(text)
    print(f"已把更新源写入 constants.js：{update_url}")


def to_jsdelivr_mirror(url):
    """GitHub raw 链接 → jsDelivr CDN 镜像链接（同一仓库内容的国内可直连备源）。
    https://raw.githubusercontent.com/<user>/<repo>/main/<path>
      → https://cdn.jsdelivr.net/gh/<user>/<repo>@main/<path>
    非 GitHub raw 地址返回空串（不硬造镜像）。"""
    m = re.match(r"https://raw\.githubusercontent\.com/([^/]+)/([^/]+)/([^/]+)/(.+)", url)
    if not m:
        return ""
    user, repo, branch, path = m.groups()
    return f"https://cdn.jsdelivr.net/gh/{user}/{repo}@{branch}/{path}"


def main():
    parser = argparse.ArgumentParser(description="OWA 一键发布")
    parser.add_argument("--zip-url", default="", help="新版本 zip 的完整直链（与 --zip-base 二选一）")
    parser.add_argument("--zip-base", default="", help="zip 所在目录直链（以 / 结尾），自动拼 OWA-V<新版本>.zip——免去手工对齐版本号")
    parser.add_argument("--notes", default="", help="更新说明（客户升级弹窗里显示）")
    parser.add_argument("--version", default="", help="指定版本号；缺省=当前版本末段 +1")
    parser.add_argument("--update-url", default="", help="更新源 JSON 的固定地址（只需首次发布时提供）")
    args = parser.parse_args()
    if not args.zip_url and not args.zip_base:
        parser.error("必须给 --zip-url（完整直链）或 --zip-base（目录直链，自动拼 OWA-V<新版本>.zip）")

    try:
        current = read_version()
    except (OSError, ValueError, json.JSONDecodeError) as error:
        print(f"读取版本失败：{error}")
        return 1
    new_version = args.version or bump_version(current)
    if not re.fullmatch(r"\d+\.\d+\.\d+", new_version):
        print(f"版本号格式不对：{new_version}（应为 x.y.z）")
        return 1
    zip_url = args.zip_url or args.zip_base.rstrip("/") + f"/OWA-V{new_version}.zip"

    ensure_builtin_update_url(args.update_url)
    # 更新源域名进 host_permissions：面板 fetch 不再受 CORS 限制（Gitee raw 没有 CORS 头）
    with open(CONSTANTS, encoding="utf-8") as f:
        ctext = f.read()
    builtin = (re.search(r'export const BUILT_IN_UPDATE_URL = "([^"]*)"', ctext) or [None, ""])[1]
    mirror_src = (re.search(r'export const BUILT_IN_UPDATE_MIRROR = "([^"]*)"', ctext) or [None, ""])[1]
    for src in (builtin, mirror_src):
        if src:
            ensure_host_permission(src)
    write_version(new_version)
    print(f"版本号：{current} → {new_version}")

    # 更新 JSON：放在项目上级目录，和 zip 一起交付给超哥上传
    out_json = os.path.join(os.path.dirname(ROOT), f"owa-update-{new_version}.json")
    payload = {"version": new_version, "url": zip_url, "notes": args.notes}
    # v1.9.89 双源：zip 主链是 GitHub raw 时自动生成 jsDelivr 镜像备链（url2），
    # 无代理客户走备链下载；只维护 GitHub 一个仓库，镜像实时回源、零额外上传。
    mirror = to_jsdelivr_mirror(zip_url)
    if mirror:
        payload["url2"] = mirror
    with open(out_json, "w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False, indent=2)
    print(f"更新 JSON 已生成：{out_json}")

    result = subprocess.run([sys.executable, os.path.join(ROOT, "tools", "package.py")])
    if result.returncode != 0:
        print("打包失败，manifest 版本号已升到", new_version, "（可修复后重跑）")
        return result.returncode

    print("\n==== 发布清单 ====")
    print(f"1. 把上级目录的 OWA-V{new_version}.zip 上传到：{zip_url}")
    print(f"2. 把 {os.path.basename(out_json)} 重命名为 owa-update.json，覆盖上传到固定更新源地址")
    print("3. 完事——所有客户打开面板 6 小时内自动发现新版，点版本号即可升级")
    return 0


if __name__ == "__main__":
    sys.exit(main())
