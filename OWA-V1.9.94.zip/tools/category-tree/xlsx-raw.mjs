// 直接读 xlsx（zip + XML），绕开 SheetJS 的两个坑：
//   ① <dimension> 声明过期（A1:AR5）导致 sheet_to_json 丢掉真实存在的行；
//   ② 单元格文本超过 32767 字符被截断。
import fs from "node:fs";
import zlib from "node:zlib";

export function readZip(file) {
  const buf = fs.readFileSync(file);
  let eocd = -1;
  for (let i = buf.length - 22; i >= 0 && i > buf.length - 70000; i -= 1) {
    if (buf.readUInt32LE(i) === 0x06054b50) { eocd = i; break; }
  }
  if (eocd < 0) throw new Error("不是有效的 zip/xlsx");
  const count = buf.readUInt16LE(eocd + 10);
  let off = buf.readUInt32LE(eocd + 16);
  const map = new Map();
  for (let n = 0; n < count; n += 1) {
    const nameLen = buf.readUInt16LE(off + 28);
    const extraLen = buf.readUInt16LE(off + 30);
    const commentLen = buf.readUInt16LE(off + 32);
    const localOff = buf.readUInt32LE(off + 42);
    const name = buf.slice(off + 46, off + 46 + nameLen).toString("utf8");
    const lNameLen = buf.readUInt16LE(localOff + 26);
    const lExtraLen = buf.readUInt16LE(localOff + 28);
    const method = buf.readUInt16LE(localOff + 8);
    const compSize = buf.readUInt32LE(off + 20);
    const dataStart = localOff + 30 + lNameLen + lExtraLen;
    const raw = buf.slice(dataStart, dataStart + compSize);
    try { map.set(name, method === 0 ? raw : zlib.inflateRawSync(raw)); } catch { /* 跳过坏条目 */ }
    off += 46 + nameLen + extraLen + commentLen;
  }
  return map;
}

const XML_ENT = { "&amp;": "&", "&lt;": "<", "&gt;": ">", "&quot;": '"', "&apos;": "'" };
export function unescapeXml(s) {
  return String(s || "")
    .replace(/&#x([0-9a-fA-F]+);/g, (_, h) => String.fromCodePoint(parseInt(h, 16)))
    .replace(/&#(\d+);/g, (_, d) => String.fromCodePoint(Number(d)))
    .replace(/&(?:amp|lt|gt|quot|apos);/g, (m) => XML_ENT[m]);
}

/** sharedStrings.xml → string[]（含富文本 <r><t> 拼接） */
export function parseSharedStrings(xml) {
  const out = [];
  const re = /<si\b[^>]*>([\s\S]*?)<\/si>/g;
  let m;
  while ((m = re.exec(xml))) {
    const body = m[1];
    let text = "";
    const tr = /<t\b[^>]*>([\s\S]*?)<\/t>/g;
    let t;
    while ((t = tr.exec(body))) text += unescapeXml(t[1]);
    out.push(text);
  }
  return out;
}

/** 只取某一行：返回 { "A": value, "U": value }（列字母 → 值） */
export function parseSheetRow(xml, shared, rowNumber) {
  const re = new RegExp(`<row\\b[^>]*\\br="${rowNumber}"[^>]*>([\\s\\S]*?)</row>`);
  const m = re.exec(xml);
  if (!m) return null;
  const cells = {};
  const cre = /<c\b([^>]*)>([\s\S]*?)<\/c>/g;
  let c;
  while ((c = cre.exec(m[1]))) {
    const attrs = c[1];
    const ref = (/\br="([A-Z]+)\d+"/.exec(attrs) || [])[1];
    if (!ref) continue;
    const type = (/\bt="([^"]+)"/.exec(attrs) || [])[1] || "n";
    const vMatch = /<v>([\s\S]*?)<\/v>/.exec(c[2]);
    const isMatch = /<is>([\s\S]*?)<\/is>/.exec(c[2]);
    let value = "";
    if (type === "s" && vMatch) value = shared[Number(vMatch[1])] ?? "";
    else if (type === "inlineStr" && isMatch) {
      const tr = /<t\b[^>]*>([\s\S]*?)<\/t>/g;
      let t;
      while ((t = tr.exec(isMatch[1]))) value += unescapeXml(t[1]);
    } else if (vMatch) value = unescapeXml(vMatch[1]);
    cells[ref] = String(value);
  }
  return cells;
}

/** 解析整张 sheet：返回 [{ row, cells }] */
export function parseSheet(xml, shared) {
  const rows = [];
  const re = /<row\b[^>]*\br="(\d+)"[^>]*>([\s\S]*?)<\/row>/g;
  let m;
  while ((m = re.exec(xml))) {
    const rowNumber = Number(m[1]);
    const cells = {};
    const cre = /<c\b([^>]*)>([\s\S]*?)<\/c>/g;
    let c;
    while ((c = cre.exec(m[2]))) {
      const attrs = c[1];
      const ref = (/\br="([A-Z]+)\d+"/.exec(attrs) || [])[1];
      if (!ref) continue;
      const type = (/\bt="([^"]+)"/.exec(attrs) || [])[1] || "n";
      const vMatch = /<v>([\s\S]*?)<\/v>/.exec(c[2]);
      const isMatch = /<is>([\s\S]*?)<\/is>/.exec(c[2]);
      let value = "";
      if (type === "s" && vMatch) value = shared[Number(vMatch[1])] ?? "";
      else if (type === "inlineStr" && isMatch) {
        const tr = /<t\b[^>]*>([\s\S]*?)<\/t>/g;
        let t;
        while ((t = tr.exec(isMatch[1]))) value += unescapeXml(t[1]);
      } else if (vMatch) value = unescapeXml(vMatch[1]);
      cells[ref] = String(value);
    }
    rows.push({ row: rowNumber, cells });
  }
  return rows;
}

export function colToIndex(col) {
  let n = 0;
  for (const ch of col) n = n * 26 + (ch.charCodeAt(0) - 64);
  return n - 1;
}
export function indexToCol(index) {
  let n = index + 1;
  let s = "";
  while (n > 0) {
    const r = (n - 1) % 26;
    s = String.fromCharCode(65 + r) + s;
    n = Math.floor((n - 1) / 26);
  }
  return s;
}
