/**
 * 用抽取结果重建 assets/ozon-category-tree.js（内置中文类目树）。
 *
 * 用法：
 *   node tools/category-tree/build-tree.mjs [抽取 JSON] [旧树备份]
 * 默认：
 *   抽取 JSON = 环境变量 OZON_TREE_RAW，或系统临时目录下 ozon-tree/categories-raw.json
 *   旧树备份 = 环境变量 OZON_OLD_TREE，或 assets/ 下第一个 ozon-category-tree.js.bak-*
 *
 * 结构：26 个顶层域 → 类目（description_category_id）→ 类型（type_id），全部来自官方模板。
 * 旧树里模板没有的类型 / 类目以 legacy: true 保留，保证历史草稿的 type_id 依然能对上。
 */
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";

const HERE = path.dirname(fileURLToPath(import.meta.url));
const PROJ = path.resolve(HERE, "..", "..");
const OUT = path.join(PROJ, "assets", "ozon-category-tree.js");

const RAW = process.argv[2] || process.env.OZON_TREE_RAW || path.join(os.tmpdir(), "ozon-tree", "categories-raw.json");

function findOldTree() {
  if (process.env.OZON_OLD_TREE) return process.env.OZON_OLD_TREE;
  const dir = path.join(PROJ, "assets");
  const bak = fs.readdirSync(dir).filter((f) => f.startsWith("ozon-category-tree.js.bak-")).sort();
  if (bak.length) return path.join(dir, bak[bak.length - 1]);
  return OUT; // 没有备份就自比对（仅在首次生成时发生）
}
const OLD = findOldTree();

const records = JSON.parse(fs.readFileSync(RAW, "utf8"));
const bundleSrc = fs.readFileSync(OLD, "utf8");
const bundleJson = JSON.parse(bundleSrc.slice(bundleSrc.indexOf("{"), bundleSrc.lastIndexOf("}") + 1));

const norm = (s) => String(s || "").replace(/[\u0000-\u001f\ufffd]/g, "").replace(/\s+/g, " ").trim();

// ---- 旧树索引（仅用于 legacy 兜底与交叉校验）----
const oldLeaves = [];
(function walk(nodes, trail) {
  for (const n of nodes || []) {
    const t = trail.concat(n.title || n.category_name || "");
    if (Number(n.type_id) > 0 || !(n.children || []).length) {
      oldLeaves.push({
        path: t.filter(Boolean),
        categoryId: Number(n.description_category_id) || 0,
        typeId: Number(n.type_id) || 0,
        typeName: norm(n.title || ""),
      });
    }
    if (n.children?.length) walk(n.children, t);
  }
})(bundleJson.tree, []);

const oldByCat = new Map();
for (const l of oldLeaves) {
  if (!oldByCat.has(l.categoryId)) oldByCat.set(l.categoryId, []);
  const list = oldByCat.get(l.categoryId);
  if (l.typeId && !list.some((x) => x.typeId === l.typeId)) list.push(l);
}

let statOfficial = 0, statNoId = 0, statLegacy = 0, statCrossOk = 0, statCrossDiff = 0;
const crossSamples = [];

const domains = new Map();
const ordered = [...records].sort((a, b) => (a.domain === b.domain ? a.categoryId - b.categoryId : a.domain.localeCompare(b.domain, "zh")));

for (const rec of ordered) {
  const oldList = oldByCat.get(rec.categoryId) || [];
  const oldById = new Map(oldList.map((l) => [l.typeId, l]));

  const seen = new Set();
  const entries = [];
  for (const o of rec.typeOptions || []) {
    const id = Number(o.id) || 0;
    const title = norm(o.name);
    if (!id || !title || seen.has(id)) continue;
    seen.add(id);
    entries.push({ title, typeId: id });
  }
  // 兜底：验证清单里有、类型属性里没有的，按名字补上（正常为 0 条）
  for (const t of rec.types || []) {
    const title = norm(t);
    if (!title || entries.some((e) => e.title === title)) continue;
    entries.push({ title, typeId: 0 });
  }

  for (const e of entries) {
    if (!e.typeId) { statNoId += 1; continue; }
    statOfficial += 1;
    const old = oldById.get(e.typeId);
    if (old) {
      if (old.typeName === e.title) statCrossOk += 1;
      else { statCrossDiff += 1; if (crossSamples.length < 10) crossSamples.push({ id: rec.categoryId, typeId: e.typeId, xlsx: e.title, old: old.typeName }); }
    }
  }

  const usedIds = new Set(entries.map((e) => e.typeId).filter(Boolean));
  const children = entries.map((e) => {
    const leaf = {
      title: e.title,
      type_name: e.title,
      type_id: e.typeId,
      description_category_id: rec.categoryId,
      disabled: false,
      children: [],
    };
    if (!e.typeId) leaf.pending = true;
    return leaf;
  });

  for (const l of oldList) {
    if (usedIds.has(l.typeId)) continue;
    usedIds.add(l.typeId);
    statLegacy += 1;
    children.push({
      title: l.typeName, type_name: l.typeName, type_id: l.typeId,
      description_category_id: rec.categoryId, disabled: false, legacy: true, children: [],
    });
  }

  if (!domains.has(rec.domain)) domains.set(rec.domain, []);
  domains.get(rec.domain).push({
    category_name: rec.domain,
    title: rec.name || String(rec.categoryId),
    description_category_id: rec.categoryId,
    children,
  });
}

// ---- 旧树里模板完全没有的类目：整块保留 ----
const xlsxIds = new Set(records.map((r) => r.categoryId));
const orphanCats = new Map();
for (const l of oldLeaves) {
  if (xlsxIds.has(l.categoryId) || !l.categoryId) continue;
  if (!orphanCats.has(l.categoryId)) orphanCats.set(l.categoryId, { domain: l.path[0] || "其他", title: l.path[1] || String(l.categoryId), leaves: [] });
  const bucket = orphanCats.get(l.categoryId);
  if (l.typeId && !bucket.leaves.some((x) => x.typeId === l.typeId)) bucket.leaves.push(l);
}
for (const [id, bucket] of orphanCats) {
  if (!domains.has(bucket.domain)) domains.set(bucket.domain, []);
  domains.get(bucket.domain).push({
    category_name: bucket.domain, title: bucket.title, description_category_id: id, legacy: true,
    children: bucket.leaves.map((l) => ({
      title: l.typeName, type_name: l.typeName, type_id: l.typeId,
      description_category_id: id, disabled: false, legacy: true, children: [],
    })),
  });
}

const domainOrder = [];
for (const r of records) if (!domainOrder.includes(r.domain)) domainOrder.push(r.domain);
for (const d of domains.keys()) if (!domainOrder.includes(d)) domainOrder.push(d);
const tree = domainOrder.map((d) => ({ category_name: d, children: domains.get(d) }));

let totalCats = 0, totalLeaves = 0, withId = 0;
for (const d of tree) {
  totalCats += d.children.length;
  for (const c of d.children) {
    totalLeaves += c.children.length;
    withId += c.children.filter((x) => Number(x.type_id) > 0).length;
  }
}

const bundle = {
  schemaVersion: 2,
  generatedAt: new Date().toISOString().slice(0, 10),
  source: "Ozon 官方 XLS 模板（tools/category-tree 生成）；type_id 取自模板 info 中「类型」属性（ID 8229）的候选值 ID",
  stats: {
    domains: tree.length,
    categories: totalCats,
    leaves: totalLeaves,
    typesWithId: withId,
    typesPending: totalLeaves - withId,
    maxDepth: 3,
  },
  tree,
};

const header = [
  "// Ozon 官方中文类目树（本地内置，离线可用，全中文，含 Ozon 数字 ID）。",
  "// 本文件由 tools/category-tree/extract-categories-raw.mjs + build-tree.mjs 从官方 XLS 模板生成，请勿手改。",
  "//   结构 = 顶层域（26）→ 类目（description_category_id）→ 类型（type_id），共 " + totalLeaves + " 个末级类型。",
  "//   type_id 直接取自模板 info 里「类型」属性（ID 8229）候选值的 ID —— 与 Ozon 类目树的 type_id 一致（已交叉校验）。",
  "//   模板里没有、旧缓存里有的类型标 legacy: true 保留，避免历史草稿失效。",
  "// 字段：tree[].category_name=顶层域；.title=类名；.description_category_id / .type_id / .type_name=上传所需数字 ID。",
  "",
].join("\n");

fs.writeFileSync(OUT, `${header}export const OZON_CATEGORY_TREE_BUNDLE = ${JSON.stringify(bundle)};\n`, "utf8");

console.log("抽取源:", RAW);
console.log("旧树（type_id 交叉校验 / legacy 来源）:", OLD);
console.log("== 生成结果 ==");
console.log("  顶层域:", bundle.stats.domains, "| 类目:", bundle.stats.categories, "| 叶子:", bundle.stats.leaves);
console.log("  有 type_id:", withId, "| 无 type_id:", totalLeaves - withId);
console.log("  来源：官方类型属性", statOfficial, "| 旧树保留(legacy)", statLegacy, "| 无名无 ID", statNoId);
console.log("  交叉校验：与旧树 type_id 同名", statCrossOk, "| 同 ID 不同名", statCrossDiff);
for (const s of crossSamples) console.log(`     ${s.id} type_id ${s.typeId}: 官方「${s.xlsx}」 vs 旧树「${s.old}」`);
console.log("  旧树独有类目（整块保留）:", orphanCats.size, JSON.stringify([...orphanCats.keys()]));
console.log("  输出:", OUT, (fs.statSync(OUT).size / 1024 / 1024).toFixed(2), "MB");
