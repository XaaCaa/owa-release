/**
 * 从 Ozon 官方 XLS 类目模板里抽取权威类目数据。
 *
 * 用法：
 *   node tools/category-tree/extract-categories-raw.mjs [模板目录] [输出 JSON]
 * 默认：
 *   模板目录 = 环境变量 OZON_TEMPLATE_DIR，或 "E:/工作/AI/OZON类目树"
 *   输出 JSON = 环境变量 OZON_TREE_OUT，或系统临时目录下 ozon-tree/categories-raw.json
 *
 * 每个模板抽出：顶层域（目录名）/ 类目 ID（configs 的 DESCRIPTION_CATEGORY_ID）/
 * 类目名（info 的 base64 解出 name）/ 类型清单（validation 的「类型*」列）/
 * 类型清单带 type_id（info 里名为「类型」的属性，ID 8229，其候选值 ID 就是 type_id）。
 *
 * 为什么不用 SheetJS：① `configs` 的 <dimension> 声明过期（写 A1:AR5、实际有 10 行），
 * SheetJS 信它就会丢掉 DESCRIPTION_CATEGORY_ID；② 单元格文本超过 32767 字符被截断，
 * 而 info 的 base64 有几十万字符、被切成上百个 32767 的格子。所以这里直接读 zip + XML。
 */
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { readZip, parseSharedStrings, parseSheet, colToIndex } from "./xlsx-raw.mjs";

const HERE = path.dirname(fileURLToPath(import.meta.url));
const PROJ = path.resolve(HERE, "..", "..");
const ROOT = process.argv[2] || process.env.OZON_TEMPLATE_DIR || "E:/工作/AI/OZON类目树";
const OUT = process.argv[3] || process.env.OZON_TREE_OUT || path.join(os.tmpdir(), "ozon-tree", "categories-raw.json");

function listXlsx(dir) {
  const out = [];
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const p = path.join(dir, entry.name);
    if (entry.isDirectory()) out.push(...listXlsx(p));
    else if (/\.xlsx$/i.test(entry.name) && !entry.name.startsWith("~$")) out.push(p);
  }
  return out;
}

function sheetMap(map) {
  const wbXml = map.get("xl/workbook.xml")?.toString("utf8") || "";
  const relsXml = map.get("xl/_rels/workbook.xml.rels")?.toString("utf8") || "";
  const relMap = new Map([...relsXml.matchAll(/<Relationship Id="([^"]+)" Target="([^"]+)"/g)].map((m) => [m[1], m[2]]));
  const out = new Map();
  for (const m of wbXml.matchAll(/<sheet name="([^"]+)"[^>]*r:id="([^"]+)"/g)) {
    const target = relMap.get(m[2]) || "";
    out.set(m[1], "xl/" + target.replace(/^\//, "").replace(/^xl\//, ""));
  }
  return out;
}

function parseOne(file) {
  const domain = path.relative(ROOT, file).split(path.sep)[0];
  const map = readZip(file);
  const shared = parseSharedStrings(map.get("xl/sharedStrings.xml")?.toString("utf8") || "");
  const sheets = sheetMap(map);
  const readSheet = (name) => {
    const target = sheets.get(name);
    if (!target || !map.has(target)) return [];
    return parseSheet(map.get(target).toString("utf8"), shared);
  };

  // configs → DESCRIPTION_CATEGORY_ID / XLS_TEMPLATE_INFO_BASE64
  let categoryId = 0;
  let cfgB64 = "";
  for (const r of readSheet("configs")) {
    const key = String(r.cells.A || "").trim();
    if (key === "DESCRIPTION_CATEGORY_ID") categoryId = Number(String(r.cells.B || "").trim()) || 0;
    if (key === "XLS_TEMPLATE_INFO_BASE64") {
      cfgB64 = Object.keys(r.cells)
        .filter((c) => c !== "A")
        .sort((a, b) => colToIndex(a) - colToIndex(b))
        .map((c) => String(r.cells[c] || ""))
        .join("");
    }
  }

  // info → base64（首行按列号顺序拼接）→ name / 类型清单（带 type_id）
  let name = "";
  let attrCount = 0;
  let typeOptions = [];
  let typeAttrName = "";
  const infoRows = readSheet("info");
  const row1 = infoRows.find((r) => r.row === 1) || { cells: {} };
  const infoB64 = Object.keys(row1.cells)
    .sort((a, b) => colToIndex(a) - colToIndex(b))
    .map((c) => String(row1.cells[c] || ""))
    .join("");
  const b64 = (infoB64.length >= cfgB64.length ? infoB64 : cfgB64) || infoB64 || cfgB64;
  if (b64) {
    try {
      const json = JSON.parse(Buffer.from(b64, "base64").toString("utf8"));
      name = String(json.name || "").trim();
      attrCount = Object.keys(json.attributes || {}).length;
      // Ozon 官方模板把「类目类型」也做成一个属性（Name="类型"、ID=8229），
      // 它的 LookupData.Values 的 key 就是上传要用的 type_id —— 这是 xlsx 里唯一的 type_id 来源。
      const descTypeName = String(json.additional_column_by_name?.desc_type || "类型").trim();
      const attr = Object.values(json.attributes || {}).find((a) => Number(a.ID) === 8229)
        || Object.values(json.attributes || {}).find((a) => String(a.Name || "").trim() === descTypeName);
      if (attr) {
        typeAttrName = String(attr.Name || "").trim();
        const values = attr.LookupData?.Values || {};
        const order = Array.isArray(attr.LookupData?.OrderedValueIDs) && attr.LookupData.OrderedValueIDs.length
          ? attr.LookupData.OrderedValueIDs
          : Object.keys(values);
        const seen = new Set();
        for (const id of order) {
          const v = values[id] ?? values[String(id)];
          if (!v) continue;
          if (seen.has(String(v.ID))) continue;
          seen.add(String(v.ID));
          typeOptions.push({ name: String(v.Value || "").trim(), id: Number(v.ID) || 0 });
        }
      }
    } catch { /* base64 解不开就跳过，靠 validation 清单兜底 */ }
  }

  // 模板 第 2 行 → 定位「类型*」列（不同类目列号不同：管乐器是 U、慢炖锅是 T）
  const header = (readSheet("模板").find((r) => r.row === 2) || {}).cells || {};
  let typeCol = null;
  for (const [col, value] of Object.entries(header)) {
    const h = String(value || "").trim();
    if (h === "类型*" || h === "类型") { typeCol = col; break; }
  }

  // validation → 该列全部值（作为类型清单的交叉校验）
  const types = [];
  if (typeCol) {
    for (const r of readSheet("validation")) {
      const v = String(r.cells[typeCol] || "").trim();
      if (v && !types.includes(v)) types.push(v);
    }
  }

  return { domain, file: path.basename(file), categoryId, name, attrCount, typeAttrName, typeCol, types, typeOptions };
}

if (!fs.existsSync(ROOT)) {
  console.error(`找不到模板目录：${ROOT}\n可用「node ${path.relative(process.cwd(), fileURLToPath(import.meta.url))} <模板目录> <输出 JSON>」指定`);
  process.exit(1);
}

const files = listXlsx(ROOT);
console.log("模板目录:", ROOT);
console.log("xlsx 总数:", files.length);
const records = [];
let failed = 0;
for (const f of files) {
  try { records.push(parseOne(f)); }
  catch (e) { failed += 1; console.error("  ✗", path.basename(f), e.message); }
}
console.log("解析成功:", records.length, "失败:", failed);

const noId = records.filter((r) => !r.categoryId);
const noName = records.filter((r) => !r.name);
const noType = records.filter((r) => !r.types.length);
console.log("categoryId 为空:", noId.length, "| name 为空:", noName.length, "| types 为空:", noType.length);
if (noId.length) console.log("  无 ID 样本:", JSON.stringify(noId.slice(0, 5), null, 1));
if (noName.length) for (const r of noName) console.log(`  无名: ${r.categoryId} ${r.domain}/${r.file} 类型数=${r.types.length}`);

// 同 ID 多模板 → 合并
const byId = new Map();
for (const r of records) {
  if (!r.categoryId) continue;
  const prev = byId.get(r.categoryId);
  if (!prev) { byId.set(r.categoryId, r); continue; }
  for (const t of r.types) if (!prev.types.includes(t)) prev.types.push(t);
  const seen = new Set(prev.typeOptions.map((o) => o.id));
  for (const o of r.typeOptions) if (o.id && !seen.has(o.id)) { prev.typeOptions.push(o); seen.add(o.id); }
  if (!prev.name && r.name) prev.name = r.name;
}
console.log("\n去重后类目数:", byId.size, "| 验证清单类型总数:", [...byId.values()].reduce((s, r) => s + r.types.length, 0));

const noTypeAttr = [...byId.values()].filter((r) => !r.typeOptions.length);
console.log("拿不到「类型」属性（无 type_id 来源）的类目:", noTypeAttr.length);
for (const r of noTypeAttr.slice(0, 10)) console.log(`   ${r.categoryId} ${r.domain}/${r.name} 验证清单类型数=${r.types.length}`);
console.log("typeOptions 总数（带 type_id）:", [...byId.values()].reduce((s, r) => s + r.typeOptions.length, 0));

const mism = [];
for (const r of byId.values()) {
  if (!r.typeOptions.length) continue;
  const a = new Set(r.types.map((t) => t.replace(/\s+/g, "")));
  const b = new Set(r.typeOptions.map((o) => String(o.name).replace(/\s+/g, "")));
  const onlyA = [...a].filter((x) => !b.has(x));
  const onlyB = [...b].filter((x) => !a.has(x));
  if (onlyA.length || onlyB.length) mism.push({ id: r.categoryId, name: r.name, onlyA: onlyA.slice(0, 5), onlyB: onlyB.slice(0, 5) });
}
console.log("验证清单 vs 类型属性 不一致的类目:", mism.length);
for (const m of mism.slice(0, 10)) console.log(`   ${m.id} ${m.name} 仅在验证清单=${JSON.stringify(m.onlyA)} 仅在类型属性=${JSON.stringify(m.onlyB)}`);

const domainCount = {};
for (const r of byId.values()) domainCount[r.domain] = (domainCount[r.domain] || 0) + 1;
console.log("\n顶层域 → 类目数:", JSON.stringify(domainCount, null, 1));

fs.mkdirSync(path.dirname(OUT), { recursive: true });
fs.writeFileSync(OUT, JSON.stringify([...byId.values()], null, 1), "utf8");
console.log("\n已写出:", OUT);
void PROJ;
