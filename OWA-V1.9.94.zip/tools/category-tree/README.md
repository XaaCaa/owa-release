# 类目树生成工具

从 **Ozon 卖家后台导出的官方 XLS 类目模板**重建 `assets/ozon-category-tree.js`（插件内置的中文类目树）。

## 怎么用

```bash
# 1) 从模板目录抽数据（默认 E:/工作/AI/OZON类目树，可用参数或 OZON_TEMPLATE_DIR 覆盖）
node tools/category-tree/extract-categories-raw.mjs [模板目录] [输出 JSON]

# 2) 用抽取结果重建内置树（会覆盖 assets/ozon-category-tree.js）
node tools/category-tree/build-tree.mjs [抽取 JSON] [旧树备份]
```

第 2 步的「旧树备份」用来做两件事：`type_id` 交叉校验、以及把模板里没有的旧类型标 `legacy: true` 保留
（保证历史草稿的 `type_id` 依然能对上）。默认取 `assets/` 下最新的 `ozon-category-tree.js.bak-*`，
所以**重新生成前先备份当前树**：

```bash
cp assets/ozon-category-tree.js assets/ozon-category-tree.js.bak-$(date +%Y%m%d)
```

## 数据从哪来

Ozon 模板是 xlsx，共 10 张 sheet（`configs` / `info` / `validation` 在 `workbook.xml` 里是 `state="hidden"`）：

| 要的东西 | 位置 |
| --- | --- |
| 类目 `description_category_id` | `configs` sheet 中 `A="DESCRIPTION_CATEGORY_ID"` 那行的 `B` 列 |
| 类目中文名 | `info` sheet 首行按列号顺序拼接 → base64 解码 → JSON 的 `name` |
| **类型清单 + `type_id`** | `info` 解码后的 `attributes` 里 **ID=8229、名「类型」** 的属性，其 `LookupData.Values` 的 **key 就是 `type_id`** |
| 类型清单（交叉校验） | `模板` sheet 第 2 行的「类型\*」列（**列号因类目而异**：管乐器是 U、慢炖锅是 T）在 `validation` sheet 里对应的整列 |
| 顶层域 | 模板文件所在的一级目录名 |

### 两个坑（所以不用 SheetJS）

1. **`<dimension>` 声明过期**：`configs` 声明 `A1:AR5`，实际有 10 行，`DESCRIPTION_CATEGORY_ID` 在第 10 行。
   SheetJS 信 dimension → `sheet_to_json` 只返回 5 行，328 个模板抽不到类目 ID。所以这里按
   `<row r="N">` 直接解析 `xl/worksheets/sheetN.xml`。
2. **单元格 32767 字符截断**：`info` 的 base64 有几十万字符，被 Excel 切成上百个 32767 的格子
   （`轮胎` 模板有 100+ 格）。必须把整行按列号顺序拼起来再解码，且 `sharedStrings.xml` 里
   `<si>` 内的多个 `<t>` 也要拼（富文本）。

另外 `模板` sheet 里**没有**预填的类型值（第 5 行数据行是空的），所以 `type_id` 只有上面那一个来源。

## 产物

`assets/ozon-category-tree.js`：`schemaVersion: 2`，`stats` 里带 `domains / categories / leaves / typesWithId / typesPending`。
结构为 3 级：顶层域（`category_name`）→ 类目（`title` + `description_category_id`）→ 类型（`title` / `type_name` / `type_id`）。

生成后请跑一遍回归：

```bash
node tools/self-test.mjs     # 「本地内置中文类目树」那一段会校验 26 / 542 / 8600
node tools/smoke-check.mjs
```

## 自检脚本

```bash
# 用真实树跑一遍「行号索引 → 清单渲染 → 解析回查」，确认 AI 只能在树内选（28 项）
node tools/category-tree/verify-tree-match.mjs
```

它校验的是 v1.9.66 的匹配链路：`buildCategoryTreeIndex` 建 D/C/T 行号索引 → 阶段 1 只渲染
「域 + 类目」（568 行）、阶段 2 只渲染命中类目的「类型」→ AI 返回的行号必须能回查到真实节点，
越界 / 非 JSON / 返回 -1 一律判失败 → `composeCategoryTreeMatch` 从真实节点取 `categoryId` / `typeId`。
`tools/self-test.mjs` 的 `v1.9.66` 段覆盖了同样的行为，这个脚本胜在能单独跑、并打印清单规模。
