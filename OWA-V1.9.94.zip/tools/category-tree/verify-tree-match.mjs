/**
 * v1.9.66 本地自检（开发期用，可反复跑）：
 * 用真实类目树跑一遍「行号索引 → 清单渲染 → 解析回查」，确认 AI 只能在树内选。
 */
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";

const HERE = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(HERE, "..", "..");

const { OZON_CATEGORY_TREE_BUNDLE } = await import(pathToFileURL(path.join(ROOT, "assets/ozon-category-tree.js")).href);
const tree = OZON_CATEGORY_TREE_BUNDLE.tree;

const {
  buildCategoryTreeIndex,
  renderCategoryTreeDomainList,
  renderCategoryTypeList,
  buildCategoryTreeDomainMessages,
  buildCategoryTreeTypeMessages,
  parseCategoryTreeDomainResult,
  parseCategoryTreeTypeResult,
  composeCategoryTreeMatch,
  categoryImageParts,
} = await import(pathToFileURL(path.join(ROOT, "src/shared/prompts.js")).href);

let ok = 0;
let fail = 0;
const brief = (value) => {
  try { return JSON.stringify(value); } catch { return String(value); }
};
const check = (name, cond, extra = "") => {
  if (cond) { ok += 1; console.log(`  OK   ${name}`); }
  else { fail += 1; console.log(`  FAIL ${name} ${extra}`); }
};

const index = buildCategoryTreeIndex(tree);
check("索引：域数 26", index.domains.length === 26, String(index.domains.length));
const categoryCount = index.domains.reduce((sum, d) => sum + d.categories.length, 0);
const typeCount = index.domains.reduce((sum, d) => sum + d.categories.reduce((s, c) => s + c.types.length, 0), 0);
check("索引：类目数 542", categoryCount === 542, String(categoryCount));
check("索引：类型数 8600", typeCount === 8600, String(typeCount));

const domainList = renderCategoryTreeDomainList(index);
const lineCount = domainList.split("\n").length;
console.log(`  域+类目清单行数：${lineCount}，字符数：${domainList.length}`);
check("清单行数 = 26 域 + 542 类目", lineCount === 568, String(lineCount));
check("清单里没有类型行（阶段 1 不给类型）", !/^\s*T\d/m.test(domainList));

// 找一个多类型类目做阶段 2 验证
let sample = null;
for (const d of index.domains) {
  for (const c of d.categories) {
    if (c.types.length >= 6 && /家用电器/.test(d.name)) { sample = { d, c }; break; }
  }
  if (sample) break;
}
if (!sample) {
  for (const d of index.domains) {
    for (const c of d.categories) if (c.types.length >= 6) { sample = { d, c }; break; }
    if (sample) break;
  }
}
console.log(`  样例类目：${sample.d.name} / ${sample.c.name}（${sample.c.types.length} 个类型，category_id=${sample.c.categoryId}）`);
const typeList = renderCategoryTypeList(sample.c);
console.log(`  类型清单行数：${typeList.split("\n").length}`);
check("类型清单行数 = 该类别类型数", typeList.split("\n").length === sample.c.types.length);

/* ---- 提示词组装 ---- */
const product = { platform: "1688", title: "不锈钢多功能空气炸锅 5.5L", description: "家用厨房电器，可炸可烤", images: ["https://img.example/a.jpg"] };
const msgs1 = buildCategoryTreeDomainMessages(product, tree, { imageDataUrls: ["data:image/jpeg;base64,AAAA"] });
check("阶段 1：system 是类目树匹配提示词", /只能在给出的清单范围内选择/.test(msgs1[0].content));
check("阶段 1：user content 是多模态数组（带图）", Array.isArray(msgs1[1].content) && msgs1[1].content[0].type === "text" && msgs1[1].content[1].type === "image_url");
check("阶段 1：提示词里带完整域+类目清单", msgs1[1].content[0].text.includes("D1. ") && msgs1[1].content[0].text.includes(`C${sample.c.key}. `));
check("阶段 1：提示词里带商品标题", msgs1[1].content[0].text.includes("不锈钢多功能空气炸锅"));
const msgs1NoImg = buildCategoryTreeDomainMessages(product, tree, {});
check("阶段 1：无图时退化为纯文本 content", typeof msgs1NoImg[1].content === "string" && /无图/.test(msgs1NoImg[1].content));

const domainPick = { domain: sample.d, category: sample.c };
const msgs2 = buildCategoryTreeTypeMessages(product, domainPick, { imageDataUrls: ["data:image/jpeg;base64,AAAA"] });
check("阶段 2：只给该类目的类型清单", msgs2[1].content[0].text.includes(`T${sample.c.key}.1.`) && !msgs2[1].content[0].text.includes("D1. "));

/* ---- 解析与回查 ---- */
check("解析阶段 1：正常", parseCategoryTreeDomainResult(`{"domain":${sample.d.lineNo},"category":${sample.c.lineNo},"confidence":0.8,"reason":"厨房电器"}`, tree)?.category?.categoryId === sample.c.categoryId);
check("解析阶段 1：域越界 → null", parseCategoryTreeDomainResult('{"domain":999,"category":1}', tree) === null);
check("解析阶段 1：类目越界 → null", parseCategoryTreeDomainResult(`{"domain":${sample.d.lineNo},"category":999}`, tree) === null);
check("解析阶段 1：AI 返回 -1（没有合适类目）→ null", parseCategoryTreeDomainResult('{"domain":-1,"category":-1,"confidence":0}', tree) === null);
check("解析阶段 1：非 JSON → null", parseCategoryTreeDomainResult("没有 JSON", tree) === null);
check("解析阶段 1：```json 围栏可解析", !!parseCategoryTreeDomainResult(`\`\`\`json\n{"domain":${sample.d.lineNo},"category":${sample.c.lineNo}}\n\`\`\``, tree));

const t3 = sample.c.types[2];
const typePick = parseCategoryTreeTypeResult(`{"type":3,"confidence":0.9,"reason":"外观是带盖的圆桶"}`, sample.c);
check("解析阶段 2：第 3 项 → types[2]", typePick?.type?.typeId === t3.typeId, brief(typePick?.type));
check("解析阶段 2：越界 → null", parseCategoryTreeTypeResult('{"type":999}', sample.c) === null);
check("解析阶段 2：-1 → null", parseCategoryTreeTypeResult('{"type":-1}', sample.c) === null);

const composed = composeCategoryTreeMatch(
  { domain: sample.d, category: sample.c, confidence: 0.8, reason: "域理由" },
  { type: t3, confidence: 0.5, reason: "类型理由" },
  { imageCount: 2 },
);
check("合成结果：categoryId / typeId 取自真实节点", composed.categoryId === sample.c.categoryId && composed.typeId === t3.typeId);
check("合成结果：path 是三级真实路径", composed.path.join(" / ") === `${sample.d.name} / ${sample.c.name} / ${t3.name}`, composed.path.join(" / "));
check("合成结果：置信度是两阶段相乘", composed.confidence === 0.4, String(composed.confidence));
check("合成结果：node 同时带 description_category_id / category_id / type_id",
  composed.node.description_category_id === sample.c.categoryId && composed.node.category_id === sample.c.categoryId && composed.node.type_id === t3.typeId);
check("合成结果：非法 ID → null", composeCategoryTreeMatch({ category: { categoryId: 0 } }, { type: { typeId: 0 } }) === null);

check("图片片段：data URL 与 http 都收，非法丢弃",
  categoryImageParts(["data:image/png;base64,AA", "https://a/b.jpg", "not-a-url"]).length === 2);
check("图片片段：最多 4 张", categoryImageParts(Array.from({ length: 9 }, () => "data:image/jpeg;base64,AA")).length === 4);

console.log(`\n结果：${ok} OK / ${fail} FAIL`);
process.exit(fail ? 1 : 0);
