"""生成扩展图标（纯标准库 PNG 写入，无第三方依赖）。"""
import struct
import zlib
import os

OUT_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "assets")

BG = (24, 95, 165)      # 深蓝
FG = (255, 255, 255)    # 白
ACCENT = (239, 159, 39)  # 橙


def make_canvas(size):
    return [[(0, 0, 0, 0) for _ in range(size)] for _ in range(size)]


def rounded_rect(px, size, x0, y0, x1, y1, r, color):
    for y in range(max(0, y0), min(size, y1)):
        for x in range(max(0, x0), min(size, x1)):
            cx = min(max(x, x0 + r), x1 - 1 - r)
            cy = min(max(y, y0 + r), y1 - 1 - r)
            dx, dy = x - cx, y - cy
            if dx * dx + dy * dy <= r * r:
                px[y][x] = color
            elif x0 + r <= x < x1 - r or y0 + r <= y < y1 - r:
                px[y][x] = color


def rect(px, size, x0, y0, x1, y1, color):
    for y in range(max(0, y0), min(size, y1)):
        for x in range(max(0, x0), min(size, x1)):
            px[y][x] = color


def disc(px, size, cx, cy, r, color):
    for y in range(max(0, cy - r), min(size, cy + r + 1)):
        for x in range(max(0, cx - r), min(size, cx + r + 1)):
            if (x - cx) ** 2 + (y - cy) ** 2 <= r * r:
                px[y][x] = color


def build(size):
    px = make_canvas(size)
    m = max(1, round(size * 0.06))
    rounded_rect(px, size, m, m, size - m, size - m, round(size * 0.22), BG + (255,))

    # 三条列表项，最后一条用橙色点缀，呼应"上架清单"语义
    unit = size / 16.0
    row_h = max(2, round(unit * 1.6))
    for i, (top, right, color) in enumerate(
        ((3.2, 12.0, FG), (6.1, 12.0, FG), (9.0, 9.6, ACCENT))
    ):
        y0 = round(top * unit)
        x1 = round(right * unit)
        rect(px, size, round(3.0 * unit), y0, x1, y0 + row_h, color + (255,))

    # 左侧圆点标记
    dot_r = max(1, round(unit * 0.9))
    for cy in (3.2, 6.1, 9.0):
        disc(px, size, round(1.9 * unit), round(cy * unit + row_h / 2), dot_r, FG + (255,))
    return px


def write_png(path, px):
    size = len(px)
    raw = bytearray()
    for row in px:
        raw.append(0)
        for r, g, b, a in row:
            raw += bytes((r, g, b, a))

    def chunk(tag, data):
        return (
            struct.pack(">I", len(data))
            + tag
            + data
            + struct.pack(">I", zlib.crc32(tag + data) & 0xFFFFFFFF)
        )

    png = b"\x89PNG\r\n\x1a\n"
    png += chunk(b"IHDR", struct.pack(">IIBBBBB", size, size, 8, 6, 0, 0, 0))
    png += chunk(b"IDAT", zlib.compress(bytes(raw), 9))
    png += chunk(b"IEND", b"")
    with open(path, "wb") as fh:
        fh.write(png)


for s in (16, 48, 128):
    write_png(os.path.join(OUT_DIR, f"icon{s}.png"), build(s))
    print("wrote", s)
