"""把扩展目录打包成发布 zip，便于安装、备份或分享。

用法：python tools/package.py [输出路径]
未指定输出路径时生成 ``OWA-V<manifest.version>.zip``。
"""
import json
import os
import re
import sys
import zipfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
EXCLUDE_DIRS = {
    ".git", ".github", ".idea", ".smoke-tmp", ".workbuddy", "__pycache__",
    "node_modules", "vendor",
}
EXCLUDE_FILES = {".DS_Store", "Thumbs.db", ".selftest-out.txt", ".smoke-out.txt"}
EXCLUDE_FILE_PATTERNS = (
    # 开发期临时产物：自测输出、同步/打包日志等 dot 文件。
    # 加通配是因为它们随时会新建，漏一个就会被塞进发布包（曾把 .selftest-summary.txt
    # 和 .tmp-pack.txt 打进 zip）。.selftest-out.txt 另有显式条目，这里再兜一层。
    re.compile(r"^\.(tmp|selftest|smoke)[-.]", re.IGNORECASE),
    # 手动/工具留下的 .bak 备份（如 ozon-category-tree.js.bak-20260930），不是运行文件。
    re.compile(r"\.bak([-.]|$)", re.IGNORECASE),
    re.compile(r"(^|\.)(env|secret|secrets)(\.|$)", re.IGNORECASE),
    re.compile(r"(credentials?|private[-_.]?key|api[-_.]?key)", re.IGNORECASE),
)

# 必须存在的文件，打包前先校验
REQUIRED = [
    "manifest.json",
    "src/background/service-worker.js",
    "src/ui/panel.html",
    "src/ui/panel.js",
    "src/ui/panel.css",
    "assets/icon16.png",
    "assets/icon48.png",
    "assets/icon128.png",
]


def read_version():
    """从 manifest 读取唯一发布版本来源，避免脚本内重复维护版本号。"""
    with open(os.path.join(ROOT, "manifest.json"), encoding="utf-8") as stream:
        manifest = json.load(stream)
    version = str(manifest.get("version", "")).strip()
    if not re.fullmatch(r"\d+\.\d+\.\d+(?:[-+][0-9A-Za-z.-]+)?", version):
        raise ValueError(f"manifest.json 的 version 不是有效 semver：{version!r}")
    return version


def default_output():
    return os.path.join(os.path.dirname(ROOT), f"OWA-V{read_version()}.zip")


def should_exclude(filename, output_path, relpath=""):
    basename = os.path.basename(filename)
    if basename in EXCLUDE_FILES or basename.lower().endswith(".zip"):
        return True
    if os.path.abspath(filename) == os.path.abspath(output_path):
        return True
    if any(pattern.search(basename) for pattern in EXCLUDE_FILE_PATTERNS):
        return True
    # 根目录散落的 md（方案、术语对照表、备忘等）是开发期文档，不是扩展运行文件。
    # 只有 README.md 该跟着发布包走（装扩展的人要看说明）。v1.9.55 因此把根目录的
    # 「v1.9.55-类目属性准确性改造方案.md」排除掉——它会被复制两份进 zip。
    if relpath and os.sep not in relpath and basename.lower().endswith(".md") and basename.lower() != "readme.md":
        return True
    return False


def main():
    try:
        version = read_version()
    except (OSError, ValueError, json.JSONDecodeError) as error:
        print(f"读取版本失败：{error}")
        return 1
    out = sys.argv[1] if len(sys.argv) > 1 else default_output()
    out = os.path.abspath(out)

    missing = [name for name in REQUIRED if not os.path.isfile(os.path.join(ROOT, name))]
    if missing:
        print("缺少必要文件：")
        for name in missing:
            print("  -", name)
        return 1

    count = 0
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as zf:
        for dirpath, dirnames, filenames in os.walk(ROOT):
            dirnames[:] = [d for d in dirnames if d not in EXCLUDE_DIRS]
            for filename in filenames:
                full = os.path.join(dirpath, filename)
                arcname = os.path.relpath(full, ROOT)
                if should_exclude(full, out, arcname):
                    continue
                zf.write(full, arcname)
                count += 1

    size = os.path.getsize(out)
    print(f"打包完成：{out}")
    print(f"版本 {version}，文件数 {count}，大小 {size / 1024:.1f} KB")
    return 0


if __name__ == "__main__":
    sys.exit(main())
