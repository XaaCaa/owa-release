// 冒烟检查：JS 语法 + manifest 引用 + 面板 HTML 引用 + 模块导入图
import fs from "fs";
import path from "path";
import { fileURLToPath } from "node:url";
import { execFileSync } from "node:child_process";
import os from "node:os";

const HERE = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(HERE, "..");
process.chdir(ROOT);

const NODE = process.execPath;
let problems = 0;

function walk(dir, out = []) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    if (["node_modules", ".git", "vendor", ".smoke-tmp"].includes(entry.name)) continue;
    const p = path.join(dir, entry.name);
    if (entry.isDirectory()) walk(p, out);
    else if (/\.(js|mjs)$/.test(entry.name)) out.push(p);
  }
  return out;
}

console.log("=== 1. JS 语法检查 ===");
const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), "ozon-smoke-"));
for (const file of walk(".")) {
  const target = path.join(tmpDir, path.basename(file).replace(/\.(js|mjs)$/, "") + "-" + Math.random().toString(36).slice(2) + ".mjs");
  fs.copyFileSync(file, target);
  try {
    execFileSync(NODE, ["--check", target], { stdio: "pipe" });
  } catch (error) {
    problems++;
    console.log(`  [FAIL] ${path.relative(ROOT, file)}`);
    console.log(`         ${String(error.stderr || error.message).split("\n").slice(0, 4).join("\n         ")}`);
  }
}
console.log(`  检查了 ${walk(".").length} 个文件`);

console.log("=== 2. manifest 引用完整性 ===");
const manifest = JSON.parse(fs.readFileSync("manifest.json", "utf8"));
const refs = [
  ...Object.values(manifest.icons || {}),
  manifest.background?.service_worker,
  manifest.options_ui?.page,
  ...(manifest.content_scripts || []).flatMap((cs) => cs.js || []),
].filter(Boolean);

for (const ref of refs) {
  if (fs.existsSync(path.join(ROOT, ref))) console.log(`  [OK]   ${ref}`);
  else { problems++; console.log(`  [MISS] ${ref}`); }
}

console.log("=== 3. 面板 HTML 引用 ===");
const html = fs.readFileSync("src/ui/panel.html", "utf8");
for (const match of html.matchAll(/(?:src|href)="([^"]+)"/g)) {
  const rel = match[1];
  if (/^https?:/i.test(rel)) continue;
  const p = path.join(ROOT, "src/ui", rel);
  if (fs.existsSync(p)) console.log(`  [OK]   ${rel}`);
  else { problems++; console.log(`  [MISS] ${rel}`); }
}

console.log("=== 4. 模块导入图（相对路径） ===");
const exts = [".js", ".mjs", ".json"];
function resolve(spec, from) {
  const base = path.resolve(path.dirname(from), spec.split("?")[0]);
  if (fs.existsSync(base) && fs.statSync(base).isFile()) return base;
  for (const e of exts) if (fs.existsSync(base + e)) return base + e;
  return null;
}
for (const file of walk(".")) {
  const src = fs.readFileSync(file, "utf8");
  const specs = new Set();
  for (const m of src.matchAll(/(?:^|[\s;{}()])(?:import|export)[^;]*?from\s*['"]([^'"]+)['"]/g)) specs.add(m[1]);
  for (const m of src.matchAll(/import\s*\(\s*['"]([^'"]+)['"]\s*\)/g)) specs.add(m[1]);
  for (const spec of specs) {
    if (!spec.startsWith(".")) continue;
    if (!resolve(spec, file)) {
      problems++;
      console.log(`  [BROKEN] ${path.relative(ROOT, file)} -> ${spec}`);
    }
  }
}

console.log("=== 5. 面板元素 ID 与 JS 引用一致性 ===");
// 重构面板最容易漏的就是改了 HTML 忘了改 JS（或反之），这里双向兜底
const uiDir = path.join(ROOT, "src/ui");
const htmlIds = new Set([...html.matchAll(/\sid="([^"]+)"/g)].map((m) => m[1]));

// JS 里动态创建的元素 id（el(..., { id: "x" }) 或 id: `pricing-${key}` 这类模板）
const dynamicIds = new Set();
for (const file of fs.readdirSync(uiDir).filter((f) => f.endsWith(".js"))) {
  const src = fs.readFileSync(path.join(uiDir, file), "utf8");
  for (const m of src.matchAll(/id:\s*["'`]([^"'`]+)["'`]/g)) {
    if (m[1].includes("${")) dynamicIds.add(m[1].split("${")[0]);
    else dynamicIds.add(m[1]);
  }
}

for (const file of fs.readdirSync(uiDir).filter((f) => f.endsWith(".js"))) {
  const src = fs.readFileSync(path.join(uiDir, file), "utf8");
  const rel = path.join("src/ui", file);
  for (const m of src.matchAll(/\$\$?\(\s*["']#([a-zA-Z0-9_-]+)["']/g)) {
    const id = m[1];
    if (htmlIds.has(id)) continue;
    if ([...dynamicIds].some((dyn) => id.startsWith(dyn))) continue;
    problems++;
    console.log(`  [MISS] ${rel} 引用了 #${id}，但 panel.html 里没有这个元素`);
  }
}
// 反向：HTML 里声明了却没有任何 JS/CSS 用到的 id 不算错误，只提示，避免噪音
console.log(`  HTML 声明 ${htmlIds.size} 个 id，JS 动态创建 ${dynamicIds.size} 个`);

console.log("=== 6. 图片过滤规则两处实现一致性 ===");
// content script 不能 import ES module，所以 adapter-base.js 里有一份等价实现。
// 这里逐字比对关键词表，防止改了一处忘了另一处导致「采集留下、面板又删」的不一致。
{
  const sharedSrc = fs.readFileSync(path.join(ROOT, "src/shared/image-filter.js"), "utf8");
  const contentSrc = fs.readFileSync(path.join(ROOT, "src/content/adapter-base.js"), "utf8");
  const pick = (src, name) => {
    const m = src.match(new RegExp(`${name}\\s*=\\s*(\\/[\\s\\S]*?\\/[a-z]*)`));
    return m ? m[1].replace(/\s+/g, "") : "";
  };
  const sharedPattern = pick(sharedSrc, "NON_PRODUCT_IMAGE_PATTERN");
  const contentPattern = pick(contentSrc, "NON_PRODUCT_PATTERN");
  if (!sharedPattern || !contentPattern) {
    problems++;
    console.log("  [FAIL] 没找到 NON_PRODUCT_IMAGE_PATTERN / NON_PRODUCT_PATTERN 定义");
  } else if (sharedPattern !== contentPattern) {
    problems++;
    console.log("  [FAIL] 关键词表已不一致，请同步 src/content/adapter-base.js 的 NON_PRODUCT_PATTERN");
    console.log(`         shared : ${sharedPattern.slice(0, 80)}…`);
    console.log(`         content: ${contentPattern.slice(0, 80)}…`);
  } else {
    console.log("  [OK]   关键词表一致");
  }
  // 尺寸阈值也要一致
  const sharedIcon = (sharedSrc.match(/ICON_MAX_SIDE\s*=\s*(\d+)/) || [])[1];
  const contentIcon = (contentSrc.match(/maxSide\s*<\s*(\d+)\)\s*return false;\s*\/\/ 图标/) || [])[1];
  if (sharedIcon && contentIcon && sharedIcon !== contentIcon) {
    problems++;
    console.log(`  [FAIL] 图标尺寸阈值不一致：shared ${sharedIcon} / content ${contentIcon}`);
  } else if (sharedIcon) {
    console.log("  [OK]   图标尺寸阈值一致");
  }
}

console.log("=== 7. 消息路由是否把 message 传给了处理函数 ===");
{
  // 这里的坑真实发生过：case 分支写成 `return testRedraw();`，
  // 而 testRedraw(message = {}) 的兜底分支会去读「已保存的设置」，
  // 于是面板上刚填的值被静默忽略 —— 表现为「输入框是 A、检测结果报 B」。
  // 规则：处理函数声明里第一个参数叫 message 的，路由必须把 message 传下去。
  const swSrc = fs.readFileSync(path.join(ROOT, "src/background/service-worker.js"), "utf8");
  const wantsMessage = new Set();
  for (const m of swSrc.matchAll(/function\s+([A-Za-z_$][\w$]*)\s*\(\s*message\b/g)) wantsMessage.add(m[1]);

  const dropped = [];
  const routeRe = /case\s+MESSAGE_ACTIONS\.(\w+)\s*:\s*(?:\/\/[^\n]*\n\s*)*return\s+([A-Za-z_$][\w$]*)\(\s*\)\s*;/g;
  for (const m of swSrc.matchAll(routeRe)) {
    if (wantsMessage.has(m[2])) dropped.push(`${m[1]} → ${m[2]}()`);
  }
  if (dropped.length) {
    problems++;
    console.log("  [FAIL] 以下路由漏传 message（处理函数需要它，却调用成无参）:");
    for (const item of dropped) console.log(`         ${item}`);
  } else {
    console.log(`  [OK]   ${wantsMessage.size} 个需要 message 的处理函数都正确传参`);
  }
}

console.log("=== 8. 类目树与上传校验回归 ===");
{
  const panelSrc = fs.readFileSync(path.join(ROOT, "src/ui/panel.js"), "utf8");
  const apiSrc = fs.readFileSync(path.join(ROOT, "src/background/ozon-api.js"), "utf8");
  if (/node\.children\.slice\(0,\s*60\)/.test(panelSrc)) {
    problems++;
    console.log("  [FAIL] 类目子节点仍被 60 条截断");
  } else console.log("  [OK]   类目子节点不再截断");
  if (!/validateAttributeValues/.test(apiSrc) || !/属性校验未通过/.test(apiSrc)) {
    problems++;
    console.log("  [FAIL] 上传前属性校验未接入");
  } else console.log("  [OK]   上传前属性校验已接入");
}

console.log("=== 9. 卖家情报与 AI 属性结果链路 ===");
{
  const panelSrc = fs.readFileSync(path.join(ROOT, "src/ui/panel.js"), "utf8");
  const htmlSrc = fs.readFileSync(path.join(ROOT, "src/ui/panel.html"), "utf8");
  const promptSrc = fs.readFileSync(path.join(ROOT, "src/shared/prompts.js"), "utf8");
  const swSrc = fs.readFileSync(path.join(ROOT, "src/background/service-worker.js"), "utf8");
  for (const [label, ok] of [
    ["卖家情报按钮有加载/空结果/错误/成功文案", /加载中：正在查找[\s\S]*没有结果：当前页面[\s\S]*读取失败[\s\S]*读取成功/.test(panelSrc)],
    ["卖家情报结果表存在", /id="intel-table"/.test(htmlSrc) && /renderTable\("#intel-table"/.test(panelSrc)],
    ["卖家情报后台路由存在", /MESSAGE_ACTIONS\.ozonSalesIntel[\s\S]*return salesIntel\(\)/.test(swSrc)],
    ["AI 属性协议包含置信度与 unknown", /confidence[\s\S]*unknown/.test(promptSrc)],
  ]) {
    if (!ok) { problems++; console.log(`  [FAIL] ${label}`); }
    else console.log(`  [OK]   ${label}`);
  }
}

console.log("=== 10. 稳定型号链路 ===");
{
  const modelSrc = fs.readFileSync(path.join(ROOT, "src/shared/product-model.js"), "utf8");
  const apiSrc = fs.readFileSync(path.join(ROOT, "src/background/ozon-api.js"), "utf8");
  const panelSrc = fs.readFileSync(path.join(ROOT, "src/ui/panel.js"), "utf8");
  const exporterSrc = fs.readFileSync(path.join(ROOT, "src/ui/exporter.js"), "utf8");
  for (const [label, ok] of [
    ["共享稳定型号 helper 已定义", /export function buildStableModel/.test(modelSrc)],
    ["上传 payload 使用稳定型号", /offer_id:\s*model[\s\S]*model,/.test(apiSrc)],
    ["库存/价格更新复用稳定型号", /buildStableModel\(state\.draft/.test(panelSrc)],
    ["上架表导出复用稳定型号", /buildStableModel\(draft,\s*sku/.test(exporterSrc)],
  ]) {
    if (!ok) { problems++; console.log(`  [FAIL] ${label}`); }
    else console.log(`  [OK]   ${label}`);
  }
}

fs.rmSync(tmpDir, { recursive: true, force: true });
console.log(problems ? `\n发现 ${problems} 个问题` : "\n全部通过");
process.exit(problems ? 1 : 0);
